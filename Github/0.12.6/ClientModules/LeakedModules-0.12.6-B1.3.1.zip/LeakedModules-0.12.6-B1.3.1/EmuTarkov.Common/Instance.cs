﻿using UnityEngine;

namespace EmuTarkov.Common
{
	public class Instance : MonoBehaviour
	{
		private void Start()
		{
			Debug.LogError("EmuTarkov.Common: Loaded");
		}
	}
}
