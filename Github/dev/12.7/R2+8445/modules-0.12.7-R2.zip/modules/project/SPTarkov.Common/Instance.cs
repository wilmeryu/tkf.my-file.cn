﻿using UnityEngine;

namespace SPTarkov.Common
{
	public class Instance : MonoBehaviour
	{
		private void Start()
		{
			Debug.LogError("SPTarkov.Common: Loaded");
		}
	}
}
