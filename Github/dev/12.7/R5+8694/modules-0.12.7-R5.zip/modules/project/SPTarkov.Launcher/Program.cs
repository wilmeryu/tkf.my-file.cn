﻿using System;
using System.IO;
using System.Reflection;
using System.Windows.Forms;
using SPTarkov.Launcher.Controllers;

namespace SPTarkov.Launcher
{
	public static class Program
	{
		[STAThread]
		private static void Main()
		{
            // set rendering
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // enable logs
            Application.ThreadException += (sender, args) => HandleException(args.Exception);
            AppDomain.CurrentDomain.UnhandledException += CurrentDomainOnUnhandledException;

            // load assenblies from EFT's managed directory
            AppDomain.CurrentDomain.AssemblyResolve += new ResolveEventHandler(AssemblyResolveEvent);

            Application.Run(new Main());
        }

        private static void CurrentDomainOnUnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            if (e.ExceptionObject is Exception exception)
            {
                HandleException(exception);
            }
            else
            {
                HandleException(new Exception("Unknown Exception!"));
            }
        }

        private static void HandleException(Exception exception)
        {
            var text = $"Exception Message:{exception.Message}{Environment.NewLine}StackTrace:{exception.StackTrace}";
			LogManager.Instance.Error(text);
            MessageBox.Show(text, "Exception", MessageBoxButtons.OK,MessageBoxIcon.Error);
        }

        private static Assembly AssemblyResolveEvent(object sender, ResolveEventArgs args)
        {
            string assembly = new AssemblyName(args.Name).Name;
            string filename = Path.Combine(Environment.CurrentDirectory, $"EscapeFromTarkov_Data/Managed/{assembly}.dll");

            // resources are embedded inside assembly
            if (filename.Contains("resources"))
            {
                return null;
            }

            return Assembly.LoadFrom(filename);
        }
    }
}
