﻿using System.Collections.Generic;

namespace EmuTarkov.RuntimeBundles.Utils.Bundles
{
	public class Manifest
	{
		public string key;
		public List<string> dependencyKeys;
	}
}
