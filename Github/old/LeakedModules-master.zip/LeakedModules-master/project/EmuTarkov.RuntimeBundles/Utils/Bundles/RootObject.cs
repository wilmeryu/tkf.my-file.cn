﻿using System.Collections.Generic;

namespace EmuTarkov.RuntimeBundles.Utils.Bundles
{
	public class RootObject
	{
		public List<Manifest> manifest;
	}
}
