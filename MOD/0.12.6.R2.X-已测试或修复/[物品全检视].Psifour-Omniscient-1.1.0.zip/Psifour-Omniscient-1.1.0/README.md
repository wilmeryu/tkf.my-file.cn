# AdvancedBotsLoadouts
## by Psifour

Makes all items identified without editing db/items.
This reduces the risk of mod conflicts if another mod also changes any items in the DB.