# MurderBots
## by Psifour

Forces all bot difficulties to impossible regardless of client preference.