this mod adds in some hidden items not yet fully implemented.

thanks to Baliston for finding these items

complete list of items "ready" to use (note that these are not yet implemented by the original game maker, so results may vary)
opscore_gasmask
opscore_picatinny_rail_adapter
opscore_single_clamp_rail_adapter
silencer_kac_qdc_65x35
silencer_silencerco_sparrow_22lr
item_spec_minedetector
developer_safecontainer
developer_container_junkbox
item_equipment_backpack_beltbag
item_dog_tags
item_dogtag_t2
