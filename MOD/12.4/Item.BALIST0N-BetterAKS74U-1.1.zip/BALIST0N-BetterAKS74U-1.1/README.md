## Better AKS-74U
This mod aim to extend the number of compatible parts with all 3 AKS-74U

### New weapons parts compatibles:
* [Polymer stock for AK-74M (6P34 Sb.15)](https://escapefromtarkov.gamepedia.com/Polymer_stock_for_AK-74M_(6P34_Sb.15) "Polymer stock for AK-74M (6P34 Sb.15)")
* [CAA AKTS AK-74 Buffer Tube for AK and compatable (foldable)](https://escapefromtarkov.gamepedia.com/CAA_AKTS_AK-74_Buffer_Tube_for_AK_and_compatable_(foldable) "CAA AKTS AK-74 Buffer Tube for AK and compatable (foldable)")  
* [Izhmash RPK-16 buffer tube](https://escapefromtarkov.gamepedia.com/Izhmash_RPK-16_buffer_tube "Izhmash RPK-16 buffer tube")
* [RPK-16 muzzlebrake & compensator](https://escapefromtarkov.gamepedia.com/Izhmash_5.45x39_RPK-16_muzzlebrake_%26_compensator "RPK-16 muzzlebrake & compensator")


### Compatibillity

make sure the  mod load after some mod who can override this one :
for example make this mod load after "AllItemsExamined" mod

to edit load order open "/user/server.config.json" , under category "mod:list[ ]"

### Pictures
![a](https://i.ibb.co/chBXdS0/2020-02-29-11-48-0.png)
![enaaa](https://i.ibb.co/XVk1yWV/2020-02-29-11-52-0.png)
![c](https://i.ibb.co/BBbLry9/2020-02-29-11-55-0.png)
![d](https://i.ibb.co/GdmT9yD/2020-02-29-11-59-0.png)
![e](https://i.ibb.co/dP1bRBH/2020-02-29-12-00-0.png)
![ff](https://i.ibb.co/RpRTML7/2020-02-29-12-03-0.png)


### Suggestions
i'm open to all suggestions to improve the mod, message me on discord @BALIST0N


## Changelog :

V1.1 : 
- changed firerate of weapons to 710-720
- removed ak100 PT lock compatibillity