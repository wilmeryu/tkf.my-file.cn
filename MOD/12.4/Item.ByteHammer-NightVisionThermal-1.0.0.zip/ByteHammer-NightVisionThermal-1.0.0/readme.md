This mod is an upgraded version of AssAssIn's CleanThermal mod. It enhances the thermals to also function as night vision goggles, significantly increasing visibility by allowing you to see the textures you're looking at instead of just the heat content. You can also see light and shadow.

You still cannot, however, look through most optics with these thermals. Get used to ironsights.