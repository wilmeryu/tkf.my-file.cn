Add the Frumorn-Auto17 folder in server/user/mods

Add these lines to your server.config.json in user folder

{
	"name": "Auto17",
	"author": "Frumorn",
	"version": "1.0.0",
	"enabled": true
}