Add the Frumorn-AutoM1A folder in server/user/mods

Add these lines to your server.config.json in user folder

{
	"name": "AutoM1A",
	"author": "Frumorn",
	"version": "1.0.0",
	"enabled": true
}