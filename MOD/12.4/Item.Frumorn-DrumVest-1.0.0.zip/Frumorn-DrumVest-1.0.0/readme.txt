Add the Frumorn-DrumVest folder in user/mods

Add these lines to your server.config.json in user folder


{
	"name": "DrumVest",
	"author": "Frumorn",
	"version": "1.0.0",
	"enabled": true
}

Make sure the mod before this ends with
},

So it looks like this


},
{
	"name": "DrumVest",
	"author": "Frumorn",
	"version": "1.0.0",
	"enabled": true
}