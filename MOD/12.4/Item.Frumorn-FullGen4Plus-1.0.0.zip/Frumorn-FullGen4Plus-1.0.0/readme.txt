Add the Frumorn-FullGen4Plus folder in server/user/mods

Add these lines to your server.config.json in user folder

{
	"name": "FullGen4Plus",
	"author": "Frumorn",
	"version": "1.0.0",
	"enabled": true
}