This mod enlarges the stash of all editions of the game by 100 tiles vertically.

Add this line in your user/server.config.json

			{
				"name": "GiantStash",
				"author": "Grasyl",
				"version": "1.0.0"
			}

Don't forget to add a , behind the } of the mods entry above.