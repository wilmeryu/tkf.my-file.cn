This mod adds a converted M4A1 receiver that replaces the full-auto function
for a 3 round burst, effectively making this an M4 receiver.

Add this line in your server.config.json

			{
				"name": "M4",
				"author": "MacrossMX",
				"version": "1.0.0"
			}

If using AssAssIn's Olympus mod, make sure this mod in on the top order to ensure the 
herc magazine works with the stock gun.