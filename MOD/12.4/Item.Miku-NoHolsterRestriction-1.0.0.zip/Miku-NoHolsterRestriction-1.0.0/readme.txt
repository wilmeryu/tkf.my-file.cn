add this folder to server/user/mods
to add this to your mods, add the following lines to server.config.json

TAKE NOTE: weapon in scabbard will always be saved, like melees in the normal game

{
	"name": "NoHolsterRestriction",
	"author": "Miku",
	"version": "1.0.2",
	"enabled": true
}