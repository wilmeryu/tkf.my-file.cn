# Lockbox
## by Psifour

Adds five additional secure containers.
The Lockboxes use the same naming convention as the retail secure containers.

These containers add more variation in size and layout which enables more control over what size of container one uses. 
As a general rule a secure container of the same tier will be larger or less compartmentalized than the equivalent Lockbox.