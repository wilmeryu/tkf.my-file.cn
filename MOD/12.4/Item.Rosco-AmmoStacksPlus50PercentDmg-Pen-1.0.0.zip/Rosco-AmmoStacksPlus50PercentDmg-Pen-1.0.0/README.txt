﻿[private] - ServerMod.

Ammo Stacks ~400 - Damage and Armor Penetration increased 50%, all ammo - v1.0 ***************************************************************************************************************************************
İnstall Tutorial ;

1) drag the Rosco-AmmoStacksPlus50%Dmg-Pen folder into server/user/mods  

2) Then change "rebuildCache": false ---> to true in user/configs/server.json and save OR just delete contents of your /server/user/cache folder. (rebuild cache.)  

3) Start Game.

******Have fun!******

   Built for 12.4-R2 server only.

Credit:
Yasin-RealAmmoStacksDamage-2.0.0 was used as the base for this mod, thank Yasin for building the complete framework for this mod