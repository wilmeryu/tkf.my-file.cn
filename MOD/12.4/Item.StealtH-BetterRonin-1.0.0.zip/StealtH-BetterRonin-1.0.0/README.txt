This mod makes the Ronin helmet actually useful.

Features:
Makes the Ronin armour class 6
Removes hearing penalty
Removes mouse movement penalty
Removes speed penalty
+10 Ergonomics when wearing the Ronin
Changes the armour material to "Polymer" (the same stuff Killas armour is made out of)
Allows you to use headphones with the Ronin


Add the StealtH-BetterRonin folder to /server/user/mods

Then

Just add this to your server config located in your /server/user folder and rechache :)



			{
				"name": "BetterRonin",
				"author": "StealtH",
				"version": "1.0.0",
				"enabled": true
			}




ENJOY