This mod provides a super high damage bullet for Remington R11RASS and M700. 

这个mod为雷明顿R11RASS和M700提供了一种超高伤害的弹药。

