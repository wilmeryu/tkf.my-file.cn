# AccountCreation
## by Psifour

Enables account creation on 0.12.3-R1. 
This functionality will be mainline with the release of 0.12.4-R1.