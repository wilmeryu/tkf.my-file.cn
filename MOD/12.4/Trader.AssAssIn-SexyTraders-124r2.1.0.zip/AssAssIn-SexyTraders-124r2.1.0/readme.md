Replaces the traders images with "sexy" (SFW) versions.

You need to manually clear your game cache for any changes to take effect:
    To clean game cache, hold Windows key and press "R" to open the run box.
    Type in "%temp%" and press enter. 
    Delete the "Battlestate Games" folder.
    Then start server and client.