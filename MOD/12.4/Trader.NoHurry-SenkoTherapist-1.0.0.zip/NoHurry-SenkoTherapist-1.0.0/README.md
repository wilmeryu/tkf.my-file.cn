## Info
The mod does the following:
- change therapist trader image to senko
- change therapist quest banner to senko
