this mod adds leg protection to level 4-5-6 armors


expections:
Redut-T5
Slick
Zhuk-6a


