This mod makes your t-7 thermal vision goggles fullscreen and noise-free (clean).
Ensure this mod is listed after AllItemsExamined mod in /server/user/configs/mods.json