If using 'AllItemsExamined' then you may wanna put this AFTER it. 
Since there are some known issues if it's not.