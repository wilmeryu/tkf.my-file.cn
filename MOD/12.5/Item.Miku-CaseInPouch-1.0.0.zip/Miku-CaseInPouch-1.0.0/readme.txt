add this folder to server/user/mods
to add this to your mods, add the following lines to server.config.json

{
	"name": "CaseInPouch",
	"author": "Miku",
	"version": "1.0.0",
	"enabled": true
}