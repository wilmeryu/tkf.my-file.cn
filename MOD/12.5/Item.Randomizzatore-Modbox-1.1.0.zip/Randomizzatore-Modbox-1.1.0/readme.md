## Modbox

This mod adds a simple container named Modifications case that allows only gun mods inside, magazines exluded.
Its internal size is 14x14, just like a junkbox.
Its price is 1000000 roubles on the flea market, or level 2 Mechanic for 14 bitcoins.

## Versions
### 1.1.0
* Fixed filters to include tactical lasers
* Barter modified from **7** bitcoins to **14** bitcoins
* Flea market price modified from **1 000 000** roubles to **2 000 000** roubles

## Credits

Randomizzatore