This is a small mod that allows the P-MAGD to work with the AS VAL. For those of you who hate how fast the VAL fires and how small the mags are :)

Add the StealtH-PmagVal folder to /server/user/mods

Then

Just add this to your server config located in your /server/user folder and rechache :)



			{
				"name": "PmagVal",
				"author": "StealtH",
				"version": "1.0.0",
				"enabled": true
			}




ENJOY