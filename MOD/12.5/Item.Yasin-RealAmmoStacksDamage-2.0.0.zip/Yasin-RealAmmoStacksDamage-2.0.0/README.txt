[private] - ServerMod.

Real Ammo Stacks + Damage and Armor Damage Settings Increased! new version: 2.0.0

***************************************************************************************************************************************
İnstall Tutorial ;

1-) Yasin-RealAmmoStacksDamage-2.0.0 drag folder into server/user/mods

2-) Then change to "rebuildCache": false ---> true in user/configs/server.json and save. (rebuild cache.)

3-) Start Game.

******Have fun!******

Real Ammo Stacks + Damage and Armor Damage Settings Increased! (Attention: Only applies to these shells!)

Ammo Names ;

---> All bullets are supported! <---
_________________________________________________

Damage of all shells has been configured between 400-435 for more realistic killing and death, and Armor Damage has been increased to x1.
For example: Original Armor Damage: 15 ve Mod state: 30

---> Attention: There are limited shells in the previous version, but in this version all shells have been edited and supported, it works! <---








