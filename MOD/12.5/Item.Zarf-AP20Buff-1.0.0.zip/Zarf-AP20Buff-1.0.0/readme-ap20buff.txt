This mod increases the penetration of the AP-20 12 gauge ammunition

This is compatible with Soratas increased bullet stack mod

extract the folder "Zarf-AP20Buff" to your server/user/mods folder

then add the following lines to server.config.json



			{
				"name": "AP20Buff",
				"author": "Zarf",
				"version": "1.0.0",
				"enabled": true
			}


