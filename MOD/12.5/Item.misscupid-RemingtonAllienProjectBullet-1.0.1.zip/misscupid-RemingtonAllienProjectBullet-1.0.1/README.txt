This mod provides two different types of the bullet for Remington R11RASS and M700. 
One high damage and the other is explosive one.

这个mod为雷明顿R11RASS和M700提供了两种种超高伤害的弹药。一种高穿甲，高肉伤，高护甲伤。 还有一个高爆子弹。

