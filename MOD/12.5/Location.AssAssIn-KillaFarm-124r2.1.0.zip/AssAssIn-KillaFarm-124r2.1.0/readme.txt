replaces all standard scavs with Killa (the boss from Interchange)

add this folder to server/user/mods