Replaces all standard scavs with Raiders on all maps (the guys from Labs)

add this folder to server/user/mods