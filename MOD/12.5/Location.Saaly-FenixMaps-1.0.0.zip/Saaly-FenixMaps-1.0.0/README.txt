In this mod, the following adjustments have been made:
1. Optimizing scav waves times
2. Optimization of waves in number, for better performance.
3. Variable game difficulty (copy and paste the bots file, inside src/classes/)
4. New places of bot appearance.
5. Variable raider groups in number and locations.
6. Fixed issues where bots remove bosses in spawn locations.

This mod is applicable to versions 0.12.3, 0.12.4 and 0.12.5