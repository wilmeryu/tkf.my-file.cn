# WARNING
**This mod is absolutely not compatible with any other mods that change the following file : globals.json.**

**This means you will most likely need to merge the changes made to globals.json into one of the modified file and remove it from the desired mod**