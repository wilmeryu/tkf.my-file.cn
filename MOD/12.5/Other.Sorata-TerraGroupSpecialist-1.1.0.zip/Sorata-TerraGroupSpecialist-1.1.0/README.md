# Welcome to the TerraGroupSpecialist mod readme.

## What do the mod ?
Wlel, for being simple, it's storyline quest mod. It adds a trader and a story with him. This is a questline made for endgame users, it can only be available after the lvl50 and after having done the Collection quest from Fence. It adds several "unique" items only useable by the mod and made by the mod. HOpefully the mod is still isn't as complete as the complete tarkov questline, but it's a beginning and i mainly want feedbacks about it to know your feeling about the quests.

## I don't find the encrypted device for the first quest
That's normal buddy ! Who said that you will get it at the first try ? Hehe.

## What now ?
Well, it's the beginning of this huge mod, a way more has to come, as well as different quests route depending on if you fail a quest or not. What will you miss in the future ? Well, it's going to be SOON for sure. More important choices will have to be made after this, so be mentally prepared ;) (The actual last quest is for this ahahahah)

## Known bugs :
Actually there's 2 jammers missing to loot. You will need to do a second run in order to get the both missing jammers.
The quest: Terragroup Weapon Prototype is actually wrong in requirement, you need to assemble the weapon in order to give handover it

## Special thanks
Well, to be honest i want to really thanks Kiva, who fucking made an amazing english translation for the story, 