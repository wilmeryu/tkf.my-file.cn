O.F.A.P.
online fleamarket average pricing

This mod increases the prices of all the items needed for the hideout.
While they are not dynamic the way official prices are, they relect average sell prices as of 2020/02/25.
These items also sell for more, to emulate you selling them on the flea to other players, although you still sell them to the regular traders

As always, make sure this is listed afer AllItemsExamined mod in your mod list