New trader with the following features:
· Unique, non-sellable items
· Objects with modifications to their characteristics
· Progression level to unlock better items
· Elsie only trades in valuables.

This mod must work in versions 0.12.3, 0.12.4 and 0.12.5