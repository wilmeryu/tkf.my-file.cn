"use strict";

function cache() {
    if (!serverConfig.rebuildCache) {
        return;
    }

    logger.logInfo("Caching: items.json");

    let base = {"err": 0, "errmsg": null, "data": {}};
    let inputFiles = db.items;

    for (let file in inputFiles) {
        let filePath = inputFiles[file];
        let fileData = json.parse(json.read(filePath));

        fileData._props.ExaminedByDefault = true;
        fileData._props.Weight = 0;
        //fileData._props.Width = 1;
        //fileData._props.height = 1;
        //fileData._props.CreditsPrice = Math.round(Math.random()*10);
        
        base.data[fileData._id] = fileData;
    }

    json.write("user/cache/items.json", base);
}

server.addStartCallback("cacheItems", cache);