"use strict";



function cache() {
    if (!serverConfig.rebuildCache) {
        return;
    }

    logger.logInfo("items.json");

    let base = {"err": 0, "errmsg": null, "data": {}};
    let inputFiles = db.items;
    const config = configuration_c.configuration.getConfig();
    for (let file in inputFiles) {
        let filePath = inputFiles[file];
        let fileData = json.parse(json.read(filePath));

        if(config.ExaminedItems === true){fileData._props.ExaminedByDefault = true;}
        if(config.ForceWeight === true && (fileData._id !== "55d7217a4bdc2d86028b456d" || fileData._id !== "5af99e9186f7747c447120b8" || fileData._id !== "557ffd194bdc2d28148b457f")){fileData._props.Weight = config.ForceWeightNumber;}
        if(config.MoreStack === true){
            if(fileData._name.includes("patron")){
                fileData._props.StackMaxSize = config.MaxStackAmount;
            }
        }
        base.data[fileData._id] = fileData;
    }

    json.write("user/cache/items.json", base);
}

server.addStartCallback("cacheItems", cache);