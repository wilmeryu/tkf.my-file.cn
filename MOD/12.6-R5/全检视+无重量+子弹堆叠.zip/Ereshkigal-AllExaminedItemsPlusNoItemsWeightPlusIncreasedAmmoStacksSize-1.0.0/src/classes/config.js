"use strict";

class Configuration {
    constructor() {
        /*
            #####################################
            #         配    置    文    件       #
            #####################################
        */
        this.variables = {
            "ExaminedItems": true,      // true为开启全检视物品 false为关闭 
            "ForceWeight": true,        // true为开启物品重量自定义 - false为关闭
            "ForceWeightNumber": 0,    // 当ForceWeight = true 的时候才生效，如果你想物品全部重量为0默认即可。
            "MoreStack": true,          // true为开启子弹堆叠 false为关闭 
            "MaxStackAmount": 400       // 指定子弹堆叠数量
        };
         /*
            #############################################
            #        DO NOT TOUCH ANYTHING BELOW        #
            #############################################
        */
    }

    getConfig() {
        return this.variables
    }

}

module.exports.configuration = new Configuration();
