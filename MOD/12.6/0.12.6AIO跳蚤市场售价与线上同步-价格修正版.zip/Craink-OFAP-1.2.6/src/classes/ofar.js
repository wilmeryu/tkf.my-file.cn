"use strict";

var fs = require("fs");
var path = require("path");


let cachePath = path.join(__dirname, "..", "..", "..", "..", "cache");
let itemsCachePath = path.join(cachePath, "items.json");
let templatesCachePath = path.join(cachePath, "templates.json");
let assorts = [
    "5a7c2eca46aef81a7ca2145d",
    "5ac3b934156ae10c4430e83c",
    "5c0647fdd443bc2504c2d371",
    "54cb50c76803fa8b248b4571",
    "54cb57776803fa99248b456e",
    "579dc571d53a0658a154fbec",
    "5935c25fb3acc3127c3d8cd9",
    "58330581ace78e27b8b10cee",
    "ragfair"
]

let avgPrices;
let assortParentItemsHash;
function setPrice() {
    if (!fs.existsSync(itemsCachePath)) {
        return;
    }
    let config = json.parse(json.read(path.join(__dirname, "..", "..", "config.json")));
    let lastCacheTime = fs.statSync(itemsCachePath).ctimeMs;

    if (config.lastCacheTime == lastCacheTime) {
        return;
    }

    avgPrices = json.parse(json.read(path.join(__dirname, "..", "..", "avgPrices.json")));

    let templatesHash = {}
    templates.data.Items.forEach(i => templatesHash[i.Id] = i);

    let assortHash = {}
    
    for (let assortId of assorts) {
        let assortCache;
        try {
            assortCache = json.parse(json.read(path.join(cachePath, "assort_" + assortId + ".json")));
        } catch (e) {
            continue;
        }


        let assortItemsHash = {}
        assortCache.data.items.forEach(i => assortItemsHash[i._id] = i);

        assortParentItemsHash = {}
        assortCache.data.items.forEach(function(i) {
            if (i.parentId === "hideout") {
                return;
            }
            if (!assortParentItemsHash.hasOwnProperty(i.parentId)) {
                assortParentItemsHash[i.parentId] = [];
            }
            assortParentItemsHash[i.parentId].push(i);
        });

        let barterSchemes = assortCache.data.barter_scheme;
        for (let assortItemId in barterSchemes) {
            let itemId = assortItemsHash[assortItemId]._tpl;

            if (!avgPrices.hasOwnProperty(itemId)) {
                continue;
            }

            for (let scheme of barterSchemes[assortItemId]) {
                for (let schemeInfo of scheme) {
                    schemeInfo.count = getCountByExchangeItemId(assortItemsHash[assortItemId], schemeInfo);
                }
            }
        }
        assortCache.crc = utility.adlerGen(json.stringify(assortCache.data));
        fs.writeFileSync(path.join(cachePath, "assort_" + assortId + ".json"), JSON.stringify(assortCache, null, "\t"));
    }


    for (let itemId in items.data) {
        if (config.allItemsExamined) {
            items.data[itemId]._props.ExaminedByDefault = true;
        }
        if (avgPrices.hasOwnProperty(itemId)) {
            items.data[itemId]._props.CreditsPrice = avgPrices[itemId];

            if (templatesHash.hasOwnProperty(itemId)) {
                templatesHash[itemId].Price = avgPrices[itemId];
            }
        }
    }


    items.crc = utility.adlerGen(json.stringify(items.data));
    templates.crc = utility.adlerGen(json.stringify(templates.data));

    fs.writeFileSync(itemsCachePath, JSON.stringify(items, null, "\t"));
    fs.writeFileSync(templatesCachePath, JSON.stringify(templates, null, "\t"));

    config.lastCacheTime = fs.statSync(itemsCachePath).ctimeMs;
    fs.writeFileSync(path.join(__dirname, "..", "..", "config.json"), JSON.stringify(config, null, "\t"));

    global.tplLookup = itm_hf.tplLookup();
}



function getCountByExchangeItemId(assortItem, schemeInfo) {
    function calculatePrice(assortItem) {
        return avgPrices[assortItem._tpl] + calculateAssortItemModsPrice(assortItem._id);
    }

    let assortItemId = assortItem._id;
    let currentCount = 0;
    let exchangeItemId = schemeInfo._tpl;
    let count = schemeInfo.count;

    if (exchangeItemId !== "5449016a4bdc2d6f028b456f") {
        if (exchangeItemId === "5696686a4bdc2da3298b456a") {
            currentCount = calculatePrice(assortItem) / 103;
        } else if (exchangeItemId === "569668774bdc2da2298b4568") {
            currentCount = calculatePrice(assortItem) / 110;
        } else {
            currentCount = count;
        }

        currentCount = Math.round(currentCount);
        if (currentCount < 1) {
            currentCount = 1;
        }
        count = currentCount;
    } else {
        count = calculatePrice(assortItem);
    }
    return count;
}

function calculateAssortItemModsPrice(assortItemId) {
    let price = 0;
    if(assortParentItemsHash.hasOwnProperty(assortItemId)) {
        for (let modItem of assortParentItemsHash[assortItemId]) {
            if(avgPrices.hasOwnProperty(modItem._tpl)) {
                price += avgPrices[modItem._tpl];
            } else{
                price += items.data[modItem._tpl]._props.CreditsPrice;
            }
            
            price += calculateAssortItemModsPrice(modItem._id)
        }
    }
    
    return price;
}

function writeFileRecursive(path, buffer) {
    let lastPath = path.substring(0, path.lastIndexOf("/"));
    fs.mkdirSync(lastPath, { recursive: true });
    fs.writeFileSync(path, buffer, "utf-8");
}



module.exports.setPrice = setPrice;
