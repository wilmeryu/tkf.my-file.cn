"use strict";

function setPrice(sessionID, req, resp, body, output) {
    if(req.url.indexOf("/client/menu/locale") == -1) {
        return;
    }
    ofar_f.setPrice();
}

server.addReceiveCallback("/client/menu/locale/", setPrice);
