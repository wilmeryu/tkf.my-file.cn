Add the Frumorn-BossPockets folder in user/mods

Add these lines to your server.config.json in user folder


{
	"name": "BossPockets",
	"author": "Frumorn",
	"version": "1.0.0",
	"enabled": true
}

Make sure the mod before this ends with
},

So it looks like this


},
{
	"name": "BossPockets",
	"author": "Frumorn",
	"version": "1.0.0",
	"enabled": true
}