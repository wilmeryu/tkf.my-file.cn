Realistic Ammo Damage - By Ivandrov

This mod increases the damage of all ammo types in the game.

To install:
1. Drag the Ivandrov-RealisticCartridgeDamage-1.0.0 folder into user/mods/ directory
2. Recache server.
3. Play!