# Suicide Kit 1.0.0
### Description
This mod adds **five SUICIDE grenades**, **one SUICIDE injector**, **one SUICIDE pill** and **one SUICIDE balm** to suicide with style in case of need, like forgetting or not finding painkillers, or wanting to forever escape from Tarkov taking with you whoever is nearby.

They can be bought from **Therapist LL1** or from the **Flea Market**!

### Content
* **Old F-1 Hand grenade**
* **Slack M67 Hand grenade**
* **Weird RGD-5 hand grenade**
* **Experimental VOG-17 Khattabka grenade**
* **Engineered VOG-25 Khattabka grenade**
* **Unknown injector**
* **Unknown jar of pills**
* **Dank Memz balm**

![Picture of the new items added](info.png)

### Warning
This mod modifies the content of `db/global.json` because it adds new stimulator buffs to the game and may override other mods' `global.json`.

### Credits
**Randomizzatore**
