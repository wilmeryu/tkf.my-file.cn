#LabScav

This is a simple mod that allows you to play on Labs as a Scav. All extracts are random, just like your PMC runs. Loot is untouched by this mod.

FAQ
	*Q: Why does it not show extracts? | A: I don't want it to, that is the point.
	*Q: Will raiders kill me? | A: Yes they will murder your soul.
	*Q: Will all my loot leave with me like normal PMC runs? | A: Yes, you will get your precious LEDX
	*Q: Why aren't raiders spawning? | A: Raiders are triggered by the same events like your PMC runs. Check possible conflicting mods.
	
Known-bugs
	*Insta death is possible, but extremely rare - I tested about 40 runs and only happened once
	*Spawning with no gear - I don't think I will investigate this as it actually adds a fun factor, this only happened 2 times to me

In the works
	*Stronger waves
	*Bosses from other maps (i.e. Killa)
	*Raiders spawning with keycards or SCAV spawning with guaranteed 1 keycard

~you can pin me @elitecheez99 in discord with questions regarding the mod~