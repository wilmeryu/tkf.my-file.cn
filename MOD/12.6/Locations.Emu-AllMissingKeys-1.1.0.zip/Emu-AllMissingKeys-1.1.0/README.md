# Emu-AllMissingKeys-1.0.0

**This mod add every official key spawn in the game.**

**A very big thnks to OquiZ#5107 wich helped me by giving me a list of each missing keys of each map.**