## IMPORTANT
- requires dev-r23.2 and above
- requires profile wipe

## Setup
- set the edition in ```user/profiles/list.json``` of your desired profile to ```easy```

## Info
The mod does the following:
- max level
- max money
- max skills
- max masteries
- max hideout areas
- all cloths
- ragfair unlocked
