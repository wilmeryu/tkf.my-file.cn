Health Rebalance - Ivandrov

This mod changes the previous health values of PMC bots, raiders, bosses and followers to match the health values of SCAVs and players.

To install:
1. Drag Ivandrov-HealthRebalance-1.0.0 folder into user/mods folder.
2. Recache server.
3. Play!