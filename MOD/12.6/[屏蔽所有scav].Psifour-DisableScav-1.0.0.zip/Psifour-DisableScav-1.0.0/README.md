# DisableScav
## by Psifour

Disables using scavs on any map. 
This forces the player to use their PMC for all raids.