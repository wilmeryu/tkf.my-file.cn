"use strict";

function load() {
    hideout_f.initialize();
}

server.addStartCallback("loadHideout", load);