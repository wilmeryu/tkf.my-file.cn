﻿/// <reference path="/files/js/jquery.min.js" />
/// <reference path="/files/js/jquery.ui.min.js" />

$(document).ready(function () {
    $.getScript('/process.aspx?c=js_plugin', function () { });
});


function rGet(cqstr, name) {
    if (cqstr == '') cqstr = location.search;
    name += '=';
    var value = cqstr.replace('?' + name, '&' + name);
    name = '&' + name;
    if (value.indexOf(name) > -1) {
        value = value.substring(value.indexOf(name) + name.length);
        if (value.indexOf('&') > -1) value = value.substring(0, value.indexOf('&'));
        if (value.indexOf('#') > -1) value = value.substring(0, value.indexOf('#'));
    } else value = '';
    return value;
}

String.prototype.replaceAll = function (s1, s2) {
    return this.replace(new RegExp(s1, "gm"), s2);
}

var curl = top.location.toString();
if (curl.indexOf("&rn=") > 0) curl = curl.substring(0, curl.indexOf("&rn="));
var protocol = curl.substring(0, curl.indexOf('://'));
var cAction = rGet(curl, "c");

function getUnixTime(time) {
    var yt = new Date(time * 1000);
    var nt = yt.getFullYear() + '-' + (yt.getMonth() + 1) + '-' + yt.getDate() + ' ' + yt.getHours() + ':' + yt.getMinutes() + ':' + yt.getSeconds();
    return nt;
}

function ajaxLoading(str) {
    if (str == undefined) str = 'Loading...';
    return '<p style="text-align:center;line-height:30px;padding-top:25px;" id="loadingMsg">' + str + '<br /><img src="/files/images/loading.gif" alt="Loading..."/></p>';
}

function confirmMsg(cTitle, msg, callback) {
    $("#processing").html('<p style="text-align:center;line-height:25px;padding-top:15px;">' + msg + '</p>');
    $("#processing").dialog({ title: cTitle, autoOpen: false, resizable: false, width: 390, height: 200, modal: true, buttons: { "确定": function () { $(this).dialog("destroy"); callback.call(); }, "取消": function () { $(this).dialog("destroy"); } } }).dialog("open");
}

function processing(str, dwidth, dheight) {
    $("#processing").html(ajaxLoading(str));
    if (dwidth == undefined) {
        dwidth = 328;
        dheight = 168;
    }
    $("#processing").dialog({ title: "　 ", autoOpen: false, resizable: false, width: dwidth, height: dheight, modal: true }).dialog("open");
}

function showResults(str, delay, cmd) {
    $("#processing p").html(str);
    switch (cmd) {
        case 'close':
            cmd = '$("#processing").dialog("close");';
            break;
        case 'reload':
            cmd = 'top.location.reload();';
            break;
    }
    if (delay > 0) setTimeout(cmd, delay);
}

function htmlEncode(html) {
    var temp = document.createElement("div");
    (temp.textContent != null) ? (temp.textContent = html) : (temp.innerText = html);
    var output = temp.innerHTML;
    temp = null;
    if (output == undefined) output = '';
    return output;
}

function htmlDecode(text) {
    var temp = document.createElement("div");
    temp.innerHTML = text;
    var output = temp.innerText || temp.textContent;
    temp = null;
    if (output == undefined) output = '';
    output = output.replaceAll('；', ';');
    return output;
}

function unJsonConvertString(str) {
    str = str.replaceAll('；', ';');
    str = str.replaceAll('＄', '$');
    str = str.replaceAll('％', '%');
    str = str.replaceAll('<br />', '\r\n');
    return str;
}

function setTitle(title) {
    document.title = title;
    if (title.indexOf(' -') > 0) title = title.substring(0, title.indexOf(' -'));
    if ($(".subtitle")) $(".subtitle:first").html(title);
}

function dialogIsOpen(obj) {
    var isOpen = false;
    if ($(obj).is(":ui-dialog")) {
        isOpen = $(obj).dialog("isOpen");
    }
    return isOpen;
}

function setCurrentButton(obj) {
    $(obj).css("font-weight", "bold").button({ icons: { primary: "ui-icon-circle-triangle-e"} });
}

function setCurrentMenu(obj, level) {
    leftMenu.find('ul li.menu_active').removeClass('menu_active');
    if (obj != '') {
        leftMenu.find(obj).addClass("link_active");
        if (level == 0) $(obj).parent().addClass('menu_active');
        else if (level == 1) $(obj).parent().parent().parent().addClass('menu_active');
        else if (level == 2) $(obj).parent().parent().parent().parent().parent().addClass('menu_active');
    }
}


function getRandomString(len) {
    len = len || 10;
    var $chars = 'ABCDEFGHJKMNPQRSTWXYZabcdefhijkmnprstwxyz2345678';
    var maxPos = $chars.length;
    var str = '';
    for (i = 0; i < len; i++) {
        str += $chars.charAt(Math.floor(Math.random() * maxPos));
    }
    return str;
}

function encode(content) {
    var csi = "";
    for (var u = 0; u < content.length; u++) {
        var r = content.charCodeAt(u);
        csi += String.fromCharCode(r + 2);
    }

    return csi
};

function isHelp() {
    var helpUrl = 'https://wiki.cloudgoing.com/idcsystem/index.html';
    var helpKey = cAction;
    if (rGet(curl, 'mt') != '') helpKey += '_' + rGet(curl, 'mt');
    helpKey += '_page';
    swin.html('<form target="_blank" style="padding-top:10px" action="' + helpUrl + '" method="get"><div style="text-align:center;padding-top:10px"><a href="' + helpUrl + '?keyword=' + helpKey + '" target="_blank" class="dialog_button">『查看本页相关功能帮助教程』</a><br />&nbsp;<br />' +
                  '<input name="keyword" style="width:130px" class="text" /> <input type="submit" class="button" value="教程搜索"/>' +
                  '</div></form>');
    swin.find("a:first").button();
    swin.dialog({ title: '帮助手册？', autoOpen: false, resizable: false, width: 399, height: 255, modal: true, buttons: { '关闭': function () { $(this).dialog("close"); } } }).dialog("open");
}


function getTimeCycleSuffix(billingCycle, timeCycle, tag) {
    var cycleSuffix = '';
    if (billingCycle == 0) {
        switch (timeCycle) {
            case '1': cycleSuffix = '天'; break;
            case '2': cycleSuffix = '小时'; break;
            default:
                cycleSuffix = '月';
                if (tag == 1) cycleSuffix = '个月';
                break;
        }
    }
    else {
        if (timeCycle == '0') {
            switch (billingCycle) {
                case '1': cycleSuffix = '月'; break;
                case '3': cycleSuffix = '季'; break;
                case '6': cycleSuffix = '半年'; break;
                case '12': cycleSuffix = '年'; break;
                case '24': cycleSuffix = '2年'; break;
                default: cycleSuffix = billingCycle + '个月'; break;
            }
        }
        else if (timeCycle == '1') {
            switch (billingCycle) {
                case '1': cycleSuffix = '天'; break;
                case '7': cycleSuffix = '周'; break;
                case '15': cycleSuffix = '半月'; break;
                case '30': cycleSuffix = '月'; break;
                case '90': cycleSuffix = '季'; break;
                case '365': cycleSuffix = '年'; break;
                default: cycleSuffix = billingCycle + '天'; break;
            }
        }
        else {
            switch (billingCycle) {
                case '1': cycleSuffix = '小时'; break;
                case '24': cycleSuffix = '天'; break;
                case '168': cycleSuffix = '周'; break;
                default: cycleSuffix = billingCycle + '小时'; break;
            }
        }
    }
    return cycleSuffix;
}