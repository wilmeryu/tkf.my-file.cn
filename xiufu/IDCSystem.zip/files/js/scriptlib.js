﻿/// <reference path="/files/js/jquery.min.js" />
/// <reference path="/files/js/jquery.ui.min.js" />

//#region HTML编辑器
//s#htmleditor
document.writeln('<script type="text/javascript" src="/files/js/tiny_mce/jquery.tinymce.js"></script>');
document.writeln('<style type="text/css">@import url(/files/plupload/jquery.ui.plupload.css);</style>');
function loadEditor(obj) {
    $(obj).tinymce({
        script_url: '/files/js/tiny_mce/tiny_mce.js',
        language: "zh",
        theme: "advanced",
        skin: "default",
        plugins: "autolink,lists,pagebreak,table,save,advhr,advimage,advlink,iespell,inlinepopups,insertdatetime,preview,media,searchreplace,contextmenu,paste,directionality,fullscreen,noneditable,visualchars,nonbreaking,xhtmlxtras,template,advlist",
        theme_advanced_buttons1: "save,newdocument,|,bold,italic,underline,strikethrough,forecolor,backcolor,|,justifyleft,justifycenter,justifyright,justifyfull,formatselect,fontselect,fontsizeselect",
        theme_advanced_buttons2: "cut,copy,paste,pastetext,pasteword,|,search,replace,|,bullist,numlist,|,outdent,indent,blockquote,|,undo,redo,|,link,unlink,anchor,image,cleanup,|,insertdate,inserttime,preview",
        theme_advanced_buttons3: "tablecontrols,|,hr,removeformat,visualaid,|,sub,sup,|,charmap,emotions,iespell,media,advhr,|,ltr,rtl,|,code,fullscreen",
        theme_advanced_toolbar_location: "top",
        theme_advanced_toolbar_align: "left",
        theme_advanced_statusbar_location: "bottom",
        theme_advanced_resizing: true,
        setup: function (ed) {
            ed.onInit.add(function (ed) {
                var e = ed.getBody();
                e.style.fontSize = '12px';
            });
            ed.onKeyDown.add(function (ed, e) {
                if (e.ctrlKey == 1 && e.keyCode == 13)
                    $(obj).parent().submit();
                return false;
            });
        }
    });
}

function htmlEdit(obj, action) {
    if (action == 0) {
        var str = '<form id="editorForm" onsubmit="return htmlEdit(\'' + obj + '\',1)"><p>' +
                  '<textarea id="editorContent" rows="10" cols="10" style="width:100%;height:415px" class="tinymce">' + unJsonConvertString($(obj).val()) + '</textarea></p></form>';
        editor.html(str);
        loadEditor("#editorForm .tinymce");
        editor.dialog({ title: "内容编辑器", autoOpen: false, resizable: false, width: 800, height: 568, modal: true, buttons: { "保存(Ctrl+Enter)": function () { htmlEdit(obj, 1); }, "关 闭": function () { $(this).dialog("close"); } } }).dialog("open");
    }
    else {
        $(obj).val(editor.find('#editorContent').html());
        $(obj).focus();
        editor.dialog("close");
        return false;
    }
}
//e#htmleditor
//#endregion

//#region 发送验证码
//s#vcode
function sendVerificationCode(vType, vAction, exData, btnObj) {
    processing('正在处理，请稍候...');
    var delay = 0;
    var cmd = 'close';
    $.get('/process.aspx?c=sendvcode&vt=' + vType + '&va=' + vAction + '&' + exData + '&' + new Date(), function (rdata) {
        var rmsg = rdata.split('|');
        if (rmsg[0] == "0") {
            rdata = '您的验证码已经发送成功！如果3分钟内没有收到验证码，请尝试重发！';
            delay = 3000;
            resendCountDown(60, btnObj, $(btnObj).val());
        } else if (rmsg[0] == "-1") {
            switch (rmsg[1]) {
                case "Invalid username or email": rdata = "请输入正确的用户名或邮箱地址！"; break;
                case "Mobile is not verified": rdata = "您的手机号码还未通过短信验证！"; break;
                case "Email is not verified": rdata = "您的电子邮箱地址还未通过验证！"; break;
                case "Email vCode disabled": rdata = "邮件验证功能已禁用！"; break;
                case "SMS vCode disabled": rdata = "短信验证功能已禁用！"; break;
                case "Time limited": rdata = "每分钟只能发送一次验证码！"; break;
                case "Invalid vtype": rdata = "无效的验证码请求方式！"; break;
                case "Invalid action": rdata = "无效的验证码请求动作！"; break;
                case "Invalid email": rdata = "您输入的电子邮件地址不正确！"; break;
                case "Invalid mobile": rdata = "您输入的手机号码不正确！"; break;
                case "Email exists": rdata = "您输入的电子邮件地址已经存在！"; break;
                case "Mobile exists": rdata = "您输入的手机号码已经存在！"; break;

                default: rdata = rmsg[1]; break;
            }
        }
        showResults(rdata, delay, cmd);
    });
}

function resendCountDown(cTime, btnObj, yBtnValue) {
    var obj = $(btnObj);
    if (cTime < 1) {
        obj.removeAttr("disabled");
        obj.val(yBtnValue);
    } else {
        obj.attr("disabled", "disabled");
        obj.val("(" + cTime.toString() + ")秒后可重发");
        cTime--;
        setTimeout(function () { resendCountDown(cTime, btnObj, yBtnValue) }, 1000);
    }
}
//e#vcode
//#endregion

//#region 上传组件
//s#plupload
document.writeln('<style type="text/css">@import url(/files/plupload/jquery.ui.plupload.css);</style>');
document.writeln('<script type="text/javascript" src="/files/plupload/plupload.full.js"></script>');
document.writeln('<script type="text/javascript" src="/files/plupload/jquery.ui.plupload.js"></script>');
document.writeln('<script type="text/javascript" src="/files/plupload/zh-cn.js"></script>');

function saveFiles() {
    var fform = $("#fileForm");
    processing("正在保存文件，请稍候......");
    var delay = 0;
    var cmd = '';
    $.post(fform.attr("action"), fform.serialize(), function (rdata) {
        var rmsg = rdata.split('|');
        if (rmsg[0] == "0") {
            var msg = $.parseJSON(rmsg[1]);
            rdata = "成功上传 " + msg.file_count + " 个文件！";
            swin.find("input[name='configvalue_path']").val(msg.dir);
            suwin.dialog("close");
            cmd = 'close';
            delay = 1000;
        } else if (rmsg[0] == "-1") {
            switch (rmsg[1]) {
                case 'Please upload the files': rdata = '请您先上传文件！'; break;
                case 'Invalid folder name': rdata = '无效的文件目录名称！'; break;
                default: rdata = rmsg[1]; break;
            }
        }
        showResults(rdata, delay, cmd);
    });
}


function initUploader(buttonObj, maxFileCount, multiSelection, callBack) {
    var uButtons = $(buttonObj).toArray();
    var uploader = new plupload.Uploader({
        runtimes: 'html5,flash,silverlight,html4',
        browse_button: uButtons,
        url: '/upload.aspx',
        max_file_count: maxFileCount,
        chunk_size: '1mb',
        unique_names: true,
        multiple_queues: true,
        multi_selection: multiSelection,
        headers: { "action": upload_action, "filepath": "/files/temp/file.temp" },
        sortable: true,
        filters: {
            max_file_size: '50mb',
            mime_types: [
                { title: "Files", extensions: upload_file_exts }
                ]
        },
        flash_swf_url: '/files/plupload/plupload.flash.swf',
        silverlight_xap_url: '/files/plupload/plupload.silverlight.xap',

        init: {
            PostInit: function () {

            },
            FilesAdded: function (up, files) {
                processing('<span>正在准备文件...</span>');
                uploader.start();
            },
            UploadProgress: function (up, file) {
                $("#processing span").html('正在上传文件：' + file.percent + '%');
            },
            FileUploaded: function (up, file, rdata) {
                var rmsg = rdata.response.split('|');
                if (rmsg[0] == "-1") {
                    switch (rmsg[1]) {
                        case 'No administrative privileges': rdata = '对不起，您没有此权限！'; break;
                        case 'Invalid file format': rdata = '无效的文件格式[' + rmsg[2] + ']！'; break;
                        case 'Invalid file path': rdata = '无效的文件路径！'; break;
                        default: rdata = rmsg[1]; break;
                    }
                    showResults(rdata, 0, '');
                    uploader.stop();
                }
            },
            UploadComplete: function (up, file) {
                showResults('文件上传成功！', 1000, 'close');
                if (typeof callBack === "function") { callBack.call(); }
            },
            Error: function (up, err) {
                processing('');
                showResults(err.message, 0, '');
            }
        }
    });
    uploader.init();

    return uploader;
}

function uploadFiles() {
    var cdir = swin.find("input[name='configvalue_path']").val();
    if (cdir == undefined) cdir = swin.find("input[name='configvalue_jspath']").val();
    if (cdir.substring(cdir.length - 1) != '/') cdir += '/';
    cdir = cdir.substring(0, cdir.lastIndexOf('/'));
    cdir = cdir.substring(cdir.lastIndexOf('/') + 1);

    var str = '<div style="padding-top:5px"><form id="fileForm" method="post" action="/upload.aspx?at=save&upload_action=' + upload_action + '">' +
                  '<strong>保存路径</strong>：' + upload_dir_prefix + '<input name="dir" style="width:108px" ' + (cdir != '' ? 'readonly="readonly" value="' + cdir + '"' : 'value="' + getRandomString(8) + '"') + ' class="text"/>/ &nbsp;&nbsp;目录名只能由字母和数字组成&nbsp;&nbsp;&nbsp;<input type="checkbox" id="unzip" name="unzip" value="1" checked="checked"/><label for="unzip">自动解压.zip文件</label><br />&nbsp;<br />' +
                  '<div id="uploader"><p>You browser does not have Flash, Silverlight, Gears, BrowserPlus or HTML5 support.</p></div>' +
                  '<div style="padding-top:20px"><strong>允许上传的文件类型：</strong>' + upload_file_exts + '</div></form></div>';
    suwin.html(str);
    suwin.dialog({ title: "文件上传", autoOpen: false, resizable: false, width: 786, height: 566, modal: true, buttons: { "保存(Ctrl+Enter)": function () { saveFiles(); }, "关 闭": function () { $(this).dialog("destroy"); } } }).dialog("open");

    suwin.find("#uploader").plupload({
        runtimes: 'html5,flash,silverlight,html4',
        url: '/upload.aspx',
        max_file_size: '50mb',
        max_file_count: 50,
        chunk_size: '1mb',
        unique_names: true,
        multiple_queues: true,
        headers: { "action": upload_action },
        sortable: true,
        filters: [
                { title: "Files", extensions: upload_file_exts },
		    ],
        flash_swf_url: '/files/plupload/plupload.flash.swf',
        silverlight_xap_url: '/files/plupload/plupload.silverlight.xap'
    });
}
//e#plupload
//#endregion


//#region 服务管理常用方法
//s#service
function getCouponError(rmsg, code) {
    var rdata = rmsg[1];
    switch (rmsg[1]) {
        case "Invalid coupon code": rdata = '您输入的优惠码无效！'; break;
        case "The coupon code is only use for monthly payment": rdata = '优惠码只能用于套餐的月付形式！'; break;
        case "Exceeds the limit": rdata = '您输入的优惠码已超过使用次数限制！'; break;
        case "Exceeds the per user limit": rdata = '当前优惠码每人只能使用' + rmsg[2] + '次！'; break;
        case "The coupon code is expired": rdata = '您输入的优惠码已过期！'; break;
        case "Current product is not allowed to use the coupon code": rdata = '当前产品套餐不允许使用优惠码！'; break;
        case "Your user group is not allowed to use the coupon code": rdata = '您的用户级别不允许使用优惠码！'; break;
        case "The coupon code is only use for " + rmsg[2] + " months payment": rdata = '优惠码仅能用于[' + rmsg[2] + ']个周期(月/天/小时)'; break;
        case "The coupon code is only use for amount more than": rdata = '优惠码仅能在总金额大于' + rmsg[2] + '的时候使用！'; break;
        case "The coupon code can not be used to order new services": rdata = '优惠码不能用于购买新产品服务！'; break;
        case "The coupon code can not be used to renew services": rdata = '优惠码不能用于续费产品服务！'; break;
        case "The coupon code can not be used to upgrade services": rdata = '优惠码不能用于升级产品服务！'; break;
        default: rdata = rmsg[1]; break;
    }
    rdata = rdata.replace('优惠码', '优惠码[<strong>' + code + '</strong>]');
    return rdata;
}

function applyCode(couponType) {
    clearCouponCode(0);
    var code = $("#couponcode").val();
    if (code == '') {
        $("#ccdes").html('请输入正确的优惠码！');
        return false;
    }
    $("#couponcode").val('Loading...');
    $.get('?c=ajax&dt=couponcode&p1=' + code + '&p2=' + couponType + '_' + productID + '_' + billingMothod + '_' + billingCycle + '_' + userData[0].utype + '_' + normalPrice.toFixed(2) + '&' + new Date(), function (rdata) {
        var rmsg = rdata.split('|');
        if (rmsg[0] == '0') {
            var fPrice = normalPrice;
            var couponConfig = $.parseJSON(rmsg[1]);
            var discount = parseFloat(couponConfig["discount"]);
            if (discount > 1) fPrice = fPrice - discount;
            else if (discount > 0 && discount < 1) fPrice = fPrice * discount;
            if (discount == 0) {
                $("#couponcode").val('');
                rdata = '当前产品不使用优惠码！';
            } else if (fPrice <= 0) {
                $("#couponcode").val('');
                rdata = '当前价格过低不能使用此优惠码！';
            } else {
                $("#suwin .finalPrice").html(fPrice.toFixed(2));
                $("#suwin .normalPrice").html('原始价格：<strike style="font-weight:bold;">' + normalPrice.toFixed(2) + '</strike> ' + userData[0].currency);
                $("#couponcode").val(code);
                rdata = couponConfig["cdes"];
            }
        }
        else {
            if (rmsg[0] == "-1") {
                rdata = getCouponError(rmsg, code);
            }
            $("#couponcode").val('');
        }
        $("#ccdes").html(rdata);
    });
}

function clearCouponCode(action) {
    $("#suwin .finalPrice").text(finalPrice.toFixed(2));
    $("#suwin .normalPrice").html('');
    $("#ccdes").html('');
    if (action == 1) $("#couponcode").val('');
}

function setAutorenew(serviceID, autorenew) {
    processing('正在' + (autorenew == '0' ? '启用' : '禁用') + '自动续费，请稍候...');
    var cmd = 'close';
    var delay = 1500;
    $.get('process.aspx?c=editservice&autorenew=' + autorenew + '&id=' + serviceID + '&' + new Date(), function (rdata) {
        var rs = rdata.split('|');
        if (rs[0] == '0') {
            rdata = '操作成功！';
        }
        else if (rs[0] == "-1") {
            switch (rs[1]) {
                case "Parameter error": rdata = "参数传递错误！"; break;
                case "No permission to Control this Service": rdata = '您没有控制此服务的权限！'; break;
            }
            delay = 0;
        }
        showResults(rdata, delay, cmd);
    });
}

function renew(serviceID, cycle, couponcode) {
    processing("正在续费，请稍候......");
    var delay = 0;
    cmd = '';
    $.get('process.aspx?c=renew&serviceid=' + serviceID + '&cycle=' + cycle + '&couponcode=' + couponcode + '&' + new Date(), function (rdata) {
        var rmsg = rdata.split('|');
        if (rmsg[0] == "0") {
            rdata = '续费成功！';
            delay = 2000;
            cmd = 'reload';
        }
        else if (rmsg[0] == "-1") {
            switch (rmsg[1]) {
                case 'Service not found': rdata = '您欲续费的产品服务并不存在！'; break;
                case 'Service does not support renewals': rdata = '您当前产品服务不支持续费操作！'; break;
                case 'Invalid payment cycle': rdata = '原付款周期或现付款周期有误！'; break;
                case 'Lack of balance': rdata = '您的余额不足于续费！'; break;
                case "Module price error": rdata = '计费模块错误！'; break;
                default: rdata = getCouponError(rmsg, couponcode); break;
            }
        }
        showResults(rdata, delay, cmd);
    });
}
//e#service
//#endregion


//#region 应用市场
//s#market
function _market(category, appType, appTitle) {
    if (category == 0) {
        swin.html('<div class="marks"></div><ul class="templatebox"></ul>');
        var cats = '<span><strong>分类：</strong></span><a class="cat0 on" href="javascript:_market(0,' + appType + ');">最新</a>';
        $.getJSON("?c=market&subaction=cat&type=" + appType + "&updates=" + updates + "&" + new Date(), function (cdata) {
            if (cdata[0].isEmpty != 'true') {
                $(cdata).each(function (i) {
                    cats += '&nbsp;|&nbsp;<a href="javascript:_market(' + cdata[i].catid + ',' + appType + ')" class="cat' + cdata[i].catid + '">' + cdata[i].cname + '</a>';
                });
            }
            swin.find(".marks").html(cats);
            _market_list(category, appType);
        });
        updates = "0"; //取消更新提示
        swin.dialog({ title: appTitle, autoOpen: false, resizable: false, width: 786, height: 566, modal: true, buttons: { "关 闭": function () { $(this).dialog("close"); }, "刷新页面": function () { top.location.reload(); } } }).dialog("open");
    }
    else _market_list(category, appType);
    swin.find(".templatebox").html(ajaxLoading());
    swin.find(".marks .on").removeClass("on");
    swin.find(".marks .cat" + category).addClass("on");
}

function _market_list(category, appType) {
    var mlist = '';
    $.getJSON("?c=market&subaction=list&catid=" + category + "&type=" + appType + "&" + new Date(), function (mdata) {
        if (mdata[0].isEmpty != 'true') {
            var daction = 0;
            var dcolor = '', dtext = '', confirmText = '', newlabel = '';
            var appExist = false;
            var appUpgrade = false;
            $(mdata).each(function (i) {
                newlabel = '';
                confirmText = '';
                appExist = false;
                appUpgrade = false;
                switch (appType) {
                    case 1:
                    case 2:
                        appExist = mainContent.find("#app_" + mdata[i].mtag).length > 0;
                        if (appExist) appUpgrade = mdata[i].mversion != mainContent.find("#app_" + mdata[i].mtag).text().substring(4);
                        break;
                    case 3:
                    case 4:
                    case 5:
                        appExist = appList[mdata[i].mtag] != undefined;
                        if (appExist) appUpgrade = mdata[i].mversion != appList[mdata[i].mtag].version;
                        break;
                }

                if (!appExist) {
                    daction = 0;
                    dcolor = '#0E52E2';
                    dtext = '『立即安装』';
                    confirmText = '您确定要安装『<strong>' + mdata[i].mname + '</strong>』吗？';
                } else {
                    if (!appUpgrade) {
                        dcolor = '#7D8587;';
                        daction = 1;
                        dtext = '『重新安装』';
                        confirmText = '您确定要重新安装『<strong>' + mdata[i].mname + '</strong>』吗？';
                    } else {
                        dcolor = '#EC3406';
                        daction = 2;
                        dtext = '<strong>『升级更新』</strong>';
                        confirmText = '您确定要升级『<strong>' + mdata[i].mname + '</strong>』到Ver' + mdata[i].mversion + '版本吗？';
                        newlabel = '<span class="new_update_label"></span>';
                    }
                }
                mlist += '<li><div><a href="' + mdata[i].surl + '" target="_blank" title="查看详情"><img alt="" src="' + mdata[i].mpic + '" /></a></div>' +
                             '<p><span class="fl" style="padding-left:6px">' + mdata[i].mname + '</span><span class="fr">Ver' + mdata[i].mversion + '</span></p><p><a href="javascript:_download(' + appType + ',' + mdata[i].mid + ',\'' + mdata[i].mname + '\',' + daction + ',\'' + confirmText + '\');" style="color:' + dcolor + ';">' + dtext + '</a><a href="' + mdata[i].surl + '" target="_blank" style="color:#7D8587;">『查看详情』</a></p>' + newlabel + '</li>';
            });
        }
        else mlist = '<li>暂无相关项目！</li>';
        swin.find(".templatebox").html(mlist);

    });
}

function _download(appType,id, mname, action, confirmText) {
    confirmMsg('操作确认！', confirmText, function () {
        processing('正在下载和安装，请稍候...');
        $.get('?c=market&subaction=download&id=' + id + '&type=' + appType + '&' + new Date(), function (rdata) {
            var rmsg = rdata.split('|');
            if (rmsg[0] == '0') {
                rdata = '太棒了！<strong>[' + mname + ']</strong>已经安装成功！';

                $("#processing p").css("padding-top", "10px");
                $("#processing").dialog("option", "buttons", { "立即启用": function () { $(this).dialog("destroy"); _active(rmsg[1], mname, appType); }, "关 闭": function () { $(this).dialog("destroy"); } });
            }
            else if (rmsg[0] == "-1") {
                switch (rmsg[1]) {
                    case 'Invalid request': rdata = '无效的文件下载请求！'; break;
                    default: rdata = rmsg[1]; break;
                }
            }
            showResults(rdata, 0, '');
        });
    });
}



function _active(id, mname, appType) {
    switch (appType) {
        case 1:
        case 2:
            _activeTheme(id, mname);
            break;
        case 3:
        case 4:
        case 5:
            _activeApp(id, 1, mname, 'reload');
            break;
    }
}

function _activeTheme(id, mname) {
    processing('正在启用 [' + mname + '] ，请稍候...');
    var cmd = 'reload';
    var delay = 1500;
    $.get('?c=' + cAction + '&at=active&id=' + id + '&' + new Date(), function (rdata) {
        var rmsg = rdata.split('|');
        if (rmsg[0] == '0') {
            rdata = '操作成功！';
        }
        else if (rmsg[0] == "-1") {
            rdata = rmsg[1];
            delay = 0;
        }
        showResults(rdata, delay, cmd);
    });
}

function _activeApp(id, cstatus, mname, cmd) {
    processing('正在' + (cstatus == '1' ? '启用' : '禁用') + ' <strong>[' + mname + ']</strong>，请稍候...');
    var delay = 1500;
    $.get('?c=mconfig&at=savecstatus&cstatus=' + cstatus + '&cid=' + id + '&' + new Date(), function (rdata) {
        var rs = rdata.split('|');
        if (rs[0] == '0') {
            rdata = '操作成功！';
        }
        else if (rs[0] == "-1") {
            rdata = rs[1];
            delay = 0;
        }
        showResults(rdata, delay, cmd);
    });
}
//e#market
//#endregion


//#region 快速编辑
//s#inlineedit
document.writeln('<script type="text/javascript" src="/files/js/jquery.editable.min.js"></script>');

function inlineSave(id, e) {
    if (e.old_value != e.value) {
        //alert(id + ' ' + e.value);
        var name = id.substring(0, id.lastIndexOf('_'));
        id = id.substring(id.lastIndexOf('_') + 1);
        e.target.append(' <img class="sloading" src="/files/images/sloading.gif" alt=""/>');
        $.post('?c=inlinesave', { "id": id, "name": name, "value": e.value }, function (esdata) {
            var rmsg = esdata.split('|');
            if (rmsg[0] == '0') {
                e.target.find(".sloading").remove();
            }
            else {
                if (rmsg[0] == "-1") {
                    switch (rmsg[1]) {
                        case "No administrative privileges": esdata = "对不起，您没有相应的管理权限！"; break;
                        default: esdata = rmsg[1]; break;
                    }
                }
                esdata = '<strong>保存时发生错误：</strong>' + esdata;
                e.target.html('<span style="color:#ff0000;" title="' + esdata + '">' + e.value + '</span>');
            }
        });
    }
}
//e#inlineedit
//#endregion