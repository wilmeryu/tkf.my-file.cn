﻿function configInit() {
    $.post($("input[name=configvalue_jspath]").val() + 'index.ashx?action=getconfig&t=' + new Date(), function (content) {
        content = content.substr(1);
        var str = '<script type="text/javascript" src="/files/js/tiny_mce/jquery.tinymce.js"></script><textarea id="content" rows="16" cols="10" style="width:100%;" name="content"  class="tinymce">' + unJsonConvertString(content) + '</textarea></br>';

        $("#jsContent").html(str);
        loadEditor("#content");
        $("#swin").dialog({
            title: '设置免责声明信息：', autoOpen: false, resizable: false, height: 610, modal: true, buttons: {
                "保存配置": function () {
                    processing("正在保存，请稍候...");
                    var content = $("#content").val();
                    var cstatus = $("input[name=cstatus]:checked").val();
                    if (content == '') {
                        showResults('请填写内容！', 2000, 'close'); return;
                    }
                    $.post($("input[name=configvalue_jspath]").val() + 'index.ashx?action=setconfig&t=' + new Date(), { "content": content, "status": cstatus }, function (rdata) {
                        if (rdata == '1') {
                            save();
                        } else {
                            showResults(rdata, 2000, 'close');
                        }
                    });
                }, "关 闭": function () { $(this).dialog("close"); }
            }
        }).dialog("open");
    });
} configInit();


function loadEditor(obj) {
    $(obj).tinymce({
        script_url: '/files/js/tiny_mce/tiny_mce.js',
        language: "zh",
        theme: "advanced",
        skin: "default",
        plugins: "autolink,lists,pagebreak,table,save,advhr,advimage,advlink,iespell,inlinepopups,insertdatetime,preview,media,searchreplace,contextmenu,paste,directionality,fullscreen,noneditable,visualchars,nonbreaking,xhtmlxtras,template,advlist",
        theme_advanced_buttons1: "save,newdocument,|,bold,italic,underline,strikethrough,forecolor,backcolor,|,justifyleft,justifycenter,justifyright,justifyfull,formatselect,fontselect,fontsizeselect",
        theme_advanced_buttons2: "cut,copy,paste,pastetext,pasteword,|,search,replace,|,bullist,numlist,|,outdent,indent,blockquote,|,undo,redo,|,link,unlink,anchor,image,cleanup,|,insertdate,inserttime,preview",
        theme_advanced_buttons3: "tablecontrols,|,hr,removeformat,visualaid,|,sub,sup,|,charmap,emotions,iespell,media,advhr,|,ltr,rtl,|,code,fullscreen",
        theme_advanced_toolbar_location: "top",
        theme_advanced_toolbar_align: "left",
        theme_advanced_statusbar_location: "bottom",
        theme_advanced_resizing: true,
        setup: function (ed) {
            ed.onInit.add(function (ed) {
                var e = ed.getBody();
                e.style.fontSize = '12px';
            });
            ed.onKeyDown.add(function (ed, e) {
                if (e.ctrlKey == 1 && e.keyCode == 13)
                    $(obj).parent().submit();
                return false;
            });
        }
    });
}

//function htmlEdit(obj, action) {
//    if (action == 0) {
//        var str = '<form id="editorForm" onsubmit="return htmlEdit(\'' + obj + '\',1)"><p>' +
//                  '<textarea id="editorContent" rows="10" cols="10" style="width:100%;height:415px" class="tinymce">' + unJsonConvertString($(obj).val()) + '</textarea></p></form>';
//        editor.html(str);
//        loadEditor("#editorForm .tinymce");
//        editor.dialog({ title: "内容编辑器", autoOpen: false, resizable: false, width: 800, height: 568, modal: true, buttons: { "保存(Ctrl+Enter)": function () { htmlEdit(obj, 1); }, "关 闭": function () { $(this).dialog("close"); } } }).dialog("open");
//    }
//    else {
//        $(obj).val(editor.find('#editorContent').html());
//        $(obj).focus();
//        editor.dialog("close");
//        return false;
//    }
//}