﻿$(function () {

    var cs = rGet(curl, 'c');
    if (cs == 'reg') {
        $.post('$pluginpath$index.ashx?action=getconfig&t=' + new Date(), function (data) {

            var enable = data.substr(0, 1);

            if (enable == "1") {
                $(".l-login").prepend("<p><label>&nbsp;&nbsp;</label> <input type=\"checkbox\" id=\"chkAgreeService\" style=\"vertical-align: middle;width:13px;height:28px;margin-left:0px;margin-right:0px;\" /> <label for=\"chkAgreeService\" style=\"width:28px;cursor:pointer\" >同意</label><a href=\"javascript:void(-1);\" id=\"showcontent\" style=\"  text-decoration: none;\">《商家服务协议》</a></p>");

                $("#showcontent").click(function () {
                    $("#swin").html(data.substr(1));
                    $("#swin").dialog({
                        title: '商家服务协议：', autoOpen: false, resizable: false, height: 600, width: 550, modal: true, buttons: {
                            "关 闭": function () { $(this).dialog("close");}
                        }
                    }).dialog("open");

                });
                $("#chkAgreeService").css("cursor", "pointer").click(function () {
                    if ($(this).prop("checked")) $("#chkAgreeService").attr("checked", "checked");
                    else $("#chkAgreeService").removeAttr("checked");

                });
                $("input[type=submit]").mousemove(function () {

                    if (!$("#chkAgreeService").is(':checked')) { processing("正在处理"); showResults("必须同意商家服务协议才能注册！", 3000, 'close'); }

                });

            }

        });
    }

});