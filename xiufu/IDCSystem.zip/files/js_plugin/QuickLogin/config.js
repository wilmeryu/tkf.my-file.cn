﻿$("#jsContent").hide();
$.post($("input[name=configvalue_jspath]").val() + 'index.ashx?cq=getquick&t=' + new Date(), function (data) {
    var vjson = $.parseJSON(data);

    var str = '<form action="index.ashx" id="quickform" name="quickform" style="margin-top:20px;"><div id="params" class="ui-accordion ui-widget ui-helper-reset ui-accordion-icons" role="tablist">' +
    '<h3 class="ui-accordion-header ui-helper-reset ui-state-default ui-state-active ui-corner-top" role="tab" aria-expanded="true" aria-selected="true" tabindex="-1"><span></span><a href="#"><strong>API主控端配置</strong></a></h3>' +
    '<div class="ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom ui-accordion-content-active" role="tabpanel"><li><label class="a">API主面板域名</label>：<input type="text" class="text" id="api_domain" name="api_domain" style="width:320px" value="' + vjson.api_domain + '"/></li>' +
    '<li><label class="a">主控端识别码</label>：<input type="text" class="text" id="api_username" name="api_username" style="width:320px" value="' + vjson.api_username + '"/></li>' +
    '<li><label class="a">API密钥</label>：<input type="text" class="text" id="api_key" name="api_key" style="width:320px" value="' + vjson.api_key + '"/></li></div>' +


   '<h3 class="ui-accordion-header ui-helper-reset ui-state-default ui-corner-all" role="tab" aria-expanded="false" aria-selected="false" tabindex="0"><span></span><a href="#"><strong>QQ快捷登录配置</strong></a></h3>' +
    '<div style="line-height: 28px; display: none;" class="ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom" role="tabpanel"><li><label class="a">APP_ID</label>：<input type="text" class="text" id="qq_appid" name="qq_appid" style="width:320px" value="' + vjson.qq_appid + '"/></li>' +
    '<li><label class="a">APP_Key</label>：<input type="text" class="text" id="qq_appkey" name="qq_appkey" style="width:320px" value="' + vjson.qq_appkey + '"/></li>' +
    '<li><label class="a">注册界面显示邮箱</label>：<input type="radio" name="qq_email" value="1" id="qq_email1"><label for="qq_email1">启用</label>&nbsp;&nbsp;&nbsp;<input type="radio" name="qq_email" value="0" id="qq_email0"><label for="qq_email0">禁用</label> &nbsp;<span style="color:red">(提示：提交审核时要禁用，审核通过后必须启用)</span></li></div>' +

     '<h3 class="ui-accordion-header ui-helper-reset ui-state-default ui-corner-all" role="tab" aria-expanded="false" aria-selected="false" tabindex="0"><span></span><a href="#"><strong>支付宝快捷登录配置</strong></a></h3>' +
    '<div class="ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom" role="tabpanel"><li><label class="a">支付宝Partner ID</label>：<input type="text" class="text" id="alipay_partnerid" name="alipay_partnerid" style="width:320px" value="' + vjson.alipay_partnerid + '"/></li>' +
    '<li><label class="a">安全校验码(Key)</label>：<input type="text" class="text" id="alipay_key" name="alipay_key" style="width:320px" value="' + vjson.alipay_key + '"/></li></div>' +

     '<h3 class="ui-accordion-header ui-helper-reset ui-state-default ui-corner-all" role="tab" aria-expanded="false" aria-selected="false" tabindex="0"><span></span><a href="#"><strong>微信快捷登录配置</strong></a></h3>' +
    '<div class="ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom" role="tabpanel"><li><label class="a">APP_ID</label>：<input type="text" class="text" id="weixin_appid" name="weixin_appid" style="width:320px" value="' + vjson.weixin_appid + '"/></li>' +
      '<li><label class="a">APP_Key</label>：<input type="text" class="text" id="weixin_appkey" name="weixin_appkey" style="width:320px" value="' + vjson.weixin_appkey + '"/></li></div></div></form>';

    //    var str = '<form action="index.ashx" id="quickform" name="quickform" style="margin-top:20px;"><ul>' +
    //'<li style="height: 30px;"><label style="font-weight: bold; float: left; text-align: right; width: 160px;">API主控端配置：</label></li>' +
    //'<li style="height: 30px;"><label style="font-weight: bold; float: left; text-align: right; width: 160px;">API主面板域名：</label><input type="text" class="text" id="api_domain" name="api_domain" style="width:320px" value="' + vjson.api_domain + '"/></li>' +
    //'<li style="height: 30px;"><label style="font-weight: bold; float: left; text-align: right; width: 160px;">主控端识别码：</label><input type="text" class="text" id="api_username" name="api_username" style="width:320px" value="' + vjson.api_username + '"/></li>' +
    //'<li style="height: 30px;"><label style="font-weight: bold; float: left; text-align: right; width: 160px;">API密钥：</label><input type="text" class="text" id="api_key" name="api_key" style="width:320px" value="' + vjson.api_key + '"/></li>' +
    //'<li style="height: 30px;"></li>' +
    //'<li style="height: 30px;"><label style="font-weight: bold; float: left; text-align: right; width: 160px;">QQ快捷登录配置：</label></li>' +
    //'<li style="height: 30px;"><label style="font-weight: bold; float: left; text-align: right; width: 160px;">APP_ID：</label><input type="text" class="text" id="qq_appid" name="qq_appid" style="width:320px" value="' + vjson.qq_appid + '"/></li>' +
    //'<li style="height: 30px;"><label style="font-weight: bold; float: left; text-align: right; width: 160px;">APP_Key：</label><input type="text" class="text" id="qq_appkey" name="qq_appkey" style="width:320px" value="' + vjson.qq_appkey + '"/></li>' +
    // '<li style="height: 30px;"><label style="font-weight: bold; float: left; text-align: right; width: 160px;">用户注册界面显示电子邮件：</label><input type="radio" name="qq_email" value="1" id="qq_email1"><label for="qq_email1">启用</label>&nbsp;&nbsp;&nbsp;<input type="radio" name="qq_email" value="0" id="qq_email0"><label for="qq_email0">禁用</label> &nbsp;<span style="color:red">(提示：提交审核时要禁用，审核通过后必须启用)</span>' +
    //'<li style="height: 30px;"></li>' +
    //'<li style="height: 30px;"><label style="font-weight: bold; float: left; text-align: right; width: 160px;">支付宝快捷登录配置：</label></li>' +
    //'<li style="height: 30px;"><label style="font-weight: bold; float: left; text-align: right; width: 160px;">支付宝Partner ID：</label><input type="text" class="text" id="alipay_partnerid" name="alipay_partnerid" style="width:320px" value="' + vjson.alipay_partnerid + '"/></li>' +
    //'<li style="height: 30px;"><label style="font-weight: bold; float: left; text-align: right; width: 160px;">安全校验码(Key)：</label><input type="text" class="text" id="alipay_key" name="alipay_key" style="width:320px" value="' + vjson.alipay_key + '"/></li>' +

    //'<li style="height: 30px;"></li>' +
    //'<li style="height: 30px;"><label style="font-weight: bold; float: left; text-align: right; width: 160px;">微信快捷登录配置：</label></li>' +
    //'<li style="height: 30px;"><label style="font-weight: bold; float: left; text-align: right; width: 160px;">APP_ID：</label><input type="text" class="text" id="weixin_appid" name="weixin_appid" style="width:320px" value="' + vjson.weixin_appid + '"/></li>' +
    //'<li style="height: 30px;"><label style="font-weight: bold; float: left; text-align: right; width: 160px;">APP_Key：</label><input type="text" class="text" id="weixin_appkey" name="weixin_appkey" style="width:320px" value="' + vjson.weixin_appkey + '"/></li>' +
    //'</ul></form>';

    $("#suwin").html(str);
    var paramsDiv = $("#params");
    paramsDiv.accordion({
        autoHeight: false,
        collapsible: true,
        active: 0
    });

    paramsDiv.find("li").css({ "height": "30px", "line-height": "30px" });
    paramsDiv.find("label.a").css({ "font-weight": "bold", "float": "left", "text-align": "right", "width": "110px", "height": "30px", "line-height": "30px" });
    paramsDiv.find(".text").css({ "width": "280px" });

    paramsDiv.find(".ui-accordion-content").css({ "height": "100px" });
    $("input[name=qq_email][value=" + (vjson.qq_email == undefined ? '0' : vjson.qq_email) + "]").attr("checked", "checked");
    $("#suwin").dialog({ title: '快捷登录配置', autoOpen: false, resizable: false, width: 620, height: 520, modal: true, buttons: { "保存配置": function () {
        processing("正在保存，请稍候...");
        $.post($("input[name=configvalue_jspath]").val() + 'index.ashx?cq=setquick&t=' + new Date(), $("#quickform").serialize(), function (rdata) {
            if (rdata == '1') {
                showResults('保存成功', 2000, 'close');
                setTimeout('$("#suwin").dialog("close");', 2000);
            } else {
                showResults(rdata, 5000, 'close');
            }
        });
    }, "关 闭": function () { $(this).dialog("close"); }
    }
    }).dialog("open");
});
