﻿$(function () {
    $("input").focus(function () { $(this).addClass("txtOver"); }).blur(function () { $(this).removeClass("txtOver"); })
    $("#btnReg").click(function () {
        if ($("#chkAgreeService").attr("id") != undefined && !$("#chkAgreeService").prop("checked")) {
            showTip('必须同意商家服务协议才能注册！', 'regTip');
            return;
        };
        runReg();
    });
    function runReg() {
        var vUname = $("#username").val();
        var vPwd = $("#pwd").val();
        var vRepwd = $("#repwd").val();
        var vEmail = $("#email").val();
        if (vUname.length <= 0) {
            showTip('用户帐号不能为空！', 'regTip');
            $("#username").focus();
            return;
        }
        if (vPwd.length <= 0) {
            showTip('用户密码不能为空！', 'regTip');
            $("#pwd").focus();
            return;
        }
        if (vPwd != vRepwd) {
            showTip('重复密码与用户密码不一致！', 'regTip');
            $("#repwd").focus();
            return;
        }
        if (vEmail.length <= 0) {
            showTip('电子邮箱地址不能为空！', 'regTip');
            $("#email").focus();
            return;
        }
        var vArgs = {
            "c": "yes",
            "action": "reg",
            "username": vUname,
            "pwd": vPwd,
            "repwd": vRepwd,
            "email": vEmail
        };
        $("#regTip").html("<div style='text-align:center;'>正在提交注册信息，请稍等...</div>").show();
        $.get("?t=" + new Date().getTime(), vArgs, function (respone) {
            var vArr = respone.split('|');
            if (vArr[0] != "0") {
                showTip(getRegErrMsg(vArr[1]));
            } else {
                $("#regTip").html("<div style='text-align:center;'>注册成功，您的支付宝帐号与系统平台帐号绑定成功！</div>");

                setTimeout("goToUsercenter('" + vArr[1] + "','" + vArr[2] + "','" + vArr[3] + "')", "1000");
            }
        });
    }
    $("#btnLogin").click(function () {
        runLogin();
    });
    function runLogin() {
        var vUname = $("#logname").val();
        var vPwd = $("#logpwd").val();
        if (vUname.length <= 0) {
            showTip('用户帐号不能为空！', 'loginTip');
            $("#logname").focus();
            return;
        }
        if (vPwd.length <= 0) {
            showTip('登录密码不能为空！', 'loginTip');
            $("#logpwd").focus();
            return;
        }

        var vArgs = {
            "c": "yes",
            "action": "login",
            "uname": vUname,
            "password": vPwd
        };
        $("#loginTip").html("<div style='text-align:center;'>正在验证登陆，请稍候...</div>").show();
        $.get("?t=" + new Date().getTime(), vArgs, function (respone) {
            var vArr = respone.split('|');
            if (vArr[0] != "0") {//登录失败
                var vMsg = '用户名或密码错误！';
                if (vArr[1] == "sessionlose") {
                    vMsg = '登录出错，支付宝用户ID丢失，请重试！';
                } else if (vArr[1] == "alipaybinded") {
                    vMsg = '该支付宝帐号已与系统平台帐号绑定了，不能重复绑定！';
                } else if (vArr[1] == "suidbinded") {
                    vMsg = '您的系统平台帐号已与支付宝帐号绑定了，不能重复绑定！';
                } else if (vArr[1] == "pwdempty") {
                    vMsg = '登录密码不能为空！';
                }
                showTip(vMsg, 'loginTip');
            } else {//登录成功                 
                $("#loginTip").html("<div style='text-align:center;'>登录成功，您的支付宝帐号与系统平台绑定成功！</div>");
                setTimeout("goToUsercenter('" + vArr[1] + "','" + vArr[2] + "','" + vArr[3] + "')", "1000");
            }
        });
    }

    function getRegErrMsg(vCode) {
        var vMsg = "";
        switch (vCode) {
            case 'Invalid_username':
                vMsg = '用户名只能由5~30位的字母及数字组成！';
                $("#username").focus();
                break;
            case 'Invalid_password_length':
                vMsg = '密码长度不能小于6位！';
                $("#pwd").focus();
                break;
            case 'Password_does_not_match':
                vMsg = '两次输入的新密码不相同！';
                $("#repwd").focus();
                break;
            case 'Invalid_email':
                vMsg = '请输入正确的电子邮箱地址！';
                $("#email").focus();
                break;
            case 'Username_exists':
                vMsg = '您输入的用户名称已经存在，请更换其它名称重试！';
                $("#username").focus();
                break;
            case 'Email_exists':
                vMsg = '您输入的邮箱地址已经存在，请更换其它邮箱重试！';
                $("#email").focus();
                break;
            case 'sessionlose':
                vMsg = '注册出错，支付宝用户ID丢失，请进入登录界面重试！';
                break;
            case 'binded':
                vMsg = '该支付宝帐号已与系统平台帐号绑定了，不能重复绑定！';
                break;
            case 'pwdempty':
                vMsg = '用户密码不能为空！';
                $("#pwd").focus();
                break;
            default:
                vMsg = vCode;
                break;
        }
        return vMsg;
    }
    function showTip(msg, id) {
        $("#" + id + "").html("<div style='text-align:center;'>" + msg + "</div>").fadeIn("slow", function () {
            setTimeout("$('#" + id + "').fadeOut('slow')", '3000');

        });
    }

    $(document).keydown(function (e) {
        if (e.keyCode == 13 && $("#username").val().length > 0 && $("#logname").val().length > 0) {
            showTip("请选择一项操作！", 'regTip')
        } else if (e.keyCode == 13 && $("#username").val().length > 0) {
            runReg();
        } else if (e.keyCode == 13 && $("#logname").val().length > 0) {
            runLogin();
        }
    });
});

function goToUsercenter(vCookie, vEncode,vUname) {
    var vApiDomain = $("#hidApiDomain").val();
    var vbackurl = $("#hidbackurl").val();
    $.getScript(vApiDomain + '/process.aspx?c=jsapi&action=login&u=' + vCookie + '|' + vEncode + '|'+vUname, function () {
        if (result == '0') {
            location.href = vbackurl;
        } else {
            alert('登录时cookies出错，请重试！');
            location.href =vApiDomain + '/page.aspx?c=login&r=%2findex.aspx';
        }
    });
}