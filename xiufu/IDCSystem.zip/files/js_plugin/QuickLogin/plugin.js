﻿var cs = rGet(curl, 'c');
if (curl.indexOf('page.aspx') > -1) {
    if (cs == '' || cs == 'login' || cs == 'logout') {
        $.post('$pluginpath$index.ashx?getenable=getenable&t=' + new Date(), function (data) {
            var arr = data.split('|');
            var str = "快捷登录：";
            if (arr[0] == "1")
                str += '<a href="javascript:void(-1)" id="btnQQ"><img src="$pluginpath$images/qq.png" alt=""></a>';
            if (arr[1] == "1")
                str += '&nbsp;&nbsp;&nbsp;<a href="javascript:void(-1)" id="btnAlipay"><img src="$pluginpath$images/ali.png" alt=""></a>';
            if (arr[2] == "1")
                str += '&nbsp;&nbsp;&nbsp;<a href="javascript:void(-1)" id="btnWeixin"><img src="$pluginpath$images/weixin.png" alt=""></a>';

            $(".l-login").append(str);

            $('#btnQQ').click(function () {
                top.location = "$pluginpath$index.ashx?action=qqlogin";
            });

            $('#btnAlipay').click(function () {
                top.location = "$pluginpath$index.ashx?action=alipaylogin";
            });

            $('#btnWeixin').click(function () {
                top.location = "$pluginpath$index.ashx?action=weixinlogin";
            });
        });
    }
}

if (cs == 'userinfo') {
    $('<tr><td class="title" style="text-align: right; width: 88px; ">解绑操作：</td><td><input class="submit" value="解除支付宝帐号绑定" type="button" name="save" id="btnAlipay">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input class="submit" value="解除QQ帐号绑定" type="button" name="save" id="btnQQ">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input class="submit" value="解除微信帐号绑定" type="button" name="save" id="btnWeixin"></td></tr>').insertBefore('.table tr:last');
    $('#btnQQ').click(function () {
        $("#swin").html(' <p style="text-align:center;padding-top:28px;">确定解除QQ帐号绑定吗？</p>');
        $("#swin").dialog({ title: "提示信息", autoOpen: false, resizable: false, width: 300, height: 180, modal: true, buttons: { "确 定": function () { top.location = "$pluginpath$index.ashx?action=qqlogin&unbind=unbind"; }, "关 闭": function () { $(this).dialog("close"); } } }).dialog("open");
    });

    $('#btnAlipay').click(function () {
        $("#swin").html(' <p style="text-align:center;padding-top:28px;">确定解除支付宝帐号绑定吗？</p>');
        $("#swin").dialog({ title: "提示信息", autoOpen: false, resizable: false, width: 300, height: 180, modal: true, buttons: { "确 定": function () { top.location = "$pluginpath$index.ashx?action=alipaylogin&unbind=unbind"; }, "关 闭": function () { $(this).dialog("close"); } } }).dialog("open");
    });
    $('#btnWeixin').click(function () {
        $("#swin").html(' <p style="text-align:center;padding-top:28px;">确定解除微信帐号绑定吗？</p>');
        $("#swin").dialog({ title: "提示信息", autoOpen: false, resizable: false, width: 300, height: 180, modal: true, buttons: { "确 定": function () { top.location = "$pluginpath$index.ashx?action=weixinlogin&unbind=unbind"; }, "关 闭": function () { $(this).dialog("close"); } } }).dialog("open");
    });
}