﻿function configInit() {

    $.post($("input[name=configvalue_jspath]").val() + 'index.ashx?action=getConfig&t=' + new Date(), function (data) {
        var vJsonArr = data.split('№');
        var vconfig = $.parseJSON(vJsonArr[0]);
        var jsonUType = $.parseJSON(vJsonArr[1]);

        var divutype = "";
        var vUType = '';
        for (var i = 0; i < jsonUType.length; i++) {
            vUType += '<option value ="' + jsonUType[i].Utype + '">' + jsonUType[i].tname + '</option>';
            divutype += '<span id ="s' + jsonUType[i].Utype + '">' + jsonUType[i].tname + '</span>';
        }


        var str = ' <div id="divutype" style="display:none">' + divutype + '</div></br>&nbsp;&nbsp;<input type="button" class="button" value="配置用户等级" id="btnuser">&nbsp;<span id="usertypeorder"></span><ul id="ulconfig">' +
      '<li><label class="a">注册奖励：</label><label><input type="checkbox" style="cursor: pointer;" id="enable_usertype1"/>提升用户组</label>&nbsp;<select id="usertype1">' + vUType + '</select>&nbsp;&nbsp;&nbsp;<label><input type="checkbox" style="cursor: pointer;" id="enable_rewardmoney1"/>奖励金额</label>&nbsp;<input type="text" id="rewardmoney1" style="width:60px" value="' + vconfig[1].rewardmoney + '" class="text"/>&nbsp;&nbsp;&nbsp;注册时间仅限于<input style="width:166px"  class="time text" id="rewardtime1" value="' + vconfig[1].time + '"/>之后</li>' +
      '<li><label class="a">认证奖励：</label><label><input type="checkbox" style="cursor: pointer;" id="enable_usertype2"/>提升用户组</label>&nbsp;<select id="usertype2">' + vUType + '</select>&nbsp;&nbsp;&nbsp;<label><input type="checkbox" style="cursor: pointer;" id="enable_rewardmoney2"/>奖励金额</label>&nbsp;<input type="text" id="rewardmoney2" style="width:60px" value="' + vconfig[2].rewardmoney + '" class="text"/>&nbsp;&nbsp;&nbsp;认证时间仅限于<input style="width:166px"  class="time text" id="rewardtime2" value="' + vconfig[2].time + '"/>之后</li>' +
      '<li><label class="a">购买奖励：</label><input type="button" class="button" value="选择产品" id="btnproduct3">&nbsp;<input style="width:227px;" type="text" class="text" value="' + vconfig[3].products + '" id="products3"><label><input type="checkbox" style="cursor: pointer;" id="enable_usertype3"/>提升用户组</label>&nbsp;<select id="usertype3">' + vUType + '</select>&nbsp;&nbsp;&nbsp;<label><input type="checkbox" style="cursor: pointer;" id="enable_rewardmoney3"/>奖励金额</label>&nbsp;<input type="text" id="rewardmoney3" style="width:60px" value="' + vconfig[3].rewardmoney + '" class="text"/><br><span style="margin-left:110px;">&nbsp;</span>购买时间仅限于<input style="width:166px"  class="time text" id="rewardtime3" value="' + vconfig[3].time + '"/>之后</li></li>' +
      '<li><label class="a">推荐下线奖励：</label><label><input type="checkbox" style="cursor: pointer;" id="enable_recommend"/>启用</label>&nbsp;&nbsp;&nbsp;推荐时间仅限于<input style="width:166px"  class="time text" id="recommendtime" value="' + vconfig[0].recommend_time + '"/>之后<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;下线用户认证条件&nbsp;>><label><input type="checkbox" style="cursor: pointer;" id="recommend_emailverified"/>邮箱验证</label>&nbsp;&nbsp;&nbsp;<label><input type="checkbox" style="cursor: pointer;" id="recommend_telverified"/>手机验证</label>' +
      '<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;推荐人每推荐一位奖励&nbsp;>><label><input type="checkbox" style="cursor: pointer;" id="enable_usertype4"/>提升用户组</label>&nbsp;<select id="usertype4">' + vUType + '</select>&nbsp;&nbsp;&nbsp;<label><input type="checkbox" style="cursor: pointer;" id="enable_rewardmoney4"/>奖励金额</label>&nbsp;<input type="text" id="rewardmoney4" style="width:60px" value="' + vconfig[4].rewardmoney + '" class="text"/>(注册或者包括下线人认证后，推荐人奖励设置)' +
      '<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;下线用户购买指定产品&nbsp;>><input type="button" class="button" value="选择产品" id="btnproduct5">&nbsp;<input style="width:200px;" type="text" class="text" value="' + vconfig[5].products + '" id="products5"><label>&nbsp;推荐人奖励>><input type="checkbox" style="cursor: pointer;" id="enable_usertype5"/>提升用户组</label>&nbsp;<select id="usertype5">' + vUType + '</select>&nbsp;&nbsp;&nbsp;<label><input type="checkbox" style="cursor: pointer;" id="enable_rewardmoney5"/>奖励金额</label>&nbsp;<input type="text" id="rewardmoney5" style="width:60px" value="' + vconfig[5].rewardmoney + '" class="text"/>' +
      '<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;下线用户数量达到&nbsp;<input style="width:60px;" type="text" class="text" value="' + vconfig[6].referralcount + '" id="referralcount6">&nbsp;人，<label>推荐人奖励>><input type="checkbox" style="cursor: pointer;" id="enable_usertype6"/>提升用户组</label>&nbsp;<select id="usertype6">' + vUType + '</select>&nbsp;&nbsp;&nbsp;<label><input type="checkbox" style="cursor: pointer;" id="enable_rewardmoney6"/>奖励金额</label>&nbsp;<input type="text" id="rewardmoney6" style="width:60px" value="' + vconfig[6].rewardmoney + '" class="text"/>' +
      '</li></ul>';


        $("#jsContent").html(str);

        var usertypeorder = "";
        if (vconfig[0].usertypeorder.length > 0) {
            vUType = "";
            var utypeorderArr = vconfig[0].usertypeorder.split(',');
            for (var i = 0; i < utypeorderArr.length; i++) {
                usertypeorder += "<span id='utype" + utypeorderArr[i] + "'>>>" + $("#divutype").find("span[id=s" + utypeorderArr[i] + "]").text() + "</span>";
                vUType += '<option value ="' + utypeorderArr[i] + '">' + $("#divutype").find("span[id=s" + utypeorderArr[i] + "]").text() + '</option>';
            }
        }
        $("#usertypeorder").html(usertypeorder);
        $("select[id^=usertype]").html(vUType);


        $("#jsContent").find(".time").datepicker({
            dateFormat: "yy-mm-dd",
            changeMonth: true,
            changeYear: true,
            beforeShow: function (input, inst) {
                ctime = $(this).val();
                if (ctime.indexOf(' ') > 0) ctime = ctime.substring(ctime.indexOf(' ') + 1);
            },
            onClose: function (dateText, inst) {
                if (dateText.indexOf(' ') < 0) $(this).val(dateText + ' ' + ctime);
            }
        });
        $("#btnuser").click(function () {
            var suwin = $("#suwin");
            suwin.html(ajaxLoading("正在加载信息，请稍等..."));

            str = '<strong style="color:#116802;">请按由低到高的用户等级顺序进行选择：</strong>(如：普通用户>>初级代理>>高级用户)<br /><ul>';

            $(jsonUType).each(function (i) {
                str += '<li><label><input type="checkbox" name="chkusertype" value="' + jsonUType[i].Utype + '"/>' + jsonUType[i].tname + '</label></li>';
            });

            str += '</ul><div id="selorderuser" style="clear:both;padding-top:10px"></div><div style="clear:both;padding-top:10px;color:red">提示：<br>1、用户等级用于奖励提升用户组，防止用户降级！<br>2、用户等级必须全部由低到高的等级进行排序！</div>';
            suwin.html(str);

            $("input[name=chkusertype]").click(function () {
                if ($(this).prop("checked")) {
                    $("#selorderuser").append("<span id='utype" + $(this).val() + "'>>>" + $(this).parent().text() + "</span>");
                } else {
                    $("#selorderuser").find("#utype" + $(this).val() + "").remove();
                }
            });

            $("#usertypeorder").find("span").each(function () {
                $("input[name=chkusertype][value=" + $(this).attr("id").replace("utype", "") + "]").click();
            });

            suwin.dialog({ title: "配置用户等级", autoOpen: false, resizable: false, width: 550, height: 450, modal: true, buttons: { "确 定": function () {

                if (jsonUType.length != $("#selorderuser").find("span").length) {
                    alert("用户等级必须全部排序！");
                    return;
                }
                $("#usertypeorder").html($("#selorderuser").html());
                var voptions = "";
                $("#selorderuser").find("span").each(function () {
                    voptions += '<option value ="' + $(this).attr("id").replace("utype", "") + '">' + $(this).text().replace(">>", "") + '</option>';
                });
                $("select[id^=usertype]").html(voptions);

                for (var i = 1; i < vconfig.length; i++) {
                    if (vconfig[i].enable_usertype == "1") {
                        $("#usertype" + vconfig[i].id).val(vconfig[i].usertype);
                    }
                }

                $(this).dialog("close");

            }, "取 消": function () { $(this).dialog("close"); }
            }
            }).dialog("open");
        });


        $("#jsContent label.a").css({ "font-weight": "bold", 'float': 'left', 'text-align': 'right', 'width': '110px' });

        $("#ulconfig input[type=checkbox]").click(function () {
            var value = $(this).prop("checked") ? '1' : '0';
            $(this).val(value);
        });

        for (var i = 0; i < vconfig.length; i++) {
            $("#usertype" + vconfig[i].id).val(vconfig[i].usertype);

            if (vconfig[i].enable_usertype == "1") {
                $("#enable_usertype" + vconfig[i].id).click();
            } else {
                $("#enable_usertype" + vconfig[i].id).val(0);
            }
            if (vconfig[i].enable_rewardmoney == "1") {
                $("#enable_rewardmoney" + vconfig[i].id).click();
            } else {
                $("#enable_rewardmoney" + vconfig[i].id).val(0);
            }
        }

        if (vconfig[0].recommend_telverified == "1") {
            $("#recommend_telverified").click();
        } else {
            $("#recommend_telverified").val(0);
        }
        if (vconfig[0].recommend_emailverified == "1") {
            $("#recommend_emailverified").click();
        } else {
            $("#recommend_emailverified").val(0);
        }
        if (vconfig[0].enable_recommend == "1") {
            $("#enable_recommend").click();
        } else {
            $("#enable_recommend").val(0);
        }



        $("input[id^=btnproduct]").click(function () {
            selectProducts($(this).next().val(), $(this).attr("id"));
        });

        $("#swin").dialog({
            title: '编辑应用插件[#' + $("input[name=cid]").val() + ']', autoOpen: false, resizable: false, height: 600, width: 900, modal: true, buttons: {
                "保存配置": function () {

                    processing("正在保存，请稍候...");

                    if ($("#usertypeorder").html().length <= 0) {
                        showResults("请先配置用户等级", 2000, 'close');
                        return;
                    }


                    var ispost = true;
                    $("input[id^=rewardmoney]").each(function () {
                        var v = $(this).val().replace(/(^\s*)/g, "");
                        if (v.length > 0 && isNaN(v)) {
                            ispost = false;
                        }
                    });


                    if (!ispost) {
                        showResults("奖励金额必须为数字", 2000, 'close');
                        return;
                    }
                    var pattern = /^[0-9]*$/;
                    var referralcount = $("#referralcount6").val().replace(/(^\s*)/g, "");
                    if (referralcount.length > 0 && !pattern.test(referralcount)) {
                        showResults("推荐人数量必须为整数", 2000, 'close');
                        return;
                    }


                    if (($("#enable_usertype1").val() == "1" || $("#enable_rewardmoney1").val() == "1") && $("#rewardtime1").val().replace(/(^\s*)/g, "").length <= 0) {
                        showResults("注册时间不能为空", 2000, 'close');
                        setTimeout('$("#rewardtime1").focus();', 2000);
                        return;
                    }
                    if (($("#enable_usertype2").val() == "1" || $("#enable_rewardmoney2").val() == "1") && $("#rewardtime2").val().replace(/(^\s*)/g, "").length <= 0) {
                        showResults("认证时间不能为空", 2000, 'close');

                        setTimeout('$("#rewardtime2").focus();', 2000);
                        return;
                    }
                    if (($("#enable_usertype3").val() == "1" || $("#enable_rewardmoney3").val() == "1") && $("#rewardtime3").val().replace(/(^\s*)/g, "").length <= 0) {
                        showResults("购买时间不能为空", 2000, 'close');

                        setTimeout('$("#rewardtime3").focus();', 2000);
                        return;
                    }
                    if ($("#enable_recommend").val() == "1" && $("#recommendtime").val().replace(/(^\s*)/g, "").length <= 0) {
                        showResults("推荐时间不能为空", 2000, 'close');
                        setTimeout('$("#recommendtime").focus();', 2000);

                        return;
                    }

                    var utypeOrder = "";
                    $("#usertypeorder").find("span").each(function () {
                        utypeOrder += "," + $(this).attr("id").replace("utype", "");
                    });
                    utypeOrder = utypeOrder.substr(1);


                    var postdata = "[{\"id\":\"0\",\"usertypeorder\":\"" + utypeOrder + "\",\"recommend_telverified\":\"" + $("#recommend_telverified").val() + "\",\"recommend_emailverified\":\"" + $("#recommend_emailverified").val() + "\",\"enable_recommend\":\"" + $("#enable_recommend").val() + "\",\"recommend_time\":\"" + $("#recommendtime").val().replace(/(^\s*)/g, "") + "\"},{\"id\":\"1\",\"enable_usertype\":\"" + $("#enable_usertype1").val() + "\",\"usertype\":\"" + $("#usertype1").val() + "\",\"enable_rewardmoney\":\"" + $("#enable_rewardmoney1").val() + "\",\"rewardmoney\":\"" + $("#rewardmoney1").val().replace(/(^\s*)/g, "") + "\",\"time\":\"" + $("#rewardtime1").val() + "\"},{\"id\":\"2\",\"enable_usertype\":\"" + $("#enable_usertype2").val() + "\",\"usertype\":\"" + $("#usertype2").val() + "\",\"enable_rewardmoney\":\"" + $("#enable_rewardmoney2").val() + "\",\"rewardmoney\":\"" + $("#rewardmoney2").val().replace(/(^\s*)/g, "") + "\",\"time\":\"" + $("#rewardtime2").val() + "\"},{\"id\":\"3\",\"enable_usertype\":\"" + $("#enable_usertype3").val() + "\",\"usertype\":\"" + $("#usertype3").val() + "\",\"enable_rewardmoney\":\"" + $("#enable_rewardmoney3").val() + "\",\"rewardmoney\":\"" + $("#rewardmoney3").val().replace(/(^\s*)/g, "") + "\",\"products\":\"" + $("#products3").val().replace(/(^\s*)/g, "") + "\",\"time\":\"" + $("#rewardtime3").val() + "\"},{\"id\":\"4\",\"enable_usertype\":\"" + $("#enable_usertype4").val() + "\",\"usertype\":\"" + $("#usertype4").val() + "\",\"enable_rewardmoney\":\"" + $("#enable_rewardmoney4").val() + "\",\"rewardmoney\":\"" + $("#rewardmoney4").val().replace(/(^\s*)/g, "") + "\"},{\"id\":\"5\",\"enable_usertype\":\"" + $("#enable_usertype5").val() + "\",\"usertype\":\"" + $("#usertype5").val() + "\",\"enable_rewardmoney\":\"" + $("#enable_rewardmoney5").val() + "\",\"rewardmoney\":\"" + $("#rewardmoney5").val().replace(/(^\s*)/g, "") + "\",\"products\":\"" + $("#products5").val().replace(/(^\s*)/g, "") + "\"},{\"id\":\"6\",\"enable_usertype\":\"" + $("#enable_usertype6").val() + "\",\"usertype\":\"" + $("#usertype6").val() + "\",\"enable_rewardmoney\":\"" + $("#enable_rewardmoney6").val() + "\",\"rewardmoney\":\"" + $("#rewardmoney6").val().replace(/(^\s*)/g, "") + "\",\"referralcount\":\"" + referralcount + "\"}]";

                    $.post($("input[name=configvalue_jspath]").val() + 'index.ashx?action=setConfig&t=' + new Date(), { "config": postdata }, function (rdata) {
                        if (rdata == '1') {

                            save();
                        } else {
                            showResults(rdata, 2000, 'close');
                        }
                    });

                }, "关 闭": function () { $(this).dialog("close"); }
            }
        }).dialog("open");
    });

} configInit();


function selectProducts(vproducts, id) {
    var suwin = $("#suwin");
    suwin.html(ajaxLoading("正在加载信息，请稍等..."));
    $.post($("input[name=configvalue_jspath]").val() + 'index.ashx?action=getAllProductType&t=' + new Date(), function (data) {
        var ptData = $.parseJSON(data);
        var str = '<div id="tcPType"><strong style="color:#e91c00">一、请选择产品类型：</strong> <input onclick="window.open(\'?c=mproducts\',\'_blank\');" type="button" class="button" style="margin-left:10px" value="产品类型管理" /><br /><ul>';
        $(ptData).each(function (i) { str += '<li class="flbox"><label><input type="radio" name="ptype" value="' + ptData[i].ptid + '"/>' + ptData[i].ptname + '</label></li>'; });
        str += '</ul></div><div id="tcPgs" style="clear:both;padding-top:10px"></div><div id="tcProducts" style="clear:both;padding-top:10px"></div>';
        str += '<div style="clear:both;padding-top:10px"><strong>已选择的产品编号：</strong><input style="width:560px;" type="text" class="text" value="' + vproducts + '" id="selproducts"><input type="hidden" id="hidproducts" value=",' + vproducts + ',"/></div>';
        suwin.html(str);

        var pgs = suwin.find("#tcPgs");
        var products = suwin.find("#tcProducts");
        suwin.find("#tcPType input[name='ptype']").click(function () {
            pgs.html(ajaxLoading());
            var _ptype = $(this).val();
            var ptName = $(this).parent().text();
            var inputType = 'radio';
            $.getJSON("?c=ajax&a=true&dt=pglist&rt=json&id=" + _ptype + "&" + new Date(), function (rdata) {
                str = '<strong style="color:#0479d5;">二、请选择产品分组：</strong> <input onclick="window.open(\'?c=mproducts&pgtype=' + _ptype + '\',\'_blank\');" type="button" class="button" style="margin-left:10px" value="' + ptName + '产品管理" /><br /><ul>';
                $(rdata).each(function (i) {
                    str += '<li class="flbox"><label><input type="' + inputType + '" name="productgroup" value="' + rdata[i].pgid + '"/>' + rdata[i].pgid + '.' + rdata[i].pgname + '</label></li>';
                });
                str += '</ul>';
                pgs.html(str);

                pgs.find("input").click(function () {

                    products.html(ajaxLoading());
                    inputType = 'checkbox';
                    $.getJSON("?c=ajax&a=true&dt=product&rt=json&id=-1&p2=" + $(this).val() + "&" + new Date(), function (pdata) {
                        str = '<strong style="color:#116802;">三、请选择相关产品：</strong><br /><ul>';
                        if (pdata[0].isEmpty != 'true') {
                            $(pdata).each(function (i) {
                                str += '<li><label><input type="' + inputType + '" name="product" value="' + pdata[i].pid + '"/>' + pdata[i].pid + '.' + pdata[i].pname + '</label></li>';
                            });
                        }
                        str += '</ul>';
                        products.html(str);

                        var vArrProducts = $("#selproducts").val().split(',');
                        for (var i = 0; i < vArrProducts.length; i++) {
                            $("input[name=product][value=" + vArrProducts[i] + "]").click();
                        }
                        $("input[name=product]").click(function () {
                            if ($(this).prop("checked")) {
                                if ($("#hidproducts").val().indexOf("," + $(this).val() + ",") == -1) {
                                    $("#selproducts").val(($("#selproducts").val() != "" ? $("#selproducts").val() + ',' : "") + $(this).val());
                                    $("#hidproducts").val(($("#hidproducts").val() == "" ? "," : $("#hidproducts").val()) + $(this).val() + ',');
                                }
                            } else {
                                $("#hidproducts").val($("#hidproducts").val().replace("," + $(this).val() + ",", ","));
                                var hidproducts = $("#hidproducts").val();
                                hidproducts = hidproducts.substr(1, hidproducts.length - 2);
                                $("#selproducts").val(hidproducts);
                            }

                            var vArr = $("#selproducts").val().split(',');
                            var productids = vArr.sort(sortNumber)
                            $("#selproducts").val(productids);
                            $("#hidproducts").val("," + productids + ',');
                        });

                    });

                });
                pgs.find("input:radio:first").click();
            });
        });
        suwin.find("#tcPType input[name='ptype']:first").click();
        suwin.dialog({ title: "选择产品", autoOpen: false, resizable: false, width: 750, height: 550, modal: true, buttons: { "确 定": function () { $("#" + id).next().val($("#selproducts").val()); $(this).dialog("close"); }, "取 消": function () { $(this).dialog("close"); } } }).dialog("open");
    });
}
function sortNumber(a, b) {
    return a - b;
}



