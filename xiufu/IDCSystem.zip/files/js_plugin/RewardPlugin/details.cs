﻿/*
  {"name":"奖励插件","tag":"RewardPlugin","version":"1.04","build":"build(201501201407)"}
 */