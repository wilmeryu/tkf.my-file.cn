﻿var cs = rGet(curl, 'c');
if (cs == "" && curl.indexOf('/idcSystem.aspx') > -1) {
    $.post('$pluginpath$index.ashx?action=checkReg&t=' + new Date(), function (data) { });
}

if (cs == 'userinfo') {
    var mailTimer = setInterval(function () {
        if ($("#mainContent").html().indexOf('<a href="javascript:vmail(0);">『修改』</a>') > -1) {
            clearInterval(mailTimer);
            $.post('$pluginpath$index.ashx?action=checkVerified&t=' + new Date(), function (data) { });
        }
    }, 500);

    var mobileTimer = setInterval(function () {
        if ($("#mainContent").html().indexOf('<a href="javascript:vmobile(0);">『修改』</a>') > -1) {
            clearInterval(mobileTimer);
            $.post('$pluginpath$index.ashx?action=checkVerified&t=' + new Date(), function (data) { });
        }
    }, 500);
}


if (cs == 'myservice' && rGet(curl, 'id').length > 0) {
    $.post('$pluginpath$index.ashx?action=checkProduct&t=' + new Date(), function (data) { });
}


