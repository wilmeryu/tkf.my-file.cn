﻿$.post($("input[name=configvalue_jspath]").val() + 'index.ashx?action=getConfig&t=' + new Date(), function (data) {
    var vjson = $.parseJSON(data);
   
    var str = '<form action="index.ashx" id="sslform" name="sslform" style="margin-top:20px;"><table  border="0" cellspacing="0" cellpadding="0" style="margin-left:62px"><tbody>' +

        '<tr><td><label><input type="checkbox" style="cursor: pointer;" id="enable_ssl" name="enable_ssl"/>启用SSL访问域名列表：</label></td></tr><tr><td>&nbsp;<textarea cols="10" rows="10" class="text" style="width:468px;height:100px" id="domains" name="domains" ></textarea><p style="color:red;margin-top:-10px;">&nbsp;提示：多个域名之间以逗号,分隔，例如：a.com,b.com,c.com</p></td></tr></tbody></table></form>';


    $("#jsContent").html(str);
   
    $("#enable_ssl").click(function () {
        var value = $(this).prop("checked") ? '1' : '0';
        $(this).val(value);
    });
    if (vjson.enable_ssl == "1") {
        $("#enable_ssl").click();
    } else {
        $("#enable_ssl").val(0);
    }
    $("#domains").val(vjson.domains.replace(/(^\s*)/g, "").replaceAll('\\|', '\r'));



    $("#swin").dialog({
        title: '编辑应用插件[#' + $("input[name=cid]").val() + ']', autoOpen: false, resizable: false, height: 565, width: 810, modal: true, buttons: {
            "保存配置": function () {

                processing("正在保存，请稍候...");

                var postdata = "{\"enable_ssl\":\"" + $("#enable_ssl").val() + "\",\"domains\":\"" + $("#domains").val().replace(/(^\s*)/g, "").replaceAll('\n{1,}', '|').replaceAll('\r\n{1,}', '|') + "\"}";

                $.post($("input[name=configvalue_jspath]").val() + 'index.ashx?action=setConfig&t=' + new Date(), { "config": postdata }, function (rdata) {
                    if (rdata == '1') {
                        save();
                    } else {
                        showResults(rdata, 2000, 'close');
                    }
                });
            }, "关 闭": function () { $(this).dialog("close"); }
        }
    }).dialog("open");
});
