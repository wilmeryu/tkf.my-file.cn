﻿var cs = rGet(curl, 'c');
if (curl.indexOf('idcSystem.aspx') > -1 || curl.indexOf('idcsystem.aspx') > -1) {

    $.post('$pluginpath$index.ashx?action=getdomain&t=' + new Date(), function (data) {
        var json = $.parseJSON(data);
        if (json.enable_ssl == "1") {
            if (document.location.protocol == 'http:' && json.domains.length > 0) {
                var vArr1 = json.domains.split('|');
                var arrDomain = [];
                for (var i = 0; i < vArr1.length; i++) {
                    var vArr2 = vArr1[i].split(',');
                    for (var j = 0; j < vArr2.length; j++) {
                        if (vArr2[j] != undefined && vArr2[j].length > 0) {
                            arrDomain.push(vArr2[j]);
                        }
                    }
                }
                for (var i = 0; i < arrDomain.length; i++) {
                    if (document.location.href.indexOf(arrDomain[i]) > -1) {
                        window.location.href = document.location.href.replace(/http\:/, 'https:');
                    }
                }
            }
        }

    });

}
