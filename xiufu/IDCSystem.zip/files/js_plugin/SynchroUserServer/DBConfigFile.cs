<xml><apiIP><![CDATA[aasdasd]]></apiIP><apidbName><![CDATA[asdasd]]></apidbName><apiName><![CDATA[asdasd]]></apiName><apiPwd><![CDATA[asdas]]></apiPwd></xml>
