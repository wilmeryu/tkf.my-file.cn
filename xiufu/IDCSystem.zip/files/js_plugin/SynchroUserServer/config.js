﻿function configInit() {
    //  $("#jsContent").hide();
    $.post($("input[name=configvalue_jspath]").val() + '/index.ashx?action=getConfig&t=' + new Date(), function (data) {
 
        var apiIP = apidbName = apiName = apiPwd = '';
        if (data != 0) {
            var json = $.parseJSON(data);
            apiIP = json.apiIP;
            apidbName = json.apidbName;
            apiName = json.apiName;
            apiPwd = json.apiPwd;
        }
        var str = ' </br><strong>XenSystem数据库配置：</strong> ' +
            '<ul  >' +
      '<li><label>数据库地址：</label><input value="' + apiIP + '" type="text" id="api_ip" name="api_ip" style="width:320px" value="" class="text"/></li>' +
         '<li><label>数据库名：</label><input value="' + apidbName + '" type="text" id="api_dbName" name="api_dbName" style="width:320px" value="" class="text"/></li>' + 
      '<li><label>登录名：</label><input value="' + apiName + '" type="text" id="api_name" name="api_name" style="width:320px" value="" class="text"/></li>' + 
      '<li><label>登录密码：</label><input value="' + apiPwd + '" type="password" id="api_pwd" name="api_pwd" style="width:320px" value="" class="text"/></li>' +
      '</ul>'

        $("#jsContent").html(str);
        $("#jsContent label").css({ "font-weight": "bold", 'float': 'left', 'text-align': 'right', 'width': '130px' });
        $("#swin").dialog({
            title: '黑户VPS终结者', autoOpen: false, resizable: false, height: 500, modal: true, buttons: {
                "保存配置": function () { 
                    if ($("#api_ip").val().replace(/(^\s*)/g, "") != "●●●●●●●●●" || $("#api_dbName").val().replace(/(^\s*)/g, "") != "●●●●●●●●●" || $("#api_name").val().replace(/(^\s*)/g, "") != "●●●●●●●●●" || $("#api_pwd").val().replace(/(^\s*)/g, "") != "●●●●●●●●●") {
                        processing("正在保存，请稍候...");
                        var api_ip = $("#api_ip").val().replace(/(^\s*)/g, "");
                        var api_dbName = $("#api_dbName").val().replace(/(^\s*)/g, "");
                        var api_name = $("#api_name").val().replace(/(^\s*)/g, "");
                        var api_pwd = $("#api_pwd").val().replace(/(^\s*)/g, "");
                        if (api_ip == '' || api_dbName == '' || api_name == '' || api_pwd == '') {
                            showResults('请填写全部参数。', 2000, 'close'); return;
                        }
                        $.post($("input[name=configvalue_jspath]").val() + '/index.ashx?action=setConfig&t=' + new Date(), { "api_ip": api_ip, "api_dbName": api_dbName, "api_name": api_name, "api_pwd": api_pwd }, function (rdata) {
                            if (rdata == '1') {
                                showResults('保存成功', 2000, 'close');
                                $("#swin").dialog("close");
                            } else {
                                showResults(rdata, 2000, 'close');
                            }
                        });
                    } else {
                        $("#swin").dialog("close");
                    }
                }, "关 闭": function () { $(this).dialog("close"); }
            }
        }).dialog("open");
  });

} configInit();


