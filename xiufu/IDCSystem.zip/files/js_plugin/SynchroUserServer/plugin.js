﻿function SynchroUserServerInit() {
    if (curl.indexOf('idcSystem.aspx') > -1) {
        var cs = rGet(curl, 'c');
        if (cs == 'mservice') {
            $('div[class="buttonList"]').children().first().before('<a href="javascript:ChekSynchroUserServerr();">VPS数量检查</a>');
        }
    }
} SynchroUserServerInit();

function ChekSynchroUserServerr() {
    var str = '<div style="width:200px;height:30px;margin-top:10px;margin-left:50px;"><strong>检测黑户VPS，确定继续执行</strong></div>';
    suwin.html(str);
    suwin.dialog({
        title: "VPS数量检查：",
        autoOpen: false,
        resizable: false,
        width: 320,
        height: 188,
        modal: true,
        buttons: {
            "确   定": function () {
                processing("正在处理中,请稍候...");
                $.post('$pluginpath$index.ashx?action=SynchroUserServer&t=' + new Date(), function (objJosn) {
                    if (objJosn.indexOf('ErrorMesage') > 0) {
                        objJosn = objJosn.replace('-1|ErrorMesage:', '');
                        showResults("<strong>" + objJosn + "</strong>", 3000, 'close'); return;
                    } else if (objJosn == "ok") {
                        showResults("<strong>检查结果正常。</strong>", 3000, 'close'); return;
                    } else {
                        $("#processing").dialog("close");
                    }
                    var htmlstr = '<table width="100%" border="0" cellspacing="0" cellpadding="0" class="table">' +
                        '<tr><th>编号</th><th>操作系统</th><th>IP地址</th></tr>';
                    var modelList = objJosn.split("^");
                    modelList.forEach(function (model) {
                        model = $.parseJSON(model);
                        htmlstr += '<tr><td>' + model.vid + '</td><td class="ct">' + model.vos + '<td class="ct">' + model.vip + '</td></tr>'
                    });
                    htmlstr += '</table>';

                    swin.html(htmlstr);
                    swin.dialog({
                        title: 'IDCSystem不存在而XenSystem存在的VPS列表：',
                        autoOpen: false,
                        resizable: false,
                        width: 600,
                        height: 400,
                        modal: true,
                        buttons: {
                            '关闭': function () {
                                $(this).dialog("close");
                            }
                        }
                    }).dialog("open");
                });
            },
            "取   消": function () { suwin.dialog("close"); }
        }
    }).dialog("open");
}