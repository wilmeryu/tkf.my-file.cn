﻿$.post($("input[name=configvalue_jspath]").val() + 'index.ashx?c=getticketconfig&t=' + new Date(), function (data) {
    var vjson = $.parseJSON(data);
    var str = '<strong>配置POP3邮件服务器：</strong>' +
   '<ul style="margin-top:20px;"><li style="height: 10px;"><label style="font-weight: bold; float: left; text-align: right; width: 100px;">帐号：</label><input type="text" class="text" id="pop3username" name="pop3username" style="width:180px" value="' + vjson.pop3username + '"/></li>' +
'<li style="height: 30px;"><li style="height: 10px;"><label style="font-weight: bold; float: left; text-align: right; width: 100px;">密码：</label><input type="text" class="text" id="pop3pwd" name="pop3pwd" style="width:180px" value="' + vjson.pop3pwd + '"/></li>' +
'<li style="height: 30px;"><li style="height: 10px;"><label style="font-weight: bold; float: left; text-align: right; width: 100px;">POP3服务器：</label><input type="text" class="text" id="pop3server" name="pop3server" style="width:180px" value="' + vjson.pop3server + '"/></li>' +
'<li style="height: 30px;"><li style="height: 10px;"><label style="font-weight: bold; float: left; text-align: right; width: 100px;">端口：</label><input type="text" class="text" id="pop3port" name="pop3port" style="width:180px" value="' + vjson.pop3port + '"/></li>' +

'<li style="height: 30px;"><li style="height: 10px;"><label style="font-weight: bold; float: left; text-align: right; width: 100px;">启用SSL：</label><input type="checkbox" checked="checked" style="cursor: pointer;" name="pop3ssl" id="pop3ssl"/></li></ul>' +
'<p style="margin-top:20px;margin-left:100px"><input type="button" id="btnsavepop3" class="button" value="检查邮件接收服务器是否正常"></p>';
    $("#jsContent").html(str);
    if (vjson.pop3ssl == "0") {
        $("#pop3ssl").removeAttr("checked");
        $("#pop3ssl").val(0);
    } else {
        $("#pop3ssl").val(1);
    }
    
    $("input[name=cstatus][value=" + vjson.cstatus + "]").attr("checked", "checked");



    $("#pop3ssl").click(function () {
        var value = $(this).prop("checked") ? '1' : '0';
        $(this).val(value);
    });

    $("#btnsavepop3").click(function () {
        processing("正在检查邮件服务器，请稍候...");

        var vArgs = {
            "pop3username": $("#pop3username").val(),
            "pop3pwd": $("#pop3pwd").val(),
            "pop3server": $("#pop3server").val(),
            "pop3port": $("#pop3port").val(),
            "pop3ssl": $("#pop3ssl").val(),
            "cstatus": $("input[name=cstatus]:checked").val()
        };
        $.post($("input[name=configvalue_jspath]").val() + 'index.ashx?c=savepop&t=' + new Date(), vArgs, function (rdata) {
            if (rdata == '0') {
                showResults('邮件服务器状态正常', 3000, 'close');
            } else {
                showResults(rdata, 5000, 'close');
            }
        });
    });

    $("input[name=cstatus]").click(function () {
        processing("正在执行操作，请稍候...");

        var vArgs = {
            "pop3username": $("#pop3username").val(),
            "pop3pwd": $("#pop3pwd").val(),
            "pop3server": $("#pop3server").val(),
            "pop3port": $("#pop3port").val(),
            "pop3ssl": $("#pop3ssl").val(),
            "cstatus": $(this).val()
        };

        $.post($("input[name=configvalue_jspath]").val() + 'index.ashx?c=setenable&t=' + new Date(), vArgs, function (rdata) {
            if (rdata == '0') {
                showResults('操作成功', 3000, 'close');
            } else {
                showResults(rdata, 5000, 'close');
            }
        });

    });
});