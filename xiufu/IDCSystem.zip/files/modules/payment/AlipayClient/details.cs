﻿/*
  {"name":"支付宝即时到帐客户端","tag":"AliPayClient","version":"1.02","build":"build(201604121407)"}
 */