﻿/// <reference path="/modules/js/jquery-vsdoc.js" />
/// <reference path="/modules/js/jquery-ui.min.js" />
function _pm_init() {
    var swin = $("#swin");
    swin.find("#paymentDescription").html('&nbsp;');
    swin.find("#btn_add").remove();
    var userAPIid = paymentData[0].cconfig.userAPIid == undefined ? '' : paymentData[0].cconfig.userAPIid;
    var userAPIKey = paymentData[0].cconfig.userAPIKey == undefined ? '' : paymentData[0].cconfig.userAPIKey;
    var Email = paymentData[0].cconfig.Email == undefined ? '' : paymentData[0].cconfig.Email;
    var Description = paymentData[0].cconfig.Description == undefined ? '' : paymentData[0].cconfig.Description;
    var feerate = ((1 - parseFloat(vfeerate)) * 100).toFixed(2).replace('.00', '');

    var str = '<li><label>用户编号：</label><input type="hidden" name="cname_001" value="userAPIid"/><input class="text" type="text" name="cvalue_001" value="' + userAPIid + '"/> </li>' +
    '<li><label>API接口密钥：</label><input type="hidden" name="cname_002" value="userAPIKey"/><input class="text" type="text" name="cvalue_002" value="' + userAPIKey + '"/></li>' +
    '<li><label>支付宝账号：</label><input type="hidden" name="cname_003" value="Email"/><input class="text" type="text" name="cvalue_003" value="' + Email + '"/></li>' +
    '<li><label>支付时显示描述：</label><input type="hidden" name="cname_004" value="Description"/><input class="text" type="text" name="cvalue_004" value="' + Description + '"/></li>' +
    '<li><label>接口手续费：</label>' + feerate + '%</li>';
    var paramList = swin.find("#paramList");
    paramList.html(str);
    swin.height("415px");
    paramList.find("li").css({ "height": "30px", "line-height": "30px" });
    paramList.find("label").css({ "font-weight": "bold", "float": "left", "text-align": "right", "width": "116px", "height": "30px", "line-height": "30px", "cursor": "default" });
    paramList.find(".text").css({ "width": "260px" }); paramList.find(".path").css({ "width": "330px" });


    swin.dialog({ title: $(".ui-dialog-title").text(), autoOpen: false, resizable: false, width: 568, height: 550, modal: true, buttons: { "保存(Ctrl+Enter)": function () {
        processing("正在保存，请稍候...");
        var userid = $("input[name=cvalue_001]").val();
         var key = $("input[name=cvalue_002]").val();
          var email = $("input[name=cvalue_003]").val();
        if (userid == '') {
            showResults('请填写用户编号。', 2000, 'close'); return;
        } else if (key == '') {
            showResults('请填写API接口密钥。', 2000, 'close'); return;
        } else if (email == '') {
            showResults('请填写支付宝账号。', 2000, 'close'); return;
        }
        var path = $("input[name=configvalue_module]").val();
        if (path.indexOf('index.ashx') == -1) path += 'index.ashx';
        $.getScript(path + "?gaction=checkuser&userid=" + userid + "&k="+key+"&email="+email+"&t=" + new Date(), function () {
           
            if (vresult == '1') {
                save(0);
            } else {
                showResults(vresult, 2000, '');
            }
        });

    }, "关 闭": function () { $(this).dialog("close"); }
    }
    }).dialog("open");


}
_pm_init();