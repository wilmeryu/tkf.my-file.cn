﻿/// <reference path="/modules/js/jquery-vsdoc.js" />
/// <reference path="/modules/js/jquery-ui.min.js" />
function _pm_init() {
    suwin.find("#paymentDescription").html('&nbsp;');

    var Email = paymentData[0].rcvalue.Email == undefined ? '' : paymentData[0].rcvalue.Email;
    var Description = paymentData[0].rcvalue.Description == undefined ? '' : paymentData[0].rcvalue.Description;
    var feerate = ((1 - parseFloat(vfeerate)) * 100).toFixed(2).replace('.00', '');
    var str = '<li><label>支付宝账号：</label><input type="hidden" name="cname_003" value="Email"/><input class="text" type="text" name="cvalue_003" value="' + Email + '"/></li>' +
    '<li><label>支付时显示描述：</label><input type="hidden" name="cname_004" value="Description"/><input class="text" type="text" name="cvalue_004" value="' + Description + '"/></li>'+
    '<li><label>接口手续费：</label>' + feerate + '%</li>';
    var paramList = suwin.find("#paramList");
    paramList.html(str);
//    paramList.find("li").css({ "height": "30px" });
//    paramList.find("label").css({ "float": "left", "font-weight": "bold", "text-align": "right", "width": "138px" });
    //    paramList.find(".text").css({ "width": "328px" });
    paramList.find("li").css({ "height": "30px", "line-height": "30px" });
    paramList.find("label").css({ "font-weight": "bold", "float": "left", "text-align": "right", "width": "130px", "height": "30px", "line-height": "30px", "cursor": "default" });
    paramList.find(".text").css({ "width": "260px" }); paramList.find(".path").css({ "width": "330px" });
}

_pm_init();