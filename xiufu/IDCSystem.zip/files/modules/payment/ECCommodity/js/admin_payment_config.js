﻿
function _pm_init() {
    var swin = $("#swin");
    swin.find("#paymentDescription").html('&nbsp;');
    swin.find("#btn_add").remove();
    var CommodityUrl = paymentData[0].cconfig.CommodityUrl == undefined  ? '' : paymentData[0].cconfig.CommodityUrl;
    var str = '<li><label>目标地址：</label><input type="hidden" name="cname_001" value="CommodityUrl"/><input class="text" type="text" name="cvalue_001" value="' + CommodityUrl + '"/></li> <li><label>支付模块版本号：</label>Ver 1.0 build(201310211538)';
    var paramList = swin.find("#paramList");
    paramList.html(str);
    paramList.find("li").css({ "height": "30px", "line-height": "30px" });
    paramList.find("label").css({ "font-weight": "bold", "float": "left", "text-align": "right", "width": "116px", "height": "30px", "line-height": "30px", "cursor": "default" });
    paramList.find(".text").css({ "width": "370px" }); paramList.find(".path").css({ "width": "330px" });
 
}

_pm_init();
