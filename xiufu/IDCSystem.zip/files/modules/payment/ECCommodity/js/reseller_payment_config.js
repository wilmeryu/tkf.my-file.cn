﻿function _pm_init() {
    suwin.find("#paymentDescription").html('&nbsp;');
    var CommodityUrl = paymentData[0].rcvalue.CommodityUrl == undefined  ? '' : paymentData[0].rcvalue.CommodityUrl;

    //resellerCommodityUrl
    var str = '<li><label>目标地址：</label><input type="hidden" name="cname_000" value="CommodityUrl"/><input class="text" type="text" name="cvalue_000" value="' + CommodityUrl + '"/> <li><label>支付模块版本号：</label>Ver 1.0 build(201310211538)';
    var paramList = suwin.find("#paramList");
    paramList.html(str);
    
    paramList.find("li").css({ "height": "30px", "line-height": "30px" });
    paramList.find("label").css({ "font-weight": "bold", "float": "left", "text-align": "right", "width": "130px", "height": "30px", "line-height": "30px", "cursor": "default" });
    paramList.find(".text").css({ "width": "260px" }); paramList.find(".path").css({ "width": "330px" });
}

_pm_init();


