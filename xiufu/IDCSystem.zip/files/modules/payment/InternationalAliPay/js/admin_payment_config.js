﻿/// <reference path="/modules/js/jquery-vsdoc.js" />
/// <reference path="/modules/js/jquery-ui.min.js" />
function _pm_init() {
    var swin = $("#swin");
    swin.find("#paymentDescription").html('&nbsp;');
    swin.find("#btn_add").remove();
    var Email = paymentData[0].cconfig.Email == undefined ? '' : paymentData[0].cconfig.Email;
    var PartnerID = paymentData[0].cconfig.PartnerID == undefined ? '' : paymentData[0].cconfig.PartnerID;
    var Key = paymentData[0].cconfig.Key == undefined ? '' : paymentData[0].cconfig.Key;
    var Description = paymentData[0].cconfig.Description == undefined ? '' : paymentData[0].cconfig.Description;
    var str = '<li><label>签约支付宝账号：</label><input type="hidden" name="cname_001" value="Email"/><input class="text" type="text" name="cvalue_001" value="' + Email + '"/></li>' +
     '<li><label>合作身份者ID：</label><input type="hidden" name="cname_002" value="PartnerID"/><input class="text" type="text" name="cvalue_002" value="' + PartnerID + '"/></li>' +
    '<li><label>交易安全检验码：</label><input type="hidden" name="cname_003" value="Key"/><input class="text" type="text" name="cvalue_003" value="' + Key + '"/></li>' +
    '<li><label>支付时显示描述：</label><input type="hidden" name="cname_004" value="Description"/><input class="text" type="text" name="cvalue_004" value="' + Description + '"/></li>' +
    '<li><label>支付模块版本号：</label>Ver 1.0 build(201407221407)</li>';
    var paramList = swin.find("#paramList");
    paramList.html(str);
    swin.height("415px");
    paramList.find("li").css({ "height": "30px", "line-height": "30px" });
    paramList.find("label").css({ "font-weight": "bold", "float": "left", "text-align": "right", "width": "126px", "height": "30px", "line-height": "30px", "cursor": "default" });
    paramList.find(".text").css({ "width": "260px" }); paramList.find(".path").css({ "width": "330px" });
}
_pm_init();