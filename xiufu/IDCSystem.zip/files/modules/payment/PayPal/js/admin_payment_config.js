﻿function paypalInit() {
    var swin = $("#swin").dialog({ height: 560, width: 550 });

    swin.find("#paymentDescription").remove();
    swin.find("#btn_add").remove();
    var paypalUserNme = paymentData[0].cconfig.paypalUserNme == undefined ? '' : paymentData[0].cconfig.paypalUserNme;
    var paypalUserPwd = paymentData[0].cconfig.paypalUserPwd == undefined ? '' : paymentData[0].cconfig.paypalUserPwd;
    var signature = paymentData[0].cconfig.signature == undefined ? '' : paymentData[0].cconfig.signature;
    var BRANDNAME = paymentData[0].cconfig.BRANDNAME == undefined ? '' : paymentData[0].cconfig.BRANDNAME;
    var exchangeRate = paymentData[0].cconfig.exchangeRate == undefined ? '' : paymentData[0].cconfig.exchangeRate;
    var currencyCode = paymentData[0].cconfig.currencyCode == undefined ? '' : paymentData[0].cconfig.currencyCode;
    var str = '<li><label>PayPal用户名：</label><input type="hidden" name="cname_001" value="paypalUserNme"/>' +
                '<input class="text" type="text" name="cvalue_001" value="' + paypalUserNme + '"/></li>' +
                '<li><label>PayPal密    码：</label><input type="hidden" name="cname_002" value="paypalUserPwd"/>' +
                '<input class="text" type="password" name="cvalue_002" value="' + paypalUserPwd + '"/></li>' +
                '<li><label>PayPal签    名：</label><input type="hidden" name="cname_003" value="signature"/>' +
                '<input class="text" type="text" name="cvalue_003" value="' + signature + '"/></li>' +
                '<li><label>支付时显示名称：</label><input type="hidden" name="cname_004" value="BRANDNAME"/>' +
                '<input class="text" type="text" name="cvalue_004" value="' + BRANDNAME + '"/></li>' +
                '<li><label>人 民 币 汇 率：</label><input type="hidden" name="cname_005" value="exchangeRate"/>' +
                '<input class="text" type="text" name="cvalue_005" value="' + exchangeRate + '"/></li>' +
                '<li><label>请选择收款币种：</label><input type="hidden" name="cname_006" value="currencyCode"/>' +
                '<select id="currencyCode"  >' +
                '<option value ="USD">美元</option> ' +
                '<option value ="HKD">港币</option> ' +
                '<option value ="EUR">欧元</option> ' +
                '<option value ="GBP">英镑</option> ' +
                '<option value ="CHF">瑞士法郎</option> ' +
                '<option value ="AUD">澳元</option> ' +
                '<option value ="TWD">新台币</option> ' +
                '<option value ="JPY">日圆</option> ' +
                '</select><input type="hidden" name="cvalue_006" id="currencyCodeVal" value="' + currencyCode + '"/> </li>' +
        '<li><label>支付模块版本号：</label> Ver 1.0 build(20140106094516)'
    var paramList = swin.find("#paramList");
    paramList.html(str);
    paramList.find("li").css({ "height": "30px", "line-height": "30px" });
    paramList.find("label").css({ "font-weight": "bold", "float": "left", "text-align": "right", "width": "145px", "height": "30px", "line-height": "30px", "cursor": "default" });
    paramList.find(".text").css({ "width": "350px" });
    if (currencyCode != '') {
        $("#currencyCode").val(currencyCode);
    }
    $("#currencyCode").change(function () {
        $('#currencyCodeVal').val($("#currencyCode").val());
    });

    $("input[name='cvalue_005']").blur(function () {
        if (isNaN($("input[name='cvalue_005']").val())) {
            processing("请输入一个正确的汇率。"); showResults("请输入一个正确的汇率。", 2000, 'close')
            $("input[name='cvalue_005']").val('');
        }
    });
}
paypalInit();