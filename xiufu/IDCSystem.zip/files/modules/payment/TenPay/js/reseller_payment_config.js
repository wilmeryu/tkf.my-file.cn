﻿/// <reference path="/modules/js/jquery-vsdoc.js" />
/// <reference path="/modules/js/jquery-ui.min.js" />
function _pm_init() {
    suwin.find("#paymentDescription").html('&nbsp;');
    var MerchantID = paymentData[0].rcvalue.MerchantID == undefined ? '' : paymentData[0].rcvalue.MerchantID;
    var Key = paymentData[0].rcvalue.Key == undefined ? '' : paymentData[0].rcvalue.Key;
    var Description = paymentData[0].rcvalue.Description == undefined ? '' : paymentData[0].rcvalue.Description;

    var str = '<li><label>财付通商户号：</label><input type="hidden" name="cname_000" value="MerchantID"/><input class="text" type="text" name="cvalue_000" value="' + MerchantID + '"/></li>' +
              '<li><label>财付通商户密钥：</label><input type="hidden" name="cname_001" value="Key"/><input class="text" type="text" name="cvalue_001" value="' + Key + '"/></li>' +
              '<li><label>支付时显示描述：</label><input type="hidden" name="cname_002" value="Description"/><input class="text" type="text" name="cvalue_002" value="' + Description + '"/></li>' +
              '<li><label>支付模块版本号：</label>Ver 1.0 build(201407221407)</li>';
    var paramList = suwin.find("#paramList");
    paramList.html(str);
    paramList.find("li").css({ "height": "30px", "line-height": "30px" });
    paramList.find("label").css({ "font-weight": "bold", "float": "left", "text-align": "right", "width": "130px", "height": "30px", "line-height": "30px", "cursor": "default" });
    paramList.find(".text").css({ "width": "260px" }); paramList.find(".path").css({ "width": "330px" });
}

_pm_init();
