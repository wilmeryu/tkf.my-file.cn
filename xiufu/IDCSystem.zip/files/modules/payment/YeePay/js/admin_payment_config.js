﻿/// <reference path="/modules/js/jquery-vsdoc.js" />
/// <reference path="/modules/js/jquery-ui.min.js" />
function _pm_init() {
    var swin = $("#swin");
    swin.find("#paymentDescription").html('&nbsp;');
    swin.find("#btn_add").remove();
    var MerchantID = paymentData[0].cconfig.MerchantID == undefined ? '' : paymentData[0].cconfig.MerchantID;
    var Key = paymentData[0].cconfig.Key == undefined ? '' : paymentData[0].cconfig.Key;
    var Description = paymentData[0].cconfig.Description == undefined ? '' : paymentData[0].cconfig.Description;

    var str = '<li><label>易宝商户编号：</label><input type="hidden" name="cname_001" value="MerchantID"/><input class="text" type="text" name="cvalue_001" value="' + MerchantID + '"/></li>' +
              '<li><label>易宝商户密钥：</label><input type="hidden" name="cname_002" value="Key"/><input class="text" type="text" name="cvalue_002" value="' + Key + '"/></li>' +
              '<li><label>支付时显示描述：</label><input type="hidden" name="cname_003" value="Description"/><input class="text" type="text" name="cvalue_003" value="' + Description + '"/></li>'+
              '<li><label>支付模块版本号：</label>Ver 1.0 build(201407221407)</li>';
    var paramList = swin.find("#paramList");
    paramList.html(str);
    paramList.find("li").css({ "height": "30px", "line-height": "30px" });
    paramList.find("label").css({ "font-weight": "bold", "float": "left", "text-align": "right", "width": "116px", "height": "30px", "line-height": "30px", "cursor": "default" });
    paramList.find(".text").css({ "width": "260px" }); paramList.find(".path").css({ "width": "330px" });
}

_pm_init();
