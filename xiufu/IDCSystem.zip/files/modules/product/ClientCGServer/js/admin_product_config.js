﻿/// <reference path="jquery.min.js" />
function baseConfig() {
    var AllProducts = productData[0].pconfig.AllProducts == undefined ? '' : productData[0].pconfig.AllProducts;
  
    $.post("?c=module&productid=" + productData[0].pid + "&show=text&caction=getAllProducts&t=" + new Date(), function (data) {
        if (data.indexOf('-1|') == "0") {
            $("#ProductConfig").html("<div style='color:red;font-size:14px; text-align:center;margin-top:50px;'>" + data + "</div>");
            return;
        }
        var str = '<input type="hidden" name="config_AllProducts" id="config_AllProducts" value="' + AllProducts + '"/><div id="params" class="ui-accordion ui-widget ui-helper-reset ui-accordion-icons" role="tablist">';
        var arrConfig = $.parseJSON(data);
        for (var i = 0, len = arrConfig.length; i < len; i++) {
            var strConfig = '<table width="100%" class="table"><tr style="background-color:#E7E7E7;height:22px;line-height:22px;">' +
                    '<th style="width:130px;">产品参数</th><th style="width:120px;">自定义产品价格</th><th style="width:120px;">成本价格</th><th style="width:170px;">自定义升级IP价格(月付)</th><th style="width:150px;">升级IP成本价格(月付)</th></tr>';

            var product = arrConfig[i];
            var productPrice = product.pprice.split('_');
            var primeCost = '';

            primeCost += "月付：" + parseFloat(productPrice[0]) + " 元<br/>";
            primeCost += "季付：" + parseFloat(productPrice[1]) + " 元<br/>";
            primeCost += "年付：" + parseFloat(productPrice[2]) + " 元<br/>";


            //IP格式：ip编号_ip数量_ip价格

            var productname = product.name;

            var arrPrice = [0, 0, 0];
            var arrUpgradeIP = [];
            var vproductconfig = getProductFromProducts(product.pid);
            if (vproductconfig != '') {
                arrPrice = vproductconfig.pprice.split('_');
                arrUpgradeIP = vproductconfig.upgradeip.split('|');
                productname = vproductconfig.name;
            }


            var vIpPrimeCost = '无', vUpgradeip = '无', vMonthIp = "0_0_0";
            if (product.upgradeip != '0_0_0') {
                var arrProductIP = product.upgradeip.split('|');
                vMonthIp = arrProductIP[0];
                vIpPrimeCost = '';
                vUpgradeip = '';
                for (var j = 1; j < arrProductIP.length; j++) {
                    var ipInfo = arrProductIP[j].split('_');
                    vIpPrimeCost += ipInfo[1] + "个IP：" + (parseFloat(ipInfo[2]) == 0 ? '免费' : ipInfo[2] + "元") + "<br>";

                    var isfind = false;
                    for (var k = 0; k < arrUpgradeIP.length; k++) {
                        var upgradeIpInfo = arrUpgradeIP[k].split('_');
                        if (ipInfo[0] == upgradeIpInfo[0]) {
                            vUpgradeip += ipInfo[1] + '个IP：<input class="text" style="width:50px;" type="text" name="ip_' + ipInfo[0] + '_' + ipInfo[1] + '" value="' + (upgradeIpInfo[2] == 0 ? "" : upgradeIpInfo[2]) + '"/> 元<br/>';
                            isfind = true;
                            break;
                        }
                    }
                    if (!isfind) vUpgradeip += ipInfo[1] + '个IP：<input class="text" style="width:50px;" type="text" name="ip_' + ipInfo[0] + '_' + ipInfo[1] + '" value=""/> 元<br/>';
                }
            }


            var vdesc = htmlDecode(product.description.replaceAll("\r\n", "<br>").replaceAll("- ", "")).split('<br>');

            strConfig += '<tr height="25" align="center" class="trdata" id="' + product.pid + '">' +
                '<td style="width:160px;"><label for="' + i + '">CPU:' + vdesc[0].toUpperCase().replaceAll("CPU", "") + '<br>内存:' + vdesc[1].toUpperCase().replaceAll("RAM", "") + '<br>硬盘:' + vdesc[2].toUpperCase().replaceAll("HDD", "") + '<br>带宽:' + vdesc[3] + '<br>IP数:' + vdesc[4].toUpperCase().replaceAll("USABLE IPS", "个") + '</label><input type="hidden" name="vdesc' + product.pid + '" id="vdesc' + product.pid + '" value="' + htmlDecode(product.description.replaceAll("\r\n", "<br>").replaceAll("- ", "")) + '"/></td><td style="width:120px;"><label for="' + i + '">月付：<input class="text" style="width:50px;" type="text" name="monthly" value="' + (arrPrice[0] == 0 ? "" : arrPrice[0]) + '"/> 元<br/>季付：<input class="text" style="width:50px;" type="text" name="quarterly" value="' + (arrPrice[1] == 0 ? "" : arrPrice[1]) + '"/> 元<br>年付：<input class="text" style="width:50px;" type="text" name="annually" value="' + (arrPrice[2] == 0 ? "" : arrPrice[2]) + '"/> 元</label></td><td style="width:120px;"><label for="' + i + '">' + primeCost + '</label></td><td style="width:150px;"><label for="' + i + '">' + vUpgradeip + '</label><input type="hidden" name="upgradeip" value="' + vMonthIp + '"/></td><td style="width:150px;"><label for="' + i + '">' + vIpPrimeCost + '</label></td></tr>';
            strConfig += '<tr height="25" align="center"><td colspan="5"><span style="color:red">重要提示：</span>自定义产品价格填写"0"或者留空，表示禁止购买，如：月付价格填写"0"或者留空，表示禁止购买月付产品<br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(自定义升级IP价格也一样)</td><tr>';
            strConfig += '</table>';

            str += '<h3 class="ui-accordion-header ui-helper-reset ui-state-default ui-corner-top" role="tab" aria-expanded="true" aria-selected="true" tabindex="0"><span></span><a href="#"></a><input class="text" id="productname' + product.pid + '" style="width:270px;margin-top:-3px;" type="text" value="' + productname + '"/></h3>' +
    '<div class="ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom ui-accordion-content-active" role="tabpanel">' + strConfig + '</div>';
        }

        $("#ProductConfig").html(str);
        var paramsDiv = $("#params");
        paramsDiv.accordion({
            autoHeight: false,
            collapsible: true,
            active: 0
        });
        $(".ui-accordion-content").height("270px");

        suwin.dialog({
            title: '产品[#' + productData[0].pid + ']参数设置', width: 850,
            height: 600,
            buttons: {
                "保存参数设置": function () { setProducts(); },
                "关 闭": function () { $(this).dialog("close"); },
                "管理产品模块": function () { window.open('?c=mmodules&mt=product&cid=' + swin.find("select[name='module']").val(), '_blank'); }
            }
        });

    });
}

baseConfig();

function getProductFromProducts(pid) {
    var product = "";
    var AllProducts = productData[0].pconfig.AllProducts == undefined ? '' : productData[0].pconfig.AllProducts;
    if (AllProducts != '') {
        var arrPrducts = $.parseJSON(AllProducts.replace(/\?/g, '"'));
        for (var i = 0, len = arrPrducts.length; i < len; i++) {
            if (arrPrducts[i].pid == pid) {
                product = arrPrducts[i];
                break;
            }
        }
    }
    return product;
}

function setProducts() {
    var param = '[';
    $("tr.trdata").each(function (index, trObj) {
        var monthly = parseFloat($(trObj).find('input[name=monthly]').val());
        monthly = isNaN(monthly) == true ? 0 : monthly;

        var quarterly = parseFloat($(trObj).find('input[name=quarterly]').val());
        quarterly = isNaN(quarterly) == true ? 0 : quarterly;

        var annually = parseFloat($(trObj).find('input[name=annually]').val());
        annually = isNaN(annually) == true ? 0 : annually;
            var upgradeip = $(trObj).find('input[name=upgradeip]').val();
            $(trObj).find('input[name^=ip]').each(function (index, obj) {
                var ipprice = $(obj).val() == '' ? 0 : $(obj).val();
                if (isNaN(ipprice)) ipprice = 0;
                upgradeip += "|" + $(obj).attr("name").substr(3) + "_" + ipprice;
            });

            param += "{?pid?:?" + $(this).attr("id") + "?,?name?:?" + $("#productname" + $(this).attr("id")).val() + "?,?description?:?" + $("#vdesc" + $(this).attr("id")).val() + "?,?pprice?:?" + monthly + "_" + quarterly + "_" + annually + "?,?upgradeip?:?" + upgradeip + "?},";
        
    });
    if (param.length > 1)
        param = param.substring(0, param.length - 1);

    param += ']';

    $('#config_AllProducts').val(param);
 
    save("moduleparam");
}
