﻿/// <reference path="jquery.min.js" />
function serviceConfig() {

    var service_data = serviceData;
    var str = "";
    $.post("?c=module&serviceid=" + service_data[0].sid + "&show=text&caction=getserviceinfo&t=" + new Date(), function (data) {
        var vdata = data.split('|');
        if (vdata[0] == "-1") {
            $("#ViewService").html('<div class="ui-state-highlight ui-corner-all" style="padding: 10px;margin:10px;text-align:center;"><strong>' + vdata[1] + '</strong></div>');
            return;
        }

        var vserver = $.parseJSON(vdata[0]);

        str = '<strong>服务器订单编号：</strong>#' + service_data[0].ssid + '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong>服务器编号：#</strong>' + vserver.serverid +
        '<br/><strong>服务器登录名：</strong>' + vserver.username + '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong>服务器密码：</strong>' + vserver.password +
        '<br/><strong>服务器资源配置：</strong><br/>';
        // '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong>端口：</strong>' + service_data[0].sconfig.rakport;
        str += '<table style="width:100%;margin-top:8px;"><tbody><tr><td style="width:90px;text-align:right"><strong>CPU型号：</strong></td><td style="text-align:left">' + service_data[0].sconfig.cpu + '<input type="hidden" value="' + service_data[0].sconfig.cpu + '" name="cpu" /></td></tr><tr><td style="height:10px;"></td><td></td></tr>' +
        '<tr><td style="width:90px;text-align:right"><strong>内存大小：</strong></td><td style="text-align:left">' + service_data[0].sconfig.ram + '<input type="hidden" value="' + service_data[0].sconfig.ram + '" name="ram" /></td></tr><tr><td style="height:10px;"></td><td></td></tr>' +
          '<tr><td style="text-align:right;padding-top:2px;"><strong>硬盘大小：</strong></td><td style="text-align:left">' + service_data[0].sconfig.disk + '<input type="hidden" value="' + service_data[0].sconfig.disk + '" name="disk" /></td></tr><tr><td style="height:10px;"></td><td></td></tr>' +
           '<tr><td style="text-align:right;padding-top:2px;"><strong>流量：</strong></td><td style="text-align:left">' + service_data[0].sconfig.bandwidth + '<input type="hidden" value="' + service_data[0].sconfig.bandwidth + '" name="bandwidth" /></td></tr><tr><td style="height:10px;"></td><td></td></tr>' +
         '<tr><td style="text-align:right;padding-top:2px;"><strong>IP个数：</strong></td><td style="text-align:left">' + service_data[0].sconfig.addip + '<input type="hidden" value="' + service_data[0].sconfig.addip + '" name="addip" /></td></tr><tr><td style="height:10px;"></td><td></td></tr>' +
         '<tr><td style="text-align:right;padding-top:2px;"><strong>操作系统：</strong></td><td>' + vserver.os + '</td></tr><tr><td style="height:10px;"><input type="hidden" value="' + service_data[0].sconfig.osid + '" name="osid" /></td><td></td></tr>' +
         '<tr><td style="text-align:right;padding-top:2px;"><strong>服务器IP：</strong></td><td style="text-align:left">' + vserver.serverip + '</td></tr><tr><td style="height:10px;"></td><td></td></tr>' +
         '<tr><td style="text-align:right;padding-top:2px;"><strong>其它附加IP：</strong></td><td style="text-align:left">' + vserver.assignedips.replaceAll("\r\n", "") + '</td></tr><tr><td style="height:10px;"></td><td></td></tr>' +
        '</tbody></table><input type="hidden" value="' + service_data[0].sconfig.pid + '" name="pid" /><input type="hidden" value="' + service_data[0].sconfig.ssid + '" name="ssid"  /><input type="hidden" value="' + service_data[0].sconfig.price + '" name="price" /><input type="hidden" value="' + service_data[0].sconfig.addip_id + '" name="addip_id" /><input type="hidden" value="' + service_data[0].sconfig.rbillingcycle + '" name="rbillingcycle" />' +
        '<input type="hidden" value="' + service_data[0].sconfig.rdomain + '" name="rdomain" /><input type="hidden" value="' + service_data[0].sconfig.rrootpwd + '" name="rrootpwd" />';

        $("#ServiceConfig").html('&nbsp;<br /><p style="line-height:30px">' + str + '</p>');

    });
}

serviceConfig();