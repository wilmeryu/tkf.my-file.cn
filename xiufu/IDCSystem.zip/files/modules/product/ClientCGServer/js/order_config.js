﻿/// <reference path="jquery-vsdoc.js" />
/// <reference path="jquery-ui.min.js" />

function orderConfig() {
    var discount = parseFloat(productData[0].discount);
    var str = '<p><strong>帐户信息</strong>：帐户余额：<strong>' + userData[0].balance + '</strong> ' + userData[0].currency;
    if (discount < 1) str += '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong>帐户优惠</strong>：<strong style="color:#0000FF">' + (discount * 100 / 10) + '</strong>折';
    str += '<br /><strong>产品名称：『' + productData[0].pname + '』</strong><br/>';
    //        if (productData[0].pdes != null && productData[0].pdes != "")
    //            str += '<strong>产品描述</strong>：' + HTMLDecode(productData[0].pdes) + '<br/><br/>';


    var strConfig = '<table width="100%" class="table"><tr style="background-color:#E7E7E7;height:22px;line-height:22px;">' +
                             '<th style="width:130px;">CPU型号</th><th style="width:120px;">内存</th><th style="width:120px;">硬盘</th><th style="width:170px;">流量带宽</th><th style="width:150px;">IP数量</th><th style="width:80px;">选择产品</th></tr>';
    var AllProducts = $.parseJSON(productData[0].pconfig.AllProducts.replace(/\?/g, '"'));
    for (var i = 0, len = AllProducts.length; i < len; i++) {
        if (AllProducts[i].pprice != "0_0_0") {
            var product = htmlDecode(AllProducts[i].description).split('<br>');
            strConfig += '<tr height="25" align="center" name="trdata">' +
                     '<td style="width:180px;"><label for="p' + i + '">' + product[0] + '</label></td><td style="width:120px;"><label for="p' + i + '">' + product[1] + '</label></td><td style="width:120px;"><label for="p' + i + '">' + product[2] + '</label></td><td style="width:150px;"><label for="p' + i + '">' + product[3] + '</label></td><td style="width:150px;"><label for="p' + i + '">' + product[4] + '</label></td><td style="width:80px;"><input type="radio" name="pid" id="p' + i + '" value="' + AllProducts[i].pid + '"></td></tr>';
        }
    }
    strConfig += "</table>";
    str += '<div id="params" class="ui-accordion ui-widget ui-helper-reset ui-accordion-icons" role="tablist">';
    str += '<h3 class="ui-accordion-header ui-helper-reset ui-state-default ui-state-active ui-corner-top" role="tab" aria-expanded="true" aria-selected="true" tabindex="0"><span></span><a href="#"><strong>选择配置</strong></a></h3>' +
    '<div class="ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom ui-accordion-content-active" role="tabpanel">' + strConfig + '</div></div>';

    str += '<br><p id="pos"><strong>主机操作系统：</strong><button  id="serveros" type="button"><span class="ui-button-text">选择操作系统</span></button><input type="hidden" name="os" id="os" value="0"/>';
    str += '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong>升级IP：</strong><select name="addIP" id="addIP">';
    str += '</select></p>';
    str += '<br><strong>主机别名：</strong><input type="text" name="mydomain" id="mydomain" class="text"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
    str += ' <strong>服务器默认密码：</strong><input type="text" name="mypwd" id="mypwd" class="text"/><input type="hidden" name="cpu" id="cpu" value=""><input type="hidden" name="ram" id="ram" value=""><input type="hidden" name="disk" id="disk" value=""><input type="hidden" name="bandwidth" id="bandwidth" value=""><input type="hidden" name="ipcount" id="ipcount" value=""><br/><br/>';


    str += '<strong>付款周期</strong>：<span id="paycycle"></span>';

    $("#OrderConfig").html(str);

    $("#serveros").click(function () {
        $("#suwin").html(ajaxLoading("正在加载系统模板，请稍候......"));
        $("#suwin").dialog({ title: "系统模板", autoOpen: false, resizable: false, width: 380, height: 350, modal: true, buttons: { "关 闭": function () { $(this).dialog("close"); } } }).dialog("open");
        $.post("?c=module&productid=" + productData[0].pid + "&show=text&caction=listos&pid=" + $("input[name=pid]:checked").val() + "&t=" + new Date(), function (data) {
            
            var arrOs = $.parseJSON(data);
            var vOS = "<div id='divos'>";
            for (var i = 0, len = arrOs.length; i < len; i++) {
                vOS += '<p><input type="radio" name="rados" id="rados' + i + '" value="' + arrOs[i].osid + '_' + arrOs[i].osname + '"/><label for="rados' + i + '">' + arrOs[i].osname + '</label></p>';
            }
            vOS += "</div>";
            $("#suwin").html(vOS);
            $("input[name=rados][value='" + $("#os").val() + "']").attr("checked", "checked");

            $("input[name=rados]").click(function () {
                $("#serveros span").html($(this).next().text());
                $("#os").val($(this).val());
                $("#suwin").dialog("close");
            });

        });
    });

    
    $("#pos input").attr("readonly", "readonly").css("border", "0px").css("width", "80px").css("font-weight", "bold");
    $("#pos button").css("color", "#000000").css("margin-right", "18px").button();

    //$('tr[name=trdata]').click(function (event) { $(this).find('input[name=pid]').attr("checked", "checked"); $(this).find('input[name=pid]').click(); event.stopPropagation(); });
   // $('tr[name="trdata"]').click(function (event) {  $($(this).find('td:last').children(':first')).click(); event.stopPropagation(); });
    $("#OrderConfig input[name=pid]").css('cursor', 'pointer');
   
//    $('input[type="radio"]').click(function (event) {
//        event.stopPropagation();
//    });

    $("#addIP").change(function () { buildPrices(); });

    var paramsDiv = $("#params");
    paramsDiv.accordion({
        autoHeight: false,
        collapsible: true,
        active: 0
    });


    if ($("#divprice").length > 0) { $("#divprice").remove(); }
    $("#swin").next().prepend('<div style="float:left;padding:15px 0px 0px 15px;" id="divprice"><strong>总价格：</strong><strong id="normalPrice" style="color:#0000FF;"></strong><span id="finalPrice"></span></div>');
    $("#OrderConfig p").css("line-height", "25px");
    $("#OrderConfig label").css({ "margin-right": "18px" });


    $("#OrderConfig input[name=pid]").click(function (event) {
        event.stopPropagation();

        $("#serveros span").html("选择操作系统");
        $("#os").val(0);

        var pindex = $("input[name=pid]:checked").attr("id").substr(1);
        var cycleId = $("input[name=baseprice]:checked").attr("id");

        var trObj = $(this).parent().parent();
        $("#cpu").val($.trim(trObj.find("td:eq(0)").text()));
        $("#ram").val($.trim(trObj.find("td:eq(1)").text()));
        $("#disk").val($.trim(trObj.find("td:eq(2)").text()));
        $("#bandwidth").val($.trim(trObj.find("td:eq(3)").text()));
        $("#ipcount").val($.trim(trObj.find("td:eq(4)").text()));
        setPayCycle(pindex, cycleId);

    });
    $("#OrderConfig input[name='pid']:first").attr("checked", true);
    $("#OrderConfig input[name=pid]:first").click();

    $(".ui-dialog-buttonset span").eq(0).click(function () {
        suwin.dialog({ title: "购买确认", autoOpen: false, resizable: false, width: 399, height: 368, modal: true, buttons: { "确定购买": function () { checkout(1); }, "继续配置": function () { $(this).dialog("close"); }, "在线充值": function () { window.open('?c=finance', '_blank'); } } }).dialog("open");
    });
}
function setPayCycle(index, cycleId) {
    var AllProducts = $.parseJSON(productData[0].pconfig.AllProducts.replace(/\?/g, '"'));
    var pcycles = [1, 3, 12];
    var pcprice = AllProducts[index].pprice.split('_');

    var vCycle = '';
    for (i = 0; i < pcycles.length; i++) {
        if (pcprice[i] != '0') {
            vCycle += '<input type="radio" name="baseprice" value="' + pcycles[i] + '_' + pcprice[i] + '_1" id="pcy' + pcycles[i] + '" /><label for="pcy' + pcycles[i] + '">' + pcycles[i] + '个月</label>　';
        }
    }
    $("#paycycle").html(vCycle);
    if ($("#" + cycleId).val() == undefined) {
        $("#OrderConfig input[name='baseprice']:first").attr("checked", true);
    } else {
        $("#" + cycleId).attr("checked", true);
    }

    $("#paycycle input[name='baseprice']").click(function () {buildPrices();});


    var vIp = '<option value="0_0" selected="selected">' + $('tr[name=trdata]').eq(index).find("td:eq(4)").text() + '(included)</option>';
    var arrUpgradeip = AllProducts[index].upgradeip.split('|');
    if (arrUpgradeip[0] != "0_0_0") {
        var arrDefaultIp = arrUpgradeip[0].split('_');
        vIp = '<option value="' + arrDefaultIp[0] + '_0'+'" selected="selected">' + arrDefaultIp[1] + ' Usable IPs (included)</option>';
        for (var i = 1; i < arrUpgradeip.length; i++) {
            var arrIp = arrUpgradeip[i].split('_');
            if (arrIp[2] != "0" && arrIp[2]!='')
            vIp += '<option value="' + arrIp[0] + '_'+arrIp[2]+'">' + arrIp[1] + ' Usable IPs (' + (parseInt(arrIp[1]) - parseInt(arrDefaultIp[1])) + ' additional) ' + arrIp[2] + ' RMB</option>';
        }
    }
    $("#addIP").html(vIp);
   
    buildPrices();
}

function buildPrices() {

    var ipValue = $('#addIP').val().split('_')[1];
    var pmothod = $("#paycycle input[name='baseprice']:checked").val().split('_');
    var basePrice = parseFloat(pmothod[1]);
    billingCycle = parseInt(pmothod[0]);
    if (billingCycle == 0) basePrice = 0;

    
  
    normalPrice = basePrice + parseFloat(ipValue) * billingCycle;
    if (normalPrice < basePrice) normalPrice = basePrice;
    var discount = parseFloat(productData[0].discount);
    finalPrice = normalPrice * discount;

    if (normalPrice > finalPrice) {
        $("#normalPrice").html('<strike>' + normalPrice.toFixed(2) + '</strike>');
        $("#finalPrice").html('<strong style="margin-left:18px">帐户优惠价(' + (discount * 100 / 10) + '折)：</strong><strong style="color:#0000FF;">' + finalPrice.toFixed(2) + '</strong> ' + userData[0].currency);
    }
    else $("#normalPrice").html(finalPrice.toFixed(2) + ' ' + userData[0].currency);
}


function setConfigDetails() {
    var vos = $("label[for=os_" + $("input[name=os]:checked").val() + "]").text();
    $("#rakosname").val(vos);
    configDetails = '<div style="margin-left:-54px;">CPU型号：' + productData[0].pconfig.rakcpu + '<br/>内存：' + $("#ram" + $("input[name=ram]:checked").val()).text() + ' <br/>硬盘：' + productData[0].pconfig.rakdisk + ' <br/>流量：' + productData[0].pconfig.rakbandwidth + ' <br/>端口：' + productData[0].pconfig.rakport + ' <br/>IP数量：' + $("#ip" + $("input[name=ip]:checked").val()).text() + ' <br/>操作系统：' + vos + '</div>';
}

orderConfig();
function HTMLDecode(text) {
    var temp = document.createElement("div");
    temp.innerHTML = text;
    var output = temp.innerText || temp.textContent;
    temp = null;
    return output;
}