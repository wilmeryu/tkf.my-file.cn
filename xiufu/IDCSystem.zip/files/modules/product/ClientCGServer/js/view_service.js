﻿/// <reference path="jquery-vsdoc.js" />
/// <reference path="jquery-ui.min.js" />

function _view() {
    var vstatus = serviceData[0].sstatus;
    if (vstatus == '-2') {
        $("#ViewService").html("<span style='color:green;font-size:14px;'>您开通服务器主机的方式为人工手动开通，请联系管理员尽快为您开通服务！</span>");
        return;
    }

    var str = '<table width="100%" border="0" cellspacing="0" cellpadding="0" class="table grid"><thead><tr><th style="text-align:right">产品服务基本信息：</th><th class="full">&nbsp;</th></tr></thead><tbody>';
    var title = '管理我租用的服务器#' + serviceData[0].sid;
    str += '<tr><td class="title">服务器订单编号：</td><td>#' + serviceData[0].ssid + '</td></tr>';
    if (userData[0].isAdmin == "True") {
        str += '<tr><td class="title">所属用户：</td><td><a href="?c=muser&uid=' + userData[0].uid + '" target="_blank" id="linkuser">' + userData[0].uname + ' [#' + userData[0].uid + ']</a></td></tr>';
    }
    str += '<tr><td class="title">服务器登录名：</td><td id="tdLoginName"></td></tr>' +
      '<tr><td class="title">服务器密码：</td><td id="tdLoginPwd"></td></tr>' +
      '<tr><td class="title">服务器IP地址：</td><td id="tdIP"></td></tr>' +
       '<tr id="trAdditionalIP"><td class="title">其它附加IP：</td><td id="tdAdditionalIP"></td></tr>' +
        '<tr><td class="title">CPU型号：</td><td id="tdram">' + serviceData[0].sconfig.cpu + '</td></tr>' +
      '<tr><td class="title">内存大小：</td><td id="tdram">' + serviceData[0].sconfig.ram + '</td></tr>' +
      '<tr><td class="title">硬盘大小：</td><td id="tddisk">' + serviceData[0].sconfig.disk + '</td></tr>' +
     '<tr><td class="title"> 流量带宽：</td><td id="tdbandwidth">' + serviceData[0].sconfig.bandwidth + '</td></tr>' +
     '<tr><td class="title"> IP地址数：</td><td id="tdips">' + serviceData[0].sconfig.addip + '</td></tr>' +
       '<tr id="tros"><td class="title">操作系统：</td><td id="tdos"><span id="spanos">' + serviceData[0].sconfig.osname + '</span>　　<span id="spanbtnos"></span></td></tr>';
    $("#pageTitle").html(title);
    document.title = title;
    var statusText = serviceStatus[parseInt(serviceData[0].sstatus) + 2];
    switch (serviceData[0].sstatus) {
        case "3": statusText = '<strong style="color:#CC3300;">' + statusText + '</strong>'; break;
        case "4": statusText = '<strong style="color:#FF0000;">' + statusText + '</strong>'; break;
    }

    str += '<tr id="trRenew"><td class="title" style="text-align: right; ">续费价格：</td><td>' + serviceData[0].sprice + ' / ' + serviceData[0].spcycle + '个月&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;帐户余额： ' + parseFloat(userData[0].balance).toFixed(2) + ' ' + userData[0].currency + '</td></tr>' +
            '<tr><td class="title">到期时间：</td><td>' + getUnixTime(serviceData[0].etime) + '&nbsp;&nbsp;&nbsp;<input id="autorenew" type="checkbox" ' + (serviceData[0].autorenew == '0' ? 'checked="checked"' : '') + '/><label for="autorenew">自动续费</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="javascript:_renew();">『马上续费』</a></td></tr>' +
            '<tr><td class="title">服务状态：</td><td>' + statusText + '</td></tr>' +
            '<tr><td class="title" style="text-align: right; ">主机状态：</td><td><span id="spanstate">正在开通</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="javascript:void(0);" id="btnfresh" style="display:none;">『刷新状态』</a></td></tr>' +

            '<tr><td class="title">服务器相关操作：</td><td id="tdServerOperat"></td></tr>' +
            '</tbody></table>';
    if (vstatus == "-1") {
        $("#ViewService").html(str);
        $("#tdServerOperat").parent().remove();

        $("#ViewService a,#ViewService input[type=button]").hide();
        $("#linkuser").show();
        $("#ViewService .title").css("text-align", "right");
       


        $("#ViewService #autorenew").css("cursor", "pointer").click(function () {
            var autorenew = $(this).prop("checked") ? '0' : '1';
            setAutorenew(serviceData[0].sid, autorenew);
        });
    } else {
    $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&caction=getserviceinfo&t=" + new Date(), function (data) {

        var vdata = data.split('|');
        if (vdata[0] == "-1") {
            $("#ViewService").html('<div class="ui-state-highlight ui-corner-all" style="padding: 10px;margin:10px;text-align:center;"><strong>' + vdata[1] + '</strong></div>');
            return;
        }
        $("#ViewService").html(str);

        var vserver = $.parseJSON(vdata[0]);

        $("#tdLoginName").text(vserver.username);

        $("#tdIP").text(vserver.serverip);
        $("#tdAdditionalIP").text(vserver.assignedips.replaceAll("\r\n", ""));

        $("#spanos").text(vserver.os);

        if (vserver.status == 'Active') {
            $("#spanbtnos").html('<input type="button" id="reinstal" class="submit" value="重装操作系统">');

            $("#tdLoginPwd").html('<input type="button" id="btngetserverpwd" class="submit" value="获取服务器密码">');

            var voperat = '<input type="button" class="submit" value="开机" onclick="ControlServer(0,\'启动\')"/>&nbsp;&nbsp;&nbsp;<input type="button" class="submit" value="关机" onclick="ControlServer(1,\'关闭\')"/>&nbsp;&nbsp;&nbsp;<input type="button" class="submit" value="重启" onclick="ControlServer(2,\'重启\')"/>';
            if (vserver.ipmi == "1") voperat += '&nbsp;&nbsp;&nbsp;<input type="button" class="submit" value="获取服务器IPMI控制台链接" onclick="getIPMIurl()"/>';
            $("#tdServerOperat").html(voperat);
            $('<tr><td class="title" style="text-align: right; ">状态图表：</td><td><a href="javascript:void(0);" id="abandwidthchart">『查看流量状态图』</a></td></tr>').insertBefore("#trRenew");


            $("#reinstal").click(function () {
                showInstalWin($("#spanos").html(), vdata[1], vdata[2]);
            });
            $("#btngetserverpwd").click(function () {
                getserverpwd(vdata[1], vdata[2], vserver.serverip);
            });
            _btnfresh();
            $("#btnfresh").show();
            $("#btnfresh").click(function () { _btnfresh(); });
            $("#abandwidthchart").click(function () { showBandwidthChart(30); });

        }
        else {
            $("#autorenew").next().next().remove();
        }
        $("#ViewService .title").css("text-align", "right");
        $("#ViewService #autorenew").css("cursor", "pointer").click(function () {
            var autorenew = $(this).prop("checked") ? '0' : '1';
            setAutorenew(serviceData[0].sid, autorenew);
        });

    });
    }

}
function getIPMIurl() {
    $("#suwin").html(ajaxLoading("正在加载信息，请稍等......"));
    $("#suwin").dialog({ title: "IPMI控制台链接地址", autoOpen: false, resizable: false, width: 380, height: 250, modal: true, buttons: { "关 闭": function () { $(this).dialog("close"); } } }).dialog("open");
    $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&caction=getipmi&t=" + new Date(), function (data) {
        var vArr = data.split('|');
        if (vArr[0] == "0") data = "<strong><a href='" + vArr[1] + "' target='_blank'>点击下载服务器IPMI控制台</a></strong>";
        $("#suwin").html("<div style=\"margin:50px 80px\">" + data + "</div>");
    });

}
function _btnfresh() {
    $("#spanstate").html("检测中......");
    $("#btnfresh").hide();
    $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&caction=freshstate&t=" + new Date(), function (data) {

        $("#btnfresh").show();
        var varr = data.split('|');
        if (varr[0] == "on") {
            $("#spanstate").html("<img src='" + varr[1] + "/js/run.png'/>正在运行");
        } else if (varr[0] == "off") {
            $("#spanstate").html("<img src='" + varr[1] + "/js/stop.png'/>已停止运行");
        } else if (varr[0] == "setup") {
            $("#spanstate").html("<img src='" + varr[1] + "/js/setup.png'/>正在重装...");
        } else {
            $("#spanstate").html("<img src='" + varr[1] + "/js/stop.png'/>" + varr[0]);
        }
        setTimeout("_btnfresh()", 120000);
    });
}

function showBandwidthChart(day) {
    if (serviceData[0].sstatus == "-1") {
        alert("当前状态不允许读取图表信息，请稍候重试！");
        return;
    }
    $("#suwin").html(ajaxLoading("正在加载图表信息，请稍等......"));
    $("#suwin").dialog({ title: "流量状态图", autoOpen: false, resizable: false, width: 530, height: 420, modal: true, buttons: { "关 闭": function () { $(this).dialog("close"); } } }).dialog("open");
    var days = "查看最近<select id=\"selday\">";
    for (var i = 1; i <= 60; i++) {
        days += "<option value =\"" + i + "\">" + i + "</option>";
    }
    days += "</select>天的状态图";

    $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&caction=getbwchart&day=" + day + "&t=" + new Date(), function (data) {
        $("#suwin").html(days + "<br><img src=\"data:image/gif;base64," + data + "\"/>").css({ "padding-top": "10px" });
        $("#selday").val(day);
        $("#selday").change(function () { showBandwidthChart($(this).val()) });
    });


}
var pwdTime = 180, vpwdtip = "";
function getserverpwd(emailchk, smschk, serverip) {
    if (userData[0].isAdmin == "True" || (emailchk == "0" && smschk == "0")) {

        $("#suwin").html(ajaxLoading("正在获取服务器密码信息，请稍等......"));
        $("#suwin").dialog({ title: "操作提示", autoOpen: false, resizable: false, width: 380, height: 220, modal: false, buttons: { "关 闭": function () { $(this).dialog("close"); } } }).dialog("open");
        $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&caction=getpwd&t=" + new Date(), function (data) {
            var vdata = data.split('|');
            if (vdata[0] == "-1") data = vdata[1];
            else data = "服务器[" + serverip + "]的密码： " + data;
            $("#suwin").html('<div style="margin-top:30px;text-align:center;font-weight:bold">' + data + "</div>");
        });
    } else {
        var vcheck = "";
        if (emailchk != "0" || smschk != "0") {
            var vcheck = '<p style="margin:15px 0px;padding-top:6px;">请选择验证方式：';
            if (smschk != "0") {
                vcheck += '<input type="radio" name="radcheck" id="smscheck" value="1"/><label for="smscheck">短信验证</label>&nbsp;&nbsp;';
            }
            if (emailchk != "0") {
                vcheck += '<input type="radio" name="radcheck" id="emailcheck" value="2" /><label for="emailcheck">邮箱验证</label>';
            }
            if (pwdTime == 180) {
                vcheck += '&nbsp;&nbsp;<input  type="button" class="submit" id="btnSendChkCode" value="发送验证码"/></p>';
            } else {
                vcheck += '&nbsp;&nbsp;<input  type="button" disabled="disabled" class="submit" style="color:gray;cursor:default" id="btnSendChkCode" value="还剩' + pwdTime + '秒"/></p>';
            }
            vcheck += '<p style="margin:15px 0px;padding-top:5px;padding-left:38px;">验 证 码：<input type="text" class="text" id="txtchkCode"/></p>';
        }

        $("#suwin").html(vcheck);
        if (vpwdtip == "email") {
            $("#emailcheck").attr("checked", "checked");
        } else {
            $("input[name=radcheck]:first").attr("checked", "checked");
        }

        $("#btnSendChkCode").click(function () {

            $("#btnSendChkCode").attr("disabled", "disabled").attr("value", "还剩" + pwdTime + "秒").css({ "color": "gray", "cursor": "default" });
            var myTimer = setInterval(function () {
                if (pwdTime > 1) {
                    pwdTime -= 1;
                    $("#btnSendChkCode").attr("value", "还剩" + pwdTime + "秒");
                }
                else {
                    clearInterval(myTimer);
                    pwdTime = 180;
                    $("#btnSendChkCode").removeAttr("disabled").css({ "color": "white", "cursor": "pointer" }).val('发送验证码');
                }
            }, 1000);
            processing("正在发送验证码，请稍等......");
            var chk = $("input[name=radcheck]:checked").val();
            if (chk == "1") {
                if (userData[0].tel == "0") {
                    showResults("您在本平台还没设置手机号！", 5000, "");
                    return;
                }
                $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&action=send_sms&tel=" + userData[0].tel + "&t=" + new Date(), function (data) {
                    vpwdtip = "tel";
                    if (data == "0") {
                        data = "验证码已发送到您的手机[<span style='color:red'>" + userData[0].tel + "</span>]，请查收！";
                    }
                    showResults(data, 5000, "close");
                });
            } else {
                $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&action=send_email&t=" + new Date(), function (data) {
                    vpwdtip = "email";
                    if (data == "0") {
                        data = "验证码已发送到您的邮箱[<span style='color:red'>" + userData[0].umail + "</span>]，请查收！";
                    }
                    showResults(data, 5000, "close");
                });
            }
        });


        $("#suwin").dialog({ title: "身份验证", autoOpen: false, resizable: false, width: 460, height: 300, modal: false, buttons: {
            "确认验证": function () {

                var code = "";
                if (userData[0].isAdmin != "True" && (emailchk != "0" || smschk != "0")) {
                    code = $("#txtchkCode").val();
                    if (code.length <= 0) {
                        processing("正在处理...");
                        showResults("请输入验证码！", 1000, "close");
                        $("#txtchkCode").val('').focus();
                        return;
                    }
                }

                processing("正在执行操作，请稍等......");
                $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&caction=getpwd&code=" + code + "&t=" + new Date(), function (data) {
                    var vdata = data.split('|');
                    if (vdata[0] == "-1") data = vdata[1];
                    else {
                        $("#suwin").dialog("close");
                        data = "服务器[" + serverip + "]的密码： " + data;
                    }

                    showResults(data, 5000, "");
                });

            }, "关 闭": function () { $(this).dialog("close"); }
        }
        }).dialog("open");
    }
}
var instalTime = 180, vcodeinstaltip = "";
function showInstalWin(os, emailchk, smschk) {
    $("#suwin").html(ajaxLoading("正在加载系统模板，请稍等......"));
    $("#suwin").dialog({ title: "重装系统", autoOpen: false, resizable: false, width: 380, height: 280, modal: false, buttons: { "关 闭": function () { $(this).dialog("close"); } } }).dialog("open");

    $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&caction=listreloados&pid=" + serviceData[0].sconfig.pid + "&t=" + new Date(), function (data) {
        var vheight = 450;
        var arrOs = $.parseJSON(data);
        var vOSprofile = "";
        for (var i = 0, len = arrOs.length; i < len; i++) {
            vOSprofile += '<p><input type="radio" name="rados" id="rados' + i + '" value="' + arrOs[i].id + '"';
            if (arrOs[i].name == os) {
                vOSprofile += " checked='checked'";
            }
            vOSprofile += '/><label for="rados' + i + '">' + arrOs[i].name + '</label></p>';
        }
        vOSprofile = '<div id="params" class="ui-accordion ui-widget ui-helper-reset ui-accordion-icons" role="tablist">' +
    '<h3 class="ui-accordion-header ui-helper-reset ui-state-default ui-state-active ui-corner-top" role="tab" aria-expanded="true" aria-selected="true" tabindex="0"><span></span><a href="#"><strong>选择操作系统</strong></a></h3>' +
    '<div class="ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom ui-accordion-content-active" role="tabpanel">' + vOSprofile + '</div></div>';

        
        if (userData[0].isAdmin != "True" && (emailchk != "0" || smschk != "0")) {
            vOSprofile += '<p style="margin:15px 0px;padding-top:6px;">请选择验证方式：';
            if (smschk != "0") {
                vOSprofile += '<input type="radio" name="radcheck" id="smscheck" value="1"/><label for="smscheck">短信验证</label>&nbsp;&nbsp;';
            }
            if (emailchk != "0") {
                vOSprofile += '<input type="radio" name="radcheck" id="emailcheck" value="2" /><label for="emailcheck">邮箱验证</label>';
            }
            if (instalTime == 180) {
                vOSprofile += '&nbsp;&nbsp;<input  type="button" class="submit" id="btnSendChkCode" value="发送验证码"/></p>';
            } else {
                vOSprofile += '&nbsp;&nbsp;<input  type="button" disabled="disabled" class="submit" style="color:gray;cursor:default" id="btnSendChkCode" value="还剩' + instalTime + '秒"/></p>';
            }
            vOSprofile += '<p style="margin:15px 0px;padding-top:5px;padding-left:5px;">新主机名称：<input type="hostname" class="text" id="hostname"/></p><p style="margin:15px 0px;padding-top:5px;padding-left:22px;">新 密 码：<input type="password" class="text" id="txtinstalPwd"/>&nbsp;&nbsp;<span style="color:green;">(由字母、数字组成的6-16位字符)</span></p>' +
    '<p style="padding-left:18px;">确认密码：<input type="password" class="text" id="txtinstalRePwd"/></p>';
            vOSprofile += '<p style="margin:15px 0px;padding-top:5px;padding-left:22px;">验 证 码：<input type="text" class="text" id="txtchkCode"/></p>';
        }
        else {
            vheight = 350;
            vOSprofile += '<p style="margin:15px 0px;padding-top:5px;padding-left:5px;">新主机名称：<input type="hostname" class="text" id="hostname"/></p><p style="margin:15px 0px;padding-top:5px;padding-left:22px;">新 密 码：<input type="password" class="text" id="txtinstalPwd"/>&nbsp;&nbsp;<span style="color:green;">(由字母、数字组成的6-16位字符)</span></p>' +
   '<p style="padding-left:18px;">确认密码：<input type="password" class="text" id="txtinstalRePwd"/></p>';
        }

        $("#suwin").html(vOSprofile);
        var paramsDiv = $("#params");
        paramsDiv.accordion({
            heightStyle: "content",
            collapsible: true,
            active: 0
        });

        $("#txtchkCode").width($("#txtinstalPwd").width());
        if (vcodeinstaltip == "email") {
            $("#emailcheck").attr("checked", "checked");
        } else {
            $("input[name=radcheck]:first").attr("checked", "checked");
        }

        $("#btnSendChkCode").click(function () {
            $("#btnSendChkCode").attr("disabled", "disabled").attr("value", "还剩" + instalTime + "秒").css({ "color": "gray", "cursor": "default" });
            var myTimer = setInterval(function () {
                if (instalTime > 1) {
                    instalTime -= 1;
                    $("#btnSendChkCode").attr("value", "还剩" + instalTime + "秒");
                }
                else {
                    clearInterval(myTimer);
                    instalTime = 180;
                    $("#btnSendChkCode").removeAttr("disabled").css({ "color": "white", "cursor": "pointer" }).val('发送验证码');
                }
            }, 1000);
            processing("正在发送验证码，请稍等......");
            var chk = $("input[name=radcheck]:checked").val();
            if (chk == "1") {
                if (userData[0].tel == "0") {
                    showResults("您在本平台还没设置手机号！", 5000, "");
                    return;
                }
                $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&action=send_sms&tel=" + userData[0].tel + "&t=" + new Date(), function (data) {
                    vcodeinstaltip = "tel";
                    if (data == "0") {
                        data = "验证码已发送到您的手机[<span style='color:red'>" + userData[0].tel + "</span>]，请查收！";
                    }
                    showResults(data, 5000, "close");
                });
            } else {
                $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&action=send_email&t=" + new Date(), function (data) {
                    vcodeinstaltip = "email";
                    if (data == "0") {
                        data = "验证码已发送到您的邮箱[<span style='color:red'>" + userData[0].umail + "</span>]，请查收！";
                    }
                    showResults(data, 5000, "close");
                });
            }
        });
        $("#suwin").dialog({ title: "重装系统", autoOpen: false, resizable: false, width: 520, height: vheight, modal: true, buttons: {
            "确认重装": function () {

                var hostname = $("#hostname").val();
                if (hostname.length <= 0) {
                    processing("正在处理...");
                    showResults("请输入新主机名称！", 1000, "close");
                    $("#hostname").val('').focus();
                    return;
                }
                var pwd = $("#txtinstalPwd").val();
                if (pwd.length <= 0) {
                    processing("正在处理...");
                    showResults("请输入新密码！", 1000, "close");
                    $("#txtinstalPwd").val('').focus();
                    return;
                }

                var repwd = $("#txtinstalRePwd").val();
                if (repwd.length <= 0) {
                    processing("正在处理...");
                    showResults("请输入确认密码！", 1000, "close");
                    $("#txtinstalRePwd").val('').focus();
                    return;
                }

                if (pwd != repwd) {
                    processing("正在处理...");
                    showResults("新密码与确认密码不一致！", 3000, "close");
                    return;
                }

                var nowOs = $("input[name=rados]:checked").val();
                var code = '';
                var exp = /^[A-Za-z0-9]{6,16}$/;
                if (userData[0].isAdmin != "True" && (emailchk != "0" || smschk != "0")) {
                    code = $("#txtchkCode").val();
                    if (code.length <= 0) {
                        processing("正在处理...");
                        showResults("请输入验证码！", 1000, "close");
                        $("#txtchkCode").val('').focus();
                        return;
                    }
                }

                processing("正在执行操作，请稍等......");
                $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&caction=reinstal&os=" + nowOs + "&pwd=" + pwd + "&repwd=" + repwd + "&hostname=" + hostname + "&code=" + code + "&t=" + new Date(), function (data) {
                    if (data == "0") {
                        showResults("重装任务已经开始...", 3000, "close");
                        $("#spanos").html($("label[for=" + $("input[name=rados]:checked").attr("id") + "]").text());
                        $("#spanstate").html('重装任务已经开始......');
                        $("#suwin").dialog("close");
                    } else {
                        showResults(data, 5000, "");
                    }
                });

            }, "关 闭": function () { $(this).dialog("close"); }
        }
        }).dialog("open");
    });
}

function showTipWin(tip, txt) {
    $("#suwin").dialog({ title: "操作提示", autoOpen: false, resizable: false, width: 350, height: 240, modal: false, buttons: { "关 闭": function () { $(this).dialog("close"); } } }).dialog("open");
    $("#suwin").html('<div style="text-align:center;margin-top:40px;font-weight:bold">' + tip + '</span></div>');
    setTimeout('top.location.reload();', 8000);
    //setTimeout('$("#suwin").dialog("close");$("#spanos").html("' + txt + '");_btnfresh();', 3000);
}
_view();

var finalPrice = 0;
var normalPrice = 0;
var productID = productData[0].pid;
var billingMothod = 1;
var billingCycle = 1;
function _renew() {
    if (serviceData[0].spmothod != "1") {
        alert("您当前服务无需续费！");
        return false;
    }
    if (serviceData[0].sstatus == "-1") {
        alert("当前状态不允许续费操作，请稍候重试！");
        return;
    }
    var discount = parseFloat(productData[0].discount);

    var str = '<div style="line-height:25px"><strong>帐户余额</strong>：<strong>' + parseFloat(userData[0].balance).toFixed(2) + '</strong> ' + userData[0].currency;
    if (discount < 1) str += '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong>帐户优惠</strong>：<strong style="color:#0000FF">' + (discount * 100 / 10) + '</strong>折';
    str += '&nbsp;<br /><strong>请选择续费周期</strong>：<br />';
    var cycles = [serviceData[0].spcycle];
    var cprices = productData[0].pprice.cprice.split(',');
    var cprice = 0, yprice = 0, pp1 = 0, pp2 = 0;
    for (i = 0; i < cycles.length; i++) {
        if (cprices[i] != '0') {
            cprice = parseFloat(cprices[i]);
            yprice = cprice;
            if (cycles[i] == serviceData[0].spcycle) cprice = serviceData[0].sprice;

            if (pp1 == 0) pp1 = parseFloat(yprice) / parseInt(cycles[i]);
            else {
                pp2 = (parseFloat(yprice) / parseInt(cycles[i]) / pp1 * 10).toFixed(1);
            }
            str += '<input type="radio" name="cycle" value="' + cycles[i] + '_' + cprice + '_' + yprice + '" id="cycle' + cycles[i] + '" /><label for="cycle' + cycles[i] + '">';
            switch (cycles[i]) {
                case "1": str += '月　付'; break;
                case "3": str += '季　付'; break;
                case "6": str += '半年付'; break;
                case "12": str += '年　付'; break;
                case "24": str += '二年付'; break;
                default: str += cycles[i] + '个月付'; break;
            }
            // str += '：' + cprice + (pp2 != 0 ? ' (' + pp2 + '折)' : '') + '</label><br />';
            if (cycles[i] == serviceData[0].spcycle) str += '：' + parseFloat(cprice).toFixed(2) + (pp2 != 0 ? ' (' + pp2 + '折)' : '') + '</label><br />';
            else
                str += '：' + (discount > 1 ? (parseFloat(cprice) * discount).toFixed(2) : cprice) + (pp2 != 0 ? ' (' + pp2 + '折)' : '') + '</label><br />';
        }
    }
    str += '&nbsp;<br /><strong>续费价格</strong>：<strong class="finalPrice"></strong> ' + userData[0].currency + '&nbsp;&nbsp;&nbsp;<span class="normalPrice"></span><br />&nbsp;<br />' +
           '<span>优 惠 码：<input type="text" id="couponcode" size="10" class="text"/> <input type="button" class="submit" value="使用" onclick="applyCode(\'renew\')"/> <input type="button" class="submit" value="不使用" onclick="clearCouponCode(1)"/></span><br />' +
           '<span id="ccdes" class="pptext"></span></div>';
    $("#suwin").html(str);
    $("#suwin input:radio").click(function () {
        clearCouponCode(1);
        var ps = $(this).val().split('_');
        billingCycle = parseInt(ps[0]);
        finalPrice = parseFloat(ps[1]);
        normalPrice = parseFloat(ps[2]);
        if (billingCycle != parseInt(serviceData[0].spcycle)) finalPrice = finalPrice * discount;
        $("#suwin .finalPrice").html(finalPrice.toFixed(2));

    });
    $("#suwin #cycle" + serviceData[0].spcycle).click();
    $("#suwin").dialog({ title: "续费确认", autoOpen: false, resizable: false, width: 500, height: 430, modal: false, buttons: { "确认续费": function () { renew(serviceData[0].sid, billingCycle, $("#couponcode").val()); }, "关 闭": function () { $(this).dialog("close"); } } }).dialog("open");
}

//开机、关机、重启、取消服务
function ControlServer(action, tip) {
    var msg = "您确定要" + tip + "服务器[" + serviceData[0].ssid + "]吗？";
    if (action == '100') msg = '提示：执行"取消服务"操作会将服务器删除！\n您确定要取消服务器[' + serviceData[0].ssid + ']吗？';
    $("#suwin").html('<p style="font-weight:bold;padding-top:20px;text-align:center;"><input type="checkbox" id="confirm_box" value="1"/><label for="confirm_box" style="cursor:pointer">' + msg + '<label></p>');
    $("#suwin").dialog({ title: "操作确认", autoOpen: false, resizable: false, width: 340, height: 200, modal: false, buttons: { "确认": function () {
        if (!$("#confirm_box").prop("checked")) {
            alert('请勾选复选框以确认操作！');
            return false;
        }
        runServer(action, tip)
    }, "关 闭": function () { $(this).dialog("close"); }
    }
    }).dialog("open");
}

function runServer(action, tip) {
    $("#suwin").html(ajaxLoading("正在" + tip + "服务器，请稍候......"));
    $("#suwin").dialog({ title: "操作提示", autoOpen: false, resizable: false, width: 300, height: 200, modal: true, buttons: { "关 闭": function () { $(this).dialog("close"); } } }).dialog("open");
    var delay = 0;
    $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&caction=handleserver&act=" + action + "&t=" + new Date(), function (data) {
        if (data == "0") {
            data = tip + '服务器成功！';
            delay = 5000;

        }
        $("#suwin").html("<br/><div style='text-align:center;'>" + data + "</div>");
        // if (delay > 0) setTimeout('top.location.reload();', delay);
        if (delay > 0) setTimeout('$("#suwin").dialog("close");_btnfresh();', delay);
    })
}
function getUpdatePrice() {
    var vpconfig = productData[0].pconfig;
    var strIp = vpconfig.upgradeip.split('|');
    var strRam = vpconfig.upgraderam.split('|');

    var selip = serviceData[0].sconfig.rakipid;
    var selram = serviceData[0].sconfig.rakramid;
    var ipprice = 0, ramprice = 0;
    for (var i = 0, len = strIp.length; i < len; i++) {
        var upgradeip = strIp[i].split('_');
        if (upgradeip[0] == selip) {
            ipprice = upgradeip[2];
            break;
        }
    }
    for (var i = 0, len = strRam.length; i < len; i++) {
        var upgraderam = strRam[i].split('_');
        if (upgraderam[0] == selram) {
            ramprice = upgraderam[2];
            break;
        }
    }
    return parseFloat(ipprice) + parseFloat(ramprice);
}

