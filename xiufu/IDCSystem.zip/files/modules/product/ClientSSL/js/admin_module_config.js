﻿
function _pm_init() {
    var swin = $("#swin");
    swin.find("#moduleDescription").html('&nbsp;');
    swin.find("#btn_add").remove();
    var userAPIid = moduleData[0].cconfig.userAPIid == undefined ? '' : moduleData[0].cconfig.userAPIid;
    var userAPIKey = moduleData[0].cconfig.userAPIKey == undefined ? '' : moduleData[0].cconfig.userAPIKey;
    var apiDomain = moduleData[0].cconfig.apiDomain == undefined ? 'https://www.cloudgoing.net' : moduleData[0].cconfig.apiDomain;
    //http://local.hugo.cloudgoing.com

    var enuserAPIid = moduleData[0].cconfig.enuserAPIid == undefined ? '0' : moduleData[0].cconfig.enuserAPIid;
    var enuserAPIKey = moduleData[0].cconfig.enuserAPIKey == undefined ? '0' : moduleData[0].cconfig.enuserAPIKey;

    var vbtnuserAPIid = vbtnAPIPwd = '修改';
    var ableuserAPIid = ableuserAPIKey = 'readonly="readonly"';
    if (enuserAPIid == '0') { vbtnuserAPIid = '加密'; ableuserAPIid = ''; }
    if (enuserAPIKey == '0') { vbtnAPIPwd = '加密'; ableuserAPIKey = ''; }

    var str = '<li><label class="a">用户编号：</label><input type="hidden" name="cname_001" value="userAPIid"/><input class="text" type="text" name="cvalue_001" value="' + userAPIid + '" ' + ableuserAPIid + ' />&nbsp;&nbsp;&nbsp;<input class="submit" value="' + vbtnuserAPIid + '" name="btnEncryp" id="btnAPIName" type="button"/><input type="hidden" name="cname_005" value="enuserAPIid"/><input type="hidden" name="cvalue_005" value="' + enuserAPIid + '"/>&nbsp;<span class="pptext"></span></li>' +
     '<li><label class="a">API接口密钥：</label><input type="hidden" name="cname_002" value="userAPIKey"/><input class="text" type="text" name="cvalue_002" value="' + userAPIKey + '" ' + ableuserAPIKey + '/>&nbsp;&nbsp;&nbsp;<input class="submit" value="' + vbtnAPIPwd + '" name="btnEncryp" id="btnAPIPwd"  type="button"/><input type="hidden" name="cname_006" value="enuserAPIKey"/><input type="hidden" name="cvalue_006" value="' + enuserAPIKey + '"  />&nbsp;<span class="pptext"></span></li>' +
      '<li><label class="a">API接口地址：</label><input type="hidden" name="cname_003" value="apiDomain"/><input class="text" type="text" name="cvalue_003" value="' + apiDomain + '"  /></li>' +
    '<li><label class="a">SSL模块版本号：</label>Ver 1.0 build(20140722115605)</li>';
    var paramList = swin.find("#paramList");
    paramList.html(str);
    paramList.find("li").css({ "height": "30px", "line-height": "30px" });
    paramList.find("label.a").css({ "font-weight": "bold", "float": "left", "text-align": "right", "width": "200px", "height": "30px", "line-height": "30px", "cursor": "default" });
    paramList.find(".text").css({ "width": "260px" }); paramList.find(".path").css({ "width": "330px" });

    $("#moduleDescription").hide();

    $("input[name=btnEncryp]").click(function () {
        var btn = $(this);
        var txt = btn.parent().find("input[type='text']");
        var hid = btn.parent().find("input:last");
        var vSpan = btn.parent().find("span");
        if (txt.val().length <= 0) {
            vSpan.html("请输入参数值！");
            txt.focus();
            return;
        }
        if (btn.attr('value') == "修改") {
            var btnID = $(this).attr('id');

            if (btnID == 'btnAPIName') {
                if (enuserAPIid == '1') {//修改操作
                    if (confirm('修改用户编号需要重新输入，确认修改？')) {
                        enuserAPIid = '0';
                        setStu(txt, hid, btn, vSpan);
                        return;
                    }
                    return;
                }
            } else if (btnID == 'btnAPIPwd') {
                if (enuserAPIKey == '1') {
                    if (confirm('修改API接口密钥需要重新输入，确认修改？')) {
                        enuserAPIKey = '0';
                        setStu(txt, hid, btn, vSpan);
                        return;
                    }
                    return;
                }
            }


        } else {
            vSpan.html("正在加密，请稍等...");
            $.getScript(currentDomain + "index.ashx?type=encryp&txt=" + txt.val() + "&t=" + new Date(), function () {
                txt.val(a);
                vSpan.html("加密完成！");
                switch (btn.attr('id')) {
                    case "btnAPIName": enuserAPIid = '1'; break;
                    case "btnAPIPwd": enuserAPIKey = '1'; break;
                }
                hid.val('1');
                btn.val('修改')
                txt.attr("readonly", "readonly");
            });
        }

    });
}
_pm_init();

function setStu(txt, hid, btn, vSpan) {
    txt.val('');
    hid.val('0');
    txt.removeAttr('readonly');
    btn.attr('value', '加密');
    vSpan.html("");
    txt.focus();
}