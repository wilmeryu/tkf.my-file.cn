﻿function baseConfig() {
    var AllProducts = productData[0].pconfig.AllProducts == undefined ? '' : productData[0].pconfig.AllProducts;

    var str = '';
    if (AllProducts == '') {
        updateSSLAllProducts();
    } else {
        var json = $.parseJSON(AllProducts.replace(/\?/g, '"'));
        if (json.length > 0) {
            str += '<table width="100%" border="0" cellspacing="0" cellpadding="0" class="table center"> <tr atl="tbody"><th  style="width:80px">编号</th><th>名称</th><th style="width:180px" >价格(元/年)</th><th style="width:130px">成本价(元/年)</th><th style="width:130px">操作</th></tr>';
            $(json).each(function (index, obj) {
                str += ' <tr name="param"><td name="pid">' + obj.id + '</td><td><input style="width:260px;text-align:center;" type="text" class="text" name="pName" value="' + obj.name + '"></td><td align="center"> <input style="width:160px;text-align:center;" type="text" class="text" name="pricedes" value="' + (typeof (obj.price) == 'undefined' ? 0 : obj.price) + '"> </td><td  style="font-weight:bold;font-size: 12px;">' + (typeof (obj.primeCost) == 'undefined' ? 0 : obj.primeCost) + '</td><td>&nbsp;<a href="javascript:;" onclick="fieldUp(this);">[上移]</a> &nbsp;<a href="javascript:;" onclick="fieldDown(this);">[下移]</a></td></tr>';
            });
            str += ' </table><input type="hidden" name="config_AllProducts" id="config_AllProducts" value="' + AllProducts + '"/>'
            $("#ProductConfig").html(str);
        }
    }
    suwin.find('td').css('text-align', 'center');
    suwin.find('th').css('text-align', 'center');
    suwin.find('tr>td[name="pid"]').css({ 'background': '#f1f1f1', 'border-right': '1px dotted #ccc', 'font': 'bold 12px 宋体', 'width': '80px' });
    suwin.dialog({
        title: '产品[#' + productData[0].pid + ']参数设置；    提示：价格“0”为不允许购买',
        buttons: {
            "保存参数设置": function () { joinProductsStr(); },
            "刷新产品列表": function () { updateSSLAllProducts(); },
            "关 闭": function () { $(this).dialog("close"); },
            "管理产品模块": function () { window.open('?c=mmodules&mt=product&cid=' + swin.find("select[name='module']").val(), '_blank'); }
        }
    });
    Sethover();
}
baseConfig();


function fieldUp(ca) {
    if ($(ca).parent().parent().prev().attr('atl') != 'tbody') {
        $($(ca).parent().parent().prev()).before($(ca).parent().parent());
    }
   
}
function fieldDown(ca) {
    
        $($(ca).parent().parent().next()).after($(ca).parent().parent());
     
}
function updateSSLAllProducts() {
    var AllProducts = typeof (productData[0].pconfig.AllProducts) == 'undefined' ? '' : productData[0].pconfig.AllProducts;
    processing('正在处理，请稍候...');
    $.post("?c=module&productid=" + productData[0].pid + "&show=text&caction=getAllProducts&t=" + new Date(), function (objJson) {

        if (objJson.indexOf("Error") > 0) {
            var errmsg = objJson.replace('-1|Error:', '');
            showResults('<strong>' + errmsg + '<strong>', 3000, 'close'); return;
        }
        showResults('<strong>正在加载数据请稍后...</strong>', 3000, 'close');
        if (AllProducts != '') {
            var ProductList = new Array();
            var json = $.parseJSON(AllProducts.replace(/\?/g, '"'));
            objJson = objJson.replace(/},{/g, "}&=&{").split("&=&");
            $(objJson).each(function (index, obj) {
                ProductList[ProductList.length] = $.parseJSON(obj)
            });
            $(ProductList).each(function (index, obj) {
                $(json).each(function (i, j) {
                    if (obj.id == j.id) {
                        obj.name = typeof (j.name) == 'undefined' ? obj.name : j.name;
                        obj.price = typeof (j.price) == 'undefined' ? 0 : j.price;
                    }
                });
            });
            objJson = ProductList;
        } else {
            objJson = objJson.replace(/},{/g, "}&=&{").split("&=&");
            var ProductList = new Array();
            $(objJson).each(function (index, obj) {
                ProductList[ProductList.length] = $.parseJSON(obj);
            });
            objJson = ProductList;
        }

        if (objJson.length > 0) {
            $("#ProductConfig").html('');
            var str = '<table width="100%" border="0" cellspacing="0" cellpadding="0" class="table center"> <tr atl="tbody"><th  style="width:80px">编号</th><th>名称</th><th style="width:180px" >价格(元/年)</th><th style="width:130px">成本价(元/年)</th><th style="width:130px">操作</th></tr>';
            $(objJson).each(function (index, obj) {
                str += ' <tr name="param"><td name="pid">' + obj.id + '</td><td><input style="width:260px;text-align:center;" type="text" class="text" name="pName" value="' + obj.name + '"></td><td align="center"> <input style="width:160px;text-align:center;" type="text" class="text" name="pricedes" value="' + (typeof (obj.price) == 'undefined' ? 0 : obj.price) + '"> </td><td  style="font-weight:bold;font-size: 12px;">' + (typeof (obj.primeCost) == 'undefined' ? 0 : obj.primeCost) + '</td><td>&nbsp;<a href="javascript:;" onclick="fieldUp(this);">[上移]</a> &nbsp;<a href="javascript:;" onclick="fieldDown(this);">[下移]</a></td></tr>';
            });
            str += ' </table><input type="hidden" name="config_AllProducts" id="config_AllProducts" value="' + AllProducts + '"/>'
            $("#ProductConfig").html(str);
            suwin.find('td').css('text-align', 'center');
            suwin.find('th').css('text-align', 'center');
            suwin.find('tr>td[name="pid"]').css({ 'background': '#f1f1f1', 'border-right': '1px dotted #ccc', 'font': 'bold 12px 宋体', 'width': '80px' });
            Sethover();
        }
    });
}

function joinProductsStr() {
    var param = '';
    if ($(suwin.find('tr[name="param"]')).length > 0) {
        param += '['
        $(suwin.find('tr[name="param"]')).each(function (index, obj) {
            var dom = $(obj).children();
            param += "{?id?:?" + $(dom[0]).html() + "?,?name?:?" + $(dom[1]).find('input').val() + "?,?price?:?" + ($(dom[2]).find("input").val() == "" ? "0" : $(dom[2]).find("input").val()) + "?,?primeCost?:?" + $(dom[3]).html() + "?},";
        });

    }

    $('#config_AllProducts').val(param.substring(0, param.length - 1) + ']');
    save("moduleparam");
}

function Sethover() {
    $(suwin.find('input[name="pricedes"]')).each(function (index, dom) {
        $(dom).hover(
      function () {
          $(this).attr('val', $(this).val()).val('');
      },
      function () {
          if ($(this).val() == '' || isNaN($(this).val())) {
              $(this).val($(this).attr('val'));
          }
      }
    );
    });
}