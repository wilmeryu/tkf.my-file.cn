﻿
function digitalocean_serviceConfig() {

    var APIOrderID = serviceData[0].sconfig.APIOrderID==undefined ? '' : serviceData[0].sconfig.APIOrderID;
    var SSLProductID = serviceData[0].sconfig.SSLProductID==undefined ? '' : serviceData[0].sconfig.SSLProductID;
    var activateSSL = serviceData[0].sconfig.activateSSL==undefined ? '' : serviceData[0].sconfig.activateSSL;
    var apiInvoiceId = serviceData[0].sconfig.apiInvoiceId==undefined ? '' : serviceData[0].sconfig.apiInvoiceId;
    var orderID = serviceData[0].sconfig.orderID==undefined ? '' : serviceData[0].sconfig.orderID;
    var serviceName = serviceData[0].sconfig.serviceName==undefined ? '' : serviceData[0].sconfig.serviceName;
    var viewID = serviceData[0].sconfig.viewID==undefined ? '' : serviceData[0].sconfig.viewID;
    var DomainName = serviceData[0].sconfig.DomainName==undefined ? '' : serviceData[0].sconfig.DomainName;
    var str = '<input type="hidden" name="APIOrderID" value="' + APIOrderID + '">' +
    '<input type="hidden" name="SSLProductID" value="' + SSLProductID + '">' +
    '<input type="hidden" name="activateSSL" value="' + activateSSL + '">' +
    '<input type="hidden" name="apiInvoiceId" value="' + apiInvoiceId + '">' +
    '<input type="hidden" name="orderID" value="' + orderID + '">' +
    '<input type="hidden" name="serviceName" value="' + serviceName + '">' +
    '<input type="hidden" name="viewID" value="' + viewID + '">' +
        '<input type="hidden" name="DomainName" value="' + DomainName + '">' +
    '<table id="tbhostinfo" width="100%" border="0" cellspacing="0" cellpadding="0" class="table grid"><thead><tr><th   style="text-align: right; ">子服务信息：</th><th class="full">&nbsp;</th></tr></thead><tbody>' +    
    '<tr><td class="title">产品编号：</td><td>' +SSLProductID + '</td></tr>' +
      '<tr><td class="title">SSL证书ID：</td><td>' + orderID + '</td></tr>' +
         '<tr><td  class="title">证书域名：</td><td>' + DomainName + '</td></tr>' +
      '<tr><td  class="title">SSL证书名称：</td><td>' + serviceName + '</td></tr>' +
    '</tbody></table>'; 
    $("#ServiceConfig").html(str);
    suwin.dialog({  buttons: { "关 闭": function () { $(this).dialog("close"); } } })
}
digitalocean_serviceConfig();