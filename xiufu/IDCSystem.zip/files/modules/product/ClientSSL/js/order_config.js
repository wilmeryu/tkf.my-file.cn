﻿function _pm_init() { 
    var buttonPane = $(".ui-dialog-buttonpane");
    if (buttonPane.find("#normalPrice").length < 1) $('<div style="float:left;padding:5px 0px 0px 15px;"><strong>总价格：</strong><strong id="normalPrice" class="pricing"></strong><span id="finalPrice"></span></div>').insertBefore(buttonPane.find(".ui-dialog-buttonset"));

    swin.dialog({ title: productData[0].pname });
    var AllProducts = productData[0].pconfig.AllProducts == undefined ? '' : productData[0].pconfig.AllProducts;
    if (AllProducts !== '') {
        var json = $.parseJSON(AllProducts.replace(/\?/g, '"'));
        if (json.length > 0) {
            var str = '<table width="100%" border="0" cellspacing="0" cellpadding="0" class="table center"><tr><th width="20%">编号</th><th>名称</th><th>价格(元/年)</th><th> 选择产品</th></tr>';
            $(json).each(function (index, obj) {
                if (obj.price != 0 && obj.price != '0') {
                    str += '<tr name="param"><td name="pid" > ' + (index + 1) + '</td><td>' + obj.name + '</label></td><td  align="center">' + obj.price + '</td><td  align="center"><input type="radio"  name="getProduct"  SSLProductID="' + obj.id + '"  SSLProductName="' + obj.name + '"></td></tr>';
                }
            });
            str += ' </table><input type="hidden" name="SSLProductID" id="SSLProductID" value=""/><input type="hidden" name="SSLProductName" id="SSLProductName" value=""/>';
            $("#OrderConfig").html(str); 
            swin.find('td').css('text-align', 'center');
            swin.find('th').css('text-align', 'center');
            swin.find('tr>td[name="pid"]').css({ 'background': '#f1f1f1', 'border-right': '1px dotted #ccc', 'font': 'bold 12px 宋体', 'width': '80px' });

        }
    }

    swin.find('input[type="radio"]').click(function (event) {
        event.stopPropagation();

        normalPrice = $(this).parent().prev().html();
        productData[0].pname = $(this).parent().prev().prev().html();
        $('#SSLProductName').val($(this).attr('SSLProductName'));
        $('#SSLProductID').val($(this).attr('SSLProductID'));
        finalPrice = normalPrice * parseFloat(productData[0].discount);
        billingCycle = 12;
        billingMothod = 1;


        if (normalPrice > finalPrice) {

            $("#normalPrice").html('<strike>' + parseFloat($(this).parent().prev().html()).toFixed(2) + '</strike>');
            $("#finalPrice").html('<strong style="margin-left:18px">帐户优惠价(' + (discount * 100 / 10) + '折)：</strong><strong class="pricing">' + finalPrice.toFixed(2) + '</strong> <strong>' + userData[0].currency + '<strong>');

        } else { $("#normalPrice").html(finalPrice.toFixed(2) + ' ' + userData[0].currency); }
         
    });
    swin.find('tr[name="param"]').click(function (event) { $($(this).find('td:last').children(':first')).click(); event.stopPropagation(); });

    swin.find('tr[name="param"]').css('cursor', 'pointer');
    swin.find('input[type="radio"]').first().click();




}
_pm_init();

