﻿
function _ps_init() {
    processing('正在处理，请稍候...'); showResults('<strong>正在处理，请稍候...<strong>', 3000, 'close');
    if (typeof (serviceData[0].sconfig.viewID) == 'undefined' || typeof (serviceData[0].sconfig.APIOrderID) == 'undefined' || typeof (serviceData[0].sconfig.orderID) == 'undefined') {
        if (typeof (serviceData[0].sconfig.activateSSL) == 'undefined' || serviceData[0].sconfig.activateSSL == '') {

            $('#ViewService').html('<p style="text-align:center;line-height:25px;padding-top:25px;" id="loadingMsg">服务等待开通中,请稍等        <a href="javascript:void(0)" onclick="javascript:window.location.reload();" >『刷  新』</a> <br><img src="/images/loading.gif" alt="Loading..."></p><div>&nbsp;</div>');
            //服务等待开通中，请等待系统审核或联系管理员开通
            return;
        }
        $('#pageTitle').html('请填写信息完成SSL证书申请')
        var htmlStr = '<table id="tbhostinfo" width="100%" border="0" cellspacing="0" cellpadding="0" class="table grid"><thead><tr><th style="text-align: right;">请填写申请资料：</th><th class="full">&nbsp;</th></tr></thead><tbody>'

        htmlStr += '<tr><td class="title" style="text-align: right; ">服务器平台：</td><td>' +
        '<select name="webserver_type"  style="width:260px;height:28px;"><option value="">选择Web服务器:</option></select></td></tr>' +
        '<tr><td class="title" style="text-align: right; ">域  名：</td><td><input type="text" name="Domain_name"  class="text"></td></tr>' +
        '<tr><td class="title" style="text-align: right; ">姓  氏：</td><td><input type="text" name="admin_firstname"  class="text"></td></tr>' +
        '<tr><td class="title" style="text-align: right; ">名  字：</td><td><input type="text" name="admin_lastname"  class="text"></td></tr>' +
        '<tr><td class="title" style="text-align: right; ">电  话：</td><td><input type="text" name="admin_phone"  class="text"></td></tr>' +
        '<tr><td class="title" style="text-align: right; ">城  市：</td><td><input type="text" name="org_city"  class="text"></td></tr>' +
        '<tr><td class="title" style="text-align: right; ">地  址：</td><td><input type="text" name="org_addressline1"  class="text"></td></tr>' +
        '<tr><td class="title" style="text-align: right; ">管理员邮箱：</td><td><input type="text" name="admin_email"  class="text"></td></tr>' +
        '<tr><td class="title" style="text-align: right; ">邮政编码：</td><td><input type="text" name="org_postalcode"  class="text"></td></tr>' +
        '<tr><td class="title" style="text-align: right; ">公司名称：</td><td><input type="text" name="org_name"  class="text"></td></tr>' +
        '<tr><td class="title" style="text-align: right; ">CSR代码：</td><td><textarea name="csr_Cood" rows="5" cols="80" style="resize:none"></textarea></td></tr>' +
        '<tr><td class="title" style="text-align: right; ">操    作：</td><td><input  name="addSSLOrder" type="button" class="button" value="提交申请"></td></tr>' +
        '</tbody></table>';
        $('#ViewService').html(htmlStr);
        $('#ViewService').find('input[name="addSSLOrder"]').click(function () {
            processing('正在处理，请稍候...');
            var webserver_type = $('select[name="webserver_type"]').val();
            var approver_email = $('select[name="approver_email"]').val();
            var admin_firstname = $('input[name="admin_firstname"]').val();
            var admin_lastname = $('input[name="admin_lastname"]').val();
            var admin_phone = $('input[name="admin_phone"]').val();
            var org_city = $('input[name="org_city"]').val();
            var org_addressline1 = $('input[name="org_addressline1"]').val();
            var org_postalcode = $('input[name="org_postalcode"]').val();
            var org_name = $('input[name="org_name"]').val();
            var admin_email = $('input[name="admin_email"]').val();
            var csrCood = $('#ViewService').find('textarea[name="csr_Cood"]').val();
            var DomainName = $('#ViewService').find('input[name="Domain_name"]').val();
            var postData = { 'csrCood': csrCood, "webserver_type": webserver_type, "approver_email": approver_email, "admin_firstname": admin_firstname, "admin_lastname": admin_lastname, "admin_phone": admin_phone, "org_city": org_city, "org_addressline1": org_addressline1, "org_postalcode": org_postalcode, "org_name": org_name, 'admin_email': admin_email, 'DomainName': DomainName, 'ClientHost': window.location.host };
            var check = false;
            for (var p in postData) {
                if (postData[p] == '' || typeof (postData[p]) == 'undefined') {
                    check = true;
                    break;
                }
            }
            if (check) { showResults('<strong>请检查是否有遗漏项未填写。<strong>', 3000, 'close'); return; }
            processing('正在处理，请稍候...请勿刷新页面。');
            $(this).attr('disabled', 'disabled');
            $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&caction=addSSLOrder&t=" + new Date(), postData, function (json) {
              
                if (json.indexOf("Error") > 0) {
                    $('#ViewService').find('input[name="addSSLOrder"]').removeAttr('disabled');
                    var errmsg = json.replace('-1|Error:', '');
                    if (errmsg.indexOf('错误代码：') > 0) {
                        $(this).click(); return;
                    }
                    if (errmsg == 'Refresh') { location.reload(); }
                    showResults('<strong>' + errmsg + '<strong>', 3000, 'close'); return;
                }

                $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&action=update_service_data&t=" + new Date(), $.parseJSON(json), function (rdata) {
                    if (json.indexOf("Error") > 0) {
                        var errmsg = json.replace('-1|Error:', '');
                        $(this).removeAttr('disabled');
                        showResults('<strong>' + errmsg + '<strong>', 3000, 'close'); return;
                    }
                    setTimeout('location.reload();', 3000)
                    showResults('申请成功，请注意查收邮箱中的验证短信。', 3000, 'close');
                });
            });
        });


        processing('正在处理，请稍候...');
        $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&caction=getWebservers&t=" + new Date(), function (json) {
            if (json.indexOf("Error") > 0) {
                var errmsg = json.replace('-1|Error:', '');
                showResults('<strong>' + errmsg + '<strong>', 3000, 'close'); return;
            } 
            json = $.parseJSON(json).webservers; 
            if (json.length > 0) {
                $(json).each(function (index, obj) {
                    $('#ViewService').find('select').append(' <option value="' + obj.id + '">' + obj.software + '</option>');
                });
            }
            showResults('正在处理，请稍候...', 3000, 'close');
        });

        //获取域名邮件
        $('#ViewService').find('input[name="Domain_name"]').blur(function () {
            var domain = $(this).val();
            var regExp = /^((https?|ftp|news):\/\/)?([a-z]([a-z0-9\-]*[\.。])+([a-z]{2}|aero|arpa|biz|com|coop|edu|gov|info|int|jobs|mil|museum|name|nato|net|org|pro|travel)|(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5]))(\/[a-z0-9_\-\.~]+)*(\/([a-z0-9_\-\.]*)(\?[a-z0-9+_\-\.%=&]*)?)?(#[a-z][a-z0-9_]*)?$/
            if (domain != '' && regExp.test(domain)) {
                $(this).attr('disabled', 'disabled');
                processing('正在处理，请稍候...');
                $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&caction=getDomainEmails&t=" + new Date(), { 'sslDomain': domain }, function (json) {

                    if (json.indexOf("Error") > 0) {
                        var errmsg = json.replace('-1|Error:', '');
                        $(this).removeAttr("disabled");
                        showResults('<strong>' + errmsg + '<strong>', 3000, 'close'); return;
                    }
                    showResults('正在处理，请稍候...', 1000, 'close');
                    json = $.parseJSON(json);
                    var str = '<select name="approver_email"  style="width:260px;height:28px;"><option value="">选择SSL验证邮箱:</option>'
                    $(json.ComodoApprovalEmails).each(function (i, obj) {
                        str += '<option value="' + obj + '">' + obj + '</option>';
                    });
                    str += '</select><input name="Domain_name" type="hidden" value="' + domain + '">';
                    $('#ViewService').find('input[name="Domain_name"]').parent().html(str).prev().html('验证邮箱：');

                });
            }
        });

        $('#ViewService').find('input[type="text"]').css({ width: "255px" });
    } else {
        shwoSSLInfo();
    }
}
_ps_init();


function shwoSSLInfo() {
    processing('正在处理，请稍候...');
    setTimeout('shwoSSLInfo()', 300000);
    $('#ViewService').html('<table id="tbhostinfo" width="100%" border="0" cellspacing="0" cellpadding="0" class="table grid"><thead><tr><th   style="text-align: right; ">SSL证书详细信息：</th><th class="full">&nbsp;</th></tr></thead><tbody></tbody></table>');
    processing('正在处理，请稍候...');

    $('#pageTitle').html('管理我的SSL证书&nbsp;&nbsp;&nbsp;&nbsp;#' + serviceData[0].sid);
    var serviceStatus = "等待开通|正在开通|正常服务|暂停服务|中止服务|即将过期|已经过期".split('|');
    var statusText = serviceStatus[parseInt(serviceData[0].sstatus) + 2];
    switch (serviceData[0].sstatus) {
        case "-1": statusText = '<strong style="color:#0000FF;">' + statusText + '</strong>'; break;
        case "0": statusText = '<strong style="color:#005B00;">' + statusText + '</strong>'; break;
        case "3": statusText = '<strong style="color:#CC3300;">' + statusText + '</strong>'; break;
        case "1":
        case "2":
        case "4": statusText = '<strong style="color:#FF0000;">' + statusText + '</strong>'; break;
    }
    processing('正在处理，请稍候...');
    $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&caction=GetSSLCertificateDetails&t=" + new Date(), function (trlist) {
        if (trlist.indexOf("Error") > 0) {
            var errmsg = trlist.replace('-1|Error:', '');
            showResults('<strong>' + errmsg + '<strong>', 3000, 'close'); return;
        }
        processing('正在处理，请稍候...'); showResults('正在处理，请稍候...', 3000, 'close');

      

        trlist = trlist.replace("Emailvalidation", "电子邮件验证");
        trlist = trlist.replace("Unlimited", "无限制");
        trlist = trlist.replace("Processing", "处理中");
        trlist = trlist.replace(/Months/g, "  月");
        trlist = trlist.replace(/Years/g, "  年").replace("Reissue", "生成中...");
        trlist = trlist.replace("Awaiting(Post-)Signing", "等待邮件验证").replace("AwaitingValidation(Full)", "等待邮件验证");
        var json = $.parseJSON(trlist);
        trlist = '';
        trlist += '<tr><td>证书状态：</td><td><span>' + (json.OrderStatus.replace("Active(Issued)", "有效")) +
            '</span><input type="button" style="margin-left: 30px;" name="RefreshState" class="button" value="刷新状态"></td></tr>' +
            '<tr><td>SSL名称：</td><td>' + json.ProductName + '</td></tr>' +
            '<tr><td>域名：</td><td>' + json.Domain + '</td></tr>' +
            '<tr><td>验证方法：</td><td>' + json.ValidationMethod + '</td></tr>' +
            '<tr id="Approvalemail"><td>验证邮箱：</td><td>' + json.Approvalemail + '</td></tr>' +
            '<tr><td>域名数量：</td><td>' + json.TotalDomains + '</td></tr>' +
            '<tr><td>服务器限制：</td><td>' + json.LicServers + '</td></tr>' +
            '<tr><td>有效期：</td><td>' + json.Validityperiod + '</td></tr>' +
            '<tr><td>开始日期：</td><td>' + json.Validfrom + '</td></tr>' +
            '<tr><td>有效期至：</td><td>' + json.Validtill + '</td></tr>' +
            '<tr><td class="title">服务状态：</td><td id="statusFlag">' + statusText + '</td></tr>' +
            '<tr><td class="title" style="text-align: right; ">操   作：</td><td><input  type="button" name="DownloadCSR" class="button" value="下载原CSR">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input  type="button" name="ReissueSSL" class="button" value="重新生成证书">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input  type="button" name="DownloadSSL" class="button" value="下载SSL证书"></td></tr>';
        $('#ViewService').find('tbody').append(trlist);
        $('#ViewService').find('tbody>tr').each(function (index, obj) { $(obj).children().first().addClass('title').css({ 'text-align': 'right' }) });

        //  $('#ViewService').find('tbody').append();

        if ($('#ViewService tr').length > 5) {
            $('#ViewService tr').eq(1).find('td:last').find('span').removeAttr('class').css({ 'width': '40px', 'font-weight': 'bold', 'color': '#228B22' });
            $('#ViewService tr').eq(1).find('input').css('cursor', 'hand').click(function () { shwoSSLInfo(); });
        } else {
            return;
        }
        if (json.Approvalemail == "0") {
            $("#Approvalemail").remove();
        }
        if (json.OrderStatus.indexOf('Active') == -1) {

            $('#ViewService tr').eq(1).find('td:last').find('span').css({ 'color': '#CD0000' })
            $('#ViewService tr:last').find('input').click(function () {
                processing(''); showResults('<strong>当前SSL证书状态不可用，请稍后刷新再试。</strong>', 60000, 'close');
            });
        } else {

            $('#ViewService').find('input[name="DownloadSSL"]').click(function () {
                processing('正在处理，请稍候...');
                $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&caction=GetDownloadSSLurl&t=" + new Date(), function (rdata) {
                    if (rdata.indexOf("Error") > 0) {
                        var errmsg = rdata.replace('-1|Error:', '');
                        showResults('<strong>' + errmsg.replace("未将对象设置到对象实例。", "正在处理SSL，请稍后重试....") + '<strong>', 3000, 'close'); return;
                    } else {
                        location.href = rdata;
                        showResults('<strong>操作成功,请保存文件。<strong>', 2000, 'close');
                    }
                });
            });
            $('#ViewService').find('input[name="DownloadCSR"]').click(function () {
                showMsg('<div style="margin-left:40px;"><strong>下载原创建证书申请的CSR文件。确定后操作!</strong></div>', function () {
                    processing('正在处理，请稍候...');
                    $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&caction=GetCSRURL&t=" + new Date(), function (rdata) {
                        if (rdata.indexOf("Error") > 0) {
                            var errmsg = rdata.replace('-1|Error:', '');
                            showResults('<strong>' + errmsg + '<strong>', 3000, 'close'); return;
                        } else {
                            location.href = rdata;
                            showResults('<strong>操作成功,请保存文件。<strong>', 2000, 'close');
                        }
                    });
                });
            });
            $('#ViewService').find('input[name="ReissueSSL"]').click(function () {
                showMsg('<strong>重新生成SSL证书后，当前SSL证书的将失效。确定后操作!</strong>', function () {
                    var str = '<div style="line-height:35px" id="ReissueSSL"><strong>服务器平台：</strong><select name="webserver_type"  style="width:450px;height:28px;"><option value="">选择Web服务器:</option></select></br><strong>CSR代码：</strong></br><textarea name="csr_Cood"   style="resize:none"></textarea></div>';
                    swin.html(str);
                    swin.find('strong').css({ width: "90px", 'text-align': 'right', 'font-weight': 'bold', 'clear': 'both', 'cursor': 'text', 'color': '#333' });
                    swin.find('textarea').css({ 'width': '540px', 'height': '220px' });
                    swin.dialog({
                        title: "重新生成证书",
                        autoOpen: false,
                        resizable: false,
                        width: 580,
                        height: 420,
                        modal: true,
                        buttons: {
                            "提   交": function () {
                                processing('正在处理，请稍候...');
                                var csrCood = swin.find('textarea[name="csr_Cood"]').val();
                                var webserver_type = $('select[name="webserver_type"]').val();
                                if ((csrCood == '' || typeof (csrCood) == 'undefined') || (webserver_type == '' || typeof (webserver_type) == 'undefined')) { showResults('<strong>请检查是否有遗漏项未填写。<strong>', 3000, 'close'); return; }
                                var postData = { 'csrCood': csrCood, 'webserver_type': webserver_type };
                                $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&caction=ReissueSSL&t=" + new Date(), postData, function (json) {

                                    if (json.indexOf("Error") > 0) {
                                        var errmsg = json.replace('-1|Error:', '');
                                        showResults('<strong>' + errmsg + '<strong>', 3000, 'close'); return;
                                    }
                                    json = $.parseJSON(json);
                                    var str = '<div style="line-height:35px;margin-top:30px; height: 60px;" id="ReissueSSL"><strong>CSR代码：</strong><span>' + json.domain + '</span></br><strong>请选择验证邮箱：</strong><select name="ApproverEmail"  style="width:280px;height:28px;"><option value="">选择Web服务器:</option></select></div>';
                                    swin.dialog({
                                        width: 500, height: 230,
                                        buttons: {
                                            "提   交": function () {
                                                processing('正在处理，请稍候...');
                                                var ApproverEmail = swin.find('select[name="ApproverEmail"]').val();
                                                if (ApproverEmail == '' || typeof (ApproverEmail) == 'undefined') { showResults('<strong>请检查是否有遗漏项未填写。<strong>', 3000, 'close'); return; }
                                                $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&caction=PostApproverEmail&t=" + new Date(), { 'ApproverEmail': ApproverEmail }, function (rData) {

                                                    if (rData.indexOf("Error") > 0) {
                                                        var errmsg = rData.replace('-1|Error:', '');
                                                        showResults('<strong>' + errmsg + '<strong>', 3000, 'close'); return;
                                                    }
                                                    if ('true' == rData) {
                                                        swin.dialog("close");
                                                        showResults('<strong>操作完成，请注意查收邮件。<strong>', 3000, 'reload');
                                                    }
                                                });
                                            },
                                            "关   闭": function () { swin.dialog("close"); }
                                        }
                                    }).html(str);
                                    swin.find('strong').css({ width: "140px", 'text-align': 'right', 'float': 'left', 'font-weight': 'bold', 'clear': 'both', 'cursor': 'text', 'color': '#333' });
                                    swin.find('span').css({ width: "200px", 'text-align': 'right', 'font-weight': 'bold', 'clear': 'both', 'cursor': 'text', 'color': '#333' });
                                    var optionlist = $.parseJSON(json.optionData);
                                    for (var key in optionlist) {
                                        swin.find('select').append(' <option value="' + optionlist[key] + '">' + optionlist[key] + '</option>');
                                    }

                                    showResults('<strong>请选择您的验证邮箱。<strong>', 3000, 'close');
                                });
                            },
                            "关   闭": function () { swin.dialog("close"); }
                        }
                    }).dialog("open");

                    processing('正在处理，请稍候...');
                    $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&caction=getWebservers&t=" + new Date(), function (json) {
                        if (json.indexOf("Error") > 0) {
                            var errmsg = json.replace('-1|Error:', '');
                            showResults('<strong>' + errmsg + '<strong>', 3000, 'close'); return;
                        }
                        showResults('正在处理，请稍候...', 1000, 'close');
                        json = $.parseJSON(json).webservers;

                        if (json.length > 0) {
                            $(json).each(function (index, obj) {
                                swin.find('select').append(' <option value="' + obj.id + '">' + obj.software + '</option>');
                            });
                        }
                    });
                });
            });
        }
    });
}
 
 
function showMsg(msg, fun) {

    var str = '<div style="width:350px;height:30px;margin-top:30px;margin-left:30px;">' + msg + '</div>';
    suwin.html(str);
    suwin.dialog({
        title: "提示",
        autoOpen: false,
        resizable: false,
        width: 430,
        height: 200,
        modal: true,
        buttons: {
            "确  定": function () { suwin.dialog("close"); fun(); },
            "取  消": function () { suwin.dialog("close"); }
        }
    }).dialog("open");
}