﻿/* 
{"name":"DNSPod域名解析模块","tag":"DNSPod","version":"1.01","build":"201310251108"}
*/
