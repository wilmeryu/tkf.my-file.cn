﻿/// <reference path="/modules/js/jquery-vsdoc.js" />
/// <reference path="/modules/js/jquery-ui.min.js" />
function _pm_init() {

    swin.find("#moduleDescription").html("");
    swin.find("#btn_add").remove();
    swin.find("#paramList").html("</br><strong>DNSPod模块版本号：</strong>201310251108");

}
_pm_init();
