﻿/// <reference path="jquery.min.js" />

function baseConfig() {
    var message = productData[0].pconfig == '' ? '' : productData[0].pconfig.message.replace(/rn/g, "\r\n");
    var str = '<div id="params" class="ui-accordion ui-widget ui-helper-reset ui-accordion-icons" role="tablist">' +
    '<h3 class="ui-accordion-header ui-helper-reset ui-state-default ui-state-active ui-corner-top" role="tab" aria-expanded="true" aria-selected="true" tabindex="0"><span></span><a href="javascript:void(0)"><strong>用户须知</strong></a></h3>' +
    '<textarea  style="resize:none;height:400px; width:763px;"class="text" name="config_message"; id="config_message">' + message + '</textarea></div>';
    $("#ProductConfig").html(str);
    suwin.dialog({
        title: "产品[#" + productData[0].pid + "]参数设置", autoOpen: false, resizable: false, width: 800, height: 568, modal: true, buttons: {
            "编 辑": function () { openHtmlEdit(message) }, "保 存": function () { save("moduleparam"); }, "管理产品模块": function () { window.open('?c=mmodules&mt=product&cid=' + moduleID, '_blank'); }, "关 闭": function () { $(this).dialog("close"); }
        }
    });
 

}
baseConfig();


function openHtmlEdit(message) {
    str = '<form id="editorForm" onsubmit="return htmlEdit(\'config_message\',1)"><p>' +
             '<textarea id="editorContent" rows="10" cols="10" style="width:100%;height:415px" class="tinymce">' + htmlDecode(message) + '</textarea></p></form>';
    editor.html(str);
    loadEditor("#editorForm .tinymce");
    editor.dialog({ title: "内容编辑器", autoOpen: false, resizable: false, width: 800, height: 568, modal: true, buttons: { "保存(Ctrl+Enter)": function () { htmlEdit('#config_message', 1); }, "关 闭": function () { $(this).dialog("close"); } } }).dialog("open");
}