﻿
function _pm_init() {
    $(".ui-dialog-title").html("用户须知：");
    var message = productData[0].pconfig.message == 'undefined' ? '' : productData[0].pconfig.message.replace(/rn/g, "\r\n");
    swin.dialog({ width: 480, height: 270 });
    $("#OrderConfig").html(htmlDecode(message));

}
_pm_init();

