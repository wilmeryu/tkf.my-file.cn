﻿/// <reference path="/modules/js/jquery-vsdoc.js" />
/// <reference path="/modules/js/jquery-ui.min.js" />
 //加载域名管理界面
function loginDNSPodInfo() {
    $("#ViewService").html(ajaxLoading()).parents("table");
    $("#pageTitle").replaceWith('<p id="pageTitle" class="subtitle">管理我的域名解析 #' + serviceData[0].sid + '</p>');
    $("#ViewService").parents("table[class='boss']").attr('id', 'tbhostinfo');
    $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&caction=send_checkLogin&t=" + new Date(), function (json) {
        var dnsJson = $.parseJSON(json);
        var htmlStr = '<tr name="dnsPodDomainInfo"><td><table width="100%" border="0" cellspacing="0" cellpadding="0" class="table" id="dnspodInfo">';
        var btnStr = '';
        if (dnsJson.status.code <= 0) {
            $("#ViewService p").remove();//
            if (dnsJson.status.message != '' || dnsJson.status.message != 'undefined') {
                processing(''); showResults(dnsJson.status.message + '!', 3000, 'close')
            };
            htmlStr += "<tr><th>操作</th></tr>";
            htmlStr += '<tr><td><input onclick="javascript:window.open(\'https://www.dnspod.cn/SignUp\')" type="button" class="button" value="注册DNSPod"/>';
            htmlStr += '<input onclick="loginDNSPod()" style="margin-left:20px;" type="button" class="button" value="设置DNSPod帐户"/></td></tr>';
        } else {
            $(".buttonList").append("<a href='javascript:void(0)' onclick='loginDNSPod()'>DNSPod帐户管理</a>");
            btnStr += '<td class="catList"><a href="javascript:createDomain();">添加域名</a>  ';
            if (dnsJson.status.code != 9) {
                btnStr += '<a href="javascript:ModifyDomain(\'enable\', \'status\');">启用域名</a>  <a href="javascript: ModifyDomain(\'disable\', \'status\');">暂停域名</a>';
                btnStr += '  <a href="javascript:ModifyDomain(\'\', \'Remove\');">删除域名</a> ';// <a href="javascript:domainTransfer();">域名过户</a>
            }
            btnStr += "</td>";
            $("#ViewService").replaceWith(btnStr);

            $(".catList a").button();

            if (dnsJson.status.code == 1) {
                if (dnsJson.info.domain_total > 0) {
                    htmlStr += "<tr><th><input type='checkbox' id='checAll'/></th><th>域 名</th><th>记 录</th><th>状 态</th><th>TTL</th><th>DNS状态</th><th>操作</th></tr>";
                    $(dnsJson.domains).each(function (Key, domain) {
                        htmlStr += "<tr id='" + domain.id + "'  domainStatus='" + domain.status + "'><td  style='width:35px;'><input type='checkbox' name='domainCheck'/></td>";
                        htmlStr += "<td  style='width:200px;'>" + domain.name + "</td>";
                        htmlStr += "<td  style='width:40px;'>" + domain.records + "条</td>";
                        var statusStr = domain.status == "pause" ? "暂  停" : domain.status == "lock" ? "锁  定" : "启   用";
                        htmlStr += "<td  style='width:40px;' name='status'>" + statusStr + "</td>";
                        htmlStr += "<td  style='width:40px;'>" + domain.ttl + "</td>";
                        var extStatus = domain.ext_status == "" ? "正  常" : "<span style='color:red'>错  误</span>";
                        htmlStr += "<td  style='width:70px;'>" + extStatus + "</td>";
                        htmlStr += "<td  style='width:240px;'><input  onclick='domainClick(\"" + domain.id + "\",\"" + domain.is_vip + "\")'value='DNS解析管理' type='button'class=' button'/>";
                        //if (statusStr == "锁  定") {
                        //    htmlStr += "<input style='margin-left:20px;'onclick='domainUnlock(\"" + domain.id + "\",\"" + domain.name + "\")' value='域名解锁' type='button'class=' button'/>";
                        //}
                        //else {
                        //    htmlStr += "<input style='margin-left:20px;'onclick='domainLock(\"" + domain.id + "\",\"" + domain.name + "\")'value='域名锁定' type='button'class=' button'/>";
                        //}
                        htmlStr += "</td></tr>";
                    });
                }
            }
            $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&caction=GetDNSPodUserInfo&t=" + new Date(), function (json) {
                var rdata = $.parseJSON(json)
                if (rdata.status.code == 1) {
                    $("#pageTitle").replaceWith('<p id="pageTitle" class="subtitle">管理我的域名解析&nbsp #' + serviceData[0].sid + '&nbsp;&nbsp;&nbsp;|&nbsp&nbsp;&nbsp;DNSPod帐户：' + rdata.info.user.email + '</p>');
                }

            });
        }
        htmlStr += "</table></td></tr>";
        $("#tbhostinfo").append(htmlStr);

        //全选按钮点击事件checAll
        $("#checAll").click(function () {
            var ck = document.getElementById("checAll").checked;
            if (ck == false)
                $("#dnspodInfo tr td input[name='domainCheck']:checked").click();
            else
                $("#dnspodInfo tr td input[name='domainCheck']").not(":checked").click();
        });

    });

}
loginDNSPodInfo();

////添加域名
function createDomain() {
    var str = "<div style='height:100px;width:260px;margin-left:20px;padding-top:0px;'><strong>域    名:</strong><input type='text' name='new-domain' id='new-domain' class='text' value=''></br><strong id='domainmsg'>到域名注册的地方将 DNS 修改为：</br>DNS服务器1：f1g1ns1.dnspod.net</br>DNS服务器2：f1g1ns2.dnspod.net</strong></div>";
    $('#suwin').html(str);

    suwin.dialog({
        title: "添加域名",
        autoOpen: false,
        resizable: false,
        width: 320,
        height: 220,
        modal: true,
        buttons: {
            "添   加": function () {
                var domain = $("#new-domain").val();
                var englishReg = "^[0-9a-z]([a-z0-9\-]*[a-z0-9])?(.com|.net|.org|.cn|.info|.mobil|.name|.com.cn|.net.cn|.gov.cn|.org.cn|.co.in|.net.in|.org.in|.gen.in|.firm.in|.ind.in|.nl|.sx|.xxx|.com.au|.net.au|.com.de|.eu.com|.gb.com|.ae|.ae.org|.kr.com|.us.com|.qc.com|.gr.com|.de.com|.gb.net|.no.com|.hu.com|.jpn.com|.uy.com|.za.com|.br.com|.sa.com|.se.com|.com.co|.net.co|.nom.co|.se.net|.uk.com|.uk.net|.ru.com|.edu|.gov|.pro|.aero|.co|.eu|.asia|.de|.uk|.us|.tk|.cc|.biz|.tv|.公司|.网络|.中国|.travel|.jobs|.museum|.coop|.mil|.ws|.sh|.mn|.bz|.ru|.la|.pt|.fm|.gov.cn|.ac|.ac.cn|.bj.cn|.sh.cn|.stj.cn|.hk.cn|.gz.cn|.net.cn|.pw|.in|.in.net|.cn.com|.es|.ca|.me|.mobi|.tel|.pe|.ph|.so|.nom.pe|.cz|.com.mx|.mx|.af|.ag|.am|.as|.at|.bi|.cl|.cm|.co.il|.co.nz|.co.uk|.com.sb|.cx|.ec|.gd|.gg|.gl|.gr|.gs|.gy|.hk|.hn|.ht|.im|.io|.je|.ki|.lc|.md|.me.uk|.mg|.mobi|.ms|.mu|.nf|.org.uk|.ps|.pl|.tm|.tl|.uz|.vc|.vg|.vn)$";
                if (domain.match(/^[www\.]/) || domain.indexOf('。') > 0 || !domain.match(englishReg)) {
                    $('#domainmsg').html("域名不正确,请输入不包含【www.】的主</br>域名 。例如：iscsystem.net");
                    return ;
                } else {
                    processing("正在处理中,请稍候...");
                    $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&caction=AddDomain&t=" + new Date(), { "domainName": domain }, function (json) {
                        var rdata = $.parseJSON(json);
                        if (rdata.status.code == 1) {
                            processing("数据加载中...请稍候...");
                            $("#tbhostinfo tr[name='dnsPodDomainInfo']").remove();
                            suwin.dialog("close");
                            loginDNSPodInfo();
                        }
                        $("#processing").dialog("open"); showResults(rdata.status.message, 2000, 'close');
                    });
                }
            },
            "取   消": function () { suwin.dialog("close"); }
        }
    }).dialog("open");
}//添加域名end

function loginDNSPod() {
    suwin.dialog({
        title: "DNSPod帐户管理",
        autoOpen: false,
        resizable: false,
        width: 320,
        height: 225,
        modal: true,
        buttons: {
            "保   存": function () { queryDomain(); },
            "取   消": function () { suwin.dialog("close"); }
        }
    }).dialog("open");
    var str = "<div style='height:80px;width:260px;padding-top:20px;padding-left:20px;'><strong>用户名：</strong><input type='text' name='login_email' id='login_email' class='text' ></br><strong>密&nbsp;&nbsp;&nbsp;码：</strong><input type='password' name='login_password ' id='login_password' class='text'  style=' margin-top:10px;'></div>";
    $('#suwin').html(str);

}
//点击验证登陆触发的事件
function queryDomain() {
    //验证邮箱
    processing("正在为您登陆，请稍候...");
    if (!$("#login_email").val().match(/^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]+$/)) {
        $("#login_email").focus();
        showResults("邮箱格式不正确！请重新输入！", 2000, 'close');
        return ;
    } else {
        $("#login_email").next().empty();
    } //密码非空验证
    if ($("#login_password").val() == '') {
        $("#login_password").focus();
        showResults("确密码不能为空！请重新输入！", 2000, 'close');
        return ;
    }

    //发送请求到后台验证
    $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&action=update_service_data&t=" + new Date(), { "login_email": $("#login_email").val(), "login_password": $("#login_password").val() }, function (json) {
        if (json.toString() == "0") {
            $('#suwin').dialog("close");
            showResults("数据加载中...请稍后...！", 2000, 'close');
            $('#tbhostinfo  tr[name="dnsPodDomainInfo"]').remove();
            loginDNSPodInfo();
        } else {
            showResults(json.toString(), 2000, 'close');
        }
    });

}



//域名状态
function ModifyDomain(data, actiontType) {
    processing("正在处理中....，请稍候...");
    if ($("#dnspodInfo tr td input[name='domainCheck']:checked").length > 0) {
        var domainIds = '';
        var domainStatus = data == "enable" ? "enable" : "pause";
        $("#dnspodInfo tr td input[name='domainCheck']:checked").parent('td').parent('tr[id]').each(function (key, val) {
            if ($(val).attr('domainstatus') != "lock" && $(val).attr('domainstatus') != domainStatus) {
                domainIds += $(val).attr('id') + "-";
            } else if ($(val).attr('domainstatus') != "lock" && actiontType == "Remove") {
                domainIds += $(val).attr('id') + "-";
            } else {
                $(val).children('td').children('input[type="checkbox"]:checked').click();
            }
        });
        if (domainIds == '') {
            showResults("锁定域名不能进行此操作。", 2000, 'close');
            var ck = document.getElementById("checAll").checked;
            if (ck != false)
                document.getElementById("checAll").click(); 
			return ;
        }
        $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&caction=ModifyDomain&t=" + new Date(), { "domainIds": domainIds, "domainStatus": data, "actiontType": actiontType }, function (json) {
            var rdata = $.parseJSON(json);

            if (rdata.status.code == 1) {
                if (actiontType == "status") {
                    var rmsg = data == "enable" ? "启   用" : data == "lock" ? "锁  定" : "暂  停";
                    $("#dnspodInfo tr td input[name='domainCheck']:checked").parent('td').siblings("td[name='status']").each(function (key, val) { $(val).html(rmsg) });
                    $("#dnspodInfo tr td input[name='domainCheck']:checked").parent('td').parent('tr[id]').each(function (key, val) {
                        $(val).attr('domainstatus', domainStatus);
                    });
                }
                if (actiontType == "Remove") {
                    $("#dnspodInfo tr td input[name='domainCheck']:checked").parent('td').parent('tr[id]').each(function (key, val) { $(val).remove(); });
                }
            }
            var ck = document.getElementById("checAll").checked;
            if (ck != false)
                document.getElementById("checAll").click();
            else
                $("#dnspodInfo tr td input[name='domainCheck']:checked").click();

            showResults(rdata.status.message, 2000, 'close');
        });
    } else {
        showResults("没有选中任何域名。", 2000, 'close');
    }

}

//域名详细信息点击domainClick
function domainClick(domain_Id, is_vpi) {
    processing("正在加载中请稍候...");
    var url = "?c=module&serviceid=" + serviceData[0].sid + "&show=text&caction=GetDomainInfo&t=" + new Date();
    var postData = { "domain_Id": domain_Id };
    $.post(url, postData, function (json) {
        var rdata = $.parseJSON(json);
        if (rdata.status.code == 1) {
            var str = '<div id="recordbtn" style="width: auto; min-height: 0px; max-height: none; height:36px;">';
            str += '<a href="javascript:createRecord();" class="dialog_button">添加记录</a>  <a href="javascript: ModifyRecord(\'enabled\', \'status\');" class="dialog_button">启  用</a>';
            str += '  <a href="javascript: ModifyRecord(\'disable\', \'status\');" class="dialog_button">暂  停</a>';
            str += '  <a href="javascript:ModifyRecord(\'\', \'Remove\');" class="dialog_button">删  除</a>';
            str += '  <a href="javascript:domainClick(\'' + rdata.domain.id + '\');" class="dialog_button">刷  新</a>  </div>';
            str += '<table id="tbRecordInfo" width="673px" border="0" cellspacing="0" cellpadding="0" class="table grid"><tr><th style="text-align:left;" id="mainDomain"; domainId="' + rdata.domain.id + '"; is_vip="' + is_vpi + '";  colspan="8">当前域名：' + rdata.domain.name + '</th></tr>';
            str += "<tr ><td style='width:25px; text-align:center;'><input type='checkbox' id='checrecordAll'/></td>";
            str += "<td style='width:100px;  text-align:center;'>主机记录</td><td style='width:80px;  text-align:center;'>记录类型</td><td  style='width:80px;  text-align:center;'>线路类型</td><td  style='width:170px;text-align:center;'>记录值</td><td  style='width:65px; text-align:center;'>MX优先级</td><td  style='width:65px;  text-align:center;'>TTL</td><td   style='width:100px;  text-align:center;'>状  态</td></tr>";
            str += "<tr type='hidden'id='createRecordInfo'/></tr>";
            $(rdata.records).each(function (key, val) {
                var dns = val.value;
                if (dns != "f1g1ns1.dnspod.net." && dns != "f1g1ns2.dnspod.net.") {
                    str += "<tr id='" + val.id + "'><td name='entry'style='width:26px; text-align:center;'><input ";
                } else {
                    str += "<tr><td name='entry'style='width:26px; text-align:center;'><input disabled='true' ";
                }
                str += "type='checkbox'name='recordCheck'/></td>";
                var strName = val.name.length > 10 ? val.name.substring(0, 5) + "..." + val.name.substring(val.name.length - 3) : val.name;
                var value = dns.length > 17 ? dns.substring(0, 10) + "..." + dns.substring(val.value.length - 4) : dns;
                str += "<td style='width:100px;  text-align:center;' data='" + val.name + "'>" + strName + "</td>";
                str += "<td style='width:80px;  text-align:center;'>" + val.type + "</td>";
                str += "<td style='width:80px;  text-align:center;'>" + val.line + "</td>";
                str += "<td style='width:170px;  text-align:center;'data='" + val.value + "'>" + value + "</td>";
                str += "<td style='width:50px;  text-align:center;'>" + val.mx + "</td>";
                str += "<td style='width:50px;  text-align:center;'>" + val.ttl + "</td>";
                var strEnabled = val.enabled == "0" ? "暂  停" : "启   用";
                str += "<td style='width:120px;  text-align:center;' name='status' status='" + val.enabled + "'>" + strEnabled + "</td>";
                str += "</tr>"
            });
            str += "<div id='recordMsg'style='position:absolute; top:160px;width:673px;height:340px; background-color:#FFFFFF; z-index:999;display: none;' ></div></table>";
            suwin.dialog({
                title: "DNS解析管理",
                autoOpen: false,
                resizable: false,
                width: 720,
                height: 600,// 405,
                modal: true,
                buttons: {

                    "关   闭": function () { suwin.dialog("close"); }
                }
            }).dialog("open");



            $('#suwin').html(str);
            $("#recordbtn  a").button();
            //记录信息全选按钮
            $("#checrecordAll").click(function () {
                var ck = document.getElementById("checrecordAll").checked;
                if (ck == false)
                    $("#tbRecordInfo tr td input[name='recordCheck']:checked").click();
                else
                    $("#tbRecordInfo tr td input[name='recordCheck']").not(":checked").click();
            });

            //为TR绑定点击事件
            $("#tbRecordInfo tr[id]").css("cursor", "pointer").dblclick(function () {
                updateRecord($(this));
            });


            $("#update-record").click(updateRecord);

            $("#processing").dialog("close");

        } else {
            showResults(rdata.status.message, 2000, 'close');
        }

    });

}

//加载域名详细信息
function loginDomainInfo(json) {


}

var modifyTr = "<input type='text' name='sub_domain'  class='text'style='width:130px;display:block;float:left;margin-top:5px;'>";


modifyTr += " <select  name='record_type' style='width:60px;height:25px;margin-left:5px;margin-top:5px;display:block;float:left;'onchange='recordTypeSelect(this.options[this.options.selectedIndex].value)'><option value ='A'>A</option><option value ='CNAME'>CNAME</option><option value ='MX'>MX</option><option value ='TXT'>TXT</option><option value ='NS'>NS</option><option value ='AAAA'>AAAA</option><option value ='SRV'>SRV</option><option value ='显性URL'>显性URL</option><option value ='隐性URL'>隐性URL</option><option value ='SRV'>SRV</option></select><select name='record_line' style='margin-left:5px;width:60px;height:25px;line-height:25px;margin-top:5px;display:block;float:left;'><option value ='默认'>默认</option><option value ='电信'>电信</option><option value ='联通'>联通</option><option value ='教育网'>教育网</option><option value ='百度'>百度</option></select><input type='text' name='value'class='text'style='width:160px; margin-left:15px;margin-top:5px;display:block;float:left;'/><input type='text' name='mx'  class='text'style='width:30px; margin-left:10px;margin-top:5px;display:block;float:left;'disabled='disabled'/><input type='text' name='ttl' value='600' class='text'style='width:50px; margin-left:20px;margin-top:5px;display:block;float:left;'/>";

//添加记录
function createRecord() {

    $("#create-record").attr('disabled', 'true');
    var suwinstr = "<tr id='createRecordInfo'> <td colspan='8'><from id='PostcreateRecord'>" + modifyTr + "<input style='width:45px;margin-left:5px;display:block;float:left;'type='button' id='AddDomainRecord' class='button' value='添加' /><input style='width:45px;margin-left:5px;display:block;float:left;'type='button' id='addCancelModify' class='button' value='取消' /></form></td></tr>";

    $('#createRecordInfo').replaceWith(suwinstr);
    setModifyMessage();
    $('#AddDomainRecord').click(function () {
        ModifyDomainRecord("AddDomainRecord", "PostcreateRecord", "createRecordInfo");

    });

    $('#addCancelModify').click(function () {
        $('#createRecordInfo').replaceWith('<tr type="hidden"id="createRecordInfo"/></tr>');
        $("#create-record").removeAttr('disabled'); $("#recordMsg").hide();
    });



}


function setModifyMessage() {
    $("#PostcreateRecord  input[name='sub_domain']").hover(function () {
        var mainDomain = $("#mainDomain").html();
        $("#recordMsg").show().html('<strong >主机记录就是域名前缀，常见用法有：</strong ></br><strong >www：</strong >解析后的域名为 www.' + mainDomain + '</br><strong >@：   </strong >直接解析主域名' + mainDomain + '</br><strong > * ：  </strong >泛解析，匹配其他所有域名 *.' + mainDomain);
    }, function () {
        setTimeout(function () {
            $("#recordMsg").hide();
        }, 6000 * 2);
    });

    $("#PostcreateRecord  select[name='record_type']").hover(function () {
        $("#recordMsg").show().html('<strong >A记录：  </strong >地址记录，用来指定域名的IPv4地址（如：8.8.8.8），如果需要将域名指向一个IP地址，就需要添加A记录。</br><strong >CNAME：   </strong >如果需要将域名指向另一个域名，再由另一个域名提供ip地址，就需要添加CNAME记录。</br><strong >TXT:  </strong >在这里可以填写任何东西，长度限制255。绝大多数的TXT记录是用来做SPF记录（反垃圾邮件）。</br><strong > NS： </strong >域名服务器记录，如果需要把子域名交给其他DNS服务商解析，就需要添加NS记录。</br><strong >AAAA： </strong >用来指定主机名（或域名）对应的IPv6地址（例如：ff06:0:0:0:0:0:0:c3）记录。</br><strong >MX: </strong >如果需要设置邮箱，让邮箱能收到邮件，就需要添加MX记录。</br><strong >显性URL: </strong >从一个地址301重定向到另一个地址的时候，就需要添加显性URL记录（注：DNSPod目前只支持301重定向）。</br><strong >隐性URL: </strong >类似于显性URL，区别在于隐性URL不会改变地址栏中的域名。</br><strong >SRV: </strong >记录了哪台计算机提供了哪个服务。格式为：服务的名字、点、协议的类型，例如：_xmpp-server._tcp。');
    }, function () {
        setTimeout(function () {
            $("#recordMsg").hide();
        }, 6000 * 2);
    });

    $("#PostcreateRecord  select[name='record_line']").hover(function () {
        $("#recordMsg").show().html('<strong >默认：  </strong ><strong >必须添加</strong >，否则只有单独指定的线路才能访问您的网站。如果双线解析，建议「默认」线路填写「电信IP」</br><strong >联通：   </strong >单独为「联通用户」指定服务器 IP，其他用户依然访问「默认」</br><strong >搜索引擎:  </strong >指定一个服务器 IP 让蜘蛛抓取</br>');

    }, function () {
        setTimeout(function () {
            $("#recordMsg").hide();
        }, 6000 * 2);
    });

    $("#PostcreateRecord input[name='value']").hover(function () {
        $("#recordMsg").show().html('<strong>各类型的记录值一般是这样的：</strong ></br>A记录：填写您服务器 IP，如果您不知道，请咨询您的空间商</br>CNAME记录：填写空间商给您提供的域名，例如：dnspod.cn</br>MX记录：填写您邮件服务器的IP地址或企业邮局给您提供的域名，如果您不知道，请咨询您的邮件服务提供商</br>TXT记录：一般用于 Google、QQ等企业邮箱的反垃圾邮件设置</br>显性URL记录：填写要跳转到的网址，例如：http://www.baidu.com</br>隐性URL记录：填写要引用内容的网址，例如：http://www.baidu.com</br>AAAA：不常用。解析到 IPv6 的地址。</br>NS记录：不常用。<strong >系统默认添加的两个NS记录请不要修改。</strong >NS向下授权，填写dns域名，例如：f1g1ns1.dnspod.net</br>SRV记录：不常用。格式为：优先级、空格、权重、空格、端口、空格、主机名，记录生成后会自动在域名后面补一个“.”，这是正常现象。例如：5 0 5269 xmpp-server.l.google.com.');
    }, function () {

        setTimeout(function () {
            $("#recordMsg").hide();
        }, 6000 * 2);

    });
    $("#PostcreateRecord  input[name='ttl']").hover(function () {
        $("#recordMsg").show().html('即 Time To Live，缓存的生存时间。指地方dns缓存您域名记录信息的时间，缓存失效后会再次到DNSPod获取记录值。</br><strong >600（10分钟）：</strong >600（10分钟）：建议正常情况下使用 600。</br><strong>  60（1分钟）：</strong >如果您经常修改IP，修改记录一分钟即可生效。长期使用 60，解析速度会略受影响。</br><strong >3600（1小时）：</strong >如果您IP极少变动（一年几次），建议选择 3600，解析速度快。如果要修改IP，提前一天改为 60，即可快速生效。');
    }, function () {
        setTimeout(function () {
            $("#recordMsg").hide();
        }, 6000 * 2);
    });
}



function recordTypeSelect(val) {
    if (val == 'MX') {
        $("input[name='mx']").removeAttr('disabled').val('5').hover(function () {
            $("#recordMsg").show().html('<strong >MX记录</strong ></br>MX优先级，用来指定邮件服务器接收邮件的先后顺序（1-50），一般默认设置为5、10、15等');
        }, function () {
            $("#recordMsg").hide();
        });

    } else {
        $("input[name='mx']").attr('disabled', 'disabled').val('');
    }
}
//提交添加记录
function ModifyDomainRecord(action, fid, trid) {
    processing("正在处理中....，请稍候...");
    if (isNaN($("#" + fid + " input[name='ttl']").val()) || isNaN($("#" + fid + " input[name='mx']").val())) {
        showResults("TTL或MX值不是数字！", 2000, 'close'); return ;
    }
    if ($("#mainDomain").attr('is_vip') == "no" && parseInt($("#" + fid + " input[name='ttl']").val()) < 600) {
        showResults("非VIP用户 TTL值不能低于600。", 2000, 'close'); return ;
    }


    var sub_domain = $("#" + fid + "  input[name='sub_domain']").val();
    var record_type = $("#" + fid + "  select[name='record_type']").val();
    var record_line = $("#" + fid + "  select[name='record_line']").val();
    var value = $("#" + fid + " input[name='value']").val();
    var mx = $("#" + fid + " input[name='mx']").val();
    var ttl = $("#" + fid + " input[name='ttl']").val();

    var psotDat = {
        "sub_domain": sub_domain, "record_type": record_type,
        "record_line": record_line, "value": value, "mx": mx, "ttl": ttl,
        "domain_id": $("#mainDomain").attr('domainId'), "record_id": trid
    };

    if (psotDat.sub_domain == '' || psotDat.value == '' || psotDat.domain_id == '') {
        showResults("缺少参数或者参数错误", 2000, 'close'); return ;
    }

    $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&caction=" + action + "&t=" + new Date(), psotDat, function (json) {
        var rdata = $.parseJSON(json);
        if (rdata.status.code == 1) {
            var strMx = mx == '' ? '0' : mx;
            var data = new Array();
            var str = '';
            if (action == "AddDomainRecord") {
                str += '<tr type="hidden"id="createRecordInfo"/></tr>';
                data[data.length] = rdata.record.id;
                data[data.length] = value;
                data[data.length] = "启   用";
                $("#create-record").removeAttr('disabled');
            } else if (action == 'UpdateRecord') {
                data[data.length] = rdata.record.id;
                data[data.length] = rdata.record.value;
                data[data.length] = rdata.record.status == "enable" ? "启   用" : "禁   用";
            }
            sub_domain = sub_domain.length > 10 ? sub_domain.substring(0, 5) + "..." + sub_domain.substring(rowData[1].length - 3) : sub_domain;
            var tdStr = data[1].length > 17 ? data[1].substring(0, 10) + "..." + data[1].substring(data[1].length - 4) : data[1];

            str += '<tr id="' + data[0] + '" style="cursor: pointer;"><td name="entry" style="width:26px; text-align:center;"><input type="checkbox" name="recordCheck" ></td><td style="width:100px;  text-align:center;" data="' + sub_domain + '">' + sub_domain + '</td><td style="width:80px;  text-align:center;">' + record_type + '</td><td style="width:80px;  text-align:center;">' + record_line + '</td><td style="width:170px;  text-align:center;"  data="' + data[1] + '">' + tdStr + '</td><td style="width:50px;  text-align:center;">' + strMx + '</td><td style="width:50px;  text-align:center;">' + ttl + '</td><td style="width:120px;  text-align:center;"  name="status"  status="1">' + data[2] + '</td></tr>';

            $('#' + trid).replaceWith(str);

            $("#" + data[0]).css("cursor", "pointer").dblclick(function () {
                updateRecord($(this));
            });
        }
        $("#recordMsg").hide();
        showResults(rdata.status.message, 2000, 'close');
    });
}




//详细信息状态修改
function ModifyRecord(data, actiontType) {
    processing("正在处理中....，请稍候...");
    if ($("#tbRecordInfo tr td input[name='recordCheck']:checked").parent('td').parent('tr[id]').length > 0) {
        var recordIds = '';
        var domain_id = $("#mainDomain").attr("domainId")
        var enabled = data == "enabled" ? '0' : '1';
        $("#tbRecordInfo tr td input[name='recordCheck']:checked").parent('td').parent('tr[id]').each(function (key, val) {
            if ($(val).children('td[name="status"]').attr("status") == enabled) {
                recordIds += $(val).attr('id') + "-"
            } else {
                $(val).children('td[name="entry"]').children('input[type="checkbox"]:checked').click();
            }

        });
        var postData = { "recordIds ": recordIds, "domainStatus": data, "actiontType": actiontType, "domain_id": domain_id };
        if (recordIds == '') {
            showResults("操作已经成功完成", 2000, 'close');
            var ck = document.getElementById("checrecordAll").checked;
            if (ck != false)
                document.getElementById("checrecordAll").click();
            else
                $("#tbRecordInfo tr td input[name='recordCheck']:checked").click();
            return ;
        }
        $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&caction=ModifyRecord&t=" + new Date(), postData, function (json) {
            var rdata = $.parseJSON(json);
            if (rdata.status.code == 1) {
                if (actiontType == "status") {
                    var rmsg = enabled == '0' ? "启   用" : "暂  停";
                    enabled = enabled == '0' ? '1' : '0';
                    $("#tbRecordInfo tr td input[name='recordCheck']:checked").parent('td').parent('tr[id]').children('td[name="status"]').each(function (key, val) {
                        $(val).attr('status', enabled).html(rmsg);
                    });
                }
                if (actiontType == "Remove") {
                    $("#tbRecordInfo tr td input[name='recordCheck']:checked").parent('td').parent('tr[id]').remove();
                }
            }
            showResults(rdata.status.message, 2000, 'close');
            var ck = document.getElementById("checrecordAll").checked;
            if (ck != false)
                document.getElementById("checrecordAll").click();
            else
                $("#tbRecordInfo tr td input[name='recordCheck']:checked").click();

        });
    } else {
        showResults("请选择您要操作的记录！", 2000, 'close'); return ;
    }

}

function updateRecord(thisTr) {
    var data = new Array();
    $(thisTr).children('td').each(function (key, td) {
        data[data.length] = $(td).html().replace(/(^\s*)|(\s*$)/g, "");
    });
    data[0] = $(thisTr).attr('id');
    data[1] = $($(thisTr).children('td[data]')[0]).attr('data');
    data[4] = $($(thisTr).children('td[data]')[1]).attr('data');
    data[data.length] = $(thisTr).children('td[name="status"]').attr('status');

    var strTr = "<tr id='" + data[0] + "'><td colspan='8'><from id='from" + data[0] + "'>" + modifyTr + "<input style='width:45px;margin-left:5px;display:block;float:left;'type='button' id='UpdateRecord' class='button' value='修改' onclick='ModifyDomainRecord(\"UpdateRecord\", \"from" + data[0] + "\", \"" + data[0] + "\")' /><input style='width:45px;margin-left:5px;display:block;float:left;'type='button' id='addCancelModify' class='button' value='取消'  onclick='cancelModify(\"" + data + "\")'/></form></td></tr>";

    $('#' + data[0]).replaceWith(strTr);
    $("#" + data[0] + " input[name='sub_domain']").val(data[1]);
    $("#" + data[0] + " select[name='record_type']").val(data[2]);
    $("#" + data[0] + " select[name='record_line']").val(data[3]);
    $("#" + data[0] + " input[name='value']").val(data[4]);
    $("#" + data[0] + " input[name='mx']").val(data[5]);
    $("#" + data[0] + " input[name='ttl']").val(data[6]);
}


//取消
function cancelModify(rowData) {
    rowData = rowData.split(',');
    var strName = rowData[1].length > 10 ? rowData[1].substring(0, 5) + "..." + rowData[1].substring(rowData[1].length - 3) : rowData[1];
    var value = rowData[4].length > 17 ? rowData[4].substring(0, 10) + "..." + rowData[4].substring(rowData[4].length - 4) : rowData[4];
    var strTr = '<tr id="' + rowData[0] + '" style="cursor: pointer;"><td name="entry" style="width:26px; text-align:center;"><input type="checkbox" name="recordCheck"></td><td style="width:100px;  text-align:center;" data="' + rowData[1] + '">' + strName + '</td><td style="width:80px;  text-align:center;">' + rowData[2] + '</td><td style="width:80px;  text-align:center;">' + rowData[3] + '</td><td style="width:170px;  text-align:center;">' + value + '</td><td style="width:50px;  text-align:center;">' + rowData[5] + '</td><td style="width:50px;  text-align:center;">' + rowData[6] + '</td><td style="width:120px;  text-align:center;" name="status"  status="' + rowData[8] + '">' + rowData[7] + '</td></tr>';
    $('#' + rowData[0]).replaceWith(strTr);

    $("#" + rowData[0]).css("cursor", "pointer").dblclick(function () {
        updateRecord($(this));
    });
}

