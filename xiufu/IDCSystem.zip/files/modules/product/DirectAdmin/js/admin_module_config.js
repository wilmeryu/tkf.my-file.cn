﻿/// <reference path="/modules/js/jquery-vsdoc.js" />
/// <reference path="/modules/js/jquery-ui.min.js" />
function _pm_init() {
    var swin = $("#swin");
    swin.find("#moduleDescription").html('&nbsp;');
    swin.find("#btn_add").remove();

    var DA_IP = moduleData[0].cconfig.DA_IP == undefined ? '' : moduleData[0].cconfig.DA_IP;
    var ResellerUserName = moduleData[0].cconfig.ResellerUserName == undefined ? '' : moduleData[0].cconfig.ResellerUserName;
    var ResellerUserPwd = moduleData[0].cconfig.ResellerUserPwd == undefined ? '' : moduleData[0].cconfig.ResellerUserPwd;


   
    var str = '<li><label>DA虚拟主机IP：</label><input type="hidden" name="cname_001" value="DA_IP"/><input class="text" type="text" name="cvalue_001" value="' + DA_IP + '"/></li>' +
              '<li><label>代理用户名：</label><input type="hidden" name="cname_002" value="ResellerUserName"/><input class="text" type="text" name="cvalue_002" value="' + ResellerUserName + '"/></li>' +
              '<li><label>代理用户密码：</label><input type="hidden" name="cname_003" value="ResellerUserPwd"/><input class="text" type="text" name="cvalue_003" value="' + ResellerUserPwd + '"/></li>';
     var paramList = swin.find("#paramList");
    paramList.html(str);
    //paramList.find("li").css({ "height": "30px" });
   // paramList.find("label").css({ "font-weight": "bold", "float": "left", "text-align": "right", "width": "126px" });
    // paramList.find(".text").css({ "width": "328px" });
    paramList.find("li").css({ "height": "30px", "line-height": "30px" });
    paramList.find("label").css({ "font-weight": "bold", "float": "left", "text-align": "right", "width": "116px", "height": "30px", "line-height": "30px", "cursor": "default" });
    paramList.find(".text").css({ "width": "260px" }); paramList.find(".path").css({ "width": "330px" });
}

_pm_init();