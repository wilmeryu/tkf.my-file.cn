﻿/// <reference path="jquery-vsdoc.js" />
/// <reference path="jquery-ui.min.js" />

function orderConfig() {
    var discount = parseFloat(productData[0].discount);
    var str = '<p><strong>帐户信息</strong>：帐户余额：<strong>' + userData[0].balance + '</strong> ' + userData[0].currency;
    if (discount < 1) str += '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong>帐户优惠</strong>：<strong style="color:#0000FF">' + (discount * 100 / 10) + '</strong>折';
    str += '<div style=\"padding-top:10px;\">';
    str += ' <strong>产品名称</strong>：<strong>『' + productData[0].pname + '』</strong><br />';
    str += "<span style=\"height:4px;display:block;\"></span>";
    str += " <strong>产品描述</strong>：" + HTMLDecode(productData[0].pdes);
    str += '<input type="hidden" value="' + productData[0].pdes + '" name="pDescription" />';
    str += "<span style=\"height:4px;display:block;\"></span>";
    var limitText = "不限"; var nullText = "暂无说明"; var offText = "不支持"; var onText = "是";
    str += "<fieldset style=\"border:1px solid #ccc; padding:0px 10px;margin:2px 0px;\">";
    str += "<legend style=\"padding:2px 8px;\">";
    str += '<strong>用户包裹</strong>';
    str += "</legend>"; str += "<span style=\"height:4px;display:block;\"></span>";
    str += "<table id=\"showpack\">";
    str += "<tr><td style=\"width:160px;text-align:right;\">";
    str += "流量：";
    str += "</td>";
    str += "<td style=\"width:100px;text-align:left;\">";
    str += productData[0].pconfig.bandwidth.replace("unlimited", limitText) + "（M）";
    str += "</td>";
    str += "<td style=\"width:150px;text-align:right;\">";
    str += "空间大小：";
    str += "</td>";
    str += "<td>";
    str += productData[0].pconfig.quota.replace("unlimited", limitText) + "（M）";
    str += "</td>";
    str += "<td style=\"width:160px;text-align:right;\">";
    str += "域名配额：";
    str += "</td>";
    str += "<td style=\"width:100px;text-align:left;\">";
    str += productData[0].pconfig.vdomains.replace("unlimited", limitText) + "（个）";
    str += "</td>";
    str += "</tr>";
    str += "<tr>";
    str += "<td style=\"width:150px;text-align:right;\">";
    str += "子域名配额：";
    str += "</td>";
    str += "<td>";
    str += productData[0].pconfig.nsubdomains.replace("unlimited", limitText) + "（个）";
    str += "</td>";
    str += "<td style=\"width:160px;text-align:right;\">";
    str += "Email帐户：";
    str += "</td>";
    str += "<td style=\"width:100px;text-align:left;\">";
    str += productData[0].pconfig.nemails.replace("unlimited", limitText) + "（个）";
    str += "</td>";
    str += "<td style=\"width:100px;text-align:right;\">";
    str += "Email转发器：";
    str += "</td>";
    str += "<td title=\"Number of forwarders the User will be allowed to create.\">";
    str += productData[0].pconfig.nemailf.replace("unlimited", limitText) + "（个）";
    str += "</td>";
    str += "</tr>";
    str += "<tr><td style=\"width:160px;text-align:right;\">";
    str += "邮件列表：";
    str += "</td>";
    str += "<td style=\"width:100px;text-align:left;\">";
    str += productData[0].pconfig.nemailml.replace("unlimited", limitText) + "（个）";
    str += "</td>";
    str += "<td style=\"width:100px;text-align:right;\">";
    str += "自动应答器：";
    str += "</td>";
    str += "<td>";
    str += productData[0].pconfig.nemailr.replace("unlimited", limitText) + "（个）";
    str += "</td>";
    str += "<td style=\"width:160px;text-align:right;\">";
    str += "MySQL数据库：";
    str += "</td>";
    str += "<td style=\"width:100px;text-align:left;\">";
    str += productData[0].pconfig.mysql.replace("unlimited", limitText) + "（个）";
    str += "</td>";
    str += "</tr>";
    str += "<tr>";
    str += "<td style=\"width:100px;text-align:right;\">";
    str += "绑定域名：";
    str += "</td>";
    str += "<td >";
    str += productData[0].pconfig.domainptr.replace("unlimited", limitText) + "（个）";
    str += "</td>";
    str += "<td style=\"width:160px;text-align:right;\">";
    str += "Ftp帐户：";
    str += "</td>";
    str += "<td style=\"width:100px;text-align:left;\">";
    str += productData[0].pconfig.ftp.replace("unlimited", limitText) + "（个）";
    str += "</td>";
    str += "<td style=\"width:100px;text-align:right;\">";
    str += "匿名FTP帐户：";
    str += "</td>";
    str += "<td>";
    str += productData[0].pconfig.aftp;
    str += "</td>";
    str += "</tr>";
    str += "<tr>";
    str += "<td style=\"width:160px;text-align:right;\">";
    str += "CGI访问：";
    str += "</td>";
    str += "<td style=\"width:100px;text-align:left;\" >";
    str += productData[0].pconfig.cgi;
    str += "</td>";
    str += "<td style=\"width:100px;text-align:right;\">";
    str += "PHP访问：";
    str += "</td>";
    str += "<td>";
    str += productData[0].pconfig.php;
    str += "</td>";
    str += "<td style=\"width:160px;text-align:right;\">";
    str += "垃圾清理：";
    str += "</td>";
    str += "<td style=\"width:100px;text-align:left;\">";
    str += productData[0].pconfig.spam;
    str += "</td>";
    str += "</tr>";
    str += "<tr>";
    str += "<td style=\"width:100px;text-align:right;\">";
    str += "计划任务：";
    str += "</td>";
    str += "<td>";
    str += productData[0].pconfig.cron;
    str += "</td>";
    str += "<td style=\"width:160px;text-align:right;\">";
    str += "|LANG_CATCHALL|：";
    str += "</td>";
    str += "<td style=\"width:100px;text-align:left;\">";
    str += productData[0].pconfig.catchall;
    str += "</td>";
    str += "<td style=\"width:100px;text-align:right;\">";
    str += "SSL 访问：";
    str += "</td>";
    str += "<td>";
    str += productData[0].pconfig.ssl;
    str += "</td>";
    str += "</tr>";
    str += "<tr>";
    str += "<td style=\"width:160px;text-align:right;\">";
    str += "SSH 访问：";
    str += "</td>";
    str += "<td style=\"width:100px;text-align:left;\">";
    str += productData[0].pconfig.ssh;
    str += "</td>";
    str += "<td style=\"width:100px;text-align:right;\">";
    str += "系统信息：";
    str += "</td>";
    str += "<td>";
    str += productData[0].pconfig.sysinfo;
    str += "</td>";
    str += "<td style=\"width:160px;text-align:right;\">";
    str += "DNS控制：";
    str += "</td>";
    str += "<td style=\"width:100px;text-align:left;\">";
    str += productData[0].pconfig.dnscontrol;
    str += "</td>";
    str += "</tr>";
    str += "<tr>";
    str += "<td style=\"width:100px;text-align:right;\">";
    str += "是否发送邮件：";
    str += "</td>";
    str += "<td>";
    str += "" + productData[0].pconfig.notify.replace("yes", "是").replace("no", "否") + "";
    str += "</td>";
    str += "<td style=\"width:260px;text-align:right;\" colspan=\"2\">";
    str += "Suspend At Limit（延缓极限交易）：";
    str += "</td>";
    str += "<td colspan=\"4\">";
    str += productData[0].pconfig.suspend_at_limit;
    str += "</td>";
    str += "</tr>";
    str += "</table>";
    str += ""; str += "<span style=\"height:8px;display:block;\"></span>";
    str += "</fieldset>"; str += "<span style=\"height:5px;display:block;\"></span>";
    str += "";
    if (productData[0].pconfig.other.length != 0) {
        str += "<fieldset style=\"border:1px solid #ccc; padding:0px 10px;margin:2px 0px;\">";
        str += "<legend style=\"padding:2px 8px;\">";
        str += '<strong>其他描述</strong>';
        str += "</legend>"; str += "<span style=\"height:4px;display:block;\"></span>";
        str += productData[0].pconfig.other; str += "<span style=\"height:8px;display:block;\"></span>";
        str += "</fieldset>";
        str += "<span style=\"height:4px;display:block;\"></span>";
    }

    str += '</div>';
    str += '<div style=\"padding-top:10px;\">';
   // billingMothod = productData[0].pprice.pmothod;
    //处理付款的方式

    timeCycle = productData[0].psconfig.time_cycle == undefined ? '0' : productData[0].psconfig.time_cycle;
    switch (billingMothod) {
        case 1:
            str += '<strong style=\"height:30px;\">租用价格：</strong><strong id="discountedPrice" style="color:#0000FF;display:none;"></strong><br />';
            str += "<span style=\"height:7px;display:block;\"></span>";
            var pcycles = productData[0].pprice.cycle.split(',');
            var pcprice = productData[0].pprice.cprice.split(',');
            var pp1 = 0, pp2 = 0;
            var k = 0;
            for (i = 0; i < pcycles.length; i++) {
                if (pcprice[i] != '0') {
                    if (pp1 == 0) pp1 = parseFloat(pcprice[i]) / parseInt(pcycles[i]);
                    else {
                        pp2 = (parseFloat(pcprice[i]) / parseInt(pcycles[i]) / pp1 * 10).toFixed(1);
                    }
                    str += '<input type="radio" name="cycle" value="' + pcycles[i] + '_' + pcprice[i] + '" id="cycle' + pcycles[i] + '" /><label for="cycle' + pcycles[i] + '">';
                    str += getTimeCycleSuffix(pcycles[i], timeCycle, 0) + (pp2 != 0 ? ' (' + pp2 + '折)' : '') + '</label>';
//                    switch (pcycles[i]) {
//                        case "1": str += '月　付'; break;
//                        case "3": str += '季　付'; break;
//                        case "6": str += '半年付'; break;
//                        case "12": str += '年　付'; break;
//                        case "24": str += '二年付'; break;
//                        default: str += pcycles[i] + '个月付'; break;
//                    }
                   // str += '<b style="display:none;">' + (discount > 1 ? (parseFloat(pcprice[i]) * discount).toFixed(2) : pcprice[i]) + '</b>' + (pp2 != 0 ? ' (' + pp2 + '折)' : '') + '</label>';
                    //str += '<b style="display:none;">' + pcprice[i] + '</b>' + (pp2 != 0 ? ' (' + pp2 + '折)' : '') + '</label>';
                    k++;
                    if (k == 4) str += '<br />';
                }
            }
            if (k > 4) str += '&nbsp;<br />';

            //填充价格
            //</strike>
            var pStr = '';
            pStr += '<div style="float:left;height:44px;line-height:44px;" id="divprice">';
            if (discount < 1) {
                var myPrice;
                for (var i = 0; i < pcprice.length; i++) {
                    if (pcprice[i] != 0) { myPrice = pcprice[i]; break; }
                }
                pStr += '<strong>总价格：<span style="color:blue;" id="OrderNormalPrice"><strike>' + myPrice + '</strike></span> <b style="">RMB</b>';
                if (discount > 0) { myPrice = myPrice * discount; }
                pStr += '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
                pStr += '帐户优惠价(' + discount * 100 / 10 + '折)：<span style="color:blue;" id="OrderPrice">' + myPrice.toFixed(2) + '</span> <b style="">RMB</b></strong>';
            }
            else {
                var myPrice;
                for (var i = 0; i < pcprice.length; i++) {
                    if (pcprice[i] != 0) { myPrice = pcprice[i]; break; }
                }
                pStr += '<strong>总价格：<span style="color:blue;" id="OrderPrice">' + myPrice + '</span> <b style="color:blue;">RMB</b></strong>';
            }
            pStr += '</div>';
            if ($("#divprice").length > 0) { $("#divprice").remove(); }
            $("#swin").next().prepend(pStr);
           // $(".ui-dialog-buttonset").before(pStr);
            break;
        case 2:
            str += '<span style=\"height:30px;\"><b>租用价格：</b>一次性付款 <b></b></span><strong id="discountedPrice" style="color:#0000FF"></strong><br />';
            str += "<span style=\"height:2px;display:block;\"></span>";

            //
            var pStr = '';

            pStr += '<div style="float:left;height:44px;line-height:44px;"  id="divprice">';
            var myPrice = parseFloat(productData[0].pprice.onetime);
            if (discount < 1 && discount > 0) {
                pStr += '<strong style=\"height:30px;\">一次性付款：<strike style="color:blue;">' + productData[0].pprice.onetime + '</strike> ' + userData[0].currency + ' </strong>';
                pStr += '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'; myPrice = myPrice * discount;
                pStr += '<b>帐户优惠价(' + discount * 100 / 10 + '折)：<span style="color:blue;" id="OrderPrice">' + parseFloat(myPrice).toFixed(2) + '</span> </b><b style="">RMB</b></strong>';
            }
            else {
                pStr += '<strong style=\"height:30px;\">一次性付款：<b style="color:blue;">' + productData[0].pprice.onetime + '</b> ' + userData[0].currency + ' </strong>';
            }
            pStr += '</div>';
            // $(".ui-dialog-buttonset").before(pStr);
            if ($("#divprice").length > 0) { $("#divprice").remove(); }
            $("#swin").next().prepend(pStr);
            finalPrice = myPrice;
            break;
        case 3:
            str += '<strong style=\"height:30px;\">租用价格：免费试用' + productData[0].pprice.free + '天</strong><strong id="discountedPrice" style="color:#0000FF"></strong><br />';
            str += "<span style=\"height:2px;display:block;\"></span>";
            var pStr = '';
            pStr += '<div style="float:left;height:44px;line-height:44px;" id="divprice">';
            pStr += '<strong style=\"height:30px;\">免费试用：' + productData[0].pprice.free + '天</strong>';
            pStr += '</div>';
            // $(".ui-dialog-buttonset").before(pStr);
            if ($("#divprice").length > 0) { $("#divprice").remove(); }
            $("#swin").next().prepend(pStr);
            billingCycle = productData[0].pprice.free;
            break;
    }

    //if (productData[0].pupgrade.des != '') str += '<br /><strong>升级选项</strong>：<br />' + productData[0].pupgrade.des.replaceAll('\r\n', '<br />');
    //str += '</p>';
    str += '</div>';
    //str = "hello,buyer";
    //str += productData[0].pconfig.motherboard;
   
    str += "&nbsp;<br /><strong>虚拟主机申请信息:</strong>";
    str += "&nbsp;<br /><br />";
    str += "<table>";
    str += "<tr style=\"height:24px;\" title='必填项'><td style=\"text-align:right;width:150px;vertical-align:middle;\">";
    str += "要绑定的主域名：";
    str += "</td>";
    str += "<td>";
    str += "<input type='text' name='cpDomain' title='必填项' class='text'> 如（IDCSystem.Net）";
    str += "</td>";
    str += "</tr>";
    str += "</table>";
    str += "<input type='hidden' name='cpEmail' value='" + userData[0].umail + "' />";
    if (productData[0].pconfig.mypdes == undefined) {
        str += "<input type='hidden' name='mypdes' value='[bandwidth]流量 / [quota]空间 / [vdomains]主域名 / [nsubdomains]子域名 / [ftp]FTP / [mysql]MYSQL' />";
    } else {
        str += "<input type='hidden' name='mypdes' value='" + productData[0].pconfig.mypdes + "' />";
    }
    str += "<span style=\"height:24px;display:block;\"></span>";
    $("#OrderConfig").html(str);
    $("#OrderConfig p").css("line-height", "25px");
    $("#OrderConfig label").css({ "margin-right": "18px" });

    $("#OrderConfig input[name='cycle']").click(function () {
        var pps = $(this).val().split('_');
        billingCycle = parseInt(pps[0]);
        normalPrice = parseFloat(pps[1]);
        finalPrice = normalPrice * discount;
                if (discount < 1) {
                    $("#discountedPrice").text('优惠价：' + finalPrice.toFixed(2));
                }
                //处理按钮同一行价格显示
                if (discount > 0 && discount < 1) {
                    $("#OrderNormalPrice").html("<strike>" + normalPrice + "</strike>");
                    $("#OrderPrice").html(finalPrice.toFixed(2));
                }
                else {
                    $("#OrderPrice").html(finalPrice.toFixed(2));
                        }
       
    });
    $("#OrderConfig input[name='cycle']:first").click();

    $(".ui-dialog-buttonset span").eq(0).click(function () {
       suwin.dialog({ title: "购买确认", autoOpen: false, resizable: false, width: 399, height: 368, modal: true, buttons: { "确定购买": function () { checkout(1); }, "继续配置": function () { $(this).dialog("close"); }, "在线充值": function () { window.open('?c=finance', '_blank'); } } }).dialog("open");
    });
}
orderConfig();
$(function () {
    $("#OrderConfig").find("tr").css("height", "25px");
});

function HTMLDecode(text) {
    var temp = document.createElement("div");
    temp.innerHTML = text;
    var output = temp.innerText || temp.textContent;
    temp = null;
    return output;
}
function getTimeCycleSuffix(billingCycle, timeCycle, tag) {
    var cycleSuffix = '';
    if (billingCycle == 0) {
        switch (timeCycle) {
            case '1': cycleSuffix = '天'; break;
            case '2': cycleSuffix = '小时'; break;
            default:
                cycleSuffix = '月';
                if (tag == 1) cycleSuffix = '个月';
                break;
        }
    }
    else {
        if (timeCycle == '0') {
            switch (billingCycle) {
                case '1': cycleSuffix = '月'; break;
                case '3': cycleSuffix = '季'; break;
                case '6': cycleSuffix = '半年'; break;
                case '12': cycleSuffix = '年'; break;
                case '24': cycleSuffix = '2年'; break;
                default: cycleSuffix = billingCycle + '个月'; break;
            }
        }
        else if (timeCycle == '1') {
            switch (billingCycle) {
                case '1': cycleSuffix = '天'; break;
                case '7': cycleSuffix = '周'; break;
                case '15': cycleSuffix = '半月'; break;
                case '30': cycleSuffix = '月'; break;
                case '90': cycleSuffix = '季'; break;
                case '365': cycleSuffix = '年'; break;
                default: cycleSuffix = billingCycle + '天'; break;
            }
        }
        else {
            switch (billingCycle) {
                case '1': cycleSuffix = '小时'; break;
                case '24': cycleSuffix = '天'; break;
                case '168': cycleSuffix = '周'; break;
                default: cycleSuffix = billingCycle + '小时'; break;
            }
        }
    }
    return cycleSuffix;
}