﻿/// <reference path="jquery.min.js" />
function baseConfig() {
    
    var product_data = productData;
    var str = '';
    str += '<strong>' + productData[0].pname + ' - 基本参数配置</strong>：<br / >';
    str += "<div style=\"color:red;padding-left:20px;\">*小提示：代理用户在DA面板修改用户包裹信息后，请您刷新此页面，再选择对应包裹点击“保存参数设置”</div>";
    //产品服务详情列表参数配置    
    str += '<div id="pdes" style="position:relative;">';
    str += '<strong>产品服务列表详情格式：</strong>';
    if (productData[0].pconfig.mypdes != undefined) {
        str += '<input  type="text" class="text" name="config_mypdes" style="width:490px;" value="' + productData[0].pconfig.mypdes + '" /> &nbsp;&nbsp;';
    } else {
        str += '<input type="text" class="text" name="config_mypdes" style="width:490px;" value="[bandwidth]流量 / [quota]空间 / [vdomains]主域名 / [nsubdomains]子域名 / [ftp]FTP / [mysql]MYSQL "/> &nbsp;&nbsp;';
        }
   
    str += '【<a href="javascript:void(0)" id="showcourse" style="font-weight:normal;">看教程</a>】';
    str += '</div>';
    //-----------参数说明书
    str += '<div id="showPdesBox" style="position:absolute;top:93px;left:150px;width:550px;height:350px;z-index:333;display:none;';
    str += 'background-color: #E6E6E6;border-radius: 5px;">';
    str += '<b style="padding-left:6px;padding-right:430px;">参数说明书：</b> <b style="cursor:pointer;" title="关闭说明书" onclick="javascript:hidePdesBox()">X</b>';
    str += '<div style="margin:15px 35px 0 35px;"><ul>';
    str += '<li>';
    str += '<b>1. </b>默认值可以不用修改，直接使用；';
    str += '</li>';
    str += '<li>';
    str += '<b>2. </b>也可以删除默认参数，自定义输入服务的详细说明；';
    str += '</li>';
    str += '<li>';
    str += '<b>3. </b>默认值使用说明，如[bandwidth]代表当前用户套餐的流量大小、[quota]代表虚拟主机空间大小，其他参数雷同；';
    str += '</li>';
    str += '<li>';
    str += '<li>';
    str += '<b>4. </b>默认参数有，[bandwidth]代表流量大小、[quota]代表空间大小、[vdomains]代表主域名配额、[nsubdomains]代表子域名配额、[ftp]代表FTP账户个数、[mysql]代表MYSQL数据库的个数、[cgi]代表对CGI访问，[dnscontrol]代表对DNS的控制权限等；';
    str += '</li>';
    str += '<li>';
    str += '<b>5. </b>如需了解更多详细说明，请参考<a style="color:blue;text-decoration:underline;" target="_blank" href="http://forum.xensystem.com/forum-7-1.html?fei=88">『官方论坛』</a>介绍。';
    str += '</li>';
    str += '</ul>'
    str += '</div>';
    str += '</div>';
    //-----------结束说明书
    //-----结束产品服务详情列表参数配置

    if (productData[0].pconfig.packageName != undefined || productData[0].pconfig.packageName != null) {
        str += "<strong>当前配置的包裹名称</strong>：" + productData[0].pconfig.packageName;
        str += "<br>";
    }
    str += "<fieldset style=\"border:1px solid #ccc; padding:0px 10px;margin:8px 0px;\">";
    str += "<legend style=\"padding:0px 6px;\">";
    str += '选择用户包裹';
    str += "</legend>";
    if (pFlag == 0) {
        var package = packageData.split('&');
        for (var j = 0; j < 20; j++) { packageDetails = packageDetails.replaceAll("ON", "支持").replaceAll("OFF", "不支持").replaceAll("unlimited", "不限"); }
        var detailsData = packageDetails.split('|');  //包裹信息分组数组
        var currDetails = "";      //当前设置的包裹信息
        str += "<label for=\"selectPackage\" style=\"cursor:default;\">";
        str += "你一共有" + package.length + "个用户包裹：";
        str += "</label>";
        str += "<select id=\"selectPackage\" name=\"selectPackage\" style=\"height:auto;cursor:pointer;\">";
        str += "";
        str += "";
        for (var i = 0; i < package.length; i++) {

            /* 处理包裹名称 */
            if (package[i] == productData[0].pconfig.packageName) {
                str += "<option style=\"height:20px;\" value=\"" + package[i] + "\" selected=\"selected\" >";
            } else {
                str += "<option style=\"height:20px;\" value=\"" + package[i] + "\" >";
            }
            str += package[i];
            str += "</option>";

            /* 处理当前设置的包裹详细 */
            if (detailsData[i].split('&')[0] == productData[0].pconfig.packageName) {
                currDetails = detailsData[i];
            }
        }
        str += "</select>";
        str += "";
        //处理包裹内的信息
        var bandwidth, quota, vdomains, nsubdomains, ftp, mysql, php, aftp, catchall, cgi, cron, dnscontrol, domainptr, language, nemailf, nemailml, nemailr, nemails, skin, spam, ssh, ssl, suspend_at_limit, sysinfo;
        var sData = currDetails.split('&');
        for (var j = 1; j < sData.length; j++) {
            if (sData[j].split('=')[0] == "bandwidth") { bandwidth = sData[j].split('=')[1]; }
            if (sData[j].split('=')[0] == "quota") { quota = sData[j].split('=')[1]; }
            if (sData[j].split('=')[0] == "vdomains") { vdomains = sData[j].split('=')[1]; }
            if (sData[j].split('=')[0] == "nsubdomains") { nsubdomains = sData[j].split('=')[1]; }
            if (sData[j].split('=')[0] == "ftp") { ftp = sData[j].split('=')[1]; }
            if (sData[j].split('=')[0] == "mysql") { mysql = sData[j].split('=')[1]; }
            if (sData[j].split('=')[0] == "php") { php = sData[j].split('=')[1]; }
            if (sData[j].split('=')[0] == "aftp") { aftp = sData[j].split('=')[1]; }
            if (sData[j].split('=')[0] == "catchall") { catchall = sData[j].split('=')[1]; }
            if (sData[j].split('=')[0] == "cgi") { cgi = sData[j].split('=')[1]; }
            if (sData[j].split('=')[0] == "cron") { cron = sData[j].split('=')[1]; }
            if (sData[j].split('=')[0] == "dnscontrol") { dnscontrol = sData[j].split('=')[1]; }
            if (sData[j].split('=')[0] == "domainptr") { domainptr = sData[j].split('=')[1]; }
            if (sData[j].split('=')[0] == "language") { language = sData[j].split('=')[1]; }
            if (sData[j].split('=')[0] == "nemailf") { nemailf = sData[j].split('=')[1]; }
            if (sData[j].split('=')[0] == "nemailml") { nemailml = sData[j].split('=')[1]; }
            if (sData[j].split('=')[0] == "nemailr") { nemailr = sData[j].split('=')[1]; }
            if (sData[j].split('=')[0] == "nemails") { nemails = sData[j].split('=')[1]; }
            if (sData[j].split('=')[0] == "skin") { skin = sData[j].split('=')[1]; }
            if (sData[j].split('=')[0] == "spam") { spam = sData[j].split('=')[1]; }
            if (sData[j].split('=')[0] == "ssh") { ssh = sData[j].split('=')[1]; }
            if (sData[j].split('=')[0] == "ssl") { ssl = sData[j].split('=')[1]; }
            if (sData[j].split('=')[0] == "suspend_at_limit") { suspend_at_limit = sData[j].split('=')[1]; }
            if (sData[j].split('=')[0] == "sysinfo") { sysinfo = sData[j].split('=')[1]; }
        }

        str += "<fieldset style=\"border:1px solid #ccc; padding:0px 10px;margin:8px 0px;\">";
        str += "<legend style=\"padding:0px 6px;\">";
        str += '用户包裹详细';
        str += "</legend>";
        str += "<table>";
        str += "<tr>";
        str += "<td style='width:100px;text-align:right;'>";
        str += "流量：";
        str += "</td>";
        str += "<td style='width:100px;text-align:left;'>";
        str += "<input type=\"hidden\" value='" + bandwidth + "' name=\"config_bandwidth\" id=\"config_bandwidth\" />";
        str += "<span style=\"\" id=\"bandwidth\">" + bandwidth + "</span> （M）";
        str += "</td>";
        str += "<td style='width:120px;text-align:right;'>";
        str += "磁盘大小：";
        str += "</td>";
        str += "<td style='text-align:left;'>";
        str += "<input type=\"hidden\" value='" + quota + "' name=\"config_quota\" id=\"config_quota\" />";
        str += "<span style=\"\" id=\"quota\">" + quota + "</span> （M）";
        str += "</td>";
        str += "</tr>";
        str += "<tr>";
        str += "<td style='width:100px;text-align:right;'>";
        str += "域名配额：";
        str += "</td>";
        str += "<td style='width:120px;text-align:left;'>";
        str += "<input type=\"hidden\" value='" + vdomains + "' name=\"config_vdomains\" id=\"config_vdomains\" />";
        str += "<span style=\"width:100px\" id=\"vdomains\">" + vdomains + "</span> （个）";
        str += "</td>";
        str += "<td style='width:100px;text-align:right;'>";
        str += "子域名配额：";
        str += "</td>";
        str += "<td style='text-align:left;'>";
        str += "<input type=\"hidden\" value='" + nsubdomains + "' name=\"config_nsubdomains\" id=\"config_nsubdomains\"/>";
        str += "<span style=\"\" id=\"nsubdomains\">" + nsubdomains + "</span> （个）";
        str += "</td>";
        str += "</tr>";
        str += "<tr>";
        str += "<td style='width:100px;text-align:right;'>";
        str += "Ftp帐户：";
        str += "</td>";
        str += "<td style='width:120px;text-align:left;'>";
        str += "<input type=\"hidden\" value='" + ftp + "' name=\"config_ftp\" id=\"config_ftp\"/>";
        str += "<span style=\"width:100px\" id=\"ftp\">" + ftp + "</span> （个）";
        str += "</td>";
        str += "<td style='width:100px;text-align:right;'>";
        str += "MySQL数据库：";
        str += "</td>";
        str += "<td style='text-align:left;'>";
        str += "<input type=\"hidden\" value='" + mysql + "' name=\"config_mysql\" id=\"config_mysql\"/>";
        str += "<span style=\"\" id=\"mysql\">" + mysql + "</span> （个）";
        str += "</td>";
        str += "</tr>";
        str += "<tr>";
        str += "<td style='width:100px;text-align:right;'>";
        str += "PHP访问：";
        str += "</td>";
        str += "<td style='width:120px;text-align:left;'>";
        str += "<input type=\"hidden\" value='" + php + "' name=\"config_php\" id=\"config_php\"/>";
        str += "<span style=\"width:100px\" id=\"php\">" + php + "</span>";
        str += "</td>";
        str += "<td style='width:100px;text-align:right;'>";
        str += "匿名FTP帐户：";
        str += "</td>";
        str += "<td style='text-align:left;'>";
        str += "<input type=\"hidden\" value='" + aftp + "' name=\"config_aftp\" id=\"config_aftp\"/>";
        str += "<span style=\"\" id=\"aftp\">" + aftp + "</span>";
        str += "</td>";
        str += "</tr>";
        str += "<tr>";
        str += "<td style='width:100px;text-align:right;' title=\"ON or OFF If ON, the User will have the ability to enable and customize a catch-all email (*@domain.com).  \">";
        str += "|LANG_CATCHALL|：";
        str += "</td>";
        str += "<td style='width:120px;text-align:left;'>";
        str += "<input type=\"hidden\" value='" + catchall + "' name=\"config_catchall\" id=\"config_catchall\"/>";
        str += "<span style=\"width:100px\" id=\"catchall\">" + catchall + "</span>";
        str += "</td>";
        str += "<td style='width:100px;text-align:right;'>";
        str += "CGI访问：";
        str += "</td>";
        str += "<td style='text-align:left;'>";
        str += "<input type=\"hidden\" value='" + cgi + "' name=\"config_cgi\" id=\"config_cgi\"/>";
        str += "<span style=\"\"  id=\"cgi\">" + cgi + "</span>";
        str += "</td>";
        str += "</tr>";
        str += "<tr>";
        str += "<td style='width:100px;text-align:right;'>";
        str += "DNS控制：";
        str += "</td>";
        str += "<td style='width:120px;text-align:left;'>";
        str += "<input type=\"hidden\" value='" + dnscontrol + "' name=\"config_dnscontrol\" id=\"config_dnscontrol\"/>";
        str += "<span style=\"width:100px\" id=\"dnscontrol\">" + dnscontrol + "</span>";
        str += "</td>";
        str += "<td style='width:100px;text-align:right;'>";
        str += "计划任务：";
        str += "</td>";
        str += "<td style='text-align:left;'>";
        str += "<input type=\"hidden\" value='" + cron + "'  name=\"config_cron\" id=\"config_cron\" />";
        str += "<span style=\"\" id=\"cron\">" + cron + "</span>";
        str += "</td>";
        str += "</tr>";
        str += "<tr>";
        str += "<td style='width:100px;text-align:right;'>";
        str += "绑定域名：";
        str += "</td>";
        str += "<td style='width:120px;text-align:left;'>";
        str += "<input type=\"hidden\" value='" + domainptr + "'  name=\"config_domainptr\" id=\"config_domainptr\" />";
        str += "<span style=\"width:100px\" id=\"domainptr\">" + domainptr + "</span> （个）";
        str += "</td>";
        str += "<td style='width:100px;text-align:right;'>";
        str += "语言：";
        str += "</td>";
        str += "<td style='text-align:left;'>";
        str += "<input type=\"hidden\" value='" + language + "'  name=\"config_language\" id=\"config_language\" />";
        str += "<span style=\"\" id=\"language\">" + language + "</span>";
        str += "</td>";
        str += "</tr>";
        str += "<tr>";
        str += "<td style='width:100px;text-align:right;'>";
        str += "Email转发器：";
        str += "</td>";
        str += "<td style='width:120px;text-align:left;'>";
        str += "<input type=\"hidden\" value='" + nemailf + "'  name=\"config_nemailf\" id=\"config_nemailf\" />";
        str += "<span style=\"width:100px\" id=\"nemailf\">" + nemailf + "</span> （个）";
        str += "</td>";
        str += "<td style='width:100px;text-align:right;'>";
        str += "邮件列表：";
        str += "</td>";
        str += "<td style='text-align:left;'>";
        str += "<input type=\"hidden\" value='" + nemailml + "'  name=\"config_nemailml\" id=\"config_nemailml\" />";
        str += "<span style=\"\" id=\"nemailml\">" + nemailml + "</span> （个）";
        str += "</td>";
        str += "</tr>";
        str += "<tr>";
        str += "<td style='width:100px;text-align:right;'>";
        str += "自动应答器：";
        str += "</td>";
        str += "<td style='width:120px;text-align:left;'>";
        str += "<input type=\"hidden\" value='" + nemailr + "' name=\"config_nemailr\" id=\"config_nemailr\" />";
        str += "<span style=\"width:100px\" id=\"nemailr\">" + nemailr + "</span> （个）";
        str += "</td>";
        str += "<td style='width:100px;text-align:right;'>";
        str += "Email帐户：";
        str += "</td>";
        str += "<td style='text-align:left;'>";
        str += "<input type=\"hidden\" value='" + nemails + "' name=\"config_nemails\" id=\"config_nemails\" />";
        str += "<span style=\"\" id=\"nemails\">" + nemails + "</span> （个）";
        str += "</td>";
        str += "</tr>";
        str += "<tr>";
        str += "<td style='width:100px;text-align:right;'>";
        str += "SSH 访问：";
        str += "</td>";
        str += "<td style='width:120px;text-align:left;'>";
        str += "<input type=\"hidden\" value='" + ssh + "'  name=\"config_ssh\" id=\"config_ssh\" />";
        str += "<span style=\"width:100px\" id=\"ssh\">" + ssh + "</span>";
        str += "</td>";
        str += "<td style='width:100px;text-align:right;'>";
        str += "SSL 访问：";
        str += "</td>";
        str += "<td style='text-align:left;'>";
        str += "<input type=\"hidden\" value='" + ssl + "'  name=\"config_ssl\" id=\"config_ssl\" />";
        str += "<span style=\"\" id=\"ssl\">" + ssl + "</span>";
        str += "</td>";
        str += "</tr>";
        str += "<tr>";
        str += "<td style='width:100px;text-align:right;'>";
        str += "垃圾清理：";
        str += "</td>";
        str += "<td style='width:100px;text-align:left;'>";
        str += "<input type=\"hidden\" value='" + spam + "'  name=\"config_spam\" id=\"config_spam\" />";
        str += "<span style=\"\" id=\"spam\">" + spam + "</span>";
        str += "</td>";
        str += "<td style='width:80px;text-align:right;'>";
        str += "系统信息：";
        str += "</td>";
        str += "<td style='text-align:left;'>";
        str += "<input type=\"hidden\" value='" + sysinfo + "'  name=\"config_sysinfo\" id=\"config_sysinfo\" />";
        str += "<span style=\"\" id=\"sysinfo\">" + sysinfo + "</span>";
        str += "</td>";
        str += "</tr>";
        str += "<tr>";
        str += "<td style='text-align:right;width:230px;'>";
        str += "Suspend At Limit（延缓极限交易）：";
        str += "</td>";
        str += "<td style='text-align:left;' colspan=\"3\">";
        str += "<input type=\"hidden\" value='" + suspend_at_limit + "'  name=\"config_suspend_at_limit\" id=\"config_suspend_at_limit\" />";
        str += "<span style=\"width:50px\" id=\"suspend_at_limit\">" + suspend_at_limit + "</span>";
        str += "</td>";
        str += "</tr>";
        str += "<tr>";
        str += "<td style='width:100px;text-align:right;'>";
        str += "是否发送邮件：";
        str += "</td>";
        str += "<td style='text-align:left;'>";
        if (product_data[0].pconfig.notify == null || product_data[0].pconfig.notify == undefined || product_data[0].pconfig.notify == "yes") {
            product_data[0].pconfig.notify = "yes";
            str += "<input type=\"radio\" title=\"An email will be sent to email\" style='cursor:pointer;' checked=\"checked\" value='yes' name=\"config_notify\" id=\"config_notify\" />是&nbsp;&nbsp;&nbsp;";
            str += "<input type=\"radio\" value='no' name=\"config_notify\" style='cursor:pointer;' />否";
        }
        else {
            str += "<input type=\"radio\" title=\"An email will be sent to email\" style='cursor:pointer;' value='yes' name=\"config_notify\" id=\"config_notify\"  />是&nbsp;&nbsp;&nbsp;";
            str += "<input type=\"radio\" style='cursor:pointer;' checked=\"checked\"  value='no' name=\"config_notify\" />否";
        }
        str += "</td>";
        str += "<td style=''>";
        str += "";
        str += "</td>";
        str += "<td style=''>";
        str += "";
        str += "</td>";
        str += "</tr>";
        str += "<tr>";
        str += "<td style='width:100px;text-align:right;'>";
        str += "其它自定义描述：";
        str += "</td>";
        str += "<td style='text-align:left;' colspan=\"3\">";
        if (product_data[0].pconfig.other == undefined || product_data[0].pconfig.other == null || product_data[0].pconfig.other == "undefined" || product_data[0].pconfig.other == "") {
            str += "<textarea style=\"width:375px;height:80px\" name=\"config_other\"></textarea>";
        }
        else {
            str += "<textarea style=\"width:375px;height:80px\" name=\"config_other\">" + product_data[0].pconfig.other + "</textarea>";
        }
        str += "</td>";
        str += "</tr>";
        str += "</table>";
        str += "<br/>";
        str += "</fieldset>";
        str += "";
        str += "<div id=\"loading\" style=\"width:300px;text-align:center;padding-top:20px;\"></div>";
        str += "<input type=\"hidden\" value='" + productData[0].pconfig.packageName + "' name=\"config_packageName\" id=\"config_packageName\" />";
    }
    else {
        str = "<div style=\"width:700px;color:red;text-align:center;padding-top:150px;\" >抱歉，代理的接口参数验证失败或还未添加用户包裹，暂不支持开通空间，请查证后再试！</div>";
    }
    str += "</fieldset>";
    $("#ProductConfig").html(str);

    $("#showcourse").click(function () {
        $("#showPdesBox").show();
    });
}
baseConfig();

function hidePdesBox() { $("#showPdesBox").hide(); }
$(function () {
    
    if (productData[0].pconfig.packageName == null || productData[0].pconfig.packageName == "undefined") {
        $("#config_packageName").val($("#selectPackage").val());
        //读取包裹信息 alert($("#selectPackage").val());
        //读取包裹信息 
        var selectDetails = "";
        for (var i = 0; i < packageData.split('&').length; i++) {
            /* 处理当前设置的包裹详细 */
            if (packageDetails.split('|')[i].split('&')[0] == $("#selectPackage").val()) {
                selectDetails = packageDetails.split('|')[i];
            }
        }
        //处理包裹内的信息
        selectDetails = selectDetails.replaceAll("ON", "支持").replaceAll("OFF", "不支持").replaceAll("unlimited", "不限");
        var sData = selectDetails.split('&');
        for (var j = 1; j < sData.length; j++) {
            if (sData[j].split('=')[0] == "bandwidth") { $("#config_bandwidth").val(sData[j].split('=')[1]); $("#bandwidth").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "quota") { $("#config_quota").val(sData[j].split('=')[1]); $("#quota").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "vdomains") { $("#config_vdomains").val(sData[j].split('=')[1]); $("#vdomains").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "nsubdomains") { $("#config_nsubdomains").val(sData[j].split('=')[1]); $("#nsubdomains").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "ftp") { $("#config_ftp").val(sData[j].split('=')[1]); $("#ftp").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "mysql") { $("#config_mysql").val(sData[j].split('=')[1]); $("#mysql").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "php") { $("#config_php").val(sData[j].split('=')[1]); $("#php").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "aftp") { $("#config_aftp").val(sData[j].split('=')[1]); $("#aftp").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "catchall") { $("#config_catchall").val(sData[j].split('=')[1]); $("#catchall").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "cgi") { $("#config_cgi").val(sData[j].split('=')[1]); $("#cgi").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "cron") { $("#config_cron").val(sData[j].split('=')[1]); $("#cron").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "dnscontrol") { $("#config_dnscontrol").val(sData[j].split('=')[1]); $("#dnscontrol").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "domainptr") { $("#config_domainptr").val(sData[j].split('=')[1]); $("#domainptr").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "language") { $("#config_language").val(sData[j].split('=')[1]); $("#language").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "nemailf") { $("#config_nemailf").val(sData[j].split('=')[1]); $("#nemailf").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "nemailml") { $("#config_nemailml").val(sData[j].split('=')[1]); $("#nemailml").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "nemailr") { $("#config_nemailr").val(sData[j].split('=')[1]); $("#nemailr").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "nemails") { $("#config_nemails").val(sData[j].split('=')[1]); $("#nemails").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "skin") { $("#config_skin").val(sData[j].split('=')[1]); $("#skin").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "spam") { $("#config_spam").val(sData[j].split('=')[1]); $("#spam").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "ssh") { $("#config_ssh").val(sData[j].split('=')[1]); $("#ssh").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "ssl") { $("#config_ssl").val(sData[j].split('=')[1]); $("#ssl").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "suspend_at_limit") { $("#config_suspend_at_limit").val(sData[j].split('=')[1]); $("#suspend_at_limit").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "sysinfo") { $("#config_sysinfo").val(sData[j].split('=')[1]); $("#sysinfo").html(sData[j].split('=')[1]); }
        }

    }
    $("#selectPackage").change(function () {
        //alert($("#selectPackage").val());
        $("#config_packageName").val($("#selectPackage").val());
        //读取包裹信息 
        var selectDetails = "";
        for (var i = 0; i < packageData.split('&').length; i++) {

            /* 处理当前设置的包裹详细 */
            if (packageDetails.split('|')[i].split('&')[0] == $("#selectPackage").val()) {
                selectDetails = packageDetails.split('|')[i];
            }
        }
        //处理包裹内的信息
        selectDetails = selectDetails.replaceAll("ON", "支持").replaceAll("OFF", "不支持").replaceAll("unlimited", "不限");
        var sData = selectDetails.split('&');
        for (var j = 1; j < sData.length; j++) {
            //sData[j].split('=')[1] = sData[j].split('=')[1].replace("ON", "是").replace("OFF", "否");
            if (sData[j].split('=')[0] == "bandwidth") { $("#config_bandwidth").val(sData[j].split('=')[1]); $("#bandwidth").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "quota") { $("#config_quota").val(sData[j].split('=')[1]); $("#quota").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "vdomains") { $("#config_vdomains").val(sData[j].split('=')[1]); $("#vdomains").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "nsubdomains") { $("#config_nsubdomains").val(sData[j].split('=')[1]); $("#nsubdomains").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "ftp") { $("#config_ftp").val(sData[j].split('=')[1]); $("#ftp").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "mysql") { $("#config_mysql").val(sData[j].split('=')[1]); $("#mysql").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "php") { $("#config_php").val(sData[j].split('=')[1]); $("#php").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "aftp") { $("#config_aftp").val(sData[j].split('=')[1]); $("#aftp").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "catchall") { $("#config_catchall").val(sData[j].split('=')[1]); $("#catchall").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "cgi") { $("#config_cgi").val(sData[j].split('=')[1]); $("#cgi").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "cron") { $("#config_cron").val(sData[j].split('=')[1]); $("#cron").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "dnscontrol") { $("#config_dnscontrol").val(sData[j].split('=')[1]); $("#dnscontrol").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "domainptr") { $("#config_domainptr").val(sData[j].split('=')[1]); $("#domainptr").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "language") { $("#config_language").val(sData[j].split('=')[1]); $("#language").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "nemailf") { $("#config_nemailf").val(sData[j].split('=')[1]); $("#nemailf").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "nemailml") { $("#config_nemailml").val(sData[j].split('=')[1]); $("#nemailml").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "nemailr") { $("#config_nemailr").val(sData[j].split('=')[1]); $("#nemailr").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "nemails") { $("#config_nemails").val(sData[j].split('=')[1]); $("#nemails").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "skin") { $("#config_skin").val(sData[j].split('=')[1]); $("#skin").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "spam") { $("#config_spam").val(sData[j].split('=')[1]); $("#spam").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "ssh") { $("#config_ssh").val(sData[j].split('=')[1]); $("#ssh").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "ssl") { $("#config_ssl").val(sData[j].split('=')[1]); $("#ssl").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "suspend_at_limit") { $("#config_suspend_at_limit").val(sData[j].split('=')[1]); $("#suspend_at_limit").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "sysinfo") { $("#config_sysinfo").val(sData[j].split('=')[1]); $("#sysinfo").html(sData[j].split('=')[1]); }
        }

    });
});
function doDetails(details, i) {
    var sData = details.split('&');
    for (var j = 1; j < sData.length; j++) {
        if (sData[j].split('=')[0] == i) { return sData[j].split('=')[1]; }
    }
}