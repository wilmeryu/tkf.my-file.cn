﻿/// <reference path="jquery.min.js" />
function serviceConfig() {
    var service_data = serviceData;
    var str = ''; var unTxt = '不限';
    if (pFlag == 0) {
        var package = packageData.split('&');
        var limitText = "不限";
        packageDetails = packageDetails.replace("ON", "支持").replace("OFF", "不支持").replaceAll("unlimited", limitText);
        var detailsData = packageDetails.split('|');  //包裹信息分组数组
        var currDetails = "";      //当前设置的包裹信息
        //虚拟主机信息
        str += '<input type="hidden" value="' + serviceData[0].sconfig.serverIP + '" name="serverIP" />';
        str += '<input type="hidden" value="' + serviceData[0].sconfig.serverPwd + '" name="serverPwd" />';
        str += '<input type="hidden" value="' + serviceData[0].sconfig.serverDomain + '" name="serverDomain" id="serverDomain" />';
        str += '<table>';
        str += '<tr style="height:26px;">';
        str += '<td style="width:90px;text-align:right;">';
        str += '<strong>虚拟主机IP：</strong>';
        str += '</td>';
        str += '<td style="width:130px;text-align:left;" id="serverip">';
        str += serviceData[0].sconfig.serverIP;
        str += '</td>';
        str += '<td  style="width:120px;text-align:right;">';
        str += '<strong>绑定的主域名：</strong>';
        str += '</td>';
        str += '<td><span id="showDomain">';
        str += serviceData[0].sconfig.serverDomain;
        str += '</span></td>';
        str += '</tr>';
        str += '<tr style="height:26px;">';
        str += '<td style="width:90px;text-align:right;">';
        str += '<strong>用户名：</strong>';
        str += '</td>';
        str += '<td style="text-align:left;">';
        str += 'v' + serviceData[0].ssid;
        str += '</td>';
        str += '<td style="width:120px;text-align:right;">';
        str += '<strong>初始密码：</strong>';
        str += '</td>';
        str += '<td>';
        str += serviceData[0].sconfig.serverPwd;
        str += '</td>';
        str += '</tr>';
        if (serviceData[0].sconfig.transferFlag != undefined) {
            str += '<tr style="style="height:26px;line-height:26px;"">';
            str += '<td style="width:90px;text-align:right;height:26px;line-height:26px;">';
            str += '<strong title="yes表示是手动转入用户；no表示平台自动开通">是否转入：</strong>';
            str += '</td>';
            str += '<td style="text-align:left;style="height:26px;line-height:26px;"">';
            str += '<input title="yes表示是手动转入用户；no表示平台自动开通" value="' + serviceData[0].sconfig.transferFlag + '" name="transferFlag" style="width:50px;" /> <span style="margin-bottom:-5px;">(yes/no)</span>';
            str += '</td>';
            str += '<td style="width:120px;text-align:right;height:26px;line-height:26px;">';
            str += '<strong>转入的用户名：</strong>';
            str += '</td>';
            str += '<td style="height:26px;line-height:26px;">';
            str += '<input value="' + serviceData[0].sconfig.transferName + '" name="transferName" style="" />';
            str += '</td>';
            str += '</tr>';
        }
        else {
            str += '<tr style="height:26px;line-height:26px;">';
            str += '<td style="width:90px;text-align:right;height:26px;line-height:26px;">';
            str += '<strong title="yes表示是手动转入用户；no表示平台自动开通">是否转入：</strong>';
            str += '</td>';
            str += '<td style="text-align:left;line-height:26px;">';
            str += '<input title="yes表示是手动转入用户；no表示平台自动开通" value="no" name="transferFlag" style="width:50px;" /> <span style="margin-bottom:-5px;">(yes/no)</span>';
            str += '</td>';
            str += '<td style="width:120px;text-align:right;height:26px;line-height:26px;">';
            str += '<strong>转入的用户名：</strong>';
            str += '</td>';
            str += '<td style="height:26px;line-height:26px;">';
            str += '<input value=v"' + serviceData[0].ssid + '" name="transferName" style="" />';
            str += '</td>';
            str += '</tr>';
        }
        str += '</table>';
        str += '<br/>';
        str += '<table>';
        str += '<tr style="line-height:28px;">';
        str += '<td><strong>更换用户包裹：</strong></td>';
        str += '<td>';
        str += "<select id=\"selectPackage\" name=\"selectPackage\" style=\"height:auto;cursor:pointer;\">";
        for (var i = 0; i < package.length; i++) {
            /* 处理包裹名称 */
            if (package[i] == serviceData[0].sconfig.packageName) {
                str += "<option style=\"height:20px;\" value=\"" + package[i] + "\" selected=\"selected\" >";
            } else {
                str += "<option style=\"height:20px;\" value=\"" + package[i] + "\" >";
            }
            str += package[i];
            str += "</option>";
            /* 处理当前设置的包裹详细 */
            if (detailsData[i].split('&')[0] == serviceData[0].sconfig.packageName) {
                currDetails = detailsData[i];
            }
        }
        str += '</select>';
        str += '</td>';
        str += '<td>';
        //同步DA里面的个人配置信息
        str += '<span id="tbFlag">正在同步虚拟主机信息</span><span id="loading"><img src="images/loading.gif" /></span>';
        str += '<span id="tbBtn"><input type="button" value="重新更新" class="submit" /></span>';
        str += '<span id="statusFlag"></span>';
        str += '</td>';
        str += '</tr>';
        str += '</table>';
        str += '<b style="height:13px;display:block;"></b>';
        str += '<fieldset style="border:1px solid #ccc; padding:0px 10px;margin:8px 0px;">';
        str += '<legend style="padding:0px 6px;">';
        str += '用户包裹详细';
        str += '</legend>';
        str += '';
        str += '<b style="height:10px;display:block;"></b>';
        str += '<table id="tb">';
        str += '<tr>';
        str += '<td style="width:100px;text-align:right;">';
        str += '流量：';
        str += '</td>';
        str += '<td style="width:100px;text-align:left;">';
        str += '<input type="hidden" value="' + serviceData[0].sconfig.bandwidth + '" name="bandwidth" id="config_bandwidth" />';
        str += '<span id="bandwidth">' + serviceData[0].sconfig.bandwidth.replace("unlimited", limitText) + '</span>（M）';
        str += '</td>';
        str += '<td style="width:160px;text-align:right;">';
        str += '空间大小：';
        str += '</td>';
        str += '<td style="width:100px;text-align:left;">';
        str += '<input type="hidden" value="' + serviceData[0].sconfig.quota + '" name="quota" id="config_quota" />';
        str += '<span id="quota">' + serviceData[0].sconfig.quota.replace("unlimited", limitText) + '</span>（M）';
        str += '</td>';
        str += '<td style="width:160px;text-align:right;">';
        str += '域名配额：';
        str += '</td>';
        str += '<td>';
        str += '<input type="hidden" value="' + serviceData[0].sconfig.vdomains + '" name="vdomains" id="config_vdomains" />';
        str += '<span id="vdomains">' + serviceData[0].sconfig.vdomains.replace("unlimited", limitText) + '</span>（个）';
        str += '</td>';
        str += '</tr>';
        str += '<tr>';
        str += '<td style="width:100px;text-align:right;">';
        str += '子域名配额：';
        str += '</td>';
        str += '<td>';
        str += '<input type="hidden" value="' + serviceData[0].sconfig.nsubdomains + '" name="nsubdomains" id="config_nsubdomains" />';
        str += '<span id="nsubdomains">' + serviceData[0].sconfig.nsubdomains.replace("unlimited", limitText) + '</span>（个）';
        str += '</td>';
        str += '<td style="width:160px;text-align:right;">';
        str += 'Email帐户：';
        str += '</td>';
        str += '<td style="width:100px;text-align:left;">';
        str += '<input type="hidden" value="' + serviceData[0].sconfig.nemails + '" name="nemails" id="config_nemails" />';
        str += '<span id="nemails">' + serviceData[0].sconfig.nemails.replace("unlimited", limitText) + '</span>（个）';
        str += '</td>';
        str += '<td style="width:160px;text-align:right;">';
        str += 'Email转发器：';
        str += '</td>';
        str += '<td>';
        str += '<input type="hidden" value="' + serviceData[0].sconfig.nemailf + '" name="nemailf" id="config_nemailf" />';
        str += '<span id="nemailf">' + serviceData[0].sconfig.nemailf.replace("unlimited", limitText) + '</span>（个）';
        str += '</td>';
        str += '</tr>';
        str += '<tr>';
        str += '<td style="width:100px;text-align:right;">';
        str += '邮件列表：';
        str += '</td>';
        str += '<td>';
        str += '<input type="hidden" value="' + serviceData[0].sconfig.nemailml + '" name="nemailml" id="config_nemailml" />';
        str += '<span id="nemailml">' + serviceData[0].sconfig.nemailml.replace("unlimited", limitText) + '</span>（个）';
        str += '</td>';
        str += '<td style="width:160px;text-align:right;">';
        str += '自动应答器：';
        str += '</td>';
        str += '<td style="width:100px;text-align:left;">';
        str += '<input type="hidden" value="' + serviceData[0].sconfig.nemailr + '" name="nemailr" id="config_nemailr" />';
        str += '<span id="nemailr">' + serviceData[0].sconfig.nemailr.replace("unlimited", limitText) + '</span>（个）';
        str += '</td>';
        str += '<td style="width:160px;text-align:right;">';
        str += 'MySQL数据库：';
        str += '</td>';
        str += '<td>';
        str += '<input type="hidden" value="' + serviceData[0].sconfig.mysql + '" name="mysql" id="config_mysql" />';
        str += '<span id="mysql">' + serviceData[0].sconfig.mysql.replace("unlimited", limitText) + '</span>（个）';
        str += '</td>';
        str += '</tr>';
        str += '<tr>';
        str += '<td style="width:100px;text-align:right;">';
        str += '绑定域名：';
        str += '</td>';
        str += '<td>';
        str += '<input type="hidden" value="' + serviceData[0].sconfig.domainptr + '" name="domainptr" id="config_domainptr" />';
        str += '<span id="domainptr">' + serviceData[0].sconfig.domainptr.replace("unlimited", limitText) + '</span>（个）';
        str += '</td>';
        str += '<td style="width:160px;text-align:right;">';
        str += 'Ftp帐户：';
        str += '</td>';
        str += '<td style="width:100px;text-align:left;">';
        str += '<input type="hidden" value="' + serviceData[0].sconfig.ftp + '" name="ftp" id="config_ftp" />';
        str += '<span id="ftp">' + serviceData[0].sconfig.ftp.replace("unlimited", limitText) + '</span>（个）';
        str += '</td>';
        str += '<td style="width:160px;text-align:right;">';
        str += '匿名FTP帐户：';
        str += '</td>';
        str += '<td>';
        str += '<input type="hidden" value="' + serviceData[0].sconfig.aftp + '" name="aftp" id="config_aftp" />';
        str += '<span id="aftp">' + serviceData[0].sconfig.aftp + '</span>';
        str += '</td>';
        str += '</tr>';
        str += '<tr>';
        str += '<td style="width:100px;text-align:right;">';
        str += 'CGI访问：';
        str += '</td>';
        str += '<td>';
        str += '<input type="hidden" value="' + serviceData[0].sconfig.cgi + '" name="cgi" id="config_cgi" />';
        str += '<span id="cgi">' + serviceData[0].sconfig.cgi + '</span>';
        str += '</td>';
        str += '<td style="width:160px;text-align:right;">';
        str += 'PHP访问：';
        str += '</td>';
        str += '<td style="width:100px;text-align:left;">';
        str += '<input type="hidden" value="' + serviceData[0].sconfig.php + '" name="php" id="config_php" />';
        str += '<span id="php">' + serviceData[0].sconfig.php + '</span>';
        str += '</td>';
        str += '<td style="width:160px;text-align:right;">';
        str += '垃圾清理：';
        str += '</td>';
        str += '<td>';
        str += '<input type="hidden" value="' + serviceData[0].sconfig.spam + '" name="spam" id="config_spam" />';
        str += '<span id="spam">' + serviceData[0].sconfig.spam + '</span>';
        str += '</td>';
        str += '</tr>';
        str += '<tr>';
        str += '<td style="width:100px;text-align:right;">';
        str += '计划任务：';
        str += '</td>';
        str += '<td>';
        str += '<input type="hidden" value="' + serviceData[0].sconfig.cron + '" name="cron" id="config_cron" />';
        str += '<span id="cron">' + serviceData[0].sconfig.cron + '</span>';
        str += '</td>';
        str += '<td style="width:160px;text-align:right;">';
        str += '|LANG_CATCHALL|：';
        str += '</td>';
        str += '<td style="width:100px;text-align:left;">';
        str += '<input type="hidden" value="' + serviceData[0].sconfig.catchall + '" name="catchall" id="config_catchall" />';
        str += '<span id="catchall">' + serviceData[0].sconfig.catchall + '</span>';
        str += '</td>';
        str += '<td style="width:160px;text-align:right;">';
        str += 'SSL 访问：';
        str += '</td>';
        str += '<td>';
        str += '<input type="hidden" value="' + serviceData[0].sconfig.ssl + '" name="ssl" id="config_ssl" />';
        str += '<span id="ssl">' + serviceData[0].sconfig.ssl + '</span>';
        str += '</td>';
        str += '</tr>';
        str += '<tr>';
        str += '<td style="width:100px;text-align:right;">';
        str += 'SSH 访问：';
        str += '</td>';
        str += '<td>';
        str += '<input type="hidden" value="' + serviceData[0].sconfig.ssh + '" name="ssh" id="config_ssh" />';
        str += '<span id="ssh">' + serviceData[0].sconfig.ssh + '</span>';
        str += '</td>';
        str += '<td style="width:160px;text-align:right;">';
        str += '系统信息：';
        str += '</td>';
        str += '<td style="width:100px;text-align:left;">';
        str += '<input type="hidden" value="' + serviceData[0].sconfig.sysinfo + '" name="sysinfo" id="config_sysinfo" />';
        str += '<span id="sysinfo">' + serviceData[0].sconfig.sysinfo + '</span>';
        str += '</td>';
        str += '<td style="width:160px;text-align:right;">';
        str += 'DNS控制：';
        str += '</td>';
        str += '<td>';
        str += '<input type="hidden" value="' + serviceData[0].sconfig.dnscontrol + '" name="dnscontrol" id="config_dnscontrol" />';
        str += '<span id="dnscontrol">' + serviceData[0].sconfig.dnscontrol + '</span>';
        str += '</td>';
        str += '</tr>';
        str += '<tr>';
        str += '<td style="width:100px;text-align:right;">';
        str += '是否发送邮件：';
        str += '</td>';
        str += '<td>';
        str += '<input type="hidden" value="' + serviceData[0].sconfig.notify.replace("yes", "是").replace("no", "否") + '" name="notify" id="config_notify" />';
        str += '<span id="notify">' + serviceData[0].sconfig.notify.replace("yes", "是").replace("no", "否") + '</span>';
        str += '</td>';
        str += '<td style="text-align:right;" colspan="2">';
        str += 'Suspend At Limit（延缓极限交易）：';
        str += '</td>';
        str += '<td style="text-align:left;" colspan="4">';
        str += '<input type="hidden" value="' + serviceData[0].sconfig.suspend_at_limit + '" name="suspend_at_limit" id="config_suspend_at_limit" />';
        str += '<span id="suspend_at_limit">' + serviceData[0].sconfig.suspend_at_limit + '</span>';
        str += '</td>';
        str += '</tr>';

        str += '</table>';
        str += '</fieldset>';
        str += '';
        str += '<input type="hidden" value="' + serviceData[0].sconfig.packageName + '" name="packageName" id="config_packageName" />';
        str += '<br/>';
        if (serviceData[0].sconfig.other != '') {
            str += '<table><tr><td><strong>其他描述：</strong></td><td>';
            str += '<textarea style="width:375px;height:80px;" name="other">';
            str += serviceData[0].sconfig.other;
            str += '</textarea>';
            str += '</td></tr></table>';
        }
        else {
            str += '<table><tr><td><strong>其他描述：</strong></td><td>';
            str += '<textarea style="width:375px;height:80px;" name="other">';
            str += '';
            str += '</textarea>';
            str += '</td></tr></table>';
        }
    } else {
        str = '<div style="padding:50px auto auto 150px;color:red;">读取用户包裹出错，请稍后再试或联系系统管理员！</div>';
    }
    $("#ServiceConfig").html('&nbsp;<br /><p style="line-height:30px">' + str + '</p>');
}
serviceConfig();
$(function () {
    if (productData[0].pconfig.packageName == null || productData[0].pconfig.packageName == "undefined") {
        //读取包裹信息 alert($("#selectPackage").val());
        //读取包裹信息 
        var selectDetails = "";
        for (var i = 0; i < packageData.split('&').length; i++) {
            /* 处理当前设置的包裹详细 */
            if (packageDetails.split('|')[i].split('&')[0] == $("#selectPackage").val()) {
                selectDetails = packageDetails.split('|')[i];
            }
        }
        //处理包裹内的信息
        selectDetails = selectDetails.replaceAll("ON", "支持").replaceAll("OFF", "不支持").replaceAll("否", "不支持");
    }
    $("#selectPackage").change(function () {
        //alert($("#selectPackage").val());
        $("#config_packageName").val($("#selectPackage").val());
        //读取包裹信息 
        var selectDetails = "";
        for (var i = 0; i < packageData.split('&').length; i++) {

            /* 处理当前设置的包裹详细 */
            if (packageDetails.split('|')[i].split('&')[0] == $("#selectPackage").val()) {
                selectDetails = packageDetails.split('|')[i];
            }
        }
        //处理包裹内的信息
        selectDetails = selectDetails.replaceAll("ON", "支持").replaceAll("OFF", "不支持").replaceAll("否", "不支持");
        var sData = selectDetails.split('&');
        for (var j = 1; j < sData.length; j++) {
            //sData[j].split('=')[1] = sData[j].split('=')[1].replace("ON", "是").replace("OFF", "否");
            if (sData[j].split('=')[0] == "bandwidth") { $("#config_bandwidth").val(sData[j].split('=')[1]); $("#bandwidth").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "quota") { $("#config_quota").val(sData[j].split('=')[1]); $("#quota").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "vdomains") { $("#config_vdomains").val(sData[j].split('=')[1]); $("#vdomains").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "nsubdomains") { $("#config_nsubdomains").val(sData[j].split('=')[1]); $("#nsubdomains").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "ftp") { $("#config_ftp").val(sData[j].split('=')[1]); $("#ftp").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "mysql") { $("#config_mysql").val(sData[j].split('=')[1]); $("#mysql").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "php") { $("#config_php").val(sData[j].split('=')[1]); $("#php").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "aftp") { $("#config_aftp").val(sData[j].split('=')[1]); $("#aftp").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "catchall") { $("#config_catchall").val(sData[j].split('=')[1]); $("#catchall").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "cgi") { $("#config_cgi").val(sData[j].split('=')[1]); $("#cgi").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "cron") { $("#config_cron").val(sData[j].split('=')[1]); $("#cron").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "dnscontrol") { $("#config_dnscontrol").val(sData[j].split('=')[1]); $("#dnscontrol").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "domainptr") { $("#config_domainptr").val(sData[j].split('=')[1]); $("#domainptr").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "language") { $("#config_language").val(sData[j].split('=')[1]); $("#language").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "nemailf") { $("#config_nemailf").val(sData[j].split('=')[1]); $("#nemailf").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "nemailml") { $("#config_nemailml").val(sData[j].split('=')[1]); $("#nemailml").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "nemailr") { $("#config_nemailr").val(sData[j].split('=')[1]); $("#nemailr").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "nemails") { $("#config_nemails").val(sData[j].split('=')[1]); $("#nemails").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "skin") { $("#config_skin").val(sData[j].split('=')[1]); $("#skin").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "spam") { $("#config_spam").val(sData[j].split('=')[1]); $("#spam").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "ssh") { $("#config_ssh").val(sData[j].split('=')[1]); $("#ssh").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "ssl") { $("#config_ssl").val(sData[j].split('=')[1]); $("#ssl").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "suspend_at_limit") { $("#config_suspend_at_limit").val(sData[j].split('=')[1]); $("#suspend_at_limit").html(sData[j].split('=')[1]); }
            if (sData[j].split('=')[0] == "sysinfo") { $("#config_sysinfo").val(sData[j].split('=')[1]); $("#sysinfo").html(sData[j].split('=')[1]); }
        }

        //隐藏加载更新，防止用户包裹设置出错
        $("#loading").hide(); $("#tbBtn").hide(); $("#tbFlag").hide();

    });
    $("#tb tr").css("height", "26px");

    ajaxLoadUsage();
    $("#tbBtn").click(function () {
        ajaxLoadUsage();
    });

});

function ajaxLoadUsage() {
    var mySID = "v" + serviceData[0].ssid;
        if (serviceData[0].sconfig.transferFlag == "yes") {
            mySID = serviceData[0].sconfig.transferName;
        }
    //同步虚拟主机信息
    var url = "?c=module&serviceid=" + serviceData[0].sid + "&productid=" + serviceData[0].pid + "&show=text&todo=ajaxUsage&ssid=" + mySID;
    $("#loading").show(); $("#tbBtn").hide(); $("#tbFlag").html(" 正在加载");
    $.get(url, function (mydata) {
       
        $("#tbFlag").html(" <b style='color:green;'>已经同步</b>"); $("#loading").hide(); $("#tbBtn").show();
        var varr = mydata.split('|');
        $("#serverip").html(varr[2]);
        var _mydata = varr[0].split('&');  //读取当前账户使用的信息（数组大小14）
        //mydata.split('|')[1] = mydata.split('|')[1].replaceAll("ON", "是").replaceAll("OFF", "否");
        var _mydataN = varr[1].replaceAll("ON", "支持").replaceAll("OFF", "不支持").replaceAll("否", "不支持").split('&'); //读取当前用户的配置信息（数组大小41）
        //alert(_mydata.length + "__" + _mydataN.length);
        //获取当前配置信息

        var bandwidth, quota, domain, vdomains, nsubdomains, nemails, nemailf, nemailml, nemailr;
        var mysql, domainptr, ftp, aftp, cgi, php, spam, cron, catchall, ssl, ssh, sysinfo, dnscontrol;
        var notify, suspend_at_limit;
        var limitTxt = "不限";
        for (var i = 0; i < _mydataN.length; i++) {
            if (_mydataN[i].split('=')[0] == "bandwidth") { bandwidth = _mydataN[i].split('=')[1]; }
            if (_mydataN[i].split('=')[0] == "quota") { quota = _mydataN[i].split('=')[1]; }
            if (_mydataN[i].split('=')[0] == "domain") {
                domain = _mydataN[i].split('=')[1];
                $("#showDomain").html(domain); $("#serverDomain").val(domain);
            }
            if (_mydataN[i].split('=')[0] == "vdomains") { vdomains = _mydataN[i].split('=')[1]; }
            if (_mydataN[i].split('=')[0] == "nsubdomains") { nsubdomains = _mydataN[i].split('=')[1]; }
            if (_mydataN[i].split('=')[0] == "nemails") { nemails = _mydataN[i].split('=')[1]; }
            if (_mydataN[i].split('=')[0] == "nemailf") { nemailf = _mydataN[i].split('=')[1]; }
            if (_mydataN[i].split('=')[0] == "nemailml") { nemailml = _mydataN[i].split('=')[1]; }
            if (_mydataN[i].split('=')[0] == "nemailr") { nemailr = _mydataN[i].split('=')[1]; }
            if (_mydataN[i].split('=')[0] == "mysql") { mysql = _mydataN[i].split('=')[1]; }
            if (_mydataN[i].split('=')[0] == "domainptr") { domainptr = _mydataN[i].split('=')[1]; }
            if (_mydataN[i].split('=')[0] == "ftp") { ftp = _mydataN[i].split('=')[1]; }
            if (_mydataN[i].split('=')[0] == "aftp") {
                aftp = _mydataN[i].split('=')[1];
                $("#config_aftp").val(aftp); $("#aftp").html(aftp);
            }
            if (_mydataN[i].split('=')[0] == "cgi") {
                cgi = _mydataN[i].split('=')[1];
                $("#config_cgi").val(cgi); $("#cgi").html(cgi);
            }
            if (_mydataN[i].split('=')[0] == "php") {
                php = _mydataN[i].split('=')[1];
                $("#config_php").val(php); $("#php").html(php);
            }
            if (_mydataN[i].split('=')[0] == "spam") {
                spam = _mydataN[i].split('=')[1];
                $("#config_spam").val(spam); $("#spam").html(spam);
            }
            if (_mydataN[i].split('=')[0] == "cron") {
                cron = _mydataN[i].split('=')[1];
                $("#config_cron").val(cron); $("#cron").html(cron);
            }
            if (_mydataN[i].split('=')[0] == "catchall") {
                catchall = _mydataN[i].split('=')[1];
                $("#config_catchall").val(catchall); $("#catchall").html(catchall);
            }
            if (_mydataN[i].split('=')[0] == "ssl") {
                ssl = _mydataN[i].split('=')[1];
                $("#config_ssl").val(ssl); $("#ssl").html(ssl);
            }
            if (_mydataN[i].split('=')[0] == "ssh") {
                ssh = _mydataN[i].split('=')[1];
                $("#config_ssh").val(ssh); $("#ssh").html(ssh);
            }
            if (_mydataN[i].split('=')[0] == "sysinfo") {
                sysinfo = _mydataN[i].split('=')[1];
                $("#config_sysinfo").val(sysinfo); $("#sysinfo").html(sysinfo);
            }
            if (_mydataN[i].split('=')[0] == "dnscontrol") {
                dnscontrol = _mydataN[i].split('=')[1];
                $("#config_dnscontrol").val(dnscontrol); $("#dnscontrol").html(dnscontrol);
            }
            //不支持if (_mydataN[i].split('=')[0] == "quota") { notify = _mydataN[i].split('=')[1]; }
            if (_mydataN[i].split('=')[0] == "suspend_at_limit") {
                suspend_at_limit = _mydataN[i].split('=')[1];
                $("#config_suspend_at_limit").val(suspend_at_limit); $("#suspend_at_limit").html(suspend_at_limit);
            }
        }
        for (var i = 0; i < _mydata.length; i++) {
            if (_mydata[i].split('=')[0] == "bandwidth") {
                if (bandwidth == "unlimited") {
                    $("#config_bandwidth").val(limitTxt); $("#bandwidth").html(limitTxt);
                } else {
                    $("#config_bandwidth").val(bandwidth); $("#bandwidth").html(bandwidth);
                    if (_mydata[i].split('=')[1] == bandwidth || parseFloat(_mydata[i].split('=')[1]) == parseFloat(bandwidth)) {
                        $("#statusFlag").html("<b style=\"color:red;font-weight: bold;\">流量用完，已经暂停</b>");
                    }
                }
            }
            if (_mydata[i].split('=')[0] == "quota") {
                if (quota == "unlimited") {
                    $("#config_quota").val(limitTxt); $("#quota").html(limitTxt);
                } else {
                    $("#config_quota").val(quota); $("#quota").html(quota);
                }
            }
            if (_mydata[i].split('=')[0] == "vdomains") {
                $("#config_vdomains").val(vdomains.replace("unlimited", limitTxt)); $("#vdomains").html(vdomains.replace("unlimited", limitTxt));
            }
            if (_mydata[i].split('=')[0] == "nsubdomains") {
                $("#config_nsubdomains").val(nsubdomains.replace("unlimited", limitTxt)); $("#nsubdomains").html(nsubdomains.replace("unlimited", limitTxt));
            }
            if (_mydata[i].split('=')[0] == "mysql") {
                $("#config_mysql").val(mysql.replace("unlimited", limitTxt)); $("#mysql").html(mysql.replace("unlimited", limitTxt));
            }
            if (_mydata[i].split('=')[0] == "ftp") {
                $("#config_ftp").val(ftp.replace("unlimited", limitTxt)); $("#ftp").html(ftp.replace("unlimited", limitTxt));
            }
            if (_mydata[i].split('=')[0] == "domainptr") {
                $("#config_domainptr").val(domainptr.replace("unlimited", limitTxt)); $("#domainptr").html(domainptr.replace("unlimited", limitTxt));
            }
            if (_mydata[i].split('=')[0] == "nemails") {
                $("#config_nemails").val(nemails.replace("unlimited", limitTxt)); $("#nemails").html(nemails.replace("unlimited", limitTxt));
            }
            if (_mydata[i].split('=')[0] == "nemailf") {
                $("#config_nemailf").val(nemailf.replace("unlimited", limitTxt)); $("#nemailf").html(nemailf.replace("unlimited", limitTxt));
            }
            if (_mydata[i].split('=')[0] == "nemailml") {
                $("#config_nemailml").val(nemailml.replace("unlimited", limitTxt)); $("#nemailml").html(nemailml.replace("unlimited", limitTxt));
            }
            if (_mydata[i].split('=')[0] == "nemailr") {
                $("#config_nemailr").val(nemailr.replace("unlimited", limitTxt)); $("#nemailr").html(nemailr.replace("unlimited", limitTxt));
            }

        }



    });
}