﻿/// <reference path="jquery-vsdoc.js" />
/// <reference path="jquery-ui.min.js" />
var timeCycle = productData[0].psconfig.time_cycle == undefined ? '0' : productData[0].psconfig.time_cycle;
function _view() {
    var str = '<table width="100%" border="0" cellspacing="0" cellpadding="0" class="table grid"><thead><tr><th style="text-align:right">当前虚拟主机信息：</th><th class=\"full\">&nbsp;</th></tr></thead><tbody>';
    var title = '';
    if (serviceData[0].sid == 0) {
        title = '管理我的虚拟主机#';
    } else {
        var userLink = '';
        if (userData[0].isAdmin == 'True') userLink = '<tr><td class="title">所属用户：</td><td><a href="?c=muser&uid=' + userData[0].uid + '" target="_blank">' + userData[0].uname + ' [#' + userData[0].uid + ']</td></tr>';
        else if (userData[0].isReseller == 'True') userLink = '<tr><td class="title">所属用户：</td><td><a href="?c=rmuser&uid=' + userData[0].uid + '" target="_blank">' + userData[0].uname + ' [#' + userData[0].uid + ']</td></tr>';

        if (serviceData[0].sconfig.transferFlag != undefined) {
            if (serviceData[0].sconfig.transferFlag == "yes") {
                title = '管理我的虚拟主机# ' + serviceData[0].sconfig.transferName + '';
            } else {
                title = '管理我的虚拟主机# v' + serviceData[0].sid + '';
            }
        } else {
            title = '管理我的虚拟主机# v' + serviceData[0].sid + '';
        }
        str += userLink;
        str += '<tr><td class="title">服务器IP：</td><td id="serverip">' + serviceData[0].sconfig.serverIP + '</td></tr>';
        if (serviceData[0].sconfig.transferFlag != undefined) {
            if (serviceData[0].sconfig.transferFlag == "yes") {
                str += '<tr><td class="title">用户名：</td><td>' + serviceData[0].sconfig.transferName + '</td></tr>';
            } else {
                str += '<tr><td class="title">用户名：</td><td>v' + serviceData[0].sid + '</td></tr>';
            }
        } else {
            str += '<tr><td class="title">用户名：</td><td>v' + serviceData[0].sid + '</td></tr>';
        }
        str += '<tr><td class="title">初始密码：</td><td>' + serviceData[0].sconfig.serverPwd + ' &nbsp;';
        //str += '<input type="submit" value="生成新密码并发送到邮箱" id="sendNewPwdBtn" class="submit" style="cursor:pointer;">';
        str += '<span id="sendEmailBox"></span>';
        str += '</td></tr>';
        str += '<tr><td class="title">域名：</td><td id="userDomain">';
        str += '<a target="_blank" href="http://' + serviceData[0].sconfig.serverDomain + '">' + serviceData[0].sconfig.serverDomain + '</a>';
        str += '</td></tr>';
        str += "<tr>";
        str += "<td class=\"title\" style=\"text-align: right;\">";
        str += "快捷登录：";
        str += "</td>";
        str += "<td>"
        str += "<form action=\"http://" + serviceData[0].sconfig.serverIP + ":2222/CMD_LOGIN\" target=\"_blank\" method=\"POST\" name=\"form\" id=\"logintoda\">";
        str += "<input type=hidden name=referer value=\"/\" />";
        str += "<input type=\"hidden\" value=\"v" + serviceData[0].ssid + "\" name=\"username\">";
        str += "<input type=\"hidden\" value=\"" + serviceData[0].sconfig.serverPwd + "\" name=password>";
        str += "<input type=\"submit\" value=\"登陆DirectAdmin管理\" class=\"submit\" style=\"cursor:pointer;\">";
        str += "</form>";
        str += "</td></tr>";
    }
    str += '<tr><td class="title">流量(月)：</td><td><span id="bandwidth"></span><span title="最大值">' + serviceData[0].sconfig.bandwidth + '（M）</span></td></tr>';
    str += '<tr><td class="title">磁盘大小：</td><td><span id="quota"></span><span title="最大值">' + serviceData[0].sconfig.quota + '（M）</span></td></tr>';
    str += '<tr><td class="title">域名配额：</td><td><span id="vdomains"></span>' + serviceData[0].sconfig.vdomains + '（个）</td></tr>';
    str += '<tr><td class="title">子域名配额：</td><td><span id="nsubdomains"></span>' + serviceData[0].sconfig.nsubdomains + '（个）</td></tr>';
    str += '<tr><td class="title">MySQL数据库：</td><td><span id="mysql"></span>' + serviceData[0].sconfig.mysql + '（个）</td></tr>';
    str += '<tr><td class="title">Ftp帐户：</td><td><span id="ftp"></span>' + serviceData[0].sconfig.ftp + '（个）</td></tr>';
    str += '<tr><td class="title">绑定域名：</td><td><span id="domainptr"></span>' + serviceData[0].sconfig.domainptr + '（个）</td></tr>';
    str += '<tr><td class="title">Email帐户：</td><td><span id="nemails"></span>' + serviceData[0].sconfig.nemails + '（个）</td></tr>';
    str += '<tr><td class="title">Email转发器：</td><td><span id="nemailf"></span>' + serviceData[0].sconfig.nemailf + '（个）</td></tr>';
    str += '<tr><td class="title">邮件列表：</td><td><span id="nemailml"></span>' + serviceData[0].sconfig.nemailml + '（个）</td></tr>';
    str += '<tr><td class="title">自动应答器：</td><td><span id="nemailr"></span>' + serviceData[0].sconfig.nemailr + '（个）</td></tr>';
    str += '<tr><td class="title">PHP访问：</td><td><span id="phpb"></span>' + serviceData[0].sconfig.php.replace('ON', '是').replace('OFF', '否') + '</td></tr>';
    str += '<tr><td class="title">CGI访问：</td><td><span id="cgib"></span>' + serviceData[0].sconfig.cgi.replace('ON', '是').replace('OFF', '否') + '</td></tr>';
    $("#pageTitle").html(title);
    document.title = title;
    var statusText = serviceStatus[parseInt(serviceData[0].sstatus) + 2];
    switch (serviceData[0].sstatus) {
        case "-1": statusText = '<strong style="color:#0000FF;">' + statusText + '</strong>'; break;
        case "0": statusText = '<strong style="color:#005B00;">' + statusText + '</strong>'; break;
        case "3": statusText = '<strong style="color:#CC3300;">' + statusText + '</strong>'; break;
        case "1":
        case "2":
        case "4": statusText = '<strong style="color:#FF0000;">' + statusText + '</strong>'; break;
    }
    switch (serviceData[0].spmothod) {
        case "1":
            str += '<tr><td class="title">虚拟主机价格：</td><td><b>' + serviceData[0].sprice + ' ' + userData[0].currency+'</b> / <b>' + getTimeCycleSuffix(serviceData[0].spcycle, timeCycle, 1) + '</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>帐户余额:</b> ' + parseFloat(userData[0].balance).toFixed(2) + ' ' + userData[0].currency + '</td></tr>' +
            '' +
            '<tr><td class="title">到期续费时间：</td><td><b>' + getUnixTime(serviceData[0].etime) + '</b>&nbsp;&nbsp;<span style="color: #ABABAB;">(请确保在日期前帐户余额充足)</span>&nbsp;&nbsp;<input id="autorenew" type="checkbox" ' + (serviceData[0].autorenew == '0' ? 'checked="checked"' : '') + '/><label for="autorenew">自动续费</label> &nbsp;&nbsp;&nbsp;&nbsp;<a href="javascript:_renew();">『马上续费』</a></td></tr>' +
            '<tr><td class="title">服务状态：</td><td id="statusFlag">' + statusText + ' &nbsp;&nbsp;';
            break;
        case "2":
            str += '<tr><td class="title">购买价格：</td><td> 一次性付款 <b>' + serviceData[0].sprice + '<b> RMB</td></tr>' +
            '<tr><td class="title">到期时间：</td><td><b>' + getUnixTime(serviceData[0].etime) + '</b></td></tr>' +
            '<tr><td class="title">服务状态：</td><td id="statusFlag">' + statusText + ' &nbsp;&nbsp;';
            break;
        case "3":
            str += '<tr><td class="title">免费试用：</td><td> <b>' + serviceData[0].spcycle + '</b> 天</td></tr>' +
            '<tr><td class="title">到期时间：</td><td><b>' + getUnixTime(serviceData[0].etime) + '</b></td></tr>' +
            '<tr><td class="title">服务状态：</td><td id="statusFlag">' + statusText + ' &nbsp;&nbsp;';
            break;

    }

    if (serviceData[0].sstatus == "-1") {
        str += '<input type=\"submit\" value=\"立即刷新状态\" class=\"submit\" onclick=\"reloadpage()\" />';
    }
    str += '</td></tr>';
    // '</tbody></table>';
    // str += '<table><thead><tr><th>当前服务其它信息：</th><th class=\"full\">&nbsp;</th></tr></thead>';
    // str += "";
    if (serviceData[0].sconfig.other != '') {
        str += "<tr>";
        str += "<td class=\"title\" style=\"text-align: right;\">";
        str += "其它描述：";
        str += "</td>";
        str += "<td>"
        str += serviceData[0].sconfig.other;
        str += "</td></tr>";
    }
    str += "<tr>";
    str += "<td class=\"title\" style=\"text-align: right;\">";
    str += "同步虚拟主机信息：";
    str += "</td>";
    str += "<td>"
    str += "<span id=\"ajaxFlag\">未同步</span>";
    str += "</td></tr>";
    //str += "</table>";
    str += '</tbody></table>';
    str += '<input type="hidden" value="" id="UserEmail">';
    $("#ViewService").html(str);

    $("#ViewService .title").css("text-align", "right");
    $("#ViewService #autorenew").css("cursor", "pointer").click(function () {
        var autorenew = $(this).prop("checked") ? '0' : '1';
        setAutorenew(serviceData[0].sid, autorenew);
    });
}
_view();
var finalPrice = 0;
var normalPrice = 0;
var productID = productData[0].pid;
var billingMothod = 1;
var billingCycle = 1;
function _renew() {
    if (serviceData[0].spmothod != "1") {
        alert("您当前服务无需续费！");
        return false;
    }
    var discount = parseFloat(productData[0].discount);
    var str = '<p style="line-height:28px"><strong>帐户余额</strong>：<strong>' + parseFloat(userData[0].balance).toFixed(2) + '</strong> ' + userData[0].currency;
    if (discount < 1) str += '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong>帐户优惠</strong>：<strong style="color:#0000FF">' + (discount * 100 / 10) + '</strong>折';
    str += '&nbsp;<br /><strong>请选择续费周期</strong>：<br />';

    var discount = parseFloat(productData[0].discount);
    var cycles = productData[0].pprice.cycle.split(',');
    var cprices = productData[0].pprice.cprice.split(',');

    var cprice = 0, yprice = 0, pp1 = 0, pp2 = 0;
    for (i = 0; i < cycles.length; i++) {
        if (cprices[i] != '0') {
            cprice = parseFloat(cprices[i]);
            yprice = cprice;
            if (cycles[i] == serviceData[0].spcycle) cprice = serviceData[0].sprice;

            if (pp1 == 0) pp1 = parseFloat(yprice) / parseInt(cycles[i]);
            else {
                pp2 = (parseFloat(yprice) / parseInt(cycles[i]) / pp1 * 10).toFixed(1);
            }
            str += '<input type="radio" name="cycle" value="' + cycles[i] + '_' + cprice + '_' + yprice + '" id="cycle' + cycles[i] + '" /><label for="cycle' + cycles[i] + '">';
            //            switch (cycles[i]) {
            //                case "1": str += '月　付'; break;
            //                case "3": str += '季　付'; break;
            //                case "6": str += '半年付'; break;
            //                case "12": str += '年　付'; break;
            //                case "24": str += '二年付'; break;
            //                default: str += cycles[i] + '个月付'; break;
            //            }

            //            if (cycles[i] == serviceData[0].spcycle) str += '：' + parseFloat(cprice).toFixed(2) + (pp2 != 0 ? ' (' + pp2 + '折)' : '') + '</label><br />';
            //            else
            //            str += '：' + (discount > 1 ? (parseFloat(cprice) * discount).toFixed(2) : cprice) + (pp2 != 0 ? ' (' + pp2 + '折)' : '') + '</label><br />';
            str += parseFloat(cprice).toFixed(2) + ' / ' + getTimeCycleSuffix(cycles[i], timeCycle, 1) + ((pp2 > 0 && pp2 < 10) ? ' (' + pp2 + '折)' : '') + '</label><br />';


        }
    }

    str += '<strong>续费价格</strong>：<strong class="finalPrice"></strong> ' + userData[0].currency + '&nbsp;&nbsp;&nbsp;<span class="normalPrice"></span><br />&nbsp;<br />' +
           '<span>优 惠 码：<input type="text" id="couponcode" size="10" class="text"/> <input type="button" class="submit" value="使用" onclick="applyCode(\'renew\')"/> <input type="button" class="submit" value="不使用" onclick="clearCouponCode(1)"/></span><br />' +
           '<span id="ccdes" class="pptext"></span></p>';
    str += "<br>";

    $("#suwin").html(str);


    $("#suwin input:radio").click(function () {
        clearCouponCode(1);
        var ps = $(this).val().split('_');
        billingCycle = parseInt(ps[0]);
        finalPrice = parseFloat(ps[1]);
        normalPrice = parseFloat(ps[2]);
        if (billingCycle != parseInt(serviceData[0].spcycle)) finalPrice = finalPrice * discount;
        $("#suwin .finalPrice").html(finalPrice.toFixed(2));
    });
    $("#suwin #cycle" + serviceData[0].spcycle).click();
    $("#suwin").dialog({ title: "续费确认", autoOpen: false, resizable: false, width: 500, height: 450, modal: false, buttons: { "确认续费": function () { renew(serviceData[0].sid, billingCycle, $("#couponcode").val()); }, "关 闭": function () { $(this).dialog("close"); } } }).dialog("open");
}
function reloadpage() {
    window.location.reload();
}
//异步获取用户子服务使用信息
$(function () {
    var mySID = "v" + serviceData[0].sid;
    if (serviceData[0].sconfig.transferFlag == "yes") {
        mySID = serviceData[0].sconfig.transferName;
    }


    var url = "?c=module&serviceid=" + serviceData[0].sid + "&productid=" + serviceData[0].pid + "&show=text&todo=ajaxUsage&ssid=" + mySID;
    if (serviceData[0].ssid == 0) {
        $("#ajaxFlag").html("<b style='color:red;'>虚拟主机还未开通，请刷新页面或联系销售人员</b>"); return false;
    }
    $("#ajaxFlag").html("正在加载<img src=\"/images/loading.gif\" />");
    $.get(url, function (mydata) {
        var varr = mydata.split('|');
        var _mydata = varr[0].split('&');  //读取当前账户使用的信息（数组大小14）
        var _mydataN = varr[1].split('&'); //读取当前用户的配置信息（数组大小41）
        //alert(_mydata.length + "__" + _mydataN.length);
        //获取当前配置信息
        $("#serverip").html(varr[2].substr(0, varr[2].indexOf(':')));
        $("#logintoda").attr("action", "http://" + varr[2] + "/CMD_LOGIN");
        var bandwidth, quota, domain, vdomains, nsubdomains, email, nemails, nemailf, nemailml, nemailr;
        var mysql, domainptr, ftp, aftp, cgi, php, spam, cron, catchall, ssl, ssh, sysinfo, dnscontrol;
        var notify, suspend_at_limit;
        for (var i = 0; i < _mydataN.length; i++) {

            if (_mydataN[i].split('=')[0] == "bandwidth") { bandwidth = _mydataN[i].split('=')[1]; }
            if (_mydataN[i].split('=')[0] == "quota") { quota = _mydataN[i].split('=')[1]; }
            if (_mydataN[i].split('=')[0] == "domain") {
                domain = _mydataN[i].split('=')[1];
                var domainStr = '<a target="_blank" href="http://' + domain + '" title="您绑定的主域名">' + domain + '</a>';
                $("#userDomain").html(domainStr);
            }
            if (_mydataN[i].split('=')[0] == "vdomains") { vdomains = _mydataN[i].split('=')[1]; }
            if (_mydataN[i].split('=')[0] == "nsubdomains") { nsubdomains = _mydataN[i].split('=')[1]; }
            if (_mydataN[i].split('=')[0] == "email") {
                email = _mydataN[i].split('=')[1];
                $("#UserEmail").val(email);
                var sendStr = '<input type="submit" value="生成新密码并发送到邮箱" id="sendNewPwdBtn" onclick="sendNewPwd()" class="submit" style="cursor:pointer;">';
                $("#sendEmailBox").html(sendStr);
            }
            if (_mydataN[i].split('=')[0] == "nemails") { nemails = _mydataN[i].split('=')[1]; }
            if (_mydataN[i].split('=')[0] == "nemailf") { nemailf = _mydataN[i].split('=')[1]; }
            if (_mydataN[i].split('=')[0] == "nemailml") { nemailml = _mydataN[i].split('=')[1]; }
            if (_mydataN[i].split('=')[0] == "nemailr") { nemailr = _mydataN[i].split('=')[1]; }
            if (_mydataN[i].split('=')[0] == "mysql") { mysql = _mydataN[i].split('=')[1]; }
            if (_mydataN[i].split('=')[0] == "domainptr") { domainptr = _mydataN[i].split('=')[1]; }
            if (_mydataN[i].indexOf('ftp=') > -1) { ftp = _mydataN[i].substr(_mydataN[i].indexOf("ftp=") + 4); }
            if (_mydataN[i].split('=')[0] == "aftp") { aftp = _mydataN[i].split('=')[1]; }
            if (_mydataN[i].split('=')[0] == "cgi") {
                cgi = _mydataN[i].split('=')[1];
                if (cgi == "不支持" || cgi == "OFF") { $("#cgib").parent().parent().hide(); }
                $("#cgib").parent().html("" + cgi.replace("ON", "支持") + "");

            }
            if (_mydataN[i].split('=')[0] == "php") {
                php = _mydataN[i].split('=')[1];
                if (php == "不支持" || php == "OFF") { $("#phpb").parent().parent().hide(); }
                $("#phpb").parent().html("" + php.replace("ON", "支持") + "");

            }
            if (_mydataN[i].split('=')[0] == "spam") { spam = _mydataN[i].split('=')[1]; }
            if (_mydataN[i].split('=')[0] == "cron") { cron = _mydataN[i].split('=')[1]; }
            if (_mydataN[i].split('=')[0] == "catchall") { catchall = _mydataN[i].split('=')[1]; }
            if (_mydataN[i].split('=')[0] == "ssl") { ssl = _mydataN[i].split('=')[1]; }
            if (_mydataN[i].split('=')[0] == "ssh") { ssh = _mydataN[i].split('=')[1]; }
            if (_mydataN[i].split('=')[0] == "sysinfo") { sysinfo = _mydataN[i].split('=')[1]; }
            if (_mydataN[i].split('=')[0] == "dnscontrol") { dnscontrol = _mydataN[i].split('=')[1]; }
            //不支持if (_mydataN[i].split('=')[0] == "quota") { notify = _mydataN[i].split('=')[1]; }
            if (_mydataN[i].split('=')[0] == "suspend_at_limit") { suspend_at_limit = _mydataN[i].split('=')[1]; }
        }

        for (var i = 0; i < _mydata.length; i++) {
            if (_mydata[i].split('=')[0] == "bandwidth") {
                if (bandwidth == "unlimited") {  // unlimited
                    $("#bandwidth").parent().html("<span style=\"color:green;font-weight: bold;\">不限</span> ；已使用 " + _mydata[i].split('=')[1] + "（M）");
                } else {
                    var level = parseFloat(_mydata[i].split('=')[1]) / parseFloat(bandwidth);
                    level = level * 100;

                    $("#bandwidth").parent().html('<div style="float:left;" title="已经使用值">' + _mydata[i].split('=')[1] + '（M）</div><div style="height:18px;width: 218px;float:left;margin-right:10px;" id="bandwidthBar" class="ui-progressbar ui-widget ui-widget-content ui-corner-all" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><div class="ui-progressbar-value ui-widget-header ui-corner-left" style="display: none; width: 0%; "></div></div> <span title="最大值"> ' + bandwidth + '（M）');
                    $("#bandwidthBar").progressbar({
                        value: parseFloat(level)
                    });

                    if (_mydata[i].split('=')[1] == bandwidth || parseFloat(_mydata[i].split('=')[1]) == parseFloat(bandwidth)) {
                        $("#statusFlag").html("<b style=\"color:red;font-weight: bold;\">已经暂停</b>");
                    }
                }
            }
            if (_mydata[i].split('=')[0] == "quota") {
                if (quota == "unlimited") {
                    $("#quota").parent().html("<span style=\"color:green;font-weight: bold;\">不限</span> ；已使用 " + _mydata[i].split('=')[1] + "（M）");
                } else {
                    var level2 = parseFloat(_mydata[i].split('=')[1]) / parseFloat(quota);
                    level2 = level2 * 100;

                    $("#quota").parent().html('<div style="float:left;" title="已经使用值">' + _mydata[i].split('=')[1] + '（M）</div><div style="height:18px;width: 218px;float:left;margin-right:10px;" id="quotaBar" class="ui-progressbar ui-widget ui-widget-content ui-corner-all" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><div class="ui-progressbar-value ui-widget-header ui-corner-left" style="display: none; width: 0%; "></div></div><span title="最大值"> ' + quota + '（M）');
                    $("#quotaBar").progressbar({
                        value: parseFloat(level2)
                    });


                }
            }
            if (_mydata[i].split('=')[0] == "vdomains") {
                if (serviceData[0].sconfig.vdomains == "unlimited") {
                    $("#vdomains").parent().html("<span style=\"color:green;font-weight: bold;\">不限</span> ；已使用 " + _mydata[i].split('=')[1] + "（个）");
                } else {
                    if (vdomains == _mydata[i].split('=')[1]) {
                        if (vdomains == 0) {
                            $("#vdomains").parent().parent().hide();
                        } else {
                            $("#vdomains").html(_mydata[i].split('=')[1] + "/");
                        }
                    } else {
                        $("#vdomains").parent().html(_mydata[i].split('=')[1] + "/" + vdomains + "（个）");
                    }
                }
            }
            if (_mydata[i].split('=')[0] == "nsubdomains") {
                if (nsubdomains == "unlimited") {
                    $("#nsubdomains").parent().html("<span style=\"color:green;font-weight: bold;\">不限</span> ；已使用 " + _mydata[i].split('=')[1] + "（个）");
                } else {
                    if (serviceData[0].sconfig.nsubdomains == _mydata[i].split('=')[1]) {
                        if (_mydata[i].split('=')[1] == 0) {
                            $("#nsubdomains").parent().parent().hide();
                        } else {
                            $("#nsubdomains").html(_mydata[i].split('=')[1] + "/");
                        }
                    } else {
                        $("#nsubdomains").parent().html(_mydata[i].split('=')[1] + "/" + nsubdomains + "（个）");
                    }
                }
            }
            if (_mydata[i].split('=')[0] == "mysql") {
                if (mysql == "unlimited") {
                    $("#mysql").parent().html("<span style=\"color:green;font-weight: bold;\">不限</span> ；已使用 " + _mydata[i].split('=')[1] + "（个）");
                } else {
                    if (mysql == _mydata[i].split('=')[1]) {
                        if (_mydata[i].split('=')[1] == 0) {
                            $("#mysql").parent().parent().hide();
                        } else {
                            $("#mysql").html(_mydata[i].split('=')[1] + "/");
                        }
                    } else {
                        $("#mysql").parent().html(_mydata[i].split('=')[1] + "/" + mysql + "（个）");
                    }
                }
            }
            if (_mydata[i].split('=')[0] == "ftp") {

                if (ftp == "unlimited") {
                    $("#ftp").parent().html("<span style=\"color:green;font-weight: bold;\">不限</span> ；已使用 " + _mydata[i].split('=')[1] + "（个）");
                } else {
                    if (ftp == _mydata[i].split('=')[1]) {
                        if (_mydata[i].split('=')[1] == 0) {
                            $("#ftp").parent().parent().hide();
                        } else {
                            $("#ftp").html(_mydata[i].split('=')[1] + "/");
                        }
                    } else {
                        $("#ftp").parent().html(_mydata[i].split('=')[1] + "/" + ftp + "（个）");
                    }
                }
            }
            if (_mydata[i].split('=')[0] == "domainptr") {
                if (domainptr == "unlimited") {
                    $("#domainptr").parent().html("<span style=\"color:green;font-weight: bold;\">不限</span> ；已使用 " + _mydata[i].split('=')[1] + "（个）");
                } else {
                    if (domainptr == _mydata[i].split('=')[1]) {
                        if (_mydata[i].split('=')[1] == 0) {
                            $("#domainptr").parent().parent().hide();
                        } else {
                            $("#domainptr").html(_mydata[i].split('=')[1] + "/");
                        }
                    } else {
                        $("#domainptr").parent().html(_mydata[i].split('=')[1] + "/" + domainptr + "（个）");
                    }
                }
            }
            if (_mydata[i].split('=')[0] == "nemails") {
                if (nemails == "unlimited") {
                    $("#nemails").parent().html("<span style=\"color:green;font-weight: bold;\">不限</span> ；已使用 " + _mydata[i].split('=')[1] + "（个）");
                } else {
                    if (nemails == _mydata[i].split('=')[1]) {
                        if (_mydata[i].split('=')[1] == 0) {
                            $("#nemails").parent().parent().hide();
                        } else {
                            $("#nemails").html(_mydata[i].split('=')[1] + "/");
                        }
                    } else {
                        $("#nemails").parent().html(_mydata[i].split('=')[1] + "/" + nemails + "（个）");
                    }
                }
            }
            if (_mydata[i].split('=')[0] == "nemailf") {
                if (nemailf == "unlimited") {
                    $("#nemailf").parent().html("<span style=\"color:green;font-weight: bold;\">不限</span> ；已使用 " + _mydata[i].split('=')[1] + "（个）");
                } else {
                    if (nemailf == _mydata[i].split('=')[1]) {
                        if (_mydata[i].split('=')[1] == 0) {
                            $("#nemailf").parent().parent().hide();
                        } else {
                            $("#nemailf").html(_mydata[i].split('=')[1] + "/");
                        }
                    } else {
                        $("#nemailf").parent().html(_mydata[i].split('=')[1] + "/" + nemailf + "（个）");
                    }
                }
            }
            if (_mydata[i].split('=')[0] == "nemailml") {
                if (nemailml == "unlimited") {
                    $("#nemailml").parent().html("<span style=\"color:green;font-weight: bold;\">不限</span> ；已使用 " + _mydata[i].split('=')[1] + "（个）");
                } else {
                    if (nemailml == _mydata[i].split('=')[1]) {
                        if (_mydata[i].split('=')[1] == 0) {
                            $("#nemailml").parent().parent().hide();
                        } else {
                            $("#nemailml").html(_mydata[i].split('=')[1] + "/");
                        }
                    } else {
                        $("#nemailml").parent().html(_mydata[i].split('=')[1] + "/" + nemailml + "（个）");
                    }
                }
            }
            if (_mydata[i].split('=')[0] == "nemailr") {
                if (nemailr == "unlimited") {
                    $("#nemailr").parent().html("<span style=\"color:green;font-weight: bold;\">不限</span> ；已使用 " + _mydata[i].split('=')[1] + "（个）");
                } else {
                    if (nemailr == _mydata[i].split('=')[1]) {
                        if (_mydata[i].split('=')[1] == 0) {
                            $("#nemailr").parent().parent().hide();
                        } else {
                            $("#nemailr").html(_mydata[i].split('=')[1] + "/");
                        }
                    } else {
                        $("#nemailr").parent().html(_mydata[i].split('=')[1] + "/" + nemailr + "（个）");
                    }
                }
            }
            //$("#ajaxFlag").parent().parent().parent().hide(); //
            var sendStr = '<input type="submit" value="生成新密码并发送到邮箱" id="sendNewPwdBtn" onclick="sendNewPwd()" class="submit" style="cursor:pointer;">';
            $("#sendEmailBox").html(sendStr);
            if (varr[0] == "-1") $("#ajaxFlag").html(varr[1]);
            else
                $("#ajaxFlag").html("<b style='color:green;'>已经完成</b>");
        }
    });

});
function sendNewPwd() {
    var mySID = "v" + serviceData[0].ssid;
    if (serviceData[0].sconfig.transferFlag == "yes") {
        mySID = serviceData[0].sconfig.transferName;
    }
    $("#suwin").dialog({ title: "重新生成[#" + mySID + "]虚拟主机密码", autoOpen: false, resizable: false, width: 380, height: 300, modal: false, buttons: {
        "关 闭": function () {
            $(this).dialog("close");
        }
    }
    }).dialog("open");

    //通过主动接口检查当前用户类型
    var str = '';
    var chkURL = "?c=module&productid=" + productData[0].pid + "&show=text&action=send_email&todo=chkUserType";
    $("#suwin").html('<div class="loading" style="height:35px;line-height: 35px;text-align:center;padding-top:5px;"></div>');
    $("#suwin .loading").html("<div style='height:20px;'></div><br/><b><img style='' src='images/loading.gif' /></br>Loading...</b>");
    $.get(chkURL, function (data) {
        if (data == "-1|1") {
            gotoFixBoxAdmin();

        } else {
            gotoFixBoxUser();
        }
    });

}

function gotoFixBoxAdmin() {
    var mySID = "v" + serviceData[0].ssid;
    if (serviceData[0].sconfig.transferFlag == "yes") {
        mySID = serviceData[0].sconfig.transferName;
    }
    $("#suwin .loading").html("");
    $("#suwin").dialog("close");
    var email = userData[0].umail;
    //填充普通用户需要验证码的操作
    var txtStr = '<div style="height:60px;"></div>';
    txtStr += '<table>';
    txtStr += '<tr style="height:30px;line-height: 30px;"><td style="width:140px;text-align:right;">';
    txtStr += '<b>接受密码邮箱：</b>';
    txtStr += '</td><td style="text-align:left;">';
    txtStr += email;
    txtStr += '</td></tr>';
    txtStr += '</table>';
    txtStr += '<div class="loading" style="height:35px;line-height: 35px;text-align:center;padding-top:5px;"></div>';
    $("#suwin").dialog({ title: "重新生成[#" + mySID + "]虚拟主机密码", autoOpen: false, resizable: false, width: 380, height: 268, modal: false, buttons: {
        "确认发送": function () {
            $("#suwin .loading").html("<img style='' src='images/loading.gif' /><br/>发送中...");
            var url2 = "?c=module&serviceid=" + serviceData[0].sid + "&productid=" + serviceData[0].pid + "&show=text&todo=SendNewPwdToEmail2&UserEmail=" + email;
            url2 += "&vcode=" + $.trim($("#vcode").val()) + "&ssid=" + mySID;
            $.post(url2, function (data) {
                if (data == 0) {
                    $("#suwin .loading").html("");
                    $("#suwin").dialog("close");
                    $("#suwin").dialog({ title: "重新生成[#" + mySID + "]密码发送成功", autoOpen: false, resizable: false, width: 380, height: 268, modal: false, buttons: {
                        "关 闭": function () {
                            $(this).dialog("close");
                        }
                    }
                    }).dialog("open");
                    $("#suwin").html("<div style='height:140px;line-height: 140px;text-align:center;width:330px;color:green;'>发送成功，请您查收！</p>");
                    setTimeout(function () { $("#suwin").dialog("close"); }, 4000);
                } else {
                    $("#suwin .loading").html("<b style='color:red;'>" + data.substr(3) + "</b>");
                }
            });

        }, "取 消": function () {
            $(this).dialog("close");
        }
    }
    }).dialog("open");
    $("#suwin").html(txtStr);

}

function gotoFixBoxUser() {
    $("#suwin .loading").html("");
    $("#suwin").dialog("close");
    var email = userData[0].umail;
    var mySID = "v" + serviceData[0].ssid;
    if (serviceData[0].sconfig.transferFlag == "yes") {
        mySID = serviceData[0].sconfig.transferName;
    }
    //填充普通用户需要验证码的操作
    var txtStr = '<div style="height:10px;"></div>';
    txtStr += '<table>';
    txtStr += '<tr style="height:30px;line-height: 30px;"><td style="width:100px;text-align:right;">';
    txtStr += '<b>发送验证码：</b>';
    txtStr += '</td><td style="text-align:left;">';
    txtStr += '<input type="button" class="submit" value="发到邮箱" id="mailBtn" onclick="sendCodeToEmail()" /> &nbsp;&nbsp;';
    txtStr += '<input type="button" class="submit" value="发到手机" id="phoneBtn" onclick="sendCodeToPhone()" />';
    txtStr += '</td></tr>';
    txtStr += '<tr style="height:30px;line-height: 30px;"><td style="width:100px;text-align:right;">';
    txtStr += '<b><input type="hidden" id="codeFlag" value="0">输入验证码：</b>';
    txtStr += '</td><td style="text-align:left;">';
    txtStr += '<input name="vcode" id="vcode" class="text" style="width:110px;margin-top:3px;" />';
    txtStr += '</td></tr>';
    txtStr += '<tr style="height:30px;line-height: 30px;"><td style="width:120px;text-align:right;">';
    txtStr += '<b>接受密码邮箱：</b>';
    txtStr += '</td><td style="text-align:left;">';
    txtStr += email;
    txtStr += '</td></tr>';
    txtStr += '</table>';
    txtStr += '<div class="loading" style="height:35px;line-height: 35px;text-align:center;padding-top:5px;"></div>';
    $("#suwin").dialog({ title: "重新生成[#" + mySID + "]虚拟主机密码", autoOpen: false, resizable: false, width: 380, height: 300, modal: false, buttons: {
        "确认发送": function () {
            if ($("#codeFlag").val() == "-1") { alert("请先获取验证码！"); return false; }
            if ($.trim($("#vcode").val()) == "") { alert("请填写刚刚收到的验证码！"); $("#vcode").focus(); return false; }
            $("#suwin .loading").html("<img style='' src='images/loading.gif' /><br/>发送中...");
            var url2 = "?c=module&serviceid=" + serviceData[0].sid + "&productid=" + serviceData[0].pid + "&show=text&todo=SendNewPwdToEmail&UserEmail=" + email;
            url2 += "&vcode=" + $.trim($("#vcode").val()) + "&ssid=" + mySID;
            $.get(url2, function (data) {
                if (data == 0) {
                    $("#suwin .loading").html("");
                    $("#suwin").dialog("close");
                    $("#suwin").dialog({ title: "重新生成[#" + mySID + "]密码发送成功", autoOpen: false, resizable: false, width: 380, height: 268, modal: false, buttons: {
                        "关 闭": function () {
                            $(this).dialog("close");
                        }
                    }
                    }).dialog("open");
                    $("#suwin").html("<div style='height:140px;line-height: 140px;text-align:center;width:330px;color:green;'>发送成功，请您查收！</p>");
                    setTimeout(function () { $("#suwin").dialog("close"); }, 4000);
                } else {
                    $("#suwin .loading").html("<b style='color:red;'>" + data.substr(3) + "</b>");
                }
            });

        }, "取 消": function () {
            $(this).dialog("close");
        }
    }
    }).dialog("open");
    $("#suwin").html(txtStr);
}

//发送验证码到邮箱
function sendCodeToEmail(tum) {
    var mySID = "v" + serviceData[0].ssid;
    if (serviceData[0].sconfig.transferFlag == "yes") {
        mySID = serviceData[0].sconfig.transferName;
    }
    $("#suwin .loading").html("<img style='' src='images/loading.gif' /><br/>正在发送验证码到邮箱中...");
    var url2 = "?c=module&productid=" + productData[0].pid + "&show=text&action=send_email&todo=send_emailCode";
    url2 += "&token=" + (new Date()).valueOf() + "&ssid=" + mySID;
    var leftTime = 180;
    $("#mailBtn").attr("disabled", "disabled").attr("value", "还剩" + leftTime + "秒").css({ "color": "gray", "cursor": "default" });
    $("#phoneBtn").attr("disabled", "disabled").attr("value", "还剩" + leftTime + "秒").css({ "color": "gray", "cursor": "default" });
    var myTimer = setInterval(function () {
        if (leftTime > 1) {
            leftTime -= 1;
            $("#mailBtn").attr("disabled", "disabled").attr("value", "还剩" + leftTime + "秒");
            $("#phoneBtn").attr("disabled", "disabled").attr("value", "还剩" + leftTime + "秒");
        }
        else {
            clearInterval(myTimer);
            $("#mailBtn").removeAttr("disabled").attr("value", "发送到邮箱").css({ "color": "white", "cursor": "pointer" });
            $("#phoneBtn").removeAttr("disabled").attr("value", "发送到手机").css({ "color": "white", "cursor": "pointer" });
        }
    }, 1000);
    $.post(url2, function (data) {
        if (parseInt(data) == 0) {
            $("#suwin .loading").html("<b style='color:green;'>发送成功，请注意查收邮箱后，输入验证码！</b>");
            $("#codeFlag").val("0");
            $("#vcode").focus();
        } else {
            if (data.indexOf("Email is not verified") > -1) {
                $("#suwin .loading").html("<b style='color:red;'>抱歉，您的邮箱在本平台还没有进行验证操作，<br/>请在\"用户资料管理界面\"验证您的邮箱！</b>");
            }
            else {
                $("#suwin .loading").html("<b style='color:red;'>" + data.substr(3) + "</b>");
            }
        }

    });
}
//发送验证码到手机
function sendCodeToPhone() {
    var mySID = "v" + serviceData[0].ssid;
    if (serviceData[0].sconfig.transferFlag == "yes") {
        mySID = serviceData[0].sconfig.transferName;
    }
    $("#suwin .loading").html("<img style='' src='images/loading.gif' /><br/>正在发送验证码到手机中...");
    var url2 = "?c=module&productid=" + productData[0].pid + "&show=text&action=send_sms&todo=send_phoneCode";
    url2 += "&token=" + (new Date()).valueOf() + "&ssid=" + mySID;
    var leftTime = 180;
    $("#mailBtn").attr("disabled", "disabled").attr("value", "还剩" + leftTime + "秒").css({ "color": "gray", "cursor": "default" });
    $("#phoneBtn").attr("disabled", "disabled").attr("value", "还剩" + leftTime + "秒").css({ "color": "gray", "cursor": "default" });
    var myTimer = setInterval(function () {
        if (leftTime > 1) {
            leftTime -= 1;
            $("#mailBtn").attr("disabled", "disabled").attr("value", "还剩" + leftTime + "秒");
            $("#phoneBtn").attr("disabled", "disabled").attr("value", "还剩" + leftTime + "秒");
        }
        else {
            clearInterval(myTimer);
            $("#mailBtn").removeAttr("disabled").attr("value", "发送到邮箱").css({ "color": "white", "cursor": "pointer" });
            $("#phoneBtn").removeAttr("disabled").attr("value", "发送到手机").css({ "color": "white", "cursor": "pointer" });
        }
    }, 1000);
    $.post(url2, function (data) {
        if (parseInt(data) == 0) {
            $("#suwin .loading").html("<b style='color:green;'>发送成功，请注意查收短信息后，输入验证码！</b>");
            $("#codeFlag").val("0");
            $("#vcode").focus();
        } else {
            if (data.indexOf("Tel is not verified") > -1) {
                $("#suwin .loading").html("<b style='color:red;'>抱歉，您的手机号码在本平台还没有进行验证操作，<br/>请在\"用户资料管理界面\"验证您的手机！</b>");
            }
            else {
                $("#suwin .loading").html("<b style='color:red;'>" + data.substr(3) + "</b>");
            }
        }

    });
}
function getTimeCycleSuffix(billingCycle, timeCycle, tag) {
    var cycleSuffix = '';
    if (billingCycle == 0) {
        switch (timeCycle) {
            case '1': cycleSuffix = '天'; break;
            case '2': cycleSuffix = '小时'; break;
            default:
                cycleSuffix = '月';
                if (tag == 1) cycleSuffix = '个月';
                break;
        }
    }
    else {
        if (timeCycle == '0') {
            switch (billingCycle) {
                case '1': cycleSuffix = '月'; break;
                case '3': cycleSuffix = '季'; break;
                case '6': cycleSuffix = '半年'; break;
                case '12': cycleSuffix = '年'; break;
                case '24': cycleSuffix = '2年'; break;
                default: cycleSuffix = billingCycle + '个月'; break;
            }
        }
        else if (timeCycle == '1') {
            switch (billingCycle) {
                case '1': cycleSuffix = '天'; break;
                case '7': cycleSuffix = '周'; break;
                case '15': cycleSuffix = '半月'; break;
                case '30': cycleSuffix = '月'; break;
                case '90': cycleSuffix = '季'; break;
                case '365': cycleSuffix = '年'; break;
                default: cycleSuffix = billingCycle + '天'; break;
            }
        }
        else {
            switch (billingCycle) {
                case '1': cycleSuffix = '小时'; break;
                case '24': cycleSuffix = '天'; break;
                case '168': cycleSuffix = '周'; break;
                default: cycleSuffix = billingCycle + '小时'; break;
            }
        }
    }
    return cycleSuffix;
}