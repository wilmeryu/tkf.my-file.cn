﻿function aiMing_regDomain(domainType, domainName, vprovider, data, templatesid) {
    $("#swin").html(ajaxLoading("正在加载信息，请稍等..."));
    $("#swin").dialog({ title: "操作提示", autoOpen: false, resizable: false, width: 400, height: 280, modal: true, buttons: { "取 消": function () {
        $(this).dialog("close");
    }
    }
    }).dialog("open");

    var jsonArr = $.parseJSON(data);
    var domain = domainName + domainType;
    var str = '';
    var tr_td_SS = '<tr style="height:29px;line-height:29px;border-bottom:1px dashed #ddd;"><td style="width:150px;text-align:right;">';
    var inputSS = 'class="text" style="margin-top:4px;"';
    str += '<h3 style="padding-left:80px;height:40px;font-size:16px;">填写域名注册信息 <b style="color:red;font-size:12px;font-weight:normal;word-spacing: 5px;"> ( 注意：请认真填写下面的信息！)</b></h3>';
    str += '<div style="padding-left:100px;">';
    str += '<table style="width:580px;">';
    str += tr_td_SS + '<b>购买的域名：</b>';
    str += '</td>';
    str += '<td style="text-align:left;"><input type="hidden" id="regDomainName" value="' + domain + '" />';
    str += domain;
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>注册年限：</b>';
    str += '</td>';
    str += '<td style="text-align:left;">';

    var priceArr = productData[0].pprice.cprice.split(',');
    str += '<select name="regYear" id="regYear" onchange="setRegYear()" style="cursor:pointer;margin-top:4px;">';
    if (priceArr[3] != 0) {
        str += '<option value="1" style="cursor:pointer;">1</option>';
    }
    if (priceArr[4] != 0) {
        str += '<option value="2" style="cursor:pointer;">2</option>';
    }
    str += '</select> 年</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';

    str += tr_td_SS + '<b>选择联系人信息：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:250px;">';
    str += '<select id=\"selcontact\" name=\"selcontact\" style=\"height:auto;cursor:pointer;\">';

    for (var i = 0; i < jsonArr.length; i++) {
        str += '<option value="' + i + '">' + jsonArr[i].lname + jsonArr[i].fname + "-" + (i + 1) + '</option>';
    }

    str += '</select>&nbsp;&nbsp;&nbsp;<input type="button" value="联系人模板管理" class="submit" id="btntemplates" style="cursor:pointer;"></td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';

    str += '<tr style="height:29px;line-height:29px;border-bottom:1px dashed #ddd;"><td style="width:120px;text-align:right;"><b>姓：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="lname" id="lname" onblur="aiMing_keyUpCheck(this)" class="text" style="margin-top:4px;width:45px" >';
    str += '&nbsp;&nbsp;&nbsp;<b>名：</b>';
    str += '<input name="fname" id="fname" onblur="aiMing_keyUpCheck(this)" class="text" style="margin-top:4px;width:60px" >';
    str += '</td>';
    str += '<td style="text-align:left;width:150px;">';
    str += ' <span style="color:green;"></span>';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>英文姓：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="lnameE" id="lnameE" onblur="aiMing_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>英文名：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="fnameE" id="fnameE" onblur="aiMing_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>联系电话：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="phone" id="phone" onfocus="aiMing_keyFocus(this)" onblur="aiMing_keyUpCheck(this)" ' + inputSS + '>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 如：020-12345678</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>传真：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="fax" id="fax" onfocus="aiMing_keyFocus(this)" onblur="aiMing_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 如：020-12345678</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>电子邮箱：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="email" id="email" onblur="aiMing_keyUpCheck(this)" value=' + userData[0].umail + ' ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>省份：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="province" id="province" onfocus="aiMing_keyFocus(this)" onblur="aiMing_keyUpCheck(this)" ' + inputSS + '>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 省/市</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>城市：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="city" id="city" onfocus="aiMing_keyFocus(this)" onblur="aiMing_keyUpCheck(this)" ' + inputSS + '>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 市/区</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>街道地址：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="street" id="street" onblur="aiMing_keyUpCheck(this)" ' + inputSS + '>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>街道地址英文：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="streetE" id="streetE" onblur="aiMing_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>邮编：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="zipcode" id="zipcode" onblur="aiMing_keyUpCheck(this)" ' + inputSS + '>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>注册公司：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="org" id="org" onblur="aiMing_keyUpCheck(this)" ' + inputSS + '>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>注册公司英文：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="orgE" id="orgE" onblur="aiMing_keyUpCheck(this)" ' + inputSS + '>';
    str += '</td>';
    str += '<td style="text-align:left;width:150px;">';
    str += '</td>';
    str += '</tr>';
    str += '</table>';
    str += '</div>';
    $("#swin").html(str);
    $("#swin").append('<form id="OrderConfig"><div id="myStr"></div></form>');

    $("#selcontact").change(function () {
        var i = $(this).val();
        $("#lname").val(jsonArr[i].lname);
        $("#fname").val(jsonArr[i].fname);
        $("#lnameE").val(jsonArr[i].lnameE);
        $("#fnameE").val(jsonArr[i].fnameE);
        $("#phone").val(jsonArr[i].phonecode + '-' + jsonArr[i].phone);
        $("#fax").val(jsonArr[i].faxcode + '-' + jsonArr[i].fax);
        $("#email").val(jsonArr[i].email);
        $("#province").val(jsonArr[i].province);
        $("#city").val(jsonArr[i].city);
        $("#street").val(jsonArr[i].street);
        $("#streetE").val(jsonArr[i].streetE);
        $("#zipcode").val(jsonArr[i].zipcode);
        $("#org").val(jsonArr[i].company);
        $("#orgE").val(jsonArr[i].companyE);

    });
    $("#selcontact").val(templatesid).change();
    $("#btntemplates").click(function () {
        common_ListDomainContact(domainType, domainName, vprovider, '', "reg", templatesid);
    });

    $("#swin").dialog({ title: "【" + domain + "】域名注册信息", autoOpen: false, resizable: false, width: 830, height: 590, modal: true, buttons: { "立即注册": function () {
        aiMing_gotoRegDomain();
    },"关 闭": function () {
        $(this).dialog("close");
    }
    }
    }).dialog("open");
    // var rType = domain.substr(domain.indexOf("."));
    var discount = parseFloat(productData[0].discount);
    var myPrice = getPriceByType(domainType, 'reg');
    var yearNum = 1;
    var pStr = '';

    $("#divprice").remove();

   pStr += '<div style="float:left;height:44px;line-height:44px;" id="divprice"><input type="hidden" value="' + yearNum + '" id="yearNum" />';
    if (discount > 0 && discount < 1) {
        pStr += '<strong>总价格：<span style="color:blue;" id="OrderNormalPrice"><strike>' + myPrice + '</strike></span> <b style="">RMB</b>';
        myPrice = parseFloat(getPriceByType(domainType, 'reg')) * discount;
        pStr += '<input type="hidden" value="' + myPrice + '" id="typePrice" />';
        pStr += '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
        pStr += '帐户优惠价(' + discount + '折)：<span style="color:blue;" id="OrderPrice">' + myPrice + '</span> <b style="">RMB</b></strong>';
    }
    else {

        myPrice = parseFloat(getPriceByType(domainType, 'reg')) * discount;

        pStr += '<input type="hidden" value="' + myPrice + '" id="typePrice" />';
        pStr += '<strong>总价格：<span style="color:blue;" id="OrderPrice">' + myPrice + '</span> <b style="color:blue;">RMB</b></strong>';
    }
    pStr += '</div>';
    $(".ui-dialog-buttonset").before(pStr);
    // });
}

function aiMing_gotoRegDomain() {
    var fname = $("#fname"), lname = $("#lname"), fnameE = $("#fnameE"), lnameE = $("#lnameE"), phone = $("#phone"), fax = $("#fax"), email = $("#email");
    var province = $("#province"), city = $("#city"), street = $("#street"), streetE = $("#streetE"), zipcode = $("#zipcode"), org = $("#org"), orgE = $("#orgE");
    if ($.trim(lname.val()) == "") { lname.parent().next("td").html("<b style='color:red;'>*姓氏不能为空！</span>"); lname.focus(); return false; }
    if ($.trim(fname.val()) == "") { fname.parent().next("td").html("<b style='color:red;'>*名子不能为空！</span>"); fname.focus(); return false; }
    if ($.trim(lnameE.val()) == "") { lnameE.parent().next("td").html("<b style='color:red;'>*英文姓氏不能为空！</span>"); lnameE.focus(); return false; }
    if ($.trim(fnameE.val()) == "") { fnameE.parent().next("td").html("<b style='color:red;'>*英文名子不能为空！</span>"); fnameE.focus(); return false; }

    
    
    if ($.trim(phone.val()) == "") {
        phone.parent().next("td").html("<b style='color:red;'>*联系电话不能为空！</span>");
        phone.focus();
        return false;
    }
    else {
        var ik = $.trim(phone.val()).indexOf("-");
        if (ik == 3 || ik == 4) {
            var phonelen = phone.val().split('-')[1].length;
            if (phonelen < 7 || phonelen > 8) {
                phone.parent().next("td").html("<span style='color:red;'>*格式错误！</span>");
                return false;
            } else {
                phone.parent().next("td").html(" 如：020-12345678");
            }
        } else {
            phone.parent().next("td").html("<span style='color:red;'>*格式错误！</span>");
            return false;
        }
    }
    if ($.trim(fax.val()) == "") {
        fax.parent().next("td").html("<b style='color:red;'>*传真不能为空！</span>");
        fax.focus();
        return false;
    }
    else {
        var ik = $.trim(fax.val()).indexOf("-");
        if (ik == 3 || ik == 4) {
            // fax.parent().next("td").html(" 如：020-12345678");
            var faxlen = fax.val().split('-')[1].length;
            if (faxlen < 7 || faxlen > 8) {
                fax.parent().next("td").html("<span style='color:red;'>*格式错误！</span>");
                return false;
            } else {
                fax.parent().next("td").html(" 如：020-12345678");
            }
        } else {
            fax.parent().next("td").html("<span style='color:red;'>*格式错误！</span>");
            return false;
        }
    }
    if ($.trim(email.val()) == "") {
        email.parent().next("td").html("<b style='color:red;'>*邮箱不能为空！</span>");
        email.focus();
        return false;
    }
    else {
        var reg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
        if (!reg.test($.trim(email.val()))) {
            email.parent().next("td").html("<b style='color:red;'>*邮箱格式不正确！</span>");
            email.focus();
            return false;
        }
        else {
            email.parent().next("td").html("<b style='font-size:1px;'>&nbsp;</b>");
        }
    }
    if ($.trim(province.val()) == "") { province.parent().next("td").html("<b style='color:red;'>*省份不能为空！</span>"); province.focus(); return false; }
    if ($.trim(city.val()) == "") { city.parent().next("td").html("<b style='color:red;'>*城市不能为空！</span>"); city.focus(); return false; }
    if ($.trim(street.val()) == "") { street.parent().next("td").html("<b style='color:red;'>*街道地址不能为空！</span>"); street.focus(); return false; }
    if ($.trim(streetE.val()) == "") { streetE.parent().next("td").html("<b style='color:red;'>*街道的英文不能为空！</span>"); streetE.focus(); return false; }

    if (streetE.val().indexOf("'") > -1) { streetE.parent().next("td").html("<b style='color:red;'>*街道英文地址不能包含单引号！</span>"); streetE.focus(); return false; }
    if ($.trim(zipcode.val()) == "") { zipcode.parent().next("td").html("<b style='color:red;'>*邮编不能为空！</span>"); zipcode.focus(); return false; }
    if ($.trim(org.val()) == "") { org.parent().next("td").html("<b style='color:red;'>*公司名称不能为空！</span>"); org.focus(); return false; }
    if ($.trim(orgE.val()) == "") { orgE.parent().next("td").html("<b style='color:red;'>*公司的英文不能为空！</span>"); orgE.focus(); return false; }
    var theDomainName = $("#regDomainName").val();
    var theType = theDomainName.substr(theDomainName.indexOf("."));
    var yNum = $("#regYear").val();
    normalPrice = parseFloat(getPriceByType(theType, 'reg')) * parseInt($("#yearNum").val());
    finalPrice = parseFloat($("#typePrice").val()) * parseInt($("#yearNum").val());
    billingCycle = parseInt($("#yearNum").val()) * 12;
    billingMothod = 1;
    var myInputs = '<input type="hidden" value="' + getPriceByType(theType, 'reg') + '" name="typePrice" />' +
          '<input type="hidden" value="' + getPriceByType(theType, 'renew') + '" name="renewPrice" />' +
          '<input type="hidden" value="' + getPriceByType(theType, 'transfer') + '" name="transferPrice" />' +
          '<input type="hidden" value="' + $("#regDomainName").val() + '" name="domainName" />' +
          '<input type="hidden" value="' + yNum + '" name="regYearNum" />' +
          '<input type="hidden" value="' + $.trim(fname.val()) + '" name="fname" />' +
          '<input type="hidden" value="' + $.trim(lname.val()) + '" name="lname" />' +
          '<input type="hidden" value="' + $.trim(fnameE.val()) + '" name="fnameE" />' +
          '<input type="hidden" value="' + $.trim(lnameE.val()) + '" name="lnameE" />' +
          '<input type="hidden" value="' + $.trim(phone.val()) + '" name="phone" />' +
          '<input type="hidden" value="' + $.trim(fax.val()) + '" name="fax" />' +
          '<input type="hidden" value="' + $.trim(email.val()) + '" name="email" />' +
          '<input type="hidden" value="' + $.trim(province.val())+ '" name="province" />' +
          '<input type="hidden" value="' + $.trim(city.val()) + '" name="city" />' +
          '<input type="hidden" value="' + $.trim(street.val()) + '" name="street" />' +
          '<input type="hidden" value="' + $.trim(streetE.val()) + '" name="streetE" />' +
          '<input type="hidden" value="' + $.trim(zipcode.val()) + '" name="zipcode" />' +
          '<input type="hidden" value="' + $.trim(org.val()) + '" name="org" />' +
          '<input type="hidden" value="' + $.trim(orgE.val()) + '" name="orgE" />' +
          '<input type="hidden" value="aiming" name="provider" />';
    $("#myStr").html(myInputs);
   suwin.next().find("#divprice").remove(); 
    suwin.dialog({ title: "购买确认", autoOpen: false, resizable: false, width: 399, height: 368, modal: true, buttons: { "确定购买": function () { checkout(1);}, "继续配置": function () { $(this).dialog("close"); }, "在线充值": function () { window.open('?c=finance', '_blank'); } } }).dialog("open");
    checkout(0);
}

function aiMing_transferDomain(domainName, domainType, pwd, provider, data, templatesid) {
    $("#swin").dialog({ title: "域名转入服务", autoOpen: false, resizable: false, width: 800, height: 568, modal: true, buttons: { "确定转入": function () {

        aiMing_gotoTransferDomain(domainName, domainType, pwd, provider);
    }, "关 闭": function () {
        $(this).dialog("close");
    }
    }
    }).dialog("open");



    var jsonArr = $.parseJSON(data);

    var str = '';
    str += '<h3 style="padding-left:70px;height:40px;font-size:16px;">请填写下面的转入域名信息 <b style="color:red;font-size:12px;font-weight:normal;word-spacing: 5px;"> ( 注意：请认真填写下面的信息！)</b></h3>';
    str += '<div style="margin-left:150px;">';
    str += '<table>';
    var tr_td_SS = '<tr style="height:29px;line-height:29px;border-bottom:1px dashed #ddd;"><td style="width:120px;text-align:right;">';
    var inputSS = 'class="text" style="margin-top:4px;"';
    str += '<div style="padding-left:170px;">';
    str += '<table style="width:450px;">';
    str += tr_td_SS + '<b>转入的域名：</b>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += domainName + domainType;
    str += '</td>';
    str += '<td style="text-align:left;width:150px;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>转移密码：</b>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += pwd;
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += '</table>';
    str += '<table id="comBox">';

    str += tr_td_SS + '<b>选择联系人信息：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:250px;">';
    str += '<select id=\"selcontact\" name=\"selcontact\" style=\"height:auto;cursor:pointer;\">';

    for (var i = 0; i < jsonArr.length; i++) {
        str += '<option value="' + i+ '">' + jsonArr[i].lname + jsonArr[i].fname + "-" + (i + 1) + '</option>';
    }
    str += '</select>&nbsp;&nbsp;&nbsp;<input type="button" value="联系人模板管理" class="submit" id="btntemplates" style="cursor:pointer;"></td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';

    str += '<tr style="height:29px;line-height:29px;border-bottom:1px dashed #ddd;"><td style="width:120px;text-align:right;"><b>姓：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="lname" id="lname" onblur="aiMing_keyUpCheck(this)" class="text" style="margin-top:4px;width:45px" >';
    str += '&nbsp;&nbsp;&nbsp;<b>名：</b>';
    str += '<input name="fname" id="fname" onblur="aiMing_keyUpCheck(this)" class="text" style="margin-top:4px;width:60px" >';
    str += '</td>';
    str += '<td style="text-align:left;width:150px;">';
    str += ' <span style="color:green;"></span>';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>联系电话：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="phone" id="phone" onfocus="aiMing_keyFocus(this)" onblur="aiMing_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' <span style="color:green;"></span>';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>传真：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="fax" id="fax" onfocus="aiMing_keyFocus(this)" onblur="aiMing_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' <span style="color:green;"></span>';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>电子邮箱：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="email" id="email" onblur="aiMing_keyUpCheck(this)"  value=' + userData[0].umail + ' ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' <span style="color:green;"></span>';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>省份：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="province" id="province" onfocus="aiMing_keyFocus(this)" onblur="aiMing_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 省/市<span style="color:green;"></span>';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>城市：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="city" id="city" onfocus="aiMing_keyFocus(this)" onblur="aiMing_keyUpCheck(this)" ' + inputSS + '>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 市/区<span style="color:green;"></span>';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>街道地址：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="street" id="street" onblur="aiMing_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' <span style="color:green;"></span>';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>邮编：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="zipcode" id="zipcode" onblur="aiMing_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' <span style="color:green;"></span>';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>注册公司：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="org" id="org" onblur="aiMing_keyUpCheck(this)" ' + inputSS + '>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' <span style="color:green;"></span>';
    str += '</td>';
    str += '</tr>';
    str += '</table>';
    str += '</div>';
    $("#swin").html(str);
    $("#selcontact").change(function () {
        var i = $(this).val();
        $("#lname").val(jsonArr[i].lname);
        $("#fname").val(jsonArr[i].fname);
        $("#phone").val(jsonArr[i].phonecode + '-' + jsonArr[i].phone);
        $("#fax").val(jsonArr[i].faxcode + '-' + jsonArr[i].fax);
        $("#email").val(jsonArr[i].email);
        $("#province").val(jsonArr[i].province); 
        $("#city").val(jsonArr[i].city);
        $("#street").val(jsonArr[i].street);
        $("#zipcode").val(jsonArr[i].zipcode);
        $("#org").val(jsonArr[i].company);
    });
    $("#selcontact").val(templatesid).change();
    $("#btntemplates").click(function () {
        common_ListDomainContact(domainType, domainName, provider, pwd, 'transfer', templatesid);
    });
}
function aiMing_gotoTransferDomain(domainName, domainType, pwd, provider) {
    var fname = $("#fname"), lname = $("#lname"), phone = $("#phone"), fax = $("#fax"), email = $("#email");
    var province = $("#province"), city = $("#city"), street = $("#street"), zipcode = $("#zipcode"), org = $("#org");
    if ($.trim(lname.val()) == "") { lname.parent().next("td").html("<b style='color:red;'>*姓氏不能为空！</span>"); lname.focus(); return false; }
    if ($.trim(fname.val()) == "") { fname.parent().next("td").html("<b style='color:red;'>*名子不能为空！</span>"); fname.focus(); return false; }
    if ($.trim(phone.val()) == "") { phone.parent().next("td").html("<b style='color:red;'>*联系电话不能为空！</span>"); phone.focus(); return false; }
    if ($.trim(fax.val()) == "") { fax.parent().next("td").html("<b style='color:red;'>*传真不能为空！</span>"); fax.focus(); return false; }
    if ($.trim(email.val()) == "") {
        email.parent().next("td").html("<b style='color:red;'>*邮箱不能为空！</span>");
        email.focus();
        return false;
    }
    else {
        var reg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
        if (!reg.test($.trim(email.val()))) {
            email.parent().next("td").html("<b style='color:red;'>*邮箱格式不正确！</span>");
            email.focus();
            return false;
        }
        else {
            email.parent().next("td").html("<b style='font-size:1px;'>&nbsp;</b>");
        }
    }
    if ($.trim(province.val()) == "") { province.parent().next("td").html("<b style='color:red;'>*省份不能为空！</span>"); province.focus(); return false; }
    if ($.trim(city.val()) == "") { city.parent().next("td").html("<b style='color:red;'>*城市不能为空！</span>"); city.focus(); return false; }
    if ($.trim(street.val()) == "") { street.parent().next("td").html("<b style='color:red;'>*街道地址不能为空！</span>"); street.focus(); return false; }
    if ($.trim(zipcode.val()) == "") { zipcode.parent().next("td").html("<b style='color:red;'>*邮编不能为空！</span>"); zipcode.focus(); return false; }
    if ($.trim(org.val()) == "") { org.parent().next("td").html("<b style='color:red;'>*公司名称不能为空！</span>"); org.focus(); return false; }

    normalPrice = getPriceByType(domainType, 'transfer'); ;
    if (isNaN(normalPrice)) { alert("抱歉，你要转入的域名类型暂不支持！"); return false; }
    billingCycle = 12;
    var discount = parseFloat(productData[0].discount);
    if (discount > 0) { normalPrice = normalPrice * discount; }
    finalPrice = normalPrice * discount;
    var myInputs = '<input type="hidden" value="' + getPriceByType(domainType, 'reg') + '" name="typePrice" />';
    myInputs += '<input type="hidden" value="' + getPriceByType(domainType, 'renew') + '" name="renewPrice" />';
    myInputs += '<input type="hidden" value="' + getPriceByType(domainType, 'transfer') + '" name="transferPrice" />';
    myInputs += '<input type="hidden" value="yes" name="transferFlag" />';
    myInputs += '<input type="hidden" value="' + domainType.replace(new RegExp(/(\.)/g), '') + '" name="transferType" />';
    myInputs += '<input type="hidden" value="' + pwd + '" name="domainPwd" />';
    myInputs += '<input type="hidden" value="1" name="regYear" />';
    myInputs += '<input type="hidden" value="' + domainName + domainType + '" name="domainName" />';
    myInputs += '<input type="hidden" value="' + $.trim(fname.val()) + '" name="fname" />';
    myInputs += '<input type="hidden" value="' + $.trim(lname.val()) + '" name="lname" />';
    myInputs += '<input type="hidden" value="' + $.trim(phone.val()) + '" name="phone" />';
    myInputs += '<input type="hidden" value="' + $.trim(fax.val()) + '" name="fax" />';
    myInputs += '<input type="hidden" value="' + $.trim(email.val()) + '" name="email" />';
    myInputs += '<input type="hidden" value="' + $.trim(province.val()) + '" name="province" />';
    myInputs += '<input type="hidden" value="' + $.trim(city.val()) + '" name="city" />';
    myInputs += '<input type="hidden" value="' + $.trim(street.val()) + '" name="street" />';
    myInputs += '<input type="hidden" value="' + $.trim(zipcode.val()) + '" name="zipcode" />';
    myInputs += '<input type="hidden" value="' + $.trim(org.val()) + '" name="org" />';
    myInputs += '<input type="hidden" value="aiming" name="provider" />';
    $("#swin").append('<form id="OrderConfig">' + myInputs + '</form>');
    $("#OrderConfig").append('<input type="hidden" id="couponcode" value="" />');
    suwin.next().find("#divprice").remove(); 
    $("#suwin").dialog({ title: "确认域名转入", autoOpen: false, resizable: false, width: 350, height: 300, modal: true, buttons: { "确定转入": function () {
        checkout(1);
    }, "取 消": function () {
        $(this).dialog("close");
    }
    }
    }).dialog("open");
    var qus = '<div style="padding-top:20px;"></div><table>';
    qus += '<tr style="height:35px;line-height:35px;"><td style="width:120px;text-align:right;">转入域名：';
    qus += '<td><b>' + domainName + domainType + '</b></td>';
    qus += '</tr>';
    qus += '<tr style="height:35px;line-height:35px;"><td style="width:120px;text-align:right;">转入密码：';
    qus += '<td><b>' + pwd + '</b></td>';
    qus += '</tr>';

    if (discount > 0 && discount < 1) {
        qus += '<tr style="height:35px;line-height:35px;"><td style="width:120px;text-align:right;">转入价格：';
        qus += '<td><strike>' + getPriceByType(domainType, 'transfer') + '</strike> RMB/1年</td>';
        qus += '</tr>';
        qus += '<tr style="height:35px;line-height:35px;"><td style="width:120px;text-align:right;">账户优惠价格：';
        qus += '<td>' + (getPriceByType(domainType, 'transfer') * discount).toFixed(2) + ' RMB/1年</td>';
        qus += '</tr>';
    } else {
        qus += '<tr style="height:35px;line-height:35px;"><td style="width:120px;text-align:right;">转入价格：';
        qus += '<td><b>' + normalPrice.toFixed(2) + ' RMB/1年</b></td>';
        qus += '</tr>';
    }
    qus += '</table>';
    qus += '<div style="color:red;font-size:15;padding-top:20px;"><b>*请认真核对域名和密码，确认转入后会立即扣费。</b></div>';
    $("#suwin").html(qus);
}




function aiMing_keyUpCheck(obj) {
    var checkName = $(obj).attr("name");
    var checkValue = $.trim($(obj).val());
    switch (checkName) {
        case "TransferDomainName":
            //            if (checkValue.indexOf(".cn") > -1 || checkValue.indexOf(".中国") > -1 || checkValue.indexOf(".公司") > -1 || checkValue.indexOf(".网络") > -1) {
            //                $("#comBox").hide();
            //                $(obj).parent().next("td").html("");
            //            }
            //            else {
            //                if (checkValue.indexOf(".") > -1) {
            //                    $("#comBox").show();
            //                    $(obj).parent().next("td").html("");
            //                }
            //                else {
            //                    if (checkValue == "") {
            //                        $(obj).parent().next("td").html("<span style='color:red;'>*请填写转入域名！</span>");
            //                    } else {
            //                        $(obj).parent().next("td").html("<span style='color:red;'>*域名格式错误！</span>");
            //                    } $(obj).focus(); return false;
            //                }
            //            }
            if (checkValue.length <= 0) {
                $(obj).parent().next("td").html("<span style='color:red;'>*请填写域名名称！</span>");
            } else if (checkValue.indexOf(".") > -1) {
                $(obj).parent().next("td").html("<span style='color:red;'>*域名名称不能包含域名后缀！</span>");
            } else {
                $(obj).parent().next("td").html("");
            }
            break;
        case "DomainPwd":
            if (checkValue.length > 4) {
                $(obj).parent().next("td").html("");
            }
            else {
                if (checkValue.length == 0) {
                    $(obj).parent().next("td").html("<span style='color:red;'>*密码不能为空！</span>");
                }
                else { $(obj).parent().next("td").html("<span style='color:red;'>*密码长度不符合要求!</span>"); }
            }
            break;
        case "email":
            var reg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
            if (!reg.test(checkValue)) {
                $(obj).parent().next("td").html("<span style='color:red;'>*邮箱格式错误！</span>");
            }
            else {
                $(obj).parent().next("td").html("");
            }
            break;
        case "phone":
            if (checkValue.length == 0) {
                $(obj).parent().next("td").html("<span style='color:red;'>*不能为空</span>");
            }
            else {
                var ik = checkValue.indexOf("-");
                if (ik == 3 || ik == 4) {
                    //$(obj).parent().next("td").html(" 如：020-12345678");
                    var phonelen = checkValue.split('-')[1].length;
                    if (phonelen < 7 || phonelen > 8) {
                        $(obj).parent().next("td").html("<span style='color:red;'>*格式错误！</span>");
                    } else {
                        $(obj).parent().next("td").html(" 如：020-12345678");
                    }

                } else {
                    $(obj).parent().next("td").html("<span style='color:red;'>*格式错误！</span>");
                }
            }
            break;
        case "fax":
            if (checkValue.length == 0) {
                $(obj).parent().next("td").html("<span style='color:red;'>*不能为空</span>");
            }
            else {
                var ik = checkValue.indexOf("-");
                if (ik == 3 || ik == 4) {
                    // $(obj).parent().next("td").html(" 如：020-12345678")
                    var faxlen = checkValue.split('-')[1].length;
                    if (faxlen < 7 || faxlen > 8) {
                        $(obj).parent().next("td").html("<span style='color:red;'>*格式错误！</span>");
                    } else {
                        $(obj).parent().next("td").html(" 如：020-12345678");
                    }
                } else {
                    $(obj).parent().next("td").html("<span style='color:red;'>*格式错误！</span>");
                }
            }
            break;
        case "province":
            if (checkValue.length == 0) {
                $(obj).parent().next("td").html("<span style='color:red;'>*不能为空</span>");
            }
            else {
                $(obj).parent().next("td").html(" 省/市，如：广东");
            }
            break;
        case "city":
            if (checkValue.length == 0) {
                $(obj).parent().next("td").html("<span style='color:red;'>*不能为空</span>");
            }
            else {
                $(obj).parent().next("td").html(" 市/区，如：广州");
            }
            break;
        default:
            if (checkValue.length == 0) {
                $(obj).parent().next("td").html("<span style='color:red;'>*不能为空</span>");
            }
            else {
                $(obj).parent().next("td").html("");
            }
            break;
    }
}
function aiMing_keyFocus(obj) {
    var checkName = $(obj).attr("name");
    var checkValue = $.trim($(obj).val());
    switch (checkName) {
        case "phone":
            $(obj).parent().next("td").html(" 如：020-12345678");
            break;
        case "fax":
            $(obj).parent().next("td").html(" 如：020-12345678");
            break;
        case "province":
            $(obj).parent().next("td").html(" 省/市，如：广东");
            break;
        case "city":
            $(obj).parent().next("td").html(" 市/区，如：广州");
            break;
    }
}