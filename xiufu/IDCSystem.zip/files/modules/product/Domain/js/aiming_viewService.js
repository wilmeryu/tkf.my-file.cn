﻿/// <reference path="jquery-vsdoc.js" />
/// <reference path="jquery-ui.min.js" />
function aiming_view() {

    var str = '<table width="100%" border="0" cellspacing="0" cellpadding="0" class="table grid"><thead><tr><th  style="text-align: right;">当前域名信息：</th><th class=\"full\">&nbsp;</th></tr></thead><tbody>';
    var title = '';
    if (serviceData[0].ssid == 0) {
        title = '域名服务还在申请中...';
    }
    else {
        title = '管理我的域名 ' + serviceData[0].sconfig.domainName + '';
    }
    str += '<tr><td class="title">域名：</td><td><span id=""></span><span title="">' + serviceData[0].sconfig.domainName + '</span></td></tr>';
    if (serviceData[0].ssid != 0) {
        str += '<tr><td class="title">注册时间：</td><td><span id="regTime" title="">' + serviceData[0].sconfig.regDate + '</span></td></tr>';
        str += "<tr>";
        str += "<td class=\"title\" style=\"text-align: right;\">";
        str += "域名管理：";
        str += "</td>";
        str += "<td>";
        str += "<form action=\"http://www.everdns.com/index.aspx\" target=\"_blank\" method=\"POST\" name=\"form1\" id=\"form1\">";
        str += "<input type=\"hidden\" value=\"\" name=\"txtdomain\" id=\"txtdomain\">";
        str += "<input type=\"hidden\" value=\"\" name='txtpassword' id='txtpassword'>";
        str += "<input type=\"submit\" name='btn_login' value=\"域名自助管理\" class=\"submit\" style=\"cursor:pointer;\">";
        str += "</form>";
        str += "</td></tr>";
    }
    if (serviceData[0].sconfig.transferType == "cn") { } else {
        str += '<tr><td class="title">姓名：</td><td><span id=""></span><span title="">' + serviceData[0].sconfig.lname + '</span>' + serviceData[0].sconfig.fname + '</td></tr>';
        str += '<tr><td class="title">联系电话：</td><td><span id=""></span><span title="">' + serviceData[0].sconfig.phone + '</span></td></tr>';
        str += '<tr><td class="title">传 真：</td><td><span id=""></span><span title="">' + serviceData[0].sconfig.fax + '</span></td></tr>';
        str += '<tr><td class="title">联系邮箱：</td><td><span id=""></span><span title="">' + serviceData[0].sconfig.email + '</span></td></tr>';
        str += '<tr><td class="title">联系地址：</td><td><span id=""></span><span title="">';
        str += serviceData[0].sconfig.province + ' ';
        str += serviceData[0].sconfig.city + ' ';
        str += serviceData[0].sconfig.street;
        str += '</span></td></tr>';
        str += '<tr><td class="title">邮 编：</td><td><span id=""></span><span title="">' + serviceData[0].sconfig.zipcode + '</span></td></tr>';
        str += '<tr><td class="title">公司名称：</td><td><span id=""></span><span title="">' + serviceData[0].sconfig.org + '</span></td></tr>';
    } str += ''
    $("#pageTitle").html(title);
    document.title = title;
    var statusText = serviceStatus[parseInt(serviceData[0].sstatus) + 2];
    switch (serviceData[0].sstatus) {
        case "-1": statusText = '<strong style="color:#0000FF;">' + statusText + '</strong>'; break;
        case "0": statusText = '<strong style="color:#005B00;">' + statusText + '</strong>'; break;
        case "3": statusText = '<strong style="color:#CC3300;">' + statusText + '</strong>'; break;
        case "1":
        case "2":
        case "4": statusText = '<strong style="color:#FF0000;">' + statusText + '</strong>'; break;
    }
    str += '<tr><td class="title">续费价格：</td><td><b>' + serviceData[0].sprice + ' ' + userData[0].currency + '</b> / ' + serviceData[0].spcycle / 12 + ' 年&nbsp;&nbsp;&nbsp;<b>账户余额：</b>' + parseFloat(userData[0].balance).toFixed(2) + ' ' + userData[0].currency + ' &nbsp;&nbsp;<a href="javascript:_renew();">『马上续费』</a></td></tr>' +
            '<tr><td class="title">到期时间：</td><td><span id="endTime">' + getUnixTime(serviceData[0].etime) + '</span>&nbsp;&nbsp;<span style="color:#999;">请确保你的账户余额充足</span>&nbsp;&nbsp;&nbsp;<input id="autorenew" type="checkbox" ' + (serviceData[0].autorenew == '0' ? 'checked="checked"' : '') + '/><label for="autorenew">自动续费</label></td></tr>' +
            '<tr><td class="title">服务状态：</td><td id="statusFlag">' + statusText + ' &nbsp;&nbsp;';
    if (serviceData[0].sstatus == "-1") {
        str += '<input type=\"submit\" value=\"立即刷新状态\" class=\"submit\" onclick=\"aiming_reloadpage()\" />';
    }
    str += '</td></tr>';

    str += '</tbody></table>';
    str += '<table width="100%" border="0" cellspacing="0" cellpadding="0" class="table grid"><thead><tr><th style="text-align: right;">当前服务其它信息：</th><th class=\"full\">&nbsp;</th></tr></thead>';
    str += "";
    if (serviceData[0].sconfig.other != undefined && serviceData[0].sconfig.other.length > 0) {
        str += "<tr>";
        str += "<td class=\"title\" style=\"text-align: right;\">";
        str += "其它描述：";
        str += "</td>";
        str += "<td>";
        str += serviceData[0].sconfig.other;
        str += "</td></tr>";
    }
    if (serviceData[0].ssid != 0) {
        str += "<tr>";
        str += "<td class=\"title\" style=\"text-align: right;\">";
        str += "联系人模板管理：";
        str += "</td>";
        str += "<td>";
        str += "<input type=\"submit\" value=\"注册联系人模板信息管理\" onclick=\"common_ListDomainContact()\" class=\"submit\" style=\"cursor:pointer;\">&nbsp;&nbsp;";
        str += "</td></tr>";


        str += "<tr>";
        str += "<td class=\"title\" style=\"text-align: right;\">";
        str += "域名密码管理：";
        str += "</td>";
        str += "<td>";
        str += "<input type=\"submit\" value=\"修改密码\" onclick=\"aiming_editPwd()\" class=\"submit\" style=\"cursor:pointer;\">&nbsp;&nbsp;";
        str += "<input type=\"submit\" value=\"获取密码\" onclick=\"aiming_getBackPwd()\" class=\"submit\" style=\"cursor:pointer;\">&nbsp;&nbsp;";
        str += "</td></tr>";
        str += "<tr>";
        str += "<td class=\"title\" style=\"text-align: right;\">";
        str += "域名DNS管理：";
        str += "</td>";
        str += "<td>";
        // str += "<input type=\"submit\" value=\"域名信息修改\" onclick=\"EditDomainInfo()\" class=\"submit\" style=\"cursor:pointer;\">&nbsp;&nbsp;";
        str += "<input type=\"submit\" value=\"域名DNS修改\" onclick=\"aiming_EditDomainDNS()\" class=\"submit\" style=\"cursor:pointer;\">&nbsp;&nbsp;";
        str += "&nbsp;&nbsp;";
        if (serviceData[0].sconfig.transferFlag == "yes") {
            str += "<input type=\"submit\" value=\"域名转入状态查询\" onclick=\"aiming_ViewTransferDomain()\" class=\"submit\" style=\"cursor:pointer;\">&nbsp;&nbsp;";
        }
        str += "</td></tr>";
    }

    str += "<td class=\"title\" style=\"text-align: right;\">";
    str += "同步域名服务时间：";
    str += "</td>";
    str += "<td>"
    str += "<span id=\"ajaxFlag\">未同步</span>";
    str += "</td></tr>";
    str += "</table>";
    $("#ViewService").html(str);
    $("#ViewService .title").css("text-align", "right");


    var url = "?c=module&productid=" + productData[0].pid + "&show=text&todo=aiming_ajaxDomainInfo";
    url += "&domainName=" + serviceData[0].sconfig.domainName;
    if (serviceData[0].ssid == 0) {
        if (serviceData[0].sconfig.transferFlag == "yes") {
            $("#ajaxFlag").html("<b style='color:red;'>域名正在转入中，请刷新页面或联系销售人员</b><input type=\"submit\" value=\"立即刷新状态\" class=\"submit\" onclick=\"aiming_reloadpage()\" />");
        } else {
            $("#ajaxFlag").html("<b style='color:red;'>域名正在注册中，请刷新页面或联系销售人员</b><input type=\"submit\" value=\"立即刷新状态\" class=\"submit\" onclick=\"aiming_reloadpage()\" />");
        } return false;
    }
    $("#ajaxFlag").html("正在加载<img src=\"/images/loading.gif\" />");
    $.post(url, function (data) {
        if (data.indexOf("320") > -1) {
            var mydata = data.split(',');
            $("#regTime").html(mydata[1].substr(mydata[1].indexOf(":") + 1));
            $("#endTime").html(mydata[2].substr(mydata[2].indexOf(":") + 1));
            $("#ajaxFlag").html("<b style='color:green;'>已经完成</b>");
            setTimeout(function () { $("#ajaxFlag").parent().parent().remove(); }, 2000);
        } else {
            if (parseInt(data) == 0) {
                $("#ajaxFlag").html("<b style='color:red;'>服务器繁忙，请点击</b><input type=\"submit\" value=\"立即刷新状态\" class=\"submit\" onclick=\"reloadpage()\" />");
            } else {
                if (data.indexOf("106") > -1) {
                    if (serviceData[0].sconfig.transferFlag == "yes") {
                        $("#ajaxFlag").html("<b style='color:red;'>您的域名还在转入中</b>");
                    } else {
                        $("#ajaxFlag").html("<b style='color:red;'>您的域名还没有备案或域名信息没有审核通过！</b>");
                    }
                } else {
                    $("#ajaxFlag").html("<b style='color:red;'>" + data + "</b>");
                }
            }
        }
        var whois = 'http://whois.chinaz.com/' + serviceData[0].sconfig.domainName;
        var mmStr = "";
        mmStr += "<tr>";
        mmStr += "<td class=\"title\" style=\"text-align: right;\">";
        mmStr += "Whois查询工具：";
        mmStr += "</td>";
        mmStr += "<td>";
        mmStr += "<span style='background-color:#444;font-weight:bold; color:White;padding:3px 5px;'><a style='font-weight:bold;text-decoration:none; color:White;' target='_blank' href='" + whois + "'>" + serviceData[0].sconfig.domainName + "</a></span>";
        mmStr += "</td></tr>";
        $("#ajaxFlag").parent().parent().parent().append(mmStr);
    });


    $("#ViewService #autorenew").css("cursor", "pointer").click(function () {
        var autorenew = $(this).prop("checked") ? '0' : '1';
        setAutorenew(serviceData[0].sid, autorenew);
    });
}
function _view() {
    switch (serviceData[0].sconfig.provider) {
        case 'aiming':
            aiming_view();
            break;
        case 'resellerclub':
            resellerclub_view();
            break;
        case 'xinnet':
            xinnet_view();
            break;
        case 'xinwang':
            xinwang_view();
            break;
    }
}
_view();
var finalPrice = 0;
var normalPrice = 0;
var productID = productData[0].pid;
var billingMothod = 1;
var billingCycle = 1;
function _renew() {
    if (serviceData[0].spmothod != "1") {
        alert("您当前服务无需续费！");
        return false;
    }
    var discount = parseFloat(productData[0].discount);
    var str = '<p style="line-height:28px"><strong>帐户余额</strong>：<strong>' + parseFloat(userData[0].balance).toFixed(2) + '</strong> ' + userData[0].currency;
    if (discount < 1) str += '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong>帐户优惠</strong>：<strong style="color:#0000FF">' + (discount * 100 / 10) + '</strong>折';
    str += '&nbsp;<br /><strong>请选择续费周期</strong>：<br />';

//    var cycles = [];
//    var tmpcprice = productData[0].pprice.cprice.split(',');
//    if (tmpcprice[3] != 0) {
//        cycles.push('12');
//    }
//    if (tmpcprice[4] != 0) {
//        cycles.push('24');
//    }
    var cycles = "12,24".split(',');
    var _price = serviceData[0].sconfig.renewPrice;
    var _pcprice = _price + "," + _price * 2;
    var pcprice = _pcprice.split(',');

    var discount = parseFloat(productData[0].discount);
    var cprices = pcprice;
    var cprice = 0, yprice = 0, pp1 = 0, pp2 = 0;
    for (i = 0; i < cycles.length; i++) {
        if (cprices[i] != '0') {
            cprice = parseFloat(cprices[i]);
            yprice = cprice;
            if (cycles[i] == serviceData[0].spcycle) cprice = serviceData[0].sprice;
            if (pp1 == 0) pp1 = parseFloat(yprice) / parseInt(cycles[i]);
            else {
                pp2 = (parseFloat(yprice) / parseInt(cycles[i]) / pp1 * 10).toFixed(1);
            }
            str += '<input type="radio" name="cycle" value="' + cycles[i] + '_' + cprice + '_' + yprice + '" id="cycle' + cycles[i] + '" /><label for="cycle' + cycles[i] + '">';
            switch (cycles[i]) {
                case "12": str += '一年'; break;
                case "24": str += '二年'; break;
                default: str += cycles[i] + '一年'; break;
            }
            // str += '：' + cprice + (pp2 != 0 ? '' : '') + '</label><br />';

            if (cycles[i] == serviceData[0].spcycle) str += '：' + parseFloat(cprice).toFixed(2) + '</label><br />';
            else
                str += '：' + (discount > 1 ? (parseFloat(cprice) * discount).toFixed(2) : parseFloat(cprice).toFixed(2)) + '</label><br />';
        }
    }
    str += '<strong>续费价格</strong>：<strong class="finalPrice"></strong> ' + userData[0].currency + '&nbsp;&nbsp;&nbsp;<span class="normalPrice"></span><br />&nbsp;<br />' +
           '<span>优 惠 码：<input type="text" id="couponcode" size="10" class="text"/> <input type="button" class="submit" value="使用" onclick="applyCode(\'renew\')"/> <input type="button" class="submit" value="不使用" onclick="clearCouponCode(1)"/></span><br />' +
           '<span id="ccdes" class="pptext"></span></p>';
    str += "<br>";
    $("#suwin").html(str);
    $("#suwin input:radio").click(function () {
        clearCouponCode(1);
        var ps = $(this).val().split('_');
        billingCycle = parseInt(ps[0]);
        finalPrice = parseFloat(ps[1]);
        normalPrice = parseFloat(ps[2]);
        if (billingCycle != parseInt(serviceData[0].spcycle)) finalPrice = finalPrice * discount;
        $("#suwin .finalPrice").html(finalPrice.toFixed(2));

    });
    $("#suwin").append("<input type='hidden' value='" + $("#suwin .finalPrice").html() + "' name='finalPrice' />");
    $("#suwin #cycle" + serviceData[0].spcycle).click();
    $("#suwin").dialog({ title: "续费确认", autoOpen: false, resizable: false, width: 500, height: 398, modal: false, buttons: { "确认续费": function () { renew(serviceData[0].sid, billingCycle, $("#couponcode").val()); }, "关 闭": function () { $(this).dialog("close"); } } }).dialog("open");
}
function aiming_reloadpage() {
    window.location.reload();
}

function aiming_keyUpCheck(obj) {
    var checkName = $(obj).attr("name");
    var checkValue = $.trim($(obj).val());
    switch (checkName) {
        case "TransferDomainName":
            if (checkValue.indexOf(".cn") > -1 || checkValue.indexOf(".中国") > -1 || checkValue.indexOf(".公司") > -1 || checkValue.indexOf(".网络") > -1) {
                $("#comBox").hide();
                $(obj).parent().next("td").html("");
            }
            else {
                if (checkValue.indexOf(".") > -1) {
                    $("#comBox").show();
                    $(obj).parent().next("td").html("");
                }
                else {
                    if (checkValue == "") {
                        $(obj).parent().next("td").html("<span style='color:red;'>*请填写转入域名！</span>");
                    } else {
                        $(obj).parent().next("td").html("<span style='color:red;'>*域名格式错误！</span>");
                    }
                    $(obj).focus();
                    return false;
                }
            }
            break;
        case "DomainPwd":
            if (checkValue.length > 4) {
                $(obj).parent().next("td").html("");
            }
            else {
                if (checkValue.length == 0) {
                    $(obj).parent().next("td").html("<span style='color:red;'>*密码不能为空！</span>");
                }
                else { $(obj).parent().next("td").html("<span style='color:red;'>*密码长度不符合要求!</span>"); }
                $(obj).focus(); return false;
            }
            break;
        case "domainPwd1":
            if (checkValue.length > 4) {
                $(obj).parent().next("td").html("");
            }
            else {
                if (checkValue.length == 0) {
                    $(obj).parent().next("td").html("<span style='color:red;'>*密码不能为空！</span>");
                }
                else { $(obj).parent().next("td").html("<span style='color:red;'>*6到16位!</span>"); }
                return false;
            }
            break;

        case "domainPwd2":
            if (checkValue.length > 4) {
                $(obj).parent().next("td").html("");
                var pwd1 = $.trim($("#domainPwd1").val());
                if (checkValue != pwd1) {
                    $(obj).parent().next("td").html("<span style='color:red;'>*确认密码不对</span>");
                }
                else {
                    $(obj).parent().next("td").html("<span style='color:red;'></span>");
                }
            }
            else {
                if (checkValue.length == 0) {
                    $(obj).parent().next("td").html("<span style='color:red;'>*密码不能为空！</span>");
                }
                else {
                    var pwd1 = $.trim($("#domainPwd1").val());
                    if (checkValue != pwd1) {
                        $(obj).parent().next("td").html("<span style='color:red;'>*确认密码不对</span>");
                    }
                    else {
                        $(obj).parent().next("td").html("<span style='color:red;'></span>");
                    }
                }
                return false;
            }
            break;
        case "email":
            var reg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
            if (!reg.test(checkValue)) {
                $(obj).parent().next("td").html("<span style='color:red;'>*邮箱格式错误！</span>");
                $(obj).focus(); return false;
            }
            else {
                $(obj).parent().next("td").html("");
            }
            break;
        case "province":
            if (checkValue.length == 0) {
                $(obj).parent().next("td").html("<span style='color:red;'>*不能为空</span>");
            }
            else {
                $(obj).parent().next("td").html(" 省/市");
            }
            break;
        case "city":
            if (checkValue.length == 0) {
                $(obj).parent().next("td").html("<span style='color:red;'>*不能为空</span>");
            }
            else {
                $(obj).parent().next("td").html(" 市/区");
            }
            break;
        default:
            if (checkValue.length == 0) {
                $(obj).parent().next("td").html("<span style='color:red;'>*不能为空</span>");
                $(obj).focus(); return false;
            }
            else {
                $(obj).parent().next("td").html("");
            }
            break;
    }
}

function aiming_keyFocus(obj) {
    var checkName = $(obj).attr("name");
    var checkValue = $.trim($(obj).val());
    switch (checkName) {
        case "province":
            $(obj).parent().next("td").html(" 省/市");
            break;
        case "city":
            $(obj).parent().next("td").html(" 市/区");
            break;
    }

}

function aiming_EditDomainDNS() {
    //var local = window.location.href;
    // local = local.replace("http://");
    var url = "?c=module&productid=" + productData[0].pid + "&show=text&todo=aiming_EditDomainDNS";
    url += "&domainName=" + serviceData[0].sconfig.domainName;
    var txtStr = '<div style="height:10px;"></div>';
    txtStr += '<table>';
    txtStr += '<tr style="height:30px;line-height: 30px;">';
    txtStr += '<td style="width:90px;text-align:right;"><b>域 名：</b></td>';
    txtStr += '<td style="text-align:left;">' + serviceData[0].sconfig.domainName + '</td><td style="width:70px;">&nbsp;</td></tr>';
    txtStr += '<tr style="height:30px;line-height: 30px;"><td style="width:90px;text-align:right;">';
    txtStr += '<b>DNS1：</b>';
    txtStr += '</td><td style="text-align:left;">';
    txtStr += '<input id="dns1" name="dns1" onblur="aiming_keyUpCheck(this)" class="text" style="width:150px;margin-top:5px;" />';
    txtStr += '</td><td style="width:70px;">';
    txtStr += '</td></tr>';
    txtStr += '<tr style="height:30px;line-height: 30px;"><td style="width:90px;text-align:right;">';
    txtStr += '<b>DNS2：</b>';
    txtStr += '</td><td style="text-align:left;">';
    txtStr += '<input id="dns2" name="dns2" class="text" style="width:150px;margin-top:5px;" />';
    txtStr += '</td><td style="width:90px;">';
    txtStr += '</td></tr>';
    txtStr += '</table>';
    txtStr += '<div class="loading" style="height:35px;line-height: 35px;text-align:center;padding-top:20px;"></div>';
    $("#suwin").html('<div class="loading" style="height:35px;line-height: 35px;text-align:center;padding-top:20px;"><img src="images/loading.gif" /></div>');
    var dns = '';
    var getInfourl = "?c=module&productid=" + productData[0].pid + "&show=text&todo=aiming_GetBackInfo";
    getInfourl += "&domainName=" + serviceData[0].sconfig.domainName;
    $.get(getInfourl, function (data) {
        if (data.indexOf("320") > -1) {
            var mydata = data.split(',');
            dns1 = mydata[5].split(':')[1];
            dns2 = mydata[6].split(':')[1];
            $("#suwin").html(txtStr);
            $("#dns1").val(dns1);
            $("#dns2").val(dns2);
        }
        else {
            $("#suwin").html(data);
        }
    });
    $("#suwin").dialog({ title: "修改域名【" + serviceData[0].sconfig.domainName + "】的DNS信息", autoOpen: false, resizable: false, width: 400, height: 290, modal: false, buttons: {
        "立即修改": function () {
            if ($.trim($("#dns1").val()) != "") {
                $("#dns1").parent().next("td").html("");
            } else {
                if ($.trim($("#dns1").val()) == "") {
                    $("#dns1").parent().next("td").html("<b style='color:red;'> *DNS1不能为空！</b>");
                } else {
                }
                $("#dns1").focus();
                return false;
            }
            //            if ($.trim($("#dns2").val()) != "") {
            //                $("#dns2").parent().next("td").html("");
            //            } else {
            //                if ($.trim($("#dns2").val()) == "") {
            //                    $("#dns2").parent().next("td").html("<b style='color:red;'> *不能为空！</b>");
            //                } else {
            //                }
            //                return false;
            //            }
            url += "&dns1=" + $.trim($("#dns1").val()) + "&dns2=" + $.trim($("#dns2").val());
            $("#suwin .loading").html("<img style='' src='images/loading.gif' /><br/>修改中...");
            $.get(url, function (data) {
                if (data.indexOf("600") > -1) {
                    $("#suwin").dialog("close");
                    $("#suwin").dialog({ title: "修改域名【" + serviceData[0].sconfig.domainName + "】的DNS信息", autoOpen: false, resizable: false, width: 400, height: 280, modal: false, buttons: { "关  闭": function () { $(this).dialog("close"); } } }).dialog("open");
                    $("#suwin").html("<div style='height:140px;line-height: 140px;text-align:center;width:330px;color:green;'>恭喜，DNS信息修改成功！</p>");
                    setTimeout(function () { $("#suwin").dialog("close"); }, 3000);
                } else {
                    $("#suwin .loading").html("");
                    $("#suwin").html("<div style='height:140px;line-height: 140px;text-align:center;width:330px;color:red;'>" + data.substr(3) + "</p>");
                }
            });

        }, "取 消": function () {
            $(this).dialog("close");
        }
    }
    }).dialog("open");
}

function aiming_ViewTransferDomain() {
    var url = "?c=module&productid=" + productData[0].pid + "&show=text&todo=aiming_TransferStatus";
    url += "&domainName=" + serviceData[0].sconfig.domainName;
    var txtStr = '<div style="height:30px;"></div>';
    txtStr += '<table>';
    txtStr += '<tr style="height:30px;line-height: 30px;">';
    txtStr += '<td style="width:120px;text-align:right;"><b>服务ID：</b></td>';
    txtStr += '<td style="text-align:left;">D' + serviceData[0].sid + '</td></tr>';
    txtStr += '<tr style="height:30px;line-height: 30px;"><td style="width:120px;text-align:right;">';
    txtStr += '<b>转入域名：</b>';
    txtStr += '</td><td style="text-align:left;">';
    txtStr += serviceData[0].sconfig.domainName;
    txtStr += '</td></tr>';
    txtStr += '</table>';
    txtStr += '<div class="loading" style="height:35px;line-height: 35px;text-align:center;padding-top:20px;"></div>';
    $("#suwin").html(txtStr);
    $("#suwin").dialog({ title: "查询服务[#D" + serviceData[0].sid + "]域名转入状态", autoOpen: false, resizable: false, width: 380, height: 280, modal: false, buttons: {
        "立即查看": function () {
            $("#suwin .loading").html("<img style='' src='images/loading.gif' /><br/>查询中...");
            $.get(url, function (data) {
                if (data.indexOf("1000") > -1) {
                    $("#suwin").html("<div style='height:140px;line-height: 140px;text-align:center;width:330px;color:green;'>恭喜，你的域名已经转入成功！</p>");
                } else {
                    $("#suwin .loading").html("");
                    if (data.indexOf("1003") > -1) {
                        $("#suwin").html("<div style='height:140px;line-height: 140px;text-align:center;width:330px;color:green;'>您好，你的域名正在转入中,请稍后！</p>");
                    } else {
                        $("#suwin").html("<div style='height:140px;line-height: 140px;text-align:center;width:330px;color:red;'>抱歉，你的转入出现错误：" + data.substr(4) + "</p>");
                    }
                }
            });

        }, "取 消": function () {
            $(this).dialog("close");
        }
    }
    }).dialog("open");

}
function aiming_getBackPwd() {
    var txtStr = '<div style="height:5px;"></div>';
    txtStr += '<table id="tbsendcode">';
    txtStr += '<tr style="height:30px;line-height: 30px;"><td style="width:100px;text-align:right;">';
    txtStr += '<b>域 名：</b>';
    txtStr += '</td><td style="text-align:left;">';
    txtStr += serviceData[0].sconfig.domainName;
    txtStr += '</td></tr>';
    var height = 190, width = 300;
    if (userData[0].isAdmin != "True" && (emailchk_AiMing != "0" || smschk_AiMing != "0")) {
        height = 280, width = 420;
        txtStr += '<tr style="height:30px;line-height: 30px;"><td style="width:100px;text-align:right;">';
        txtStr += '<b>发送验证码：</b>';
        txtStr += '</td><td style="text-align:left;">';
        if (emailchk_AiMing != "0") {
            txtStr += '<input type="button" class="submit" value="发到邮箱" id="mailBtn" onclick="sendCodeToEmail(3)" /> &nbsp;&nbsp;';
        }
        if (smschk_AiMing != "0") {
            txtStr += '<input type="button" class="submit" value="发到手机" id="phoneBtn" onclick="sendCodeToPhone(3)" />';
        }
        txtStr += '</td></tr>';
        txtStr += '<tr style="height:30px;line-height: 30px;"><td style="width:100px;text-align:right;">';
        txtStr += '<b><input type="hidden" id="codeFlag" value="-1">输入验证码：</b>';
        txtStr += '</td><td style="text-align:left;">';
        txtStr += '<input name="vcode" id="vcode" class="text" style="width:110px;margin-top:3px;" />';
        txtStr += '</td></tr>';

        $("#tbsendcode").css("paddingLeft", "40px");
    }
    txtStr += '</table>';
    txtStr += '<div class="loading" style="text-align:center;padding-top:2px;"></div>';
    $("#suwin").html(txtStr);

    $("#suwin").dialog({ title: "获取域名【" + serviceData[0].sconfig.domainName + "】的密码", autoOpen: false, resizable: false, width: width, height: height, modal: true, buttons: {
        "立即获取": function () {
            processing("正在获取中...");
            if (userData[0].isAdmin != "True" && (emailchk_AiMing != "0" || smschk_AiMing != "0") && $.trim($("#vcode").val()) == "") {
                showResults('验证码不能为空！', 3000, "close");
                return false;
            }
            var url = "?c=module&serviceid=" + serviceData[0].sid + "&show=text&todo=aiming_GetBackPwd&vcode=" + $("#vcode").val();
            $.get(url, function (data) {
                var vArr = data.split('|');
                if (vArr[0] == "0") {
                    $("#processing").dialog("close");
                    var txtStr = '<p style="padding-left:70px;padding-top:20px;"><b>域 名：</b>' + serviceData[0].sconfig.domainName + '</p><p style="padding-left:70px;"><b>密 码：</b>' + vArr[1] + '</p>';

                    txtStr += "<form action=\"http://www.everdns.com/index.aspx\" target=\"_blank\" method=\"POST\" name=\"form1\" id=\"form1\">";
                    txtStr += "<input type=\"hidden\" name=\"__VIEWSTATE\" id=\"__VIEWSTATE\" value=\"" + vArr[2] + "\" />";
                    txtStr += "<input type=\"hidden\" name=\"__EVENTVALIDATION\" id=\"__EVENTVALIDATION\" value=\"" + vArr[3] + "\" />";
                    txtStr += "<input type=hidden name=referer value=\"/\" />";
                    txtStr += "<input type=\"hidden\" value=\"" + serviceData[0].sconfig.domainName + "\" name=\"txtdomain\" id=\"txtdomain\">";
                    txtStr += "<input type=\"hidden\" value=\"" + vArr[1] + "\" name='txtpassword' id='txtpassword'>";
                    txtStr += "<p style=\"padding-left:70px;padding-top:10px;\">马上：<input type=\"submit\" value=\"登录域名自助管理\" name=\"btn_login\" class=\"submit\" style=\"cursor:pointer;\"></p>";
                    txtStr += "</form>";
                    $("#suwin").html(txtStr);
                    $("#suwin").dialog({ title: "操作提示", autoOpen: false, resizable: false, width: 350, height: 250, modal: true, buttons: { "关 闭": function () { $(this).dialog("close"); } } }).dialog("open");
                } else {
                    showResults(vArr[1], 3000, "close");
                }
            });

        }, "取 消": function () {
            $(this).dialog("close");
        }
    }
    }).dialog("open");
}

function aiming_getBackInfo() {
    var local = window.location.href;
    local = local.replace("http://");
    var url = "?c=module&productid=" + productData[0].pid + "&show=text&todo=aiming_GetBackInfo";
    url += "&domainName=" + serviceData[0].sconfig.domainName;
    var txtStr = '<div style="height:30px;"></div>';
    txtStr += '<table>';
    txtStr += '<tr style="height:30px;line-height: 30px;"><td style="width:120px;text-align:right;">';
    txtStr += '域 名：';
    txtStr += '</td><td style="text-align:left;">';
    txtStr += serviceData[0].sconfig.domainName;
    txtStr += '</td></tr>';
    txtStr += '</table>';
    txtStr += '<div class="loading" style="height:35px;line-height: 35px;text-align:center;padding-top:20px;"></div>';
    $("#suwin").html(txtStr);
    $("#suwin").dialog({ title: "获取域名【" + serviceData[0].sconfig.domainName + "]的信息", autoOpen: false, resizable: false, width: 380, height: 268, modal: false, buttons: {
        "立即获取": function () {
            $("#suwin .loading").html("<img style='' src='images/loading.gif' /><br/>查询中...");
            $.get(url, function (data) {
                if (data.indexOf("320") > -1) {
                    var mydata = data.split(',');
                    var str = '<table>';
                    str += '<tr style="height:26px;line-height: 26px;"><td style="text-align:right;width:130px;"><b>域名：</b>';
                    str += '</td>';
                    str += '<td style="text-align:left;width:130px;">' + serviceData[0].sconfig.domainName;
                    str += '</td></tr>';
                    for (var i = 1; i < 6; i++) {
                        str += '<tr style="height:26px;line-height: 26px;"><td style="text-align:right;width:130px;"><b>' + mydata[i].split(':')[0] + '：</b>';
                        str += '</td>';
                        str += '<td style="text-align:left;width:130px;">' + mydata[i].split(':')[1];
                        str += '</td></tr>';
                    }
                    str += '</table>';
                    $("#suwin").html("<div style='height:140px;line-height: 140px;text-align:center;width:330px;'>" + str + "</p>");
                } else {
                    $("#suwin .loading").html("");
                    $("#suwin").html("<div style='height:140px;line-height: 140px;text-align:center;width:330px;color:red;'>" + data.substr(0) + "</p>");
                }
            });

        }, "取 消": function () {
            $(this).dialog("close");
        }
    }
    }).dialog("open");


}

function aiming_editPwd() {
    var txtStr = '<div style="height:0px;"></div>';
    txtStr += '<table>';
    txtStr += '<tr style="height:30px;line-height: 30px;"><td style="width:100px;text-align:right;">';
    txtStr += '<b>域 名：</b>';
    txtStr += '</td><td style="text-align:left;">';
    txtStr += serviceData[0].sconfig.domainName;
    txtStr += '</td><td style="text-align:left;width:100px;"></td></tr>';
    var height = 280, width = 380;
    if (userData[0].isAdmin != "True" && (emailchk_AiMing != "0" || smschk_AiMing != "0")) {
        height = 330, width = 380;
        txtStr += '<tr style="height:30px;line-height: 30px;"><td style="width:100px;text-align:right;">';
        txtStr += '<b>发送验证码：</b>';
        txtStr += '</td><td style="text-align:left;" colspan="2">';

        if (emailchk_AiMing != "0") {
            txtStr += '<input type="button" class="submit" value="发到邮箱" id="mailBtn" onclick="sendCodeToEmail(3)" /> &nbsp;';
        }
        if (smschk_AiMing != "0") {
            txtStr += '<input type="button" class="submit" value="发到手机" id="phoneBtn" onclick="sendCodeToPhone(3)" />';
        }
        txtStr += '</td></tr>';
        txtStr += '<tr style="height:30px;line-height: 30px;"><td style="width:100px;text-align:right;">';
        txtStr += '<input type="hidden" id="codeFlag" value="-1"><b>输入验证码：</b>';
        txtStr += '</td><td style="text-align:left;">';
        txtStr += '<input name="vcode" id="vcode" class="text" onblur="aiming_keyUpCheck(this)" style="width:120px;margin-top:3px;" />';
        txtStr += '</td><td></td></tr>';
    }
    txtStr += '<tr style="height:30px;line-height: 30px;"><td style="width:100px;text-align:right;">';
    txtStr += '<b>新密码：</b>';
    txtStr += '</td><td style="text-align:left;">';
    txtStr += '<input type="password" id="domainPwd1" name="domainPwd1" onblur="aiming_keyUpCheck(this)" class="text" style="width:120px;margin-top:5px;" />';
    txtStr += '</td><td style="text-align:left;width:120px;"></td></tr>';
    txtStr += '<tr style="height:30px;line-height: 30px;"><td style="width:100px;text-align:right;">';
    txtStr += '<b>确认密码：</b>';
    txtStr += '</td><td style="text-align:left;">';
    txtStr += '<input type="password" id="domainPwd2" name="domainPwd2" onblur="aiming_keyUpCheck(this)" class="text" style="width:120px;margin-top:5px;" />';
    txtStr += '</td><td style="text-align:left;width:120px;"></td></tr>';

    txtStr += '</table>';
    txtStr += '<div class="loading" style="height:30px;line-height: 30px;text-align:center;padding-top:2px;"></div>';
    $("#suwin").html(txtStr);
    $("#suwin").dialog({ title: "修改域名【" + serviceData[0].sconfig.domainName + "]的密码", autoOpen: false, resizable: false, width: width, height: height, modal: false, buttons: {
        "立即修改": function () {
            processing("正在处理，请稍等...");
            if (userData[0].isAdmin != "True" && (emailchk_AiMing != "0" || smschk_AiMing != "0") && $.trim($("#vcode").val()) == "") {
                showResults("请填写刚刚收到的验证码", 3000, "close");
                $("#vcode").focus();
                return false;
            }
            var pwd = $("#domainPwd1"), pwd2 = $("#domainPwd2");
            if ($.trim(pwd.val()).length < 6 || $.trim(pwd.val()).lenght > 16) {
                $("#processing").dialog("close");
                if ($.trim(pwd.val()) == "") {
                    pwd.parent().next("td").html("<b style='color:red;'>*不能为空！</b>");
                }
                else {
                    pwd.parent().next("td").html("<b style='color:red;'>*6到16位！</b>");
                }
                return false;
            }
            else {
                pwd.parent().next("td").html("");
            }
            if ($.trim(pwd.val()) != $.trim(pwd2.val())) {
                $("#processing").dialog("close");
                if ($.trim(pwd2.val()) == "") {
                    pwd2.parent().next("td").html("<b style='color:red;'>*不能为空！</b>");
                }
                else {
                    pwd2.parent().next("td").html("<b style='color:red;'>*确认密码有误</b>");
                }
                return false;
            }
            var url = "?c=module&serviceid=" + serviceData[0].sid + "&show=text&todo=aiming_EditPwd&domainPwd=" + $.trim(pwd.val()) + "&vcode=" + $.trim($("#vcode").val());

            $.get(url, function (data) {

                var vArr = data.split('|');
                if (vArr[0] == "0") {
                    $("#suwin").dialog("close");
                    showResults("恭喜，密码修改成功！", 3000, "close");
                } else {
                    showResults(vArr[1], 3000, "close");
                }

                //                if (data.indexOf("328") > -1) {
                //                    // $("#suwin").html("<div style='height:140px;line-height: 140px;text-align:center;width:330px;color:green;'>恭喜，密码修改成功！</p>");
                //                    // setTimeout(function () { $("#suwin").dialog("close"); }, 5000);
                //                    $("#suwin").dialog("close");
                //                    showResults("恭喜，密码修改成功！", 3000, "close");
                //                } else {
                //                    //$("#suwin .loading").html("");
                //                    // $("#suwin .loading").html("<div style='height:30px;line-height: 30px;text-align:center;width:330px;color:red;'>" + data.substr(3) + "</p>");
                //                    showResults(data.substr(3), 3000, "close");
                //                }
            });

        }, "取 消": function () {
            $(this).dialog("close");
        }
    }
    }).dialog("open");
}
