﻿function common_ListDomainContact() {
    processing("正在加载信息，请稍等...");
    var url = "?c=module&productid=" + productData[0].pid + "&show=text&todo=common_listDomainContact&t=" + new Date();
    $.post(url, function (data) {
        $("#processing").dialog("close");
        var jsonArr = $.parseJSON(data);
        var str = '<div id="main-content"><table>' +
                          '<thead><tr><th width="10%">姓名</th><th width="10%">手机</th><th width="10%">email</th><th width="20%">地址</th><th width="20%">&nbsp;</th></tr></thead>';

        for (var i = 0, len = jsonArr.length; i < len; i++) {
            str += '<tr id="tr' + i + '"><td width="10%" align="center">' + jsonArr[i].lname + jsonArr[i].fname + '</td>' +
            '<td width="10%" align="center">' + jsonArr[i].tel + '</td>' +
            '<td width="10%" align="center">' + jsonArr[i].email + '</td>';
            str += '<td width="20%" align="center">' + jsonArr[i].street + '</td>';
            str += '<td><input type="button" name="del' + i + '" class="button" value="删除" onclick="common_DelDomainContact(' + jsonArr[i].id + ')"/>&nbsp;&nbsp;<input type="button" name="edit' + i + '" class="button" value="修改" onclick="common_AddEditDomainContact(' + jsonArr[i].id + ')"/></td></tr>';
        }

        str += '</table>';
        $("#suwin").html(str);

        $("#suwin").dialog({ title: "注册联系人模板信息管理", autoOpen: false, resizable: false, width: 600, height: 400, modal: true, buttons: { "添加联系人模板信息": function () { common_AddEditDomainContact(0); }, "关 闭": function () { $(this).dialog("close"); } } }).dialog("open");
        

    });
}

function common_AddEditDomainContact(id) {
    suwin.html(ajaxLoading("正在加载信息，请稍候..."));

    var str = '<div style="padding-left:100px;"><form action="?c=module&productid=' + productData[0].pid + '&show=text&todo=common_saveDomainContact" onsubmit="return false;"><input type="hidden" name="hidid" id="hidid" value="' + id + '"/>';
    str += '<table style="width:580px;">';
    str += getFormContent();
    str += '</table></form>';
    str += '</div>';

    if (id != 0) {
        var url = "?c=module&productid=" + productData[0].pid + "&show=text&todo=common_getDomainContact&id=" + id + "&t=" + new Date();
        $.post(url, function (rdata) {

            suwin.html(str);
            var jsonArr = $.parseJSON(rdata);
            suwin.find("#lname").val(jsonArr[0].lname);
            suwin.find("#fname").val(jsonArr[0].fname);
            suwin.find("#lnameE").val(jsonArr[0].lnameE);
            suwin.find("#fnameE").val(jsonArr[0].fnameE);
            suwin.find("#tel").val(jsonArr[0].tel);
            suwin.find("#phone").val(jsonArr[0].phonecode + '-' + jsonArr[0].phone);
            suwin.find("#fax").val(jsonArr[0].faxcode + '-' + jsonArr[0].fax);
            suwin.find("#email").val(jsonArr[0].email);
            suwin.find("#zipcode").val(jsonArr[0].zipcode);
            suwin.find("#Country").val(jsonArr[0].countrycode);
            suwin.find("#province").val(jsonArr[0].province);
            suwin.find("#city").val(jsonArr[0].city);
            suwin.find("#street").val(jsonArr[0].street);
            suwin.find("#streetE").val(jsonArr[0].streetE);
            suwin.find("#company").val(jsonArr[0].company);
            suwin.find("#companyE").val(jsonArr[0].companyE);
            suwin.find("#companylocation").val(jsonArr[0].companylocation);
        });
    } else {
        suwin.html(str);
    }

    suwin.dialog({ title: "添加/修改联系人模板信息", autoOpen: false, resizable: false, width: 860, height: 600, modal: true, buttons: { "保存联系人模板信息": function () {

        if (!common_checkDomainContactInfo()) return false;
        processing("正在处理，请稍等...");
        var cform = suwin.find("form:first");
        $.post(cform.attr("action"), cform.serialize(), function (rdata) {
            if (rdata == "1") {
                showResults("操作成功", 3000, "close");
                setTimeout(function () {
                    common_ListDomainContact();

                }, 3000);
            } else {
                showResults(rdata, 5000, "close");
            }
        });


    }, "返回联系人模板管理界面": function () { common_ListDomainContact() }
    }
    }).dialog("open");
}
function common_DelDomainContact(id) {
    var str = '<form><div style="font-weight:bold;padding-top:10px;line-height:30px;">';
    str += '<p style="font-weight:bold;padding-top:20px;text-align:center;"><input type="checkbox" id="confirm_box" value="1"/><label for="confirm_box" style="cursor:pointer;display:inline;">您确定要删除该联系人模板信息吗？</label></p>';
    swin.html(str);
    swin.dialog({ title: '操作提示', autoOpen: false, resizable: false, width: 400, height: 220, modal: true, buttons: { '确定': function () {

        var confirm_box = $("#confirm_box").prop("checked");
        if (!confirm_box) {
            alert('请勾选复选框以确认操作！');
            return false;
        }
        swin.dialog('close');
        processing("正在处理，请稍等...");

        var url = '?c=module&productid=' + productData[0].pid + '&show=text&todo=common_delDomainContact&id=' + id + '&t=' + new Date();
        $.post(url, function (rdata) {
            if (rdata == "1") {
                showResults("操作成功", 2000, "close");
                setTimeout(function () {
                    common_ListDomainContact();

                }, 1000);
            } else {
                showResults(rdata, 3000, "close");
            }
        });

    }, '取消': function () { $(this).dialog("close"); }
    }
    }).dialog("open");
}
function common_checkDomainContactInfo() {
    var fname = suwin.find("#fname"), lname = suwin.find("#lname"), fnameE = suwin.find("#fnameE"), lnameE = suwin.find("#lnameE"), tel = suwin.find("#tel"), phone = suwin.find("#phone"), fax = suwin.find("#fax"), email = suwin.find("#email");
    var province = suwin.find("#province"), city = suwin.find("#city"), street = suwin.find("#street"), streetE = suwin.find("#streetE"), zipcode = suwin.find("#zipcode"), org = suwin.find("#company"), orgE = suwin.find("#companyE"), companylocation = suwin.find("#companylocation");
    if ($.trim(lname.val()) == "") { lname.parent().next("td").html("<b style='color:red;'>*姓氏不能为空！</span>"); lname.focus(); return false; }
    if ($.trim(fname.val()) == "") { fname.parent().next("td").html("<b style='color:red;'>*名字不能为空！</span>"); fname.focus(); return false; }
    if ($.trim(lnameE.val()) == "") { lnameE.parent().next("td").html("<b style='color:red;'>*英文姓氏不能为空！</span>"); lnameE.focus(); return false; }
    if ($.trim(fnameE.val()) == "") { fnameE.parent().next("td").html("<b style='color:red;'>*英文名字不能为空！</span>"); fnameE.focus(); return false; }

    var reg = /^\d{11}$/g;
    if (!reg.test($.trim(tel.val()))) {
        tel.parent().next("td").html("<b style='color:red;'>*手机格式不正确！</span>");
        tel.focus();
        return false;
    }
    else {
        tel.parent().next("td").html("<b style='font-size:1px;'>&nbsp;</b>");
    }

    reg = /^([0-9]{6})?$/;
    if (!reg.test($.trim(zipcode.val()))) {
        zipcode.parent().next("td").html("<b style='color:red;'>*邮编格式不正确！</span>");
        zipcode.focus();
        return false;
    }
    else {
        zipcode.parent().next("td").html("<b style='font-size:1px;'>&nbsp;</b>");
    }

    if ($.trim(phone.val()) == "") {
        phone.parent().next("td").html("<b style='color:red;'>*联系电话不能为空！</span>");
        phone.focus();
        return false;
    }
    else {
        var ik = $.trim(phone.val()).indexOf("-");
        if (ik == 3 || ik == 4) {
            var phonelen = phone.val().split('-')[1].length;
            if (phonelen < 7 || phonelen > 8) {
                phone.parent().next("td").html("<span style='color:red;'>*格式错误！</span>");
                return false;
            } else {
                phone.parent().next("td").html(" 如：020-12345678");
            }
        } else {
            phone.parent().next("td").html("<span style='color:red;'>*格式错误！</span>");
            return false;
        }
    }
    if ($.trim(fax.val()) == "") {
        fax.parent().next("td").html("<b style='color:red;'>*传真不能为空！</span>");
        fax.focus();
        return false;
    }
    else {
        var ik = $.trim(fax.val()).indexOf("-");
        if (ik == 3 || ik == 4) {
            var faxlen = fax.val().split('-')[1].length;
            if (faxlen < 7 || faxlen > 8) {
                fax.parent().next("td").html("<span style='color:red;'>*格式错误！</span>");
                return false;
            } else {
                fax.parent().next("td").html(" 如：020-12345678");
            }
        } else {
            fax.parent().next("td").html("<span style='color:red;'>*格式错误！</span>");
            return false;
        }
    }
    if ($.trim(email.val()) == "") {
        email.parent().next("td").html("<b style='color:red;'>*邮箱不能为空！</span>");
        email.focus();
        return false;
    }
    else {
        reg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
        if (!reg.test($.trim(email.val()))) {
            email.parent().next("td").html("<b style='color:red;'>*邮箱格式不正确！</span>");
            email.focus();
            return false;
        }
        else {
            email.parent().next("td").html("<b style='font-size:1px;'>&nbsp;</b>");
        }
    }


    if ($.trim(province.val()) == "") { province.parent().next("td").html("<b style='color:red;'>*省份不能为空！</span>"); province.focus(); return false; }
    if ($.trim(city.val()) == "") { city.parent().next("td").html("<b style='color:red;'>*城市不能为空！</span>"); city.focus(); return false; }
    if ($.trim(street.val()) == "") { street.parent().next("td").html("<b style='color:red;'>*街道地址不能为空！</span>"); street.focus(); return false; }
    if ($.trim(streetE.val()) == "") { streetE.parent().next("td").html("<b style='color:red;'>*街道的英文不能为空！</span>"); streetE.focus(); return false; }

    if (streetE.val().indexOf("'") > -1) { streetE.parent().next("td").html("<b style='color:red;'>*街道英文地址不能包含单引号！</span>"); streetE.focus(); return false; }
    if ($.trim(zipcode.val()) == "") { zipcode.parent().next("td").html("<b style='color:red;'>*邮编不能为空！</span>"); zipcode.focus(); return false; }
    if ($.trim(org.val()) == "") { org.parent().next("td").html("<b style='color:red;'>*公司名称不能为空！</span>"); org.focus(); return false; }
    if ($.trim(orgE.val()) == "") { orgE.parent().next("td").html("<b style='color:red;'>*公司的英文不能为空！</span>"); orgE.focus(); return false; }
    if ($.trim(companylocation.val()) == "") { companylocation.parent().next("td").html("<b style='color:red;'>*公司所在地不能为空！</span>"); companylocation.focus(); return false; }
    return true;
}
function getFormContent() {
    var tr_td_SS = '<tr style="height:29px;line-height:29px;border-bottom:1px dashed #ddd;"><td style="width:150px;text-align:right;">';
    var inputSS = 'class="text" style="margin-top:4px;"';
    var str = '<tr style="height:29px;line-height:29px;border-bottom:1px dashed #ddd;"><td style="width:120px;text-align:right;"><b>姓：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="lname" id="lname" onblur="aiMing_keyUpCheck(this)" class="text" style="margin-top:4px;width:45px" >';
    str += '&nbsp;&nbsp;&nbsp;<b>名：</b>';
    str += '<input name="fname" id="fname" onblur="aiMing_keyUpCheck(this)" class="text" style="margin-top:4px;width:60px" >';
    str += '</td>';
    str += '<td style="text-align:left;width:150px;">';
    str += ' <span style="color:green;"></span>';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>英文姓：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="lnameE" id="lnameE" onblur="aiMing_keyUpCheck(this)" ' + inputSS + '>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>英文名：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="fnameE" id="fnameE" onblur="aiMing_keyUpCheck(this)" ' + inputSS + '>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>手机：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="tel" id="tel" value="' + (userData[0].tel == "0" ? "" : userData[0].tel) + '" onfocus="aiMing_keyFocus(this)" onblur="aiMing_keyUpCheck(this)" ' + inputSS + '>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 如：13916245610</td>';
    str += '</tr>';

    str += tr_td_SS + '<b>联系电话：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="phone" id="phone" onfocus="aiMing_keyFocus(this)" onblur="aiMing_keyUpCheck(this)" ' + inputSS + '>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 如：020-12345678</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>传真：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="fax" id="fax" onfocus="aiMing_keyFocus(this)" onblur="aiMing_keyUpCheck(this)" ' + inputSS + '>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 如：020-12345678</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>电子邮箱：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="email" id="email" onblur="aiMing_keyUpCheck(this)" value=' + userData[0].umail + ' ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>邮编：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="zipcode" id="zipcode" onblur="aiMing_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>国家：</b>';
    str += '</td>';
    str += '<td style="text-align:left;">' + xinnet_getCountryList() + '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>省份：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="province" id="province" onfocus="aiMing_keyFocus(this)" onblur="aiMing_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 省/市，如：广东</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>城市：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="city" id="city" onfocus="aiMing_keyFocus(this)" onblur="aiMing_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 市/区，如：广州</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>街道地址：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="street" id="street" onblur="aiMing_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>街道地址英文：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="streetE" id="streetE" onblur="aiMing_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>公司名称：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="company" id="company" onblur="aiMing_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>公司名称英文：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="companyE" id="companyE" onblur="aiMing_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;width:150px;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>公司所在地：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="companylocation" id="companylocation" onblur="aiMing_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;width:150px;">如：广东广州';
    str += '</td>';
    str += '</tr>';
    return str;
}
function aiMing_keyUpCheck(obj) {
    var checkName = $(obj).attr("name");
    var checkValue = $.trim($(obj).val());
    switch (checkName) {
        case "TransferDomainName":
            if (checkValue.length <= 0) {
                $(obj).parent().next("td").html("<span style='color:red;'>*请填写域名名称！</span>");
            } else if (checkValue.indexOf(".") > -1) {
                $(obj).parent().next("td").html("<span style='color:red;'>*域名名称不能包含域名后缀！</span>");
            } else {
                $(obj).parent().next("td").html("");
            }
            break;
        case "DomainPwd":
            if (checkValue.length > 4) {
                $(obj).parent().next("td").html("");
            }
            else {
                if (checkValue.length == 0) {
                    $(obj).parent().next("td").html("<span style='color:red;'>*密码不能为空！</span>");
                }
                else { $(obj).parent().next("td").html("<span style='color:red;'>*密码长度不符合要求!</span>"); }
            }
            break;
        case "email":
            var reg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
            if (!reg.test(checkValue)) {
                $(obj).parent().next("td").html("<span style='color:red;'>*邮箱格式错误！</span>");
            }
            else {
                $(obj).parent().next("td").html("");
            }
            break;
        case "phone":
            if (checkValue.length == 0) {
                $(obj).parent().next("td").html("<span style='color:red;'>*不能为空</span>");
            }
            else {
                var ik = checkValue.indexOf("-");
                if (ik == 3 || ik == 4) {
                    //$(obj).parent().next("td").html(" 如：020-12345678");
                    var phonelen = checkValue.split('-')[1].length;
                    if (phonelen < 7 || phonelen > 8) {
                        $(obj).parent().next("td").html("<span style='color:red;'>*格式错误！</span>");
                    } else {
                        $(obj).parent().next("td").html(" 如：020-12345678");
                    }

                } else {
                    $(obj).parent().next("td").html("<span style='color:red;'>*格式错误！</span>");
                }
            }
            break;
        case "fax":
            if (checkValue.length == 0) {
                $(obj).parent().next("td").html("<span style='color:red;'>*不能为空</span>");
            }
            else {
                var ik = checkValue.indexOf("-");
                if (ik == 3 || ik == 4) {
                    // $(obj).parent().next("td").html(" 如：020-12345678")
                    var faxlen = checkValue.split('-')[1].length;
                    if (faxlen < 7 || faxlen > 8) {
                        $(obj).parent().next("td").html("<span style='color:red;'>*格式错误！</span>");
                    } else {
                        $(obj).parent().next("td").html(" 如：020-12345678");
                    }
                } else {
                    $(obj).parent().next("td").html("<span style='color:red;'>*格式错误！</span>");
                }
            }
            break;
        case "province":
            if (checkValue.length == 0) {
                $(obj).parent().next("td").html("<span style='color:red;'>*不能为空</span>");
            }
            else {
                $(obj).parent().next("td").html(" 省/市，如：广东");
            }
            break;
        case "city":
            if (checkValue.length == 0) {
                $(obj).parent().next("td").html("<span style='color:red;'>*不能为空</span>");
            }
            else {
                $(obj).parent().next("td").html(" 市/区，如：广州");
            }
            break;
        default:
            if (checkValue.length == 0) {
                $(obj).parent().next("td").html("<span style='color:red;'>*不能为空</span>");
            }
            else {
                $(obj).parent().next("td").html("");
            }
            break;
    }
}
function aiMing_keyFocus(obj) {
    var checkName = $(obj).attr("name");
    var checkValue = $.trim($(obj).val());
    switch (checkName) {
        case "phone":
            $(obj).parent().next("td").html(" 如：020-12345678");
            break;
        case "fax":
            $(obj).parent().next("td").html(" 如：020-12345678");
            break;
        case "province":
            $(obj).parent().next("td").html(" 省/市，如：广东");
            break;
        case "city":
            $(obj).parent().next("td").html(" 市/区，如：广州");
            break;
    }
}