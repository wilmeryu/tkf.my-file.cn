﻿/// <reference path="/modules/js/jquery-vsdoc.js" />
/// <reference path="/modules/js/jquery-ui.min.js" />
function _pm_init() {
    var swin = $("#swin");
    swin.find("#moduleDescription").html('&nbsp;');
     swin.find("#btn_add").remove();
     swin.find("#moduleDescription").next().append('<input id="btnCheckTemplate" type="button" class="button" value="检测域名联系人模板表信息"/>');
    var AiMingUserID = moduleData[0].cconfig.AiMingUserID == undefined ? '' : moduleData[0].cconfig.AiMingUserID;
    var AiMingPwd = moduleData[0].cconfig.AiMingPwd == undefined ? '' : moduleData[0].cconfig.AiMingPwd;
    var AiMingEnable = moduleData[0].cconfig.AiMingEnable == undefined ? '0' : moduleData[0].cconfig.AiMingEnable;
    var enUserid_AiMing = moduleData[0].cconfig.enUserid_AiMing == undefined ? '0' : moduleData[0].cconfig.enUserid_AiMing;
    var enPwd_AiMing = moduleData[0].cconfig.enPwd_AiMing == undefined ? '0' : moduleData[0].cconfig.enPwd_AiMing;

    var emailchk_AiMing = moduleData[0].cconfig.emailchk_AiMing == undefined ? '1' : moduleData[0].cconfig.emailchk_AiMing;
    var smschk_AiMing = moduleData[0].cconfig.smschk_AiMing == undefined ? '1' : moduleData[0].cconfig.smschk_AiMing;




    var ResellerClubEnable = moduleData[0].cconfig.ResellerClubEnable == undefined ? '0' : moduleData[0].cconfig.ResellerClubEnable;
    var ResellerClubUserID = moduleData[0].cconfig.ResellerClubUserID == undefined ? '' : moduleData[0].cconfig.ResellerClubUserID;
    var ResellerClubPwd = moduleData[0].cconfig.ResellerClubPwd == undefined ? '' : moduleData[0].cconfig.ResellerClubPwd;
    var ResellerClubDns1 = moduleData[0].cconfig.ResellerClubDns1 == undefined ? 'ns1.domain.com' : moduleData[0].cconfig.ResellerClubDns1;
    var ResellerClubDns2 = moduleData[0].cconfig.ResellerClubDns2 == undefined ? 'ns2.domain.com' : moduleData[0].cconfig.ResellerClubDns2;
    var ResellerClubUserLoginPath = moduleData[0].cconfig.ResellerClubUserLoginPath == undefined ? '' : moduleData[0].cconfig.ResellerClubUserLoginPath;
    var enUserid_ResellerClub = moduleData[0].cconfig.enUserid_ResellerClub == undefined ? '0' : moduleData[0].cconfig.enUserid_ResellerClub;
    var enPwd_ResellerClub = moduleData[0].cconfig.enPwd_ResellerClub == undefined ? '0' : moduleData[0].cconfig.enPwd_ResellerClub;

    var emailchk_ResellerClub = moduleData[0].cconfig.emailchk_ResellerClub == undefined ? '1' : moduleData[0].cconfig.emailchk_ResellerClub;
    var smschk_ResellerClub = moduleData[0].cconfig.smschk_ResellerClub == undefined ? '1' : moduleData[0].cconfig.smschk_ResellerClub;



    var XinnetUserName = moduleData[0].cconfig.XinnetUserName == undefined ? '' : moduleData[0].cconfig.XinnetUserName;
    var XinnetPwd = moduleData[0].cconfig.XinnetPwd == undefined ? '' : moduleData[0].cconfig.XinnetPwd;
    var XinnetEnable = moduleData[0].cconfig.XinnetEnable == undefined ? '0' : moduleData[0].cconfig.XinnetEnable;
    var XinnetDns1 = moduleData[0].cconfig.XinnetDns1 == undefined ? 'ns1.dns.com.cn' : moduleData[0].cconfig.XinnetDns1;
    var XinnetDns2 = moduleData[0].cconfig.XinnetDns2 == undefined ? 'ns2.dns.com.cn' : moduleData[0].cconfig.XinnetDns2;

    var enUname_Xinnet = moduleData[0].cconfig.enUname_Xinnet == undefined ? '0' : moduleData[0].cconfig.enUname_Xinnet;
    var enPwd_Xinnet = moduleData[0].cconfig.enPwd_Xinnet == undefined ? '0' : moduleData[0].cconfig.enPwd_Xinnet;

    var emailchk_Xinnet = moduleData[0].cconfig.emailchk_Xinnet == undefined ? '1' : moduleData[0].cconfig.emailchk_Xinnet;
    var smschk_Xinnet = moduleData[0].cconfig.smschk_Xinnet == undefined ? '1' : moduleData[0].cconfig.smschk_Xinnet;


    var XinwangUserName = moduleData[0].cconfig.XinwangUserName == undefined ? '' : moduleData[0].cconfig.XinwangUserName;
   // var XinwangPwd = moduleData[0].cconfig.XinwangPwd == undefined ? '' : moduleData[0].cconfig.XinwangPwd;
    var XinwangAPIPwd = moduleData[0].cconfig.XinwangAPIPwd == undefined ? '' : moduleData[0].cconfig.XinwangAPIPwd;
    var XinwangEnable = moduleData[0].cconfig.XinwangEnable == undefined ? '0' : moduleData[0].cconfig.XinwangEnable;
    var XinwangDns1 = moduleData[0].cconfig.XinwangDns1 == undefined ? 'ns.xinnetdns.com' : moduleData[0].cconfig.XinwangDns1;
    var XinwangDns2 = moduleData[0].cconfig.XinwangDns2 == undefined ? 'ns.xinnet.cn' : moduleData[0].cconfig.XinwangDns2;
    var enUname_Xinwang = moduleData[0].cconfig.enUname_Xinwang == undefined ? '0' : moduleData[0].cconfig.enUname_Xinwang;
   // var enPwd_Xinwang = moduleData[0].cconfig.enPwd_Xinwang == undefined ? '0' : moduleData[0].cconfig.enPwd_Xinwang;
    var enAPIPwd_Xinwang = moduleData[0].cconfig.enAPIPwd_Xinwang == undefined ? '0' : moduleData[0].cconfig.enAPIPwd_Xinwang;

    var emailchk_Xinwang = moduleData[0].cconfig.emailchk_Xinwang == undefined ? '1' : moduleData[0].cconfig.emailchk_Xinwang;
    var smschk_Xinwang = moduleData[0].cconfig.smschk_Xinwang == undefined ? '1' : moduleData[0].cconfig.smschk_Xinwang;


    var str = '<div id="params" class="ui-accordion ui-widget ui-helper-reset ui-accordion-icons" role="tablist">' +
    '<h3 class="ui-accordion-header ui-helper-reset ui-state-default ui-state-active ui-corner-top" role="tab" aria-expanded="true" aria-selected="true" tabindex="0"><span></span><a href="#"><strong>爱名网</strong></a></h3>' +
    '<div class="ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom ui-accordion-content-active" role="tabpanel"><li><label class="a">爱名网代理用户ID</label>：<input type="hidden" name="cname_001" value="AiMingUserID"/><input class="text" type="text" name="cvalue_001" value="' + AiMingUserID + '" ' + (enUserid_AiMing == "0" ? "" : "readonly=readonly") + '/>&nbsp;&nbsp;&nbsp;<input class="submit" value="' + (enUserid_AiMing == "0" ? "加密" : "修改") + '" name="btnEncryp" id="btnAiMingName" type="button"/><input type="hidden" name="cname_015" value="enUserid_AiMing"/><input type="hidden" name="cvalue_015" value="' + enUserid_AiMing + '"/>&nbsp;<span class="pptext"></span></li>' +
    '<li><label class="a">代理用户API密码</label>：<input type="hidden" name="cname_002" value="AiMingPwd"/><input class="text" type="text" name="cvalue_002" value="' + AiMingPwd + '" ' + (enPwd_AiMing == "0" ? "" : "readonly=readonly") + '/>&nbsp;&nbsp;&nbsp;<input class="submit" value="' + (enPwd_AiMing == "0" ? "加密" : "修改") + '" name="btnEncryp" id="btnAiMingPwd" type="button"/><input type="hidden" name="cname_016" value="enPwd_AiMing"/><input type="hidden" name="cvalue_016" value="' + enPwd_AiMing + '"/>&nbsp;<span class="pptext"></span></li>' +
    '<li><label class="a">邮件验证</label>：<input type="hidden" name="cname_0024" value="emailchk_AiMing"/>&nbsp<input type="radio" name="cvalue_0024" value="1" id="email_AiMing1"><label for="email_AiMing1">启用</label>&nbsp;&nbsp;&nbsp;<input type="radio" name="cvalue_0024" value="0" id="email_AiMing0"><label for="email_AiMing0">禁用</label>' +
    '<li><label class="a">短信验证</label>：<input type="hidden" name="cname_0025" value="smschk_AiMing"/>&nbsp;<input type="radio" name="cvalue_0025" value="1" id="sms_AiMing1"><label for="sms_AiMing1">启用</label>&nbsp;&nbsp;&nbsp;<input type="radio" name="cvalue_0025" value="0" id="sms_AiMing0"><label for="sms_AiMing0">禁用</label>' +
    '<li><label class="a">模块是否启用</label>：<input type="hidden" name="cname_003" value="AiMingEnable"/>&nbsp<input type="radio" name="cvalue_003" value="1" id="aimingyes"><label for="aimingyes">启用</label>&nbsp;&nbsp;&nbsp;<input type="radio" name="cvalue_003" value="0" checked="checked" id="aimingno"><label for="aimingno">禁用</label></li></div>' +
   
    '<h3 class="ui-accordion-header ui-helper-reset ui-state-default ui-corner-all" role="tab" aria-expanded="false" aria-selected="false" tabindex="-1"><span></span><a href="#"><strong>ResellerClub</strong></a></h3>' +
    '<div style="line-height: 28px; display: none;" class="ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom" role="tabpanel"><li><label class="a">ResellerClub代理用户ID</label>：<input type="hidden" name="cname_004" value="ResellerClubUserID"/><input class="text" type="text" name="cvalue_004" value="' + ResellerClubUserID + '" ' + (enUserid_ResellerClub == "0" ? "" : "readonly=readonly") + '/>&nbsp;&nbsp;&nbsp;<input class="submit" value="' + (enUserid_ResellerClub == "0" ? "加密" : "修改") + '" name="btnEncryp" id="btnResellerClubName" type="button"/><input type="hidden" name="cname_017" value="enUserid_ResellerClub"/><input type="hidden" name="cvalue_017" value="' + enUserid_ResellerClub + '"/>&nbsp;<span class="pptext"></span></li>' +
    '<li><label class="a">ResellerClub代理用户API Key</label>：<input type="hidden" name="cname_005" value="ResellerClubPwd"/><input class="text" type="text" name="cvalue_005" value="' + ResellerClubPwd + '" ' + (enPwd_ResellerClub == "0" ? "" : "readonly=readonly") + '/>&nbsp;&nbsp;&nbsp;<input class="submit" value="' + (enPwd_ResellerClub == "0" ? "加密" : "修改") + '" name="btnEncryp" id="btnResellerClubPwd" type="button"/><input type="hidden" name="cname_018" value="enPwd_ResellerClub"/><input type="hidden" name="cvalue_018" value="' + enPwd_ResellerClub + '"/>&nbsp;<span class="pptext"></span></li>' +
    '<li><label class="a">普通客户登录地址</label>：<input type="hidden" name="cname_006" value="ResellerClubUserLoginPath"/><input class="text path" type="text" name="cvalue_006" value="' + ResellerClubUserLoginPath + '"/></li>' +
     '<li><label class="a">默认DNS1</label>：<input type="hidden" name="cname_0011" value="ResellerClubDns1"/><input class="text path" type="text" name="cvalue_0011" value="' + ResellerClubDns1 + '"/></li>' +
     '<li><label class="a">默认DNS2</label>：<input type="hidden" name="cname_0012" value="ResellerClubDns2"/><input class="text path" type="text" name="cvalue_0012" value="' + ResellerClubDns2+ '"/></li>' +
    '<li><label class="a">邮件验证</label>：<input type="hidden" name="cname_0026" value="emailchk_ResellerClub"/>&nbsp<input type="radio" name="cvalue_0026" value="1" id="email_ResellerClub1"><label for="email_ResellerClub1">启用</label>&nbsp;&nbsp;&nbsp;<input type="radio" name="cvalue_0026" value="0" id="email_ResellerClub0"><label for="email_ResellerClub0">禁用</label>' +
    '<li><label class="a">短信验证</label>：<input type="hidden" name="cname_0027" value="smschk_ResellerClub"/>&nbsp;<input type="radio" name="cvalue_0027" value="1" id="sms_ResellerClub1"><label for="sms_ResellerClub1">启用</label>&nbsp;&nbsp;&nbsp;<input type="radio" name="cvalue_0027" value="0" id="sms_ResellerClub0"><label for="sms_ResellerClub0">禁用</label>' +

    '<li><label class="a">模块是否启用</label>：<input type="hidden" name="cname_007" value="ResellerClubEnable"/>&nbsp<input type="radio" name="cvalue_007" value="1" id="ResellerClubyes"><label for="ResellerClubyes">启用</label>&nbsp;&nbsp;&nbsp;<input type="radio" name="cvalue_007" value="0" checked="checked" id="ResellerClubno"><label for="ResellerClubno">禁用</label></li></div>' +

    '<h3 class="ui-accordion-header ui-helper-reset ui-state-default ui-state-active ui-corner-top" role="tab" aria-expanded="true" aria-selected="true" tabindex="0"><span></span><a href="#"><strong>新网互联</strong></a></h3>' +
    '<div class="ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom ui-accordion-content-active" role="tabpanel"><li><label class="a">新网互联代理用户名</label>：<input type="hidden" name="cname_008" value="XinnetUserName"/><input class="text" type="text" name="cvalue_008" value="' + XinnetUserName + '" ' + (enUname_Xinnet == "0" ? "" : "readonly=readonly") + '/>&nbsp;&nbsp;&nbsp;<input class="submit" value="' + (enUname_Xinnet == "0" ? "加密" : "修改") + '" name="btnEncryp" id="btnXinnetName" type="button"/><input type="hidden" name="cname_019" value="enUname_Xinnet"/><input type="hidden" name="cvalue_019" value="' + enUname_Xinnet + '"/>&nbsp;<span class="pptext"></span></li>' +
    '<li><label class="a">新网互联代理用户API密码</label>：<input type="hidden" name="cname_009" value="XinnetPwd"/><input class="text" type="text" name="cvalue_009" value="' + XinnetPwd + '" ' + (enPwd_Xinnet == "0" ? "" : "readonly=readonly") + '/>&nbsp;&nbsp;&nbsp;<input class="submit" value="' + (enPwd_Xinnet == "0" ? "加密" : "修改") + '" name="btnEncryp" id="btnXinnetPwd" type="button"/><input type="hidden" name="cname_020" value="enPwd_Xinnet"/><input type="hidden" name="cvalue_020" value="' + enPwd_Xinnet + '"/>&nbsp;<span class="pptext"></span></li>' +
    '<li><label class="a">默认DNS1</label>：<input type="hidden" name="cname_0013" value="XinnetDns1"/><input class="text path" type="text" name="cvalue_0013" value="' + XinnetDns1 + '"/></li>' +
    '<li><label class="a">默认DNS2</label>：<input type="hidden" name="cname_0014" value="XinnetDns2"/><input class="text path" type="text" name="cvalue_0014" value="' + XinnetDns2 + '"/></li>' +

     '<li><label class="a">邮件验证</label>：<input type="hidden" name="cname_0028" value="emailchk_Xinnet"/>&nbsp<input type="radio" name="cvalue_0028" value="1" id="email_Xinnet1"><label for="email_Xinnet1">启用</label>&nbsp;&nbsp;&nbsp;<input type="radio" name="cvalue_0028" value="0" id="email_Xinnet0"><label for="email_Xinnet0">禁用</label>' +
    '<li><label class="a">短信验证</label>：<input type="hidden" name="cname_0029" value="smschk_Xinnet"/>&nbsp;<input type="radio" name="cvalue_0029" value="1" id="sms_Xinnet1"><label for="sms_Xinnet1">启用</label>&nbsp;&nbsp;&nbsp;<input type="radio" name="cvalue_0029" value="0" id="sms_Xinnet0"><label for="sms_Xinnet0">禁用</label>' +

    '<li><label class="a">模块是否启用</label>：<input type="hidden" name="cname_010" value="XinnetEnable"/>&nbsp<input type="radio" name="cvalue_010" value="1" id="xinnetyes"><label for="xinnetyes">启用</label>&nbsp;&nbsp;&nbsp;<input type="radio" name="cvalue_010" value="0" checked="checked" id="xinnetno"><label for="xinnetno">禁用</label></li></div>' +

     '<h3 class="ui-accordion-header ui-helper-reset ui-state-default ui-state-active ui-corner-top" role="tab" aria-expanded="true" aria-selected="true" tabindex="0"><span></span><a href="#"><strong>新网</strong></a></h3>' +
    '<div class="ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom ui-accordion-content-active" role="tabpanel"><li><label class="a">新网代理用户名</label>：<input type="hidden" name="cname_0015" value="XinwangUserName"/><input class="text" type="text" name="cvalue_0015" value="' + XinwangUserName + '" ' + (enUname_Xinwang == "0" ? "" : "readonly=readonly") + '/>&nbsp;&nbsp;&nbsp;<input class="submit" value="' + (enUname_Xinwang == "0" ? "加密" : "修改") + '" name="btnEncryp" id="btnXinwangName" type="button"/><input type="hidden" name="cname_0016" value="enUname_Xinwang"/><input type="hidden" name="cvalue_0016" value="' + enUname_Xinwang + '"/>&nbsp;<span class="pptext"></span></li>' +
   // '<li><label class="a">新网代理用户密码</label>：<input type="hidden" name="cname_0017" value="XinwangPwd"/><input class="text" type="text" name="cvalue_0017" value="' + XinwangPwd + '" ' + (enPwd_Xinwang == "0" ? "" : "readonly=readonly") + '/>&nbsp;&nbsp;&nbsp;<input class="submit" value="' + (enPwd_Xinwang == "0" ? "加密" : "修改") + '" name="btnEncryp" id="btnXinwangPwd" type="button"/><input type="hidden" name="cname_0018" value="enPwd_Xinwang"/><input type="hidden" name="cvalue_0018" value="' + enPwd_Xinwang + '"/>&nbsp;<span class="pptext"></span></li>' +
      '<li><label class="a">API认证密码</label>：<input type="hidden" name="cname_0022" value="XinwangAPIPwd"/><input class="text" type="text" name="cvalue_0022" value="' + XinwangAPIPwd + '" ' + (enAPIPwd_Xinwang == "0" ? "" : "readonly=readonly") + '/>&nbsp;&nbsp;&nbsp;<input class="submit" value="' + (enAPIPwd_Xinwang == "0" ? "加密" : "修改") + '" name="btnEncryp" id="btnXinwangAPIPwd" type="button"/><input type="hidden" name="cname_0023" value="enAPIPwd_Xinwang"/><input type="hidden" name="cvalue_0023" value="' + enAPIPwd_Xinwang + '"/>&nbsp;<span class="pptext"></span></li>' +
    '<li><label class="a">默认DNS1</label>：<input type="hidden" name="cname_0019" value="XinwangDns1"/><input class="text path" type="text" name="cvalue_0019" value="' + XinwangDns1 + '"/></li>' +
    '<li><label class="a">默认DNS2</label>：<input type="hidden" name="cname_0020" value="XinwangDns2"/><input class="text path" type="text" name="cvalue_0020" value="' + XinwangDns2 + '"/></li>' +
    '<li><label class="a">邮件验证</label>：<input type="hidden" name="cname_0030" value="emailchk_Xinwang"/>&nbsp<input type="radio" name="cvalue_0030" value="1" id="email_Xinwang1"><label for="email_Xinwang1">启用</label>&nbsp;&nbsp;&nbsp;<input type="radio" name="cvalue_0030" value="0" id="email_Xinwang0"><label for="email_Xinwang0">禁用</label>' +
    '<li><label class="a">短信验证</label>：<input type="hidden" name="cname_0031" value="smschk_Xinwang"/>&nbsp;<input type="radio" name="cvalue_0031" value="1" id="sms_Xinwang1"><label for="sms_Xinwang1">启用</label>&nbsp;&nbsp;&nbsp;<input type="radio" name="cvalue_0031" value="0" id="sms_Xinwang0"><label for="sms_Xinwang0">禁用</label>' +
    '<li><label class="a">模块是否启用</label>：<input type="hidden" name="cname_0021" value="XinwangEnable"/>&nbsp<input type="radio" name="cvalue_0021" value="1" id="xinwangyes"><label for="xinwangyes">启用</label>&nbsp;&nbsp;&nbsp;<input type="radio" name="cvalue_0021" value="0" checked="checked" id="xinwangno"><label for="xinwangno">禁用</label></li></div>' +
    '</div>';
    var paramList = swin.find("#paramList");
    paramList.html(str);

    $("input[name=cvalue_0024][value=" + emailchk_AiMing + "]").attr("checked", "checked");
    $("input[name=cvalue_0025][value=" + smschk_AiMing + "]").attr("checked", "checked");
    $("input[name=cvalue_0026][value=" + emailchk_ResellerClub + "]").attr("checked", "checked");
    $("input[name=cvalue_0027][value=" + smschk_ResellerClub + "]").attr("checked", "checked");
    $("input[name=cvalue_0028][value=" + emailchk_Xinnet + "]").attr("checked", "checked");
    $("input[name=cvalue_0029][value=" + smschk_Xinnet + "]").attr("checked", "checked");
    $("input[name=cvalue_0030][value=" + emailchk_Xinwang + "]").attr("checked", "checked");
    $("input[name=cvalue_0031][value=" + smschk_Xinwang + "]").attr("checked", "checked");

    $("input[name=cvalue_003][value=" + AiMingEnable + "]").attr("checked", "checked");
    $("input[name=cvalue_007][value=" + ResellerClubEnable + "]").attr("checked", "checked");
    $("input[name=cvalue_010][value=" + XinnetEnable + "]").attr("checked", "checked");
    $("input[name=cvalue_0021][value=" + XinwangEnable + "]").attr("checked", "checked");
    paramList.find("li").css({ "height": "30px", "line-height": "30px" });
    paramList.find("label.a").css({ "font-weight": "bold", "float": "left", "text-align": "right", "width": "200px", "height": "30px", "line-height": "30px" });
    paramList.find(".text").css({ "width": "280px" });

    var paramsDiv = $("#params");
    paramsDiv.accordion({
        autoHeight: false,
        collapsible: true,
        active: 0
    });

    $("#btnCheckTemplate").click(function () {
        processing("正在处理，请稍等...");

        $.getScript(currentDomain + "index.ashx?type=checkDomainTemplate&t=" + new Date(), function () {
            showResults(result, 2000, "close");
        });
    });
    $("input[name=btnEncryp]").click(function () {
        var btn = $(this);
        var txt = btn.parent().find("input[type='text']");
        var hid = btn.parent().find("input:last");
        var vSpan = btn.parent().find("span");
        if (txt.val().length <= 0) {
            vSpan.html("请输入参数值！");
            txt.focus();
            return;
        }

        if ($(this).attr('id').indexOf("Name") > -1) {
            if (hid.val() == '1') {//修改操作
                if (confirm('修改参数需要重新输入参数值，确认修改？')) {
                    txt.val('');
                    hid.val('0');
                    txt.removeAttr('readonly');
                    btn.attr('value', '加密');
                    vSpan.html("");
                    txt.focus();
                }
                return;
            }
        } else {
            if (hid.val() == '1') {
                if (confirm('修改参数需要重新输入参数值，确认修改？')) {
                    txt.val('');
                    hid.val('0');
                    txt.removeAttr('readonly');
                    btn.attr('value', '加密');
                    vSpan.html("");
                    txt.focus();
                }
                return;
            }
        }
        vSpan.html("正在加密，请稍等...");
        $.getScript(currentDomain + "index.ashx?type=encryp&txt=" + txt.val() + "&t=" + new Date(), function () {
            txt.val(a);
            vSpan.html("加密完成！");
            hid.val('1');
            btn.val('修改')
            txt.attr("readonly", "readonly");
        });
    });
}

_pm_init();