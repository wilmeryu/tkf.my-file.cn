﻿/// <reference path="jquery-vsdoc.js" />
/// <reference path="jquery-ui.min.js" />
Request = { QueryString: function (item) { var svalue = location.search.match(new RegExp("[\?\&]" + item + "=([^\&]*)(\&?)", "i")); return svalue ? svalue[1] : svalue; } }
function orderConfig() {
    if ($("#divprice").length > 0) { $("#divprice").remove(); }
    var vdomain = productData[0].pconfig.vdomain.split('_');
    var domain = Request.QueryString("domain");
    if (domain != null) {
        var tmpdomainType = decodeURI(domain.substr(domain.indexOf('.')));
        var tmpdomainName = decodeURI(domain.substr(0, domain.indexOf('.')));
        var vprovider = '';
        for (var i = 0; i < vdomain.length; i++) {
            var domainArr = vdomain[i].split('|');
            for (var j = 1; j < domainArr.length; j++) {
                if (tmpdomainType == domainArr[j]) {
                    vprovider = domainArr[0];
                    break;
                }
            }
            if (vprovider.length > 0) break;
        }

        regDomain(tmpdomainType, tmpdomainName, vprovider, 0);

    } else {
        $.post("?c=module&productid=" + productData[0].pid + "&show=text&todo=getenableconfig&t=" + new Date(), function (data) {
            var enabledata = $.parseJSON(data);
            var discount = parseFloat(productData[0].discount);
            var str = '', showinfo = '';
            var liStyle = 'style="float:left;width:90px;height:26px;line-height:26px;text-align:left;"';
            str += '<div style="text-align:center;margin-top:20px;">';
            str += '<div style="height:157px;width:480px;margin:0 auto;text-align:center;">';
            str += '<b>WWW.</b><input name="domainName" id="domainName" class="text"/>';
            str += '&nbsp;&nbsp;&nbsp;<input type="button" value="查询" class=\"submit\" onclick="queryDomain()" style="cursor:pointer;" />';
            str += '<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>';
            str += '<div id="typeBox"><div id="type_en"><h3 style="text-align: left;">域名类型</h3><div id="sv"><div><ul>';
            var vregPrice = productData[0].pconfig.vregPrice.split('_');
            var vrenewPrice = productData[0].pconfig.vrenewPrice.split('_');
            var vtransferPrice = productData[0].pconfig.vtransferPrice.split('_');

            for (var j = 0; j < vdomain.length; j++) {
                var domainArr = vdomain[j].split('|');
                var regPriceArr = vregPrice[j].split('|');
                var renewPriceArr = vrenewPrice[j].split('|');
                var transferPriceArr = vtransferPrice[j].split('|')
                for (var i = 1, len = domainArr.length; i < len; i++) {
                    if ((domainArr[0] == "aiming" && enabledata.AiMingEnable == '1') || (domainArr[0] == "resellerclub" && enabledata.ResellerClubEnable == '1') || (domainArr[0] == "xinnet" && enabledata.XinnetEnable == '1') || (domainArr[0] == "xinwang" && enabledata.XinwangEnable == '1')) {
                        str += '<li ' + liStyle + '>';
                        var domainid = domainArr[i].replace(new RegExp(/(\.)/g), '');
                        str += '<input type="checkbox" value="' + domainArr[i] + '_' + domainArr[0] + '" name="domainType" id="' + domainid + '" /><label for="' + domainid + '">' + domainArr[i] + '</label>';
                        str += '</li>';

                        showinfo += '<tr style="clear: both; border: 1px solid rgb(204, 204, 204); height: 26px; line-height: 26px;"><td width="80" style="clear: both; border: 1px solid rgb(204, 204, 204); text-align: center;">';
                        showinfo += domainArr[i];
                        showinfo += '</td><td width="130" style="clear: both; border: 1px solid rgb(204, 204, 204); text-align: center;">';
                        showinfo += (parseFloat(regPriceArr[i]) * discount).toFixed(2);
                        showinfo += '</td><td width="130" style="clear: both; border: 1px solid rgb(204, 204, 204); text-align: center;">';
                        showinfo += (parseFloat(renewPriceArr[i]) * discount).toFixed(2);
                        showinfo += '</td><td width="130" style="clear: both; border: 1px solid rgb(204, 204, 204); text-align: center;">';

                        if (domainArr[0] == "xinwang") {
                            showinfo += "暂未提供";
                        } else {
                            showinfo += (parseFloat(transferPriceArr[i]) * discount).toFixed(2);
                        }
                        showinfo += '</td></tr>';
                    }
                }
            }
            str += '<li ' + liStyle + '>';
            str += '<input type="checkbox" value="" name="selAll" id="selAll" onclick="selectAll()"/><label for="selAll">全选/反选</label>';
            str += '</li>';        
            str += '</ul>';


            str += '</div></div></div></div>';
            str += '<div id="loading" style="clear:both;display:none;text-align:left;padding-top:25px;padding-left:165px;">';
            str += '正在查询中...<br>';
            str += '<img src="files/images/loading.gif" />';
            str += '</div><div id="result" style="clear:both;display:none;text-align:center;padding-top:30px;"></div>';
            str += '<div id="domainPrice" style="clear: both; border: 0px solid rgb(204, 204, 204); width: 500px; padding: 30px 0px 0px; text-align: center;">'
            str += '<table><tr style="clear: both; border: 1px solid rgb(204, 204, 204); height: 26px; line-height: 26px;"><td width="80" style="clear: both; border: 1px solid rgb(204, 204, 204); text-align: center;"><b>域名类型</b></td>';
            str += '<td width="130" style="clear: both; border: 1px solid rgb(204, 204, 204); text-align: center;"><b>注册价格(元/年)</b></td>';
            str += '<td width="130" style="clear: both; border: 1px solid rgb(204, 204, 204); text-align: center;"><b>续费价格(元/年)</b></td>';
            str += '<td width="130" style="clear: both; border: 1px solid rgb(204, 204, 204); text-align: center;"><b>转入价格(元/年)</b></td>';
            str += '</tr>';
            str += showinfo;
            str += '</table>';
            str += '</div>';
            $("#OrderConfig").html(str);

            if (!ia) {
                $("#swin").dialog({ title: productData[0].pname, autoOpen: false, resizable: false, width: 800, height: 568, modal: true, buttons: { "域名查询": function () {
                    queryDomain();
                }, "域名转入": function () {
                    transferDomain();
                }, "关 闭": function () {
                    $(this).dialog("close");
                }
                }
                }).dialog("open");
            } else {
                $("#swin").dialog({ title: productData[0].pname, autoOpen: false, resizable: false, width: 800, height: 568, modal: true, buttons: { "域名查询": function () {
                    queryDomain();
                }, "域名转入": function () {
                    transferDomain();
                }, "域名导入": function () {
                    importDomain();
                }, "关 闭": function () {
                    $(this).dialog("close");
                }
                }
                }).dialog("open");
            }

            if (enabledata.AiMingEnable == '0' && enabledata.ResellerClubEnable == '0' && enabledata.XinnetEnable == '0' && enabledata.XinwangEnable == '1') {
                $(".ui-dialog-buttonset button:eq(1)").remove();
            }
        });
    }
}
orderConfig();


function queryDomain() {
    var domainName = $.trim($("#domainName").val());
    var types = "";
    if (domainName == "") { $("#domainName").focus(); alert("请输入你要查询的域名!!!"); return false; }
    if (domainName.indexOf("|") > -1) { alert("域名输入有误，请不要输入特殊字符“|”"); return false; }
    var reg = "!|@|#|$|%|^|&|*|(|)|+|?|>|<|~|.|,|[|]".split('|');
    for (var i = 0; i < reg.length; i++) {
        if (domainName.indexOf(reg[i]) > -1) {
            alert("域名输入有误，包含特殊字符“" + reg[i] + "”");
            return false;
        }
    }
    $("#type_en #sv input[name='domainType']:checked").each(function () {
        types += $(this).val() + "|";
    });
    if (types.length < 1) {
        alert("请勾选你需要查询的域名后缀类型！！！");
        return false;
    } else {
        types = types.substr(0, types.length - 1);
    }

    $("#result").html("");
    $("#result").show();
    $("#domainPrice").hide();

    var url = "?c=module&productid=" + productData[0].pid + "&show=text&todo=common_checkDomain&domainName=" + domainName + "&domainType=" + types;
    $("#loading").show();
    $.post(url, function (data) {
        $("#loading").hide();
        $("#result").show();

        var str = '<div style="text-align:center;"><table>';
        str += '<tr style="height:35px;line-height:35px;">';
        str += '<td style="width:130px;text-align:center;font-size:14px;">';
        str += '<strong>域名</strong></td>';
        str += '<td style="width:100px;text-align:center;font-size:14px;">';
        str += '<strong>查询结果</strong></td>';
        str += '<td style="width:80px;text-align:center;font-size:14px;">';
        str += '<strong>注册价格</strong></td>';
        str += '<td style="width:80px;text-align:center;">';
        str += '</td></tr>';
        var myData = data.split(','); //查询结果分组
        for (var i = 0; i < myData.length; i++) {
            var row = myData[i].split('|');
            str += '<tr style="height:25px;line-height:25px;border-bottom:1px dashed #ccc;">';
            str += '<td style="width:130px;text-align:center;">';
            str += row[1];
            str += '</td>';
            switch (row[2]) {
                case "available":
                    str += '<td style="width:120px;text-align:center;">';
                    str += '<strong style="color:green;">可以注册</strong>';
                    str += '</td>';
                    str += '<td style="width:100px;text-align:center;">';
                    if (getPriceByType(row[0], 'reg') == undefined) {
                        str += '<b style="color:gray;">暂未提供</b>';
                        str += '</td>';
                        str += '<td style="width:80px;text-align:center;">';
                        str += '<a style="color:gray;font-weight:bold;cursor:pointer;">立即注册</a>';
                        str += '</td>';

                    } else {
                        str += (parseFloat(getPriceByType(row[0], 'reg')) * discount).toFixed(2) + " 元/年";
                        str += '</td>';
                        str += '<td style="width:80px;text-align:center;">';
                        str += '<a onclick="regDomain(\'' + row[0] + '\',\'' + domainName + '\',0,0)" style="color:blue;font-weight:bold;cursor:pointer;">立即注册</a>';
                        str += '</td>';
                    }
                    break;
                case "regthroughothers":
                case "regthroughus":
                    str += '<td style="width:120px;text-align:center;">';
                    str += '<strong style="color:red;">已经被注册</strong>';
                    str += '</td>';
                    str += '<td style="width:100px;text-align:center;">';
                    if (getPriceByType(row[0], 'reg') == undefined) {
                        str += '<b style="color:gray;">暂未提供</b>';
                    } else {
                        str += (parseFloat(getPriceByType(row[0], 'reg')) * discount).toFixed(2) + " 元/年";
                    } str += '</td>';
                    str += '<td style="width:80px;text-align:center;">';
                    str += '<span style="color:gray;font-weight:blod;">立即注册</span>';
                    str += '</td>';
                    break;
                case "unknown":
                    str += '<td style="width:120px;text-align:center;">';
                    str += '<strong style="color:red;">状态未知</strong>';
                    str += '</td>';
                    str += '<td style="width:100px;text-align:center;">';
                    if (getPriceByType(row[0], 'reg') == undefined) {
                        str += '<b style="color:gray;">暂未提供</b>';
                    } else {
                        str += (parseFloat(getPriceByType(row[0], 'reg')) * discount).toFixed(2) + " 元/年";
                    }
                    str += '</td>';
                    str += '<td style="width:80px;text-align:center;">';
                    str += '<span style="color:gray;font-weight:blod;">立即注册</span>';
                    str += '</td>';
                    break;
                case "illegal":
                    str += '<td style="width:120px;text-align:center;">';
                    str += '<strong style="color:red;">非法关键词</strong>';
                    str += '</td>';
                    str += '<td style="width:100px;text-align:center;">';
                    if (getPriceByType(row[0], 'reg') == undefined) {
                        str += '<b style="color:gray;">暂未提供</b>';
                    } else {
                        str += (parseFloat(getPriceByType(row[0], 'reg')) * discount).toFixed(2) + " 元/年";
                    }
                    str += '</td>';
                    str += '<td style="width:80px;text-align:center;">';
                    str += '<span style="color:gray;font-weight:blod;">立即注册</span>';
                    str += '</td>';
                    break;

                default:
                    str += '<td style="width:120px;text-align:center;">';
                    str += '<strong style="color:red;">' + row[2] + '</strong>';
                    str += '</td>';
                    str += '<td style="width:100px;text-align:center;">';
                    if (getPriceByType(row[0], 'reg') == undefined) {
                        str += '<b style="color:gray;">暂未提供</b>';
                    } else {
                        str += (parseFloat(getPriceByType(row[0], 'reg')) * discount).toFixed(2) + " 元/年";
                    }
                    str += '</td>';
                    str += '<td style="width:80px;text-align:center;">';
                    str += '<span style="color:gray;font-weight:blod;">立即注册</span>';
                    str += '</td>';
                    break;
            }
            str += '</tr>';
        }
        str += '</table>';
        if (data == "" || data == undefined) { str += "系统繁忙，请稍后再试！"; }
        str += '</div>';
        $("#result").html(str);
    });

}
function regDomain(domainType, domainName, vprovider, templatesid) {
    if (vprovider == 0) vprovider = $("#" + domainType.replace(new RegExp(/(\.)/g), '')).val().split('_')[1]; //获取域名商

    $("#suwin").html(ajaxLoading("正在检查你的账户"));
    $("#suwin").dialog({ title: "域名系统正在检查你的账户信息", autoOpen: false, resizable: false, width: 400, height: 280, modal: true, buttons: { "取 消": function () {
        $(this).dialog("close");
    }
    }
    }).dialog("open");


    var url = "?c=module&productid=" + productData[0].pid + "&show=text&todo=common_checkDomainContact&t=" + new Date();
    $.get(url, function (data) {
        //$("#swin").dialog("close");
        $("#suwin").dialog("close");

        if (data == "[]") {
            common_RegDomainContact(domainType, domainName, vprovider, 0, "reg", 0);
        } else {
            if (vprovider == "aiming") {
                aiMing_regDomain(domainType, domainName, vprovider, data, templatesid);
            } else if (vprovider == "resellerclub") {
                resellerclub_regDomain(domainType, domainName);
            } else if (vprovider == "xinnet") {
                xinnet_regDomain(domainType, domainName, vprovider, data, templatesid);
            } else if (vprovider == "xinwang") {
                xinwang_regDomain(domainType, domainName, vprovider, data, templatesid);
            }
        }
    });
}
function importDomain() {
    var str = '联系人模板：<input type="button" name="btntemplates" id="btntemplates"  class="button" value="选择模板" onclick="settemplates()"/>';
    str += '<div id="params" class="ui-accordion ui-widget ui-helper-reset ui-accordion-icons" role="tablist">' +
    '<h3 class="ui-accordion-header ui-helper-reset ui-state-default ui-state-active ui-corner-top" role="tab" aria-expanded="true" aria-selected="true" tabindex="0"><span></span><a href="#"><strong>爱名网</strong></a></h3>' +
    '<div class="ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom ui-accordion-content-active" role="tabpanel"><li><textarea name="domainlist_aiming" id="domainlist_aiming" rows="5" cols="75" ></textarea><br><strong style="color:red">提示：多个域名用逗号(,)分开</strong></li></div>' +

    '<h3 class="ui-accordion-header ui-helper-reset ui-state-default ui-corner-all" role="tab" aria-expanded="false" aria-selected="false" tabindex="-1"><span></span><a href="#"><strong>ResellerClub</strong></a></h3>' +
    '<div style="line-height: 28px; display: none;" class="ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom" role="tabpanel"><li><textarea name="domainlist_resellerclub" id="domainlist_resellerclub" rows="5" cols="75" ></textarea><br><strong style="color:red">提示：多个域名用逗号(,)分开</strong></li></div>' +

    '<h3 class="ui-accordion-header ui-helper-reset ui-state-default  ui-corner-top" role="tab" aria-expanded="true" aria-selected="true" tabindex="0"><span></span><a href="#"><strong>新网互联</strong></a></h3>' +
    '<div class="ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom ui-accordion-content-active" role="tabpanel"><li><textarea name="domainlist_xinnet" id="domainlist_xinnet" rows="5" cols="75" ></textarea><br><strong style="color:red">提示：多个域名用逗号(,)分开</strong></li></div>' +

     '<h3 class="ui-accordion-header ui-helper-reset ui-state-default  ui-corner-top" role="tab" aria-expanded="true" aria-selected="true" tabindex="0"><span></span><a href="#"><strong>新网</strong></a></h3>' +
    '<div class="ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom ui-accordion-content-active" role="tabpanel"><li><textarea name="domainlist_xinwang" id="domainlist_xinwang" rows="5" cols="75" ></textarea><br><strong style="color:red">提示：多个域名用逗号(,)分开</strong></li></div>' +
    '</div><form id="OrderConfig"><input type="hidden" name="templateid" value="0"/></form>';
    $("#swin").html(str);
    var paramsDiv = $("#params");
    paramsDiv.accordion({
        autoHeight: false,
        collapsible: true,
        active: 0
    });

    $("#swin").dialog({ title: "域名导入", autoOpen: false, resizable: false, width: 570, height: 460, modal: true, buttons: { "导 入": function () {
        processing("正在处理，请稍等...");
        if ($("input[name=templateid]").val() == 0) {
            showResults("请先选择联系人模板", 2000, "close");
            return;
        }

        var domainArr = [];
        var domainlist_aiming = $("#domainlist_aiming").val();
        if (domainlist_aiming.indexOf('，') > -1) {
            showResults("爱名网域名列表格式错误，请用英文逗号(,)", 2000, "close");
            return;
        }
        if (domainlist_aiming.length > 1 && domainlist_aiming.indexOf('.') > -1) {
            var domainlist = domainlist_aiming.split(',');
            for (var i = 0; i < domainlist.length; i++) {
                if (domainlist[i].indexOf('.') > -1) {
                    domainArr.push(domainlist[i].replaceAll('\\s+', '') + "|aiming");
                }
            }
        }

        var domainlist_resellerclub = $("#domainlist_resellerclub").val();
        if (domainlist_resellerclub.indexOf('，') > -1) {
            showResults("Resellerclub域名列表格式错误，请用英文逗号(,)", 2000, "close");
            return;
        }
        if (domainlist_resellerclub.length > 1 && domainlist_resellerclub.indexOf('.') > -1) {
            var domainlist = domainlist_resellerclub.split(',');
            for (var i = 0; i < domainlist.length; i++) {
                if (domainlist[i].indexOf('.') > -1) {
                    domainArr.push(domainlist[i].replaceAll('\\s+', '') + "|resellerclub");
                }
            }
        }

        var domainlist_xinnet = $("#domainlist_xinnet").val();
        if (domainlist_xinnet.indexOf('，') > -1) {
            showResults("新网互联域名列表格式错误，请用英文逗号(,)", 2000, "close");
            return;
        }
        if (domainlist_xinnet.length > 1 && domainlist_xinnet.indexOf('.') > -1) {
            var domainlist = domainlist_xinnet.split(',');
            for (var i = 0; i < domainlist.length; i++) {
                if (domainlist[i].indexOf('.') > -1) {
                    domainArr.push(domainlist[i].replaceAll('\\s+', '') + "|xinnet");
                }
            }
        }

        var domainlist_xinwang = $("#domainlist_xinwang").val();
        if (domainlist_xinwang.indexOf('，') > -1) {
            showResults("新网域名列表格式错误，请用英文逗号(,)", 2000, "close");
            return;
        }
        if (domainlist_xinwang.length > 1 && domainlist_xinwang.indexOf('.') > -1) {
            var domainlist = domainlist_xinwang.split(',');
            for (var i = 0; i < domainlist.length; i++) {
                if (domainlist[i].indexOf('.') > -1) {
                    domainArr.push(domainlist[i].replaceAll('\\s+', '') + "|xinwang");
                }
            }
        }

        var templateid = $("input[name=templateid]").val();
        for (var i = 0; i < domainArr.length; i++) {
            var arr = domainArr[i].split('|');
            var domainName = arr[0];
            var domainType = domainName.substr(domainName.indexOf("."));

            normalPrice = parseFloat(getPriceByType(domainType, 'reg'));
            finalPrice = normalPrice * parseFloat(productData[0].discount);
            billingCycle = 12;
            billingMothod = 1;
            var vOrderConfig = '<input type="hidden" value="' + getPriceByType(domainType, 'reg') + '" name="typePrice" />' +
          '<input type="hidden" value="' + getPriceByType(domainType, 'renew') + '" name="renewPrice" />' +
          '<input type="hidden" value="' + getPriceByType(domainType, 'transfer') + '" name="transferPrice" />' +
          '<input type="hidden" value="' + domainName + '" name="domainName" />' +
          '<input type="hidden" value="1" name="regYearNum" />' +
          '<input type="hidden" value="' + arr[1] + '" name="provider" />' +
           '<input type="hidden" value="yes" name="importdomain" />' +
           '<input type="hidden" value="' + templateid + '" name="templateid" /><input type="hidden" id="couponcode" value="" />';
            $("#OrderConfig").html(vOrderConfig);
            checkout(1);
        }
        var myTimer = setInterval(function () {
            if ($("#processing").html().indexOf("购买成功") > -1) {
                $("#processing").dialog("destroy");
                processing("正在处理，请稍等...");
                $("#processing").html("<div style='text-align:center;padding-top:20px;'>恭喜，导入域名成功！</div>");
                clearInterval(myTimer);
            } else if ($("#processing").html().indexOf("正在发送购买请求") > -1) {
                processing("正在处理，请稍等...");
            }
        }, 1);

    }, "取 消": function () {
        $(this).dialog("close");
    }
    }
    }).dialog("open");
}
function settemplates() {
    processing("正在处理，请稍等...");
    var url = "?c=module&productid=" + productData[0].pid + "&show=text&todo=common_listDomainContact&t=" + new Date();
    $.post(url, function (data) {
        $("#processing").dialog("close");
        var jsonArr = $.parseJSON(data);
        var str = '<div id="main-content"><table class="table" border="0" cellspacing="0" cellpadding="0" width="100%">' +
                          '<thead><tr><th width="10%">姓名</th><th width="10%">手机</th><th width="10%">email</th><th width="20%">地址</th><th width="20%">&nbsp;</th></tr></thead>';

        for (var i = 0, len = jsonArr.length; i < len; i++) {
            str += '<tr id="tr' + i + '" title="双击选用该模板"><td width="10%" align="center">' + jsonArr[i].lname + jsonArr[i].fname + '</td>' +
            '<td width="10%" align="center">' + jsonArr[i].tel + '</td>' +
            '<td width="10%" align="center">' + jsonArr[i].email + '</td>';
            str += '<td width="20%" align="center">' + jsonArr[i].street + '</td>';
            str += '<td><input type="button" name="del' + i + '" class="button" value="删除" onclick="common_DelDomainContact(' + jsonArr[i].id + ',\'\',\'\',\'\',\'\',\'import\',\'0\')"/>&nbsp;&nbsp;<input type="button" name="edit' + i + '" class="button" value="修改" onclick="common_AddEditDomainContact(' + jsonArr[i].id + ',\'\',\'\',\'\',\'\',\'import\',\'0\')"/></td></tr>';
        }

        str += '</table>';
        $("#suwin").html(str);
        $("#suwin").next().find("#divprice").remove();
        $("#suwin table tr").not(":first").dblclick(function () {
            var id = $(this).attr("id");
            id = id.substr(2);
            var templatename = $(this).find("td:first").html();

            $("#swin").find("input[name=templateid]").val(jsonArr[id].id);
            $("#swin").find("#btntemplates").val(templatename);
            $("#suwin").dialog('close');

        });

        $("#suwin").dialog({ title: "联系人模板管理", autoOpen: false, resizable: false, width: 600, height: 400, modal: true, buttons: { "添加联系人模板": function () { common_AddEditDomainContact(0, '', '', '', '', 'import', 0); } } }).dialog("open");

    });
}
function common_ListDomainContact(domainType, domainName, vprovider, pwd, refferer, templatesid) {
    processing("正在处理，请稍等...");
    var url = "?c=module&productid=" + productData[0].pid + "&show=text&todo=common_listDomainContact&t=" + new Date();
    $.post(url, function (data) {
        $("#processing").dialog("close");
        var jsonArr = $.parseJSON(data);
        var str = '<div id="main-content"><table class="table" border="0" cellspacing="0" cellpadding="0" width="100%">' +
                          '<thead><tr><th width="10%">姓名</th><th width="10%">手机</th><th width="10%">email</th><th width="20%">地址</th><th width="20%">&nbsp;</th></tr></thead>';

        for (var i = 0, len = jsonArr.length; i < len; i++) {
            str += '<tr id="tr' + i + '" title="双击选用该模板"><td width="10%" align="center">' + jsonArr[i].lname + jsonArr[i].fname + '</td>' +
            '<td width="10%" align="center">' + jsonArr[i].tel + '</td>' +
            '<td width="10%" align="center">' + jsonArr[i].email + '</td>';
            str += '<td width="20%" align="center">' + jsonArr[i].street + '</td>';
            str += '<td><input type="button" name="del' + i + '" class="button" value="删除" onclick="common_DelDomainContact(' + jsonArr[i].id + ',\'' + domainType + '\',\'' + domainName + '\',\'' + vprovider + '\',\'' + pwd + '\',\'' + refferer + '\',\'' + templatesid + '\')"/>&nbsp;&nbsp;<input type="button" name="edit' + i + '" class="button" value="修改" onclick="common_AddEditDomainContact(' + jsonArr[i].id + ',\'' + domainType + '\',\'' + domainName + '\',\'' + vprovider + '\',\'' + pwd + '\',\'' + refferer + '\',\'' + templatesid + '\')"/></td></tr>';
        }

        str += '</table>';
        $("#suwin").html(str);
        $("#suwin").next().find("#divprice").remove();

        $("#suwin table tr").not(":first").dblclick(function () {
            var id = $(this).attr("id");
            id = id.substr(2);
            if (refferer == "reg")
                regDomain(domainType, domainName, vprovider, id);
            else
                gotoTransferDomain(domainName, domainType, pwd, vprovider, id);
        });


        if (refferer == "reg")
            $("#suwin").dialog({ title: "联系人管理", autoOpen: false, resizable: false, width: 600, height: 400, modal: true, buttons: { "添加联系人": function () { common_AddEditDomainContact(0, domainType, domainName, vprovider, pwd, refferer, templatesid); }, "返回域名注册界面": function () { regDomain(domainType, domainName, vprovider, templatesid); } } }).dialog("open");
        else
            $("#suwin").dialog({ title: "联系人管理", autoOpen: false, resizable: false, width: 600, height: 400, modal: true, buttons: { "添加联系人": function () { common_AddEditDomainContact(0, domainType, domainName, vprovider, pwd, refferer, templatesid); }, "返回域名转入界面": function () { gotoTransferDomain(domainName, domainType, pwd, vprovider, templatesid); } } }).dialog("open");

    });
}
function common_DelDomainContact(id, domainType, domainName, vprovider, pwd, refferer, templatesid) {
    var str = '<form><div style="font-weight:bold;padding-top:10px;line-height:30px;">';
    str += '<p style="font-weight:bold;padding-top:20px;text-align:center;"><input type="checkbox" id="confirm_box" value="1"/><label for="confirm_box" style="cursor:pointer;display:inline;">您确定要删除该联系人信息吗？</label></p>';
    $("#processing").html(str);
    $("#processing").next().find("#divprice").remove();
    $("#processing").dialog({ title: '操作提示', autoOpen: false, resizable: false, width: 400, height: 220, modal: true, buttons: { '确定': function () {

        var confirm_box = $("#confirm_box").prop("checked");
        if (!confirm_box) {
            alert('请勾选复选框以确认操作！');
            return false;
        }
        $("#processing").dialog('destroy');
        processing("正在处理，请稍等...");

        var url = '?c=module&productid=' + productData[0].pid + '&show=text&todo=common_delDomainContact&id=' + id + '&t=' + new Date();
        $.post(url, function (rdata) {
            if (rdata == "1") {
                showResults("操作成功", 2000, "close");
                setTimeout(function () {
                    if (refferer == 'import') settemplates();
                    else
                        common_ListDomainContact(domainType, domainName, vprovider, pwd, refferer, templatesid);

                }, 1000);
            } else {
                showResults(rdata, 3000, "close");
            }
        });

    }, '取消': function () { $(this).dialog("close"); }
    }
    }).dialog("open");
}
function common_AddEditDomainContact(id, domainType, domainName, vprovider, pwd, refferer, templatesid) {
    suwin.html(ajaxLoading("正在加载信息，请稍候..."));

    var str = '<div style="padding-left:100px;"><form action="?c=module&productid=' + productData[0].pid + '&show=text&todo=common_saveDomainContact" onsubmit="return false;"><input type="hidden" name="hidid" id="hidid" value="' + id + '"/>';
    str += '<table style="width:580px;">';
    str += getFormContent();
    str += '</table></form>';
    str += '</div>';

    if (id != 0) {
        var url = "?c=module&productid=" + productData[0].pid + "&show=text&todo=common_getDomainContact&id=" + id + "&t=" + new Date();
        $.post(url, function (rdata) {

            suwin.html(str);
            var jsonArr = $.parseJSON(rdata);
            suwin.find("#lname").val(jsonArr[0].lname);
            suwin.find("#fname").val(jsonArr[0].fname);
            suwin.find("#lnameE").val(jsonArr[0].lnameE);
            suwin.find("#fnameE").val(jsonArr[0].fnameE);
            suwin.find("#tel").val(jsonArr[0].tel);
            suwin.find("#phone").val(jsonArr[0].phonecode + '-' + jsonArr[0].phone);
            suwin.find("#fax").val(jsonArr[0].faxcode + '-' + jsonArr[0].fax);
            suwin.find("#email").val(jsonArr[0].email);
            suwin.find("#zipcode").val(jsonArr[0].zipcode);
            suwin.find("#Country").val(jsonArr[0].countrycode);
            suwin.find("#province").val(jsonArr[0].province);
            suwin.find("#city").val(jsonArr[0].city);
            suwin.find("#street").val(jsonArr[0].street);
            suwin.find("#streetE").val(jsonArr[0].streetE);
            suwin.find("#company").val(jsonArr[0].company);
            suwin.find("#companyE").val(jsonArr[0].companyE);
            suwin.find("#companylocation").val(jsonArr[0].companylocation);
        });
    } else {
        suwin.html(str);
    }
    $("#processing").dialog("destroy");
    suwin.dialog({ title: "添加/修改联系人模板信息", autoOpen: false, resizable: false, width: 860, height: 600, modal: true, buttons: { "保存模板信息": function () {

        if (!common_checkDomainContactInfo()) return false;
        processing("正在处理，请稍等...");
        var cform = suwin.find("form:first");
        $.post(cform.attr("action"), cform.serialize(), function (rdata) {
            if (rdata == "1") {
                showResults("操作成功", 3000, "close");
                setTimeout(function () {
                    if (refferer == 'import') settemplates();
                    else
                        common_ListDomainContact(domainType, domainName, vprovider, pwd, refferer, templatesid);

                }, 3000);
            } else {
                showResults(rdata, 5000, "close");
            }
        });


    }, "返回联系人模板管理界面": function () {

        if (refferer == 'import') settemplates();
        else
            common_ListDomainContact(domainType, domainName, vprovider, pwd, refferer, templatesid);

    }
    }
    }).dialog("open");
}

function common_RegDomainContact(domainType, domainName, vprovider, pwd, reffer, templatesid) {
    $("#suwin").dialog({ title: "注册账户信息", autoOpen: false, resizable: false, width: 860, height: 600, modal: true, buttons: { "注册账户": function () {
        common_gotoRegDomainContact(domainType, domainName, vprovider, pwd, reffer, templatesid);
    }, "关 闭": function () {
        $(this).dialog("close");
    }
    }
    }).dialog("open");
    var str = '';

    str += '<h3 style="padding-left:80px;height:40px;font-size:16px;">填写您的账户信息 <b style="color:red;font-size:12px;font-weight:normal;word-spacing: 5px;"> ( 注意：请认真填写下面的信息！)</b></h3>';
    str += '<div style="padding-left:170px;"><form action="?c=module&productid=' + productData[0].pid + '&show=text&todo=common_regDomainContact" onsubmit="return false;">';
    str += '<table style="width:460px;">';
    str += getFormContent();
    str += '</table></form>';
    str += '</div>';
    $("#suwin").html(str);


}

function getFormContent() {
    var tr_td_SS = '<tr style="height:29px;line-height:29px;border-bottom:1px dashed #ddd;"><td style="width:150px;text-align:right;">';
    var inputSS = 'class="text" style="margin-top:4px;"';
    var str = '<tr style="height:29px;line-height:29px;border-bottom:1px dashed #ddd;"><td style="width:120px;text-align:right;"><b>姓：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="lname" id="lname" onblur="aiMing_keyUpCheck(this)" class="text" style="margin-top:4px;width:45px" >';
    str += '&nbsp;&nbsp;&nbsp;<b>名：</b>';
    str += '<input name="fname" id="fname" onblur="aiMing_keyUpCheck(this)" class="text" style="margin-top:4px;width:60px" >';
    str += '</td>';
    str += '<td style="text-align:left;width:150px;">';
    str += ' <span style="color:green;"></span>';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>英文姓：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="lnameE" id="lnameE" onblur="aiMing_keyUpCheck(this)" ' + inputSS + '>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>英文名：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="fnameE" id="fnameE" onblur="aiMing_keyUpCheck(this)" ' + inputSS + '>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>手机：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="tel" id="tel" value="' + (userData[0].tel == "0" ? "" : userData[0].tel) + '" onfocus="aiMing_keyFocus(this)" onblur="aiMing_keyUpCheck(this)" ' + inputSS + '>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 如：13916245610</td>';
    str += '</tr>';

    str += tr_td_SS + '<b>联系电话：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="phone" id="phone" onfocus="aiMing_keyFocus(this)" onblur="aiMing_keyUpCheck(this)" ' + inputSS + '>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 如：020-12345678</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>传真：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="fax" id="fax" onfocus="aiMing_keyFocus(this)" onblur="aiMing_keyUpCheck(this)" ' + inputSS + '>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 如：020-12345678</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>电子邮箱：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="email" id="email" onblur="aiMing_keyUpCheck(this)" value=' + userData[0].umail + ' ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>邮编：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="zipcode" id="zipcode" onblur="aiMing_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>国家：</b>';
    str += '</td>';
    str += '<td style="text-align:left;">' + xinnet_getCountryList() + '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>省份：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="province" id="province" onfocus="aiMing_keyFocus(this)" onblur="aiMing_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 省/市，如：广东</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>城市：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="city" id="city" onfocus="aiMing_keyFocus(this)" onblur="aiMing_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 市/区，如：广州</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>街道地址：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="street" id="street" onblur="aiMing_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>街道地址英文：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="streetE" id="streetE" onblur="aiMing_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>公司名称：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="company" id="company" onblur="aiMing_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>公司名称英文：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="companyE" id="companyE" onblur="aiMing_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;width:150px;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>公司所在地：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="companylocation" id="companylocation" onblur="aiMing_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;width:190px;">如：广东广州';
    str += '</td>';
    str += '</tr>';
    return str;
}

function common_checkDomainContactInfo() {
    var fname = suwin.find("#fname"), lname = suwin.find("#lname"), fnameE = suwin.find("#fnameE"), lnameE = suwin.find("#lnameE"), tel = suwin.find("#tel"), phone = suwin.find("#phone"), fax = suwin.find("#fax"), email = suwin.find("#email");
    var province = suwin.find("#province"), city = suwin.find("#city"), street = suwin.find("#street"), streetE = suwin.find("#streetE"), zipcode = suwin.find("#zipcode"), org = suwin.find("#company"), orgE = suwin.find("#companyE"), companylocation = suwin.find("#companylocation");
    if ($.trim(lname.val()) == "") { lname.parent().next("td").html("<b style='color:red;'>*姓氏不能为空！</span>"); lname.focus(); return false; }
    if ($.trim(fname.val()) == "") { fname.parent().next("td").html("<b style='color:red;'>*名字不能为空！</span>"); fname.focus(); return false; }
    if ($.trim(lnameE.val()) == "") { lnameE.parent().next("td").html("<b style='color:red;'>*英文姓氏不能为空！</span>"); lnameE.focus(); return false; }
    if ($.trim(fnameE.val()) == "") { fnameE.parent().next("td").html("<b style='color:red;'>*英文名字不能为空！</span>"); fnameE.focus(); return false; }

    
    var reg = /^\d{11}$/g;
    if (!reg.test($.trim(tel.val()))) {
        tel.parent().next("td").html("<b style='color:red;'>*手机格式不正确！</span>");
        tel.focus();
        return false;
    }
    else {
        tel.parent().next("td").html("<b style='font-size:1px;'>&nbsp;</b>");
    }

    reg = /^([0-9]{6})?$/;
    if (!reg.test($.trim(zipcode.val()))) {
        zipcode.parent().next("td").html("<b style='color:red;'>*邮编格式不正确！</span>");
        zipcode.focus();
        return false;
    }
    else {
        zipcode.parent().next("td").html("<b style='font-size:1px;'>&nbsp;</b>");
    }


    if ($.trim(phone.val()) == "") {
        phone.parent().next("td").html("<b style='color:red;'>*联系电话不能为空！</span>");
        phone.focus();
        return false;
    }
    else {
        var ik = $.trim(phone.val()).indexOf("-");
        if (ik == 3 || ik == 4) {
            var phonelen = phone.val().split('-')[1].length;
            if (phonelen < 7 || phonelen > 8) {
                phone.parent().next("td").html("<span style='color:red;'>*格式错误！</span>");
                return false;
            } else {
                phone.parent().next("td").html(" 如：020-12345678");
            }
        } else {
            phone.parent().next("td").html("<span style='color:red;'>*格式错误！</span>");
            return false;
        }
    }
    if ($.trim(fax.val()) == "") {
        fax.parent().next("td").html("<b style='color:red;'>*传真不能为空！</span>");
        fax.focus();
        return false;
    }
    else {
        var ik = $.trim(fax.val()).indexOf("-");
        if (ik == 3 || ik == 4) {
            var faxlen = fax.val().split('-')[1].length;
            if (faxlen < 7 || faxlen > 8) {
                fax.parent().next("td").html("<span style='color:red;'>*格式错误！</span>");
                return false;
            } else {
                fax.parent().next("td").html(" 如：020-12345678");
            }
        } else {
            fax.parent().next("td").html("<span style='color:red;'>*格式错误！</span>");
            return false;
        }
    }
    if ($.trim(email.val()) == "") {
        email.parent().next("td").html("<b style='color:red;'>*邮箱不能为空！</span>");
        email.focus();
        return false;
    }
    else {
        reg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
        if (!reg.test($.trim(email.val()))) {
            email.parent().next("td").html("<b style='color:red;'>*邮箱格式不正确！</span>");
            email.focus();
            return false;
        }
        else {
            email.parent().next("td").html("<b style='font-size:1px;'>&nbsp;</b>");
        }
    }


    if ($.trim(province.val()) == "") { province.parent().next("td").html("<b style='color:red;'>*省份不能为空！</span>"); province.focus(); return false; }
    if ($.trim(city.val()) == "") { city.parent().next("td").html("<b style='color:red;'>*城市不能为空！</span>"); city.focus(); return false; }
    if ($.trim(street.val()) == "") { street.parent().next("td").html("<b style='color:red;'>*街道地址不能为空！</span>"); street.focus(); return false; }
    if ($.trim(streetE.val()) == "") { streetE.parent().next("td").html("<b style='color:red;'>*街道的英文不能为空！</span>"); streetE.focus(); return false; }

    if (streetE.val().indexOf("'") > -1) { streetE.parent().next("td").html("<b style='color:red;'>*街道英文地址不能包含单引号！</span>"); streetE.focus(); return false; }
    if ($.trim(zipcode.val()) == "") { zipcode.parent().next("td").html("<b style='color:red;'>*邮编不能为空！</span>"); zipcode.focus(); return false; }
    if ($.trim(org.val()) == "") { org.parent().next("td").html("<b style='color:red;'>*公司名称不能为空！</span>"); org.focus(); return false; }
    if ($.trim(orgE.val()) == "") { orgE.parent().next("td").html("<b style='color:red;'>*公司的英文不能为空！</span>"); orgE.focus(); return false; }
    if ($.trim(companylocation.val()) == "") { companylocation.parent().next("td").html("<b style='color:red;'>*公司所在地不能为空！</span>"); companylocation.focus(); return false; }
    return true;
}
function common_gotoRegDomainContact(domainType, domainName, vprovider, pwd, reffer, templatesid) {

    //    var fname = $("#fname"), lname = $("#lname"), fnameE = $("#fnameE"), lnameE = $("#lnameE"), tel = $("#tel"), phone = $("#phone"), fax = $("#fax"), email = $("#email");
    //    var province = $("#province"), city = $("#city"), street = $("#street"), streetE = $("#streetE"), zipcode = $("#zipcode"), org = $("#company"), orgE = $("#companyE"), companylocation = $("#companylocation");
    //    if ($.trim(lname.val()) == "") { lname.parent().next("td").html("<b style='color:red;'>*姓氏不能为空！</span>"); lname.focus(); return false; }
    //    if ($.trim(fname.val()) == "") { fname.parent().next("td").html("<b style='color:red;'>*名字不能为空！</span>"); fname.focus(); return false; }
    //    if ($.trim(lnameE.val()) == "") { lnameE.parent().next("td").html("<b style='color:red;'>*英文姓氏不能为空！</span>"); lnameE.focus(); return false; }
    //    if ($.trim(fnameE.val()) == "") { fnameE.parent().next("td").html("<b style='color:red;'>*英文名字不能为空！</span>"); fnameE.focus(); return false; }

    //    var reg = /^[1-9]{11}$/;
    //    if (!reg.test($.trim(tel.val()))) {
    //        tel.parent().next("td").html("<b style='color:red;'>*手机格式不正确！</span>");
    //        tel.focus();
    //        return false;
    //    }
    //    else {
    //        tel.parent().next("td").html("<b style='font-size:1px;'>&nbsp;</b>");
    //    }

    //    if ($.trim(phone.val()) == "") {
    //        phone.parent().next("td").html("<b style='color:red;'>*联系电话不能为空！</span>");
    //        phone.focus();
    //        return false;
    //    }
    //    else {
    //        var ik = $.trim(phone.val()).indexOf("-");
    //        if (ik == 3 || ik == 4) {
    //            var phonelen = phone.val().split('-')[1].length;
    //            if (phonelen < 7 || phonelen > 8) {
    //                phone.parent().next("td").html("<span style='color:red;'>*格式错误！</span>");
    //                return false;
    //            } else {
    //                phone.parent().next("td").html(" 如：020-12345678");
    //            }
    //        } else {
    //            phone.parent().next("td").html("<span style='color:red;'>*格式错误！</span>");
    //            return false;
    //        }
    //    }
    //    if ($.trim(fax.val()) == "") {
    //        fax.parent().next("td").html("<b style='color:red;'>*传真不能为空！</span>");
    //        fax.focus();
    //        return false;
    //    }
    //    else {
    //        var ik = $.trim(fax.val()).indexOf("-");
    //        if (ik == 3 || ik == 4) {
    //            var faxlen = fax.val().split('-')[1].length;
    //            if (faxlen < 7 || faxlen > 8) {
    //                fax.parent().next("td").html("<span style='color:red;'>*格式错误！</span>");
    //                return false;
    //            } else {
    //                fax.parent().next("td").html(" 如：020-12345678");
    //            }
    //        } else {
    //            fax.parent().next("td").html("<span style='color:red;'>*格式错误！</span>");
    //            return false;
    //        }
    //    }
    //    if ($.trim(email.val()) == "") {
    //        email.parent().next("td").html("<b style='color:red;'>*邮箱不能为空！</span>");
    //        email.focus();
    //        return false;
    //    }
    //    else {
    //        reg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
    //        if (!reg.test($.trim(email.val()))) {
    //            email.parent().next("td").html("<b style='color:red;'>*邮箱格式不正确！</span>");
    //            email.focus();
    //            return false;
    //        }
    //        else {
    //            email.parent().next("td").html("<b style='font-size:1px;'>&nbsp;</b>");
    //        }
    //    }


    //    if ($.trim(province.val()) == "") { province.parent().next("td").html("<b style='color:red;'>*省份不能为空！</span>"); province.focus(); return false; }
    //    if ($.trim(city.val()) == "") { city.parent().next("td").html("<b style='color:red;'>*城市不能为空！</span>"); city.focus(); return false; }
    //    if ($.trim(street.val()) == "") { street.parent().next("td").html("<b style='color:red;'>*街道地址不能为空！</span>"); street.focus(); return false; }
    //    if ($.trim(streetE.val()) == "") { streetE.parent().next("td").html("<b style='color:red;'>*街道的英文不能为空！</span>"); streetE.focus(); return false; }

    //    if (streetE.val().indexOf("'") > -1) { streetE.parent().next("td").html("<b style='color:red;'>*街道英文地址不能包含单引号！</span>"); streetE.focus(); return false; }
    //    if ($.trim(zipcode.val()) == "") { zipcode.parent().next("td").html("<b style='color:red;'>*邮编不能为空！</span>"); zipcode.focus(); return false; }
    //    if ($.trim(org.val()) == "") { org.parent().next("td").html("<b style='color:red;'>*公司名称不能为空！</span>"); org.focus(); return false; }
    //    if ($.trim(orgE.val()) == "") { orgE.parent().next("td").html("<b style='color:red;'>*公司的英文不能为空！</span>"); orgE.focus(); return false; }
    //    if ($.trim(companylocation.val()) == "") { companylocation.parent().next("td").html("<b style='color:red;'>*公司所在地不能为空！</span>"); companylocation.focus(); return false; }


    if (!common_checkDomainContactInfo()) return false;
    processing("提交中，请稍后...");
    var cform = suwin.find("form:first");

    $.post(cform.attr("action"), cform.serialize(), function (rdata) {
        if (rdata == "1") {
            showResults('<b style="color:green;">注册账户成功！<br/>即将准备填写域名注册信息</b>', 5000, "close");
            setTimeout(function () {
                $("#swin").dialog("close");
                $("#suwin").dialog("close");

                if (reffer == "reg")
                    regDomain(domainType, domainName, vprovider, templatesid);
                else if (reffer == "transfer")
                    gotoTransferDomain(domainName, domainType, pwd, vprovider, templatesid)
            }, 5000);
        } else {
            showResults('<b style="color:red;">' + rdata + '</b>', 3000, "close");
        }
    });
}

function gotoTransferDomain(domainName, domainType, pwd, provider, templatesid) {

    $("#suwin").html(ajaxLoading("正在检查你的账户"));
    $("#suwin").dialog({ title: "域名系统正在检查你的账户信息", autoOpen: false, resizable: false, width: 400, height: 280, modal: true, buttons: { "取 消": function () {
        $(this).dialog("close");
    }
    }
    }).dialog("open");

    var url = "?c=module&productid=" + productData[0].pid + "&show=text&todo=common_checkDomainContact&t=" + new Date();
    $.get(url, function (data) {
        //$("#swin").dialog("close");
        $("#suwin").dialog("close");
        if (data == "[]") {
            common_RegDomainContact(domainType, domainName, provider, pwd, "transfer", 0);
        } else {
            if (provider == "aiming") {
                aiMing_transferDomain(domainName, domainType, pwd, provider, data, templatesid);
            } else if (provider == "resellerclub") {
                resellerclub_gotoChkUserAccountToTransfer(domainName, domainType, pwd, provider);
            } else if (provider == "xinnet") {
                xinnet_gotoChkTransferDomain(domainName, domainType, pwd, provider, data, templatesid);
            }
        }
    });
}

function transferDomain() {
    var str = '';
    //str += '<h3 style="padding-left:70px;height:40px;font-size:16px;">请填写下面的转入域名信息 <b style="color:red;font-size:12px;font-weight:normal;word-spacing: 5px;"> ( 注意：请认真填写下面的信息！)</b></h3>';
    str += '<div style="margin-left:150px;">';
    str += '<table>';
    var tr_td_SS = '<tr style="height:29px;line-height:29px;border-bottom:1px dashed #ddd;"><td style="width:120px;text-align:right;">';
    var inputSS = 'class="text" style="margin-top:4px;"';
    str += '<div style="padding-left:170px;">';
    str += '<table style="width:600px;">';
    str += tr_td_SS + '<b>转入的域名名称：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:100px;">';
    str += '<input name="TransferDomainName" id="TransferDomainName" onblur="aiMing_keyUpCheck(this)" ' + inputSS + '/>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>转移密码：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:100px">';
    str += '<input name="DomainPwd" id="DomainPwd" onblur="aiMing_keyUpCheck(this)" ' + inputSS + '/>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += '</table>';
    str += '</div>';
    str += '<div id="TransferPrice" style="margin-left:180px;margin-top:40px;">'
    str += '<table style="border-top:solid 1px #444;">';
    str += '<tr style="border-bottom:solid 1px #444;height:30px;line-height:30px;">';
    str += '<td width="130" style="text-align:center;border-left:solid 1px #444;"><b>域名类型</b>';
    str += '</td>';
    str += '<td width="130" style="text-align:center;border-left:solid 1px #444;border-right:solid 1px #444;"><b>转入价格(元/年)</b>';
    str += '</td>';
    str += '<td width="130" style="text-align:center;border-right:solid 1px #444;"><b>续费价格(元/年)</b>';
    str += '</td>';
    //    str += '<td width="130" style="text-align:center;border-right:solid 1px #444;"><b>选择域名类型</b>';
    //    str += '</td>';
    str += '</tr>';

    var vdomain = productData[0].pconfig.vdomain.split('_');
    var vrenewPrice = productData[0].pconfig.vrenewPrice.split('_');
    var vtransferPrice = productData[0].pconfig.vtransferPrice.split('_');

    for (var j = 0; j < vdomain.length; j++) {
        var domainArr = vdomain[j].split('|');
        if (domainArr[0] != 'xinwang') {
            var renewPriceArr = vrenewPrice[j].split('|');
            var transferPriceArr = vtransferPrice[j].split('|')
            for (var i = 1, len = domainArr.length; i < len; i++) {
                str += '<tr style="border-bottom:solid 1px #444;height:30px;line-height:30px;">';
                str += '<td style="padding-left:36px;border-left:solid 1px #444;"><input type="radio" class="' + domainArr[0] + '" name="radtype" value="' + domainArr[i] + '" id="' + domainArr[i] + '"/>';
                str += ' <label for="' + domainArr[i] + '">' + domainArr[i] + '</label>';
                str += '</td>';
                str += '<td style="text-align:center;border-left:solid 1px #444;border-right:solid 1px #444;">';
                str += (parseFloat(transferPriceArr[i]) * discount).toFixed(2);
                str += '</td>';
                str += '<td style="text-align:center;border-right:solid 1px #444;">';
                str += (parseFloat(renewPriceArr[i]) * discount).toFixed(2);
                str += '</td>';

                str += '</tr>';
            }
        }
    }

    str += '</table>';
    str += '</div>';
    $("#swin").html(str);
    $("#swin").dialog({ title: "域名转入服务", autoOpen: false, resizable: false, width: 800, height: 568, modal: true, buttons: { "进入下一步": function () {

        if (userData[0].umail == '0') {
            alert("您的电子邮箱无效，请在本平台填写好邮箱后再进行下一步操作！");
            return false;
        }
        //        else if (userData[0].tel == '0') {
        //            alert("您的手机号码无效，请在本平台填写好手机号码后再进行下一步操作！");
        //            return false;
        //        }

        var domainName = $("#TransferDomainName").val();
        var pwd = $("#DomainPwd").val();
        var domainType = $("input[name=radtype]:checked");
        var provider = '';
        if (domainName.length <= 0) {
            alert("请填写域名名称！");
            return false;
        } else if (domainName.indexOf(".") > -1) {
            alert("域名名称不能包含域名后缀！");
            return false;
        } else if (pwd.length <= 5) {
            alert("密码长度不符合要求！");
            return false;
        }
        else if (domainType.length <= 0) {
            alert("请选择域名类型！");
            return false;
        } else {
            provider = domainType.attr('class');
            domainType = domainType.val();
        }
        gotoTransferDomain(domainName, domainType, pwd, provider, 0);
    }, "关 闭": function () {
        $(this).dialog("close");
    }
    }
    }).dialog("open");
}




function getPriceByType(domainType, priceType) {
    var vdomain = productData[0].pconfig.vdomain.split('_');
    var vArrPrice = [];
    if (priceType == 'reg') {
        vArrPrice = productData[0].pconfig.vregPrice.split('_');
    }
    else if (priceType == 'renew') {
        vArrPrice = productData[0].pconfig.vrenewPrice.split('_');
    }
    else if (priceType == 'transfer') {
        vArrPrice = productData[0].pconfig.vtransferPrice.split('_');
    }
    for (var j = 0; j < vdomain.length; j++) {
        var domainArr = vdomain[j].split('|');
        for (var i = 1, len = domainArr.length; i < len; i++) {
            if (domainArr[i].toLowerCase() == domainType.toLowerCase()) {
                return vArrPrice[j].split('|')[i];

            }
        }
    }
    return 0; //找不到返回0
}

function setRegYear() {
    var yNum = $("#regYear").val();
    $("#yearNum").val(yNum);
    var regDomain = $("#regDomainName").val();
    var rType = regDomain.substr(regDomain.indexOf("."));
    var typePrice = getPriceByType(rType, 'reg');
    normalPrice = typePrice * parseInt(yNum);
    finalPrice = normalPrice * parseInt(yNum);
    billingCycle = parseInt(yNum) * 12;
    billingMothod = 1;
    var discount = parseFloat(productData[0].discount);
    if (discount > 0) {
        //  $(".ui-dialog-buttonset").prev().find("#OrderNormalPrice").html(parseInt(yNum) * parseFloat(typePrice));
        $("#OrderNormalPrice").html(parseInt(yNum) * parseFloat(typePrice));
        typePrice = (typePrice * discount).toFixed(2);
        finalPrice = (normalPrice * discount).toFixed(2);
       // $(".ui-dialog-buttonset").prev().find("#OrderPrice").html(parseInt(yNum) * parseFloat(typePrice));
       $("#OrderPrice").html(parseInt(yNum) * parseFloat(typePrice));
    }
    else {
        //$(".ui-dialog-buttonset").prev().find("#OrderPrice").html(parseInt(yNum) * parseFloat(typePrice));
       $("#OrderPrice").html(parseInt(yNum) * parseFloat(typePrice));
    }
}



function selectAll() {
    $("input[name=domainType]").each(function () {
        $(this).attr("checked", !$(this).attr("checked"));
    });
}
function HTMLDecode(text) {
    var temp = document.createElement("div");
    temp.innerHTML = text;
    var output = temp.innerText || temp.textContent;
    temp = null;
    return output;
}

$(function () {
    $("#typeBox input").mouseover().css({ "cursor": "pointer" });
    $("#typeBox h3").mouseover().css({ "cursor": "pointer" });
    $("#typeBox tr").css({ "height": "23px", "line-height": "23px" });
    $("#typeBox tr td").css({ "width": "88px", "text-align": "left" });
    $("#type_en").css({});
    $("#type_en h3").css({ "z-index": "1", "width": "75px", "text-align": "center" }).click(function () {
        $("#type_cn h3").css({ "z-index": "1", "color": "#666666" });
        $("#type_cn div").css({ "display": "none" });
        $("#type_en h3").css({ "z-index": "3", "color": "#C00" });
        $("#type_en div").css({ "display": "block" });
        $("#EnTypeMoreBox").css("display", "none");
        $("#showMoreEnType").css("display", "block");
    });
    $("#type_en div").css({ "z-index": "2" });
    $("#type_cn").css({ "clear": "both" });
    $("#type_cn h3").css({ "color": "#666666", "width": "75px", "text-align": "center" });
    $("#type_cn h3").css({}).click(function () {
        $("#type_en h3").css({ "z-index": "1", "color": "#666666" });
        $("#type_en div").css({ "display": "none" });
        $("#type_cn h3").css({ "z-index": "3", "color": "#C00" });
        $("#type_cn div").css({ "display": "block" });
        $("#EnTypeMoreBox").css("display", "none");
        $("#showMoreEnType").css("display", "none");
    });
    $("#type_cn div").css({ "float": "left", "display": "none" });
    $("#showMoreEnType").css({ "font-size": "11px", "cursor": "pointer" });
    $("#domainPrice").css({ "clear": "both", "border": "solid 0px #ccc", "width": "500px", "padding": "0px", "padding-top": "30px", "text-align": "center", "marign": "0" });
    $("#domainPrice tr").css({ "clear": "both", "border": "solid 1px #ccc", "height": "26px", "line-height": "26px" });
    $("#domainPrice tr td").css({ "clear": "both", "border": "solid 1px #ccc", "text-align": "center" });
});