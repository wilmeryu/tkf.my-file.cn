﻿/// <reference path="jquery.min.js" />

function baseConfig() {
    $.post("?c=module&productid=" + productData[0].pid + "&show=text&todo=getconfig&t=" + new Date(), function (data) {
        var vdata = $.parseJSON(data);

        var str = '<div style="font-size:12px;color:red;margin:10px;">*产品配置提示：域名类型如：".com"、".net"、".org"，且不能重复。</div>';
        str += '<input type="hidden" name="config_vdomain" id="config_vdomain" value="' + productData[0].pconfig.vdomain + '">' +
        '<input type="hidden" name="config_vregPrice" id="config_vregPrice" value="' + productData[0].pconfig.vregPrice + '">' +
        '<input type="hidden" name="config_vrenewPrice" id="config_vrenewPrice" value="' + productData[0].pconfig.vrenewPrice + '">' +
        '<input type="hidden" name="config_vtransferPrice" id="config_vtransferPrice" value="' + productData[0].pconfig.vtransferPrice + '"><div id="params">';
        var vdomain = [], vregPrice = [], vrenewPrice = [], vtransferPrice = [];

        if (productData[0].pconfig.vdomain != undefined) {
            vdomain = productData[0].pconfig.vdomain.split('_');
            vregPrice = productData[0].pconfig.vregPrice.split('_');
            vrenewPrice = productData[0].pconfig.vrenewPrice.split('_');
            vtransferPrice = productData[0].pconfig.vtransferPrice.split('_');
        }
        var aimingcount = 0, resellerclubcount = 0, xinnetcount = 0, xinwangcount = 0;

        for (var i = 0; i < vdomain.length; i++) {
            switch (vdomain[i].split('|')[0]) {
                case 'aiming':
                    if (vdata.AiMingEnable == '1') {
                        str += getTable('爱名网', 'aiming', vdomain[i].split('|'), vregPrice[i].split('|'), vrenewPrice[i].split('|'), vtransferPrice[i].split('|'), 1);
                        aimingcount = 1;
                    }
                    break;
                case 'resellerclub':
                    if (vdata.ResellerClubEnable == '1') {
                        str += getTable('ResellerClub', 'resellerclub', vdomain[i].split('|'), vregPrice[i].split('|'), vrenewPrice[i].split('|'), vtransferPrice[i].split('|'), 1);
                        resellerclubcount = 1;
                    }
                    break;

                case 'xinnet':
                    if (vdata.XinnetEnable == '1') {
                        str += getTable('新网互联', 'xinnet', vdomain[i].split('|'), vregPrice[i].split('|'), vrenewPrice[i].split('|'), vtransferPrice[i].split('|'), 1);
                        xinnetcount = 1;
                    }
                    break;

                case 'xinwang':
                    if (vdata.XinwangEnable == '1') {
                        str += getTable('新网', 'xinwang', vdomain[i].split('|'), vregPrice[i].split('|'), vrenewPrice[i].split('|'), vtransferPrice[i].split('|'), 1);
                        xinwangcount = 1;
                    }
                    break;
            }
        }

        if (vdata.AiMingEnable == '1' && aimingcount == 0) {
            str += getTable('爱名网', 'aiming', vdomain, vregPrice, vrenewPrice, vtransferPrice, 0);
        }

        if (vdata.ResellerClubEnable == '1' && resellerclubcount == 0) {
            str += getTable('ResellerClub', 'resellerclub', vdomain, vregPrice, vrenewPrice, vtransferPrice, 0);
        }

        if (vdata.XinnetEnable == '1' && xinnetcount == 0) {
            str += getTable('新网互联', 'xinnet', vdomain, vregPrice, vrenewPrice, vtransferPrice, 0);
        }

        if (vdata.XinwangEnable == '1' && xinwangcount == 0) {
            str += getTable('新网', 'xinwang', vdomain, vregPrice, vrenewPrice, vtransferPrice, 0);
        }
        str += '</div>';

        $("#ProductConfig").html(str);
        var paramsDiv = $("#params");
        paramsDiv.accordion({
            autoHeight: false,
            collapsible: true,
            active: 0
        });

        $("input:checkbox").mouseover().css("cursor", "pointer");
        $(".domainBox").css({ "border": "solid 1px #ccc", "margin-left": "30px", "margin-top": "10px" });
        $(".domainBox tr").css({ "height": "32px", "line-height": "32px" });
        $(".domainBox tr td").css({ "border": "solid 1px #ccc" });
        $(".domainBox .tdl").css({ "text-align": "center" });
        $(".domainBox .tdl1 .t").css({ "width": "70px", "margin-top": "5px", "text-align": "center" });
        $(".domainBox .tdl2 .t").css({ "width": "90px", "margin-top": "5px", "text-align": "center" });
        $(".domainBox .tdl3 .t").css({ "width": "90px", "margin-top": "5px", "text-align": "center" });
        $(".domainBox .tdl4 .t").css({ "width": "90px", "margin-top": "5px", "text-align": "center" });
        $(".domainBox .tdl5 .submit").css({ "margin-top": "5px" });
        $(".ui-accordion-content").css("height", "100%");

    });
}
baseConfig();

function getTable(tbname, provider, vdomain, vregPrice, vrenewPrice, vtransferPrice, rowcount) {
    var str = '<h3><a href="#"><strong>' + tbname + '</strong></a></h3>' +
            '<div>';
    str += '<table class="domainBox" id="' + provider + '">';
    str += '<tr><td style="width:100px;text-align:center;" >';
    str += '<strong>域名类型</strong>';
    str += '</td>';
    str += '<td style="width:145px;text-align:center;" >';
    str += '<strong>注册价格(RMB/年)</strong>';
    str += '</td>';
    str += '<td style="width:145px;text-align:center;">';
    str += '<strong>续费价格(RMB/年)</strong>';
    str += '</td>';

    if (provider != 'xinwang') {
        str += '<td style="width:145px;text-align:center;">';
        str += '<strong>转入价格(RMB/年)</strong>';
        str += '</td>';
    }
    str += '<td style="width:120px;text-align:center;">';
    str += '<strong>操作</strong>';
    str += '</td>';
    str += '</tr>';
    if (rowcount == 1) {
        for (var i = 1; i < vdomain.length; i++) {
            str += '<tr><td class="tdl tdl1" >';
            str += '<input class="t txtdomain text" name="' + provider + '_domain' + i + '" value="' + vdomain[i] + '" />';
            str += '</td>';
            str += '<td class="tdl tdl2">';
            str += '<input class="t txtregPrice text" name="' + provider + '_regPrice' + i + '" value="' + vregPrice[i] + '" />';
            str += '</td>';
            str += '<td class="tdl tdl3">';
            str += '<input class="t txtrenewPrice text" name="' + provider + '_renewPrice' + i + '" value="' + vrenewPrice[i] + '" />';
            str += '</td>';
            if (provider != 'xinwang') {
                str += '<td class="tdl tdl4">';
                str += '<input class="t txttransferPrice text" name="' + provider + '_transferPrice' + i + '" value="' + vtransferPrice[i] + '" />';
                str += '</td>';
            } else {
                str += '<input type="hidden" class="t txttransferPrice text" name="' + provider + '_transferPrice' + i + '" value="' + vtransferPrice[i] + '" />';
            }

            str += '<td class="tdl tdl5">';
            str += '<input type="button" class="submit" onclick="deleteDomain(this)" value="删除" />';
            str += '</td>';
            str += '</tr>';
        }
    }

    str += '<tr><td class="tdl tdl1" >';
    str += '';
    str += '</td>';
    str += '<td class="tdl tdl2">';
    str += '';
    str += '</td>';
    str += '<td class="tdl tdl3">';
    str += '';
    str += '</td>';
    if (provider != 'xinwang') {
        str += '<td class="tdl tdl4">';
        str += '';
        str += '</td>';
    }
    str += '<td class="tdl tdl5">';
    str += '<input type="button" class="submit" onclick="addDomain(this,\'' + provider + '\')" value="添加" />&nbsp;&nbsp;<input type="button" class="submit" onclick="saveDomain()" value="保存" />';
    str += '</td>';
    str += '</tr>';
    str += '</table></div>';
    return str;
}
//获取重复的域名
function removeRepater(array) {
    array = array || [];
    var arr = [];
    var a = {};
    for (var i = 0; i < array.length; i++) {
        var v = array[i];
        if (a[v] == undefined) {
            a[v] = 1;
        } else arr.push(v);
    }
    return arr;
}

function saveDomain() {
    var arr = [];
    $(".txtdomain").each(function () {
        arr.push($(this).val().toLowerCase());
    });


    arr = removeRepater(arr);
    if (arr.length > 0) {
        var str = '重复的域名类型：';
        for (var i = 0; i < arr.length; i++)
            str += arr[i] + '、';
        str = str.substr(0, str.length - 1);
        str += '\n请确保域名类型的惟一性！';
        alert(str);
    } else {
        var vdomain = '';
        var vregPrice = '';
        var vrenewPrice = '';
        var vtransferPrice = '';
        var vdomainArr = [];
        //aiming|.com|.cn|.net_resellerClub|.org|.cc
        //aiming|40|30|20_resellerClub|10|20
        var isfind = false;
        $(".domainBox").each(function () {
            var vprovider = $(this).attr("id");
            if ($("#" + $(this).attr("id") + " .txtdomain").length > 0) {

                $("#" + $(this).attr("id") + " .txtdomain").each(function () {
                    vdomainArr.push($(this).val());
                    if (vprovider == "resellerclub" && $(this).val() == ".uk") isfind = true;
                });
                if (vdomain.length > 0) {
                    vdomain += '_';
                }
                vdomain += $(this).attr("id") + '|' + vdomainArr.join('|');
                vdomainArr.length = 0;
            }


            if ($("#" + $(this).attr("id") + " .txtregPrice").length > 0) {
                $("#" + $(this).attr("id") + " .txtregPrice").each(function () {
                    vdomainArr.push($(this).val());
                });
                if (vregPrice.length > 0) {
                    vregPrice += '_';
                }
                vregPrice += $(this).attr("id") + '|' + vdomainArr.join('|');
                vdomainArr.length = 0;
            }


            if ($("#" + $(this).attr("id") + " .txtrenewPrice").length > 0) {
                $("#" + $(this).attr("id") + " .txtrenewPrice").each(function () {
                    vdomainArr.push($(this).val());
                });
                if (vrenewPrice.length > 0) {
                    vrenewPrice += '_';
                }
                vrenewPrice += $(this).attr("id") + '|' + vdomainArr.join('|');
                vdomainArr.length = 0;
            }

            if ($("#" + $(this).attr("id") + " .txttransferPrice").length > 0) {
                $("#" + $(this).attr("id") + " .txttransferPrice").each(function () {
                    vdomainArr.push($(this).val());
                });
                if (vtransferPrice.length > 0) {
                    vtransferPrice += '_';
                }
                vtransferPrice += $(this).attr("id") + '|' + vdomainArr.join('|');
                vdomainArr.length = 0;
            }

        });
        if (isfind) {
            alert("resellerclub平台不支持后缀为.uk的域名，请删除后再保存！");
            return;
        }
        $("#config_vdomain").val(vdomain.toLowerCase());
        $("#config_vregPrice").val(vregPrice);
        $("#config_vrenewPrice").val(vrenewPrice);
        $("#config_vtransferPrice").val(vtransferPrice);
        alert('保存成功！');
    }


}
function addDomain(obj, provider) {
    var nowTr = $(obj).parent().parent();
    var prevTr = nowTr.prev();

    var nowId = $("#" + provider).find("tr").length - 1;
    var str = "";
    str += '<tr style="height:32px;"><td class="tdl tdl1" style="border:solid 1px #ccc;text-align:center;">';
    str += '<input class="t txtdomain text" style="width:70px;margin-top:5px;text-align:center;" name="' + provider + '_domain' + nowId + '" value="" />';
    str += '</td>';
    str += '<td class="tdl tdl2" style="border:solid 1px #ccc;text-align:center;">';
    str += '<input class="t txtregPrice text" style="width:90px;margin-top:5px;text-align:center;" name="' + provider + '_regPrice' + nowId + '" value="" />';
    str += '</td>';
    str += '<td class="tdl tdl3" style="border:solid 1px #ccc;text-align:center;">';
    str += '<input class="t txtrenewPrice text" style="width:90px;margin-top:5px;text-align:center;" name="' + provider + '_renewPrice' + nowId + '" value="" />';
    str += '</td>';
    if (provider != 'xinwang') {
        str += '<td class="tdl tdl4" style="border:solid 1px #ccc;text-align:center;">';
        str += '<input class="t txttransferPrice text" style="width:90px;margin-top:5px;text-align:center;" name="' + provider + '_transferPrice' + nowId + '" value="" />';
        str += '</td>';
    } else {       
        str += '<input type="hidden" class="t txttransferPrice text" style="width:90px;margin-top:5px;text-align:center;" name="' + provider + '_transferPrice' + nowId + '" value="-1"/>';
    }
    str += '<td class="tdl tdl5" style="border:solid 1px #ccc;text-align:center;">';
    str += '<input type="button" class="submit" style="margin-top:5px;" onclick="deleteDomain(this,\'' + provider + '\')" value="删除" />';
    str += '</td>';
    str += '</tr>';
    prevTr.after(str);

}

function deleteDomain(obj, provider) {
    var nowObj = $(obj).parent().parent();
    nowObj.remove();
}