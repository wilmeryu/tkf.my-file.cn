﻿function resellerclub_regDomain(domainType, domainName) {
    //var domainName = $.trim($("#domainName").val());
    var domain = domainName + domainType;
    $("#suwin").dialog({ title: "域名系统正在检查你的账户信息", autoOpen: false, resizable: false, width: 400, height: 280, modal: true, buttons: { "取 消": function () {
        $(this).dialog("close");
    }
    }
    }).dialog("open");
    var str = '';
    str += '<div style="width:100%; margin:0 auto; text-align:center; padding-top:50px;"><b>正在检查你的账户</b><br><br>';
    str += '<img src="files/images/loading.gif" />';
    str += '</div>';
    $("#suwin").html(str);
    if (userData[0].uconfig.mail_verified != '1') {
        $("#suwin").html("您的邮箱还没经过验证！");
        return;
    }

    var email = userData[0].umail;
    var url = "?c=module&productid=" + productData[0].pid + "&show=text&todo=resellerclub_checkUserAccount&email=" + email + "&t=" + new Date();
    $.get(url, function (data) {
        var ChkFlag = data.substr(0, data.indexOf("|"));
        switch (ChkFlag) {
            case "To RegDomain":
                $("#suwin").dialog("close");
                switch (domainType) {
                    case ".us":
                        resellerclub_regDomain_US(domain, data.split('|')[1], data.split('|')[2]);
                        break;
                    case ".ru":
                        resellerclub_regDomain_RU(domain, data.split('|')[1], data.split('|')[2]);
                        break;
                    case ".asia":
                        resellerclub_regDomain_ASIA(domain, data.split('|')[1], data.split('|')[2]);
                        break;
                    default:
                        resellerclub_regDomain_Common(domain, data.split('|')[1], data.split('|')[2]);
                        break;
                }
                break;
            case "Need Regist Account":
                $("#suwin").dialog("close");
                switch (domainType) {
                    case ".us":
                        resellerclub_regUserAccount_US(domain);
                        break;
                    case ".ru":
                        resellerclub_regUserAccount_RU(domain);
                        break;
                    case ".asia":
                        resellerclub_regUserAccount_ASIA(domain);
                        break;
                    default:
                        resellerclub_regUserAccount(domain);
                        break;
                }
                break;
            default:
                $("#suwin").html("返回格式错误,请联系代理或技术支持人员！错误代码：" + data);
                break;
        }
    });
}

function resellerclub_regUserAccount_US(domain) {
    var domainName = domain;
    $("#swin").dialog({ title: "注册账户信息", autoOpen: false, resizable: false, width: 860, height: 600, modal: true, buttons: { "注册账户": function () {
        resellerclub_gotoRegUserAccount_US(domainName);
    }, "关 闭": function () {
        $(this).dialog("close");
    }
    }
    }).dialog("open");
    var str = '';
    var tr_td_SS = '<tr style="height:29px;line-height:29px;border-bottom:1px dashed #ddd;"><td style="width:150px;text-align:right;">';
    var inputSS = 'class="text" style="margin-top:4px;"';
    str += '<h3 style="padding-left:80px;height:40px;font-size:16px;">填写您的ResellerClub账户信息 <b style="color:red;font-size:12px;font-weight:normal;word-spacing: 5px;"> ( 注意：请认真填写下面的信息，只能输入英文！)</b></h3>';
    str += '<div style="padding-left:170px;">';
    str += '<table style="width:460px;">';
    str += tr_td_SS + '<b>账户名：</b>';
    str += '</td>';
    str += '<td style="text-align:left;"><input type="hidden" id="regUserName" value="' + userData[0].umail + '" />';
    str += userData[0].umail;
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>联系人：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="name" id="name" onfocus="keyFocus(this)" onblur="keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;width:150px;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>注册公司：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="company" id="company" onfocus="keyFocus(this)" onblur="keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;width:150px;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>国家：</b>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '<select name="country" id="country" style="cursor:pointer;margin-top:4px;">' +
        '<option value="AU">Australia</option>' +
        '<option value="CA">Canada</option>' +
        '<option value="CN" selected="selected">China</option>' +
        '<option value="CX">Christmas Island</option>' +
        '<option value="DK">Denmark</option>' +
        '<option value="DJ">Djibouti</option>' +
        '<option value="DM">Dominica</option>' +
        '<option value="DO">Dominican Republic</option>' +
        '<option value="TP">East Timor</option>' +
        '<option value="FR">France</option>' +
        '<option value="IN">India</option>' +
        '<option value="JP">Japan</option>' +
        '<option value="MA">Morocco</option>' +
        '<option value="NZ">New Zealand</option>' +
        '<option value="OM">Oman</option>' +
        '<option value="RU">Russia</option>' +
        '<option value="SB">Solomon Islands</option>' +
        '<option value="SO">Somalia</option>' +
        '<option value="ZA">South Africa</option>' +
        '<option value="ES">Spain</option>' +
        '<option value="LK">Sri Lanka</option>' +
        '<option value="SD">Sudan</option>' +
        '<option value="TW">Taiwan</option>' +
        '<option value="US">United States</option>';
    str += '</select>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>省份：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="province" id="province" onfocus="resellerclub_keyFocus(this)" onblur="resellerclub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 省/市</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>城市：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="city" id="city" onfocus="resellerclub_keyFocus(this)" onblur="resellerclub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 市/区</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>地址：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="address-line-1" id="address-line-1" onblur="resellerclub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>邮编：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="zipcode" id="zipcode" onblur="resellerclub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>联系电话：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="phone-cc" id="phone-cc" value="086" class="text" style="margin-top:4px;width:34px;">';
    str += '+<input name="phone" id="phone" style="margin-top:4px;width:145px;" class="text">';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 如：086+12345678</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>语言：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<select name="lang-pref" id="lang-pref" style="cursor:pointer;margin-top:4px;">' +
           '<option value="ch" style="cursor:pointer;">CN</option>' +
           '<option value="en"  selected="selected" style="cursor:pointer;">EN</option>';
    str += '</select>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>域名用途：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:360px;" colspan="2">';
    str += '';
    str += '<input type="radio" name="Purpose" id="p1" checked="checked" value="P1"><label for="p1">盈利的商务组织</label>';
    str += '</br>';
    str += '<input type="radio" name="Purpose" id="p2" value="P2"><label for="p2">非盈利交易，组织等</label>';
    str += '</br>';
    str += '<input type="radio" name="Purpose" id="p3"  value="P3"><label for="p3">个人用途</label>';
    str += '</br>';
    str += '<input type="radio" name="Purpose" id="p4"  value="P4"><label for="p4">教育用途</label>';
    str += '</br>';
    str += '<input type="radio" name="Purpose" id="p5"  value="P5"><label for="p5">政府用途</label>';
    str += '';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>联系人类别：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:360px;" colspan="2">';
    str += '<input type="radio" checked="checked" name="NexusCategory" value="C11" id="nc1">';
    str += '<label for="nc1">美国公民自然人</label>';
    str += '</br>';
    str += '<input type="radio" name="NexusCategory" value="C12" id="nc2">';
    str += '<label for="nc2">美国永久居民自然人</label>';
    str += '</br>';
    str += '<input type="radio" name="NexusCategory" value="C21" id="nc3">';
    str += '<label for="nc3">总部设在美国的组织或公司—在美国领土上已成立的组织或公司或在美国法律下组建的组织</label>';
    str += '</br>';
    str += '<input type="radio" name="NexusCategory" value="C31" id="nc4">';
    str += '<label for="nc4">外国个体或组织—在美国进行道德和法律允许范围内的活动，如:销售产品、服务、商务交易、非商业性质、非盈利等</label>';
    str += '</br>';
    str += '<input type="radio" name="NexusCategory" value="C32" id="nc5">';
    str += '<label for="nc5">个体 — 在美国拥有办公室、物业</label>';
    str += '</br>';
    str += '</td>';
    str += '</tr>';
    str += '</table>';
    str += '</div>';
    $("#swin").html(str);
}
function resellerclub_regUserAccount_ASIA(domain) {
    var domainName = domain;
    $("#swin").dialog({ title: "注册账户信息", autoOpen: false, resizable: false, width: 860, height: 600, modal: true, buttons: { "注册账户": function () {
        resellerclub_gotoRegUserAccount_ASIA(domainName);
    }, "关 闭": function () {
        $(this).dialog("close");
    }
    }
    }).dialog("open");
    var str = '';
    var tr_td_SS = '<tr style="height:29px;line-height:29px;border-bottom:1px dashed #ddd;"><td style="width:150px;text-align:right;">';
    var inputSS = 'class="text" style="margin-top:4px;"';
    str += '<h3 style="padding-left:80px;height:40px;font-size:16px;">填写您的ResellerClub账户信息 <b style="color:red;font-size:12px;font-weight:normal;word-spacing: 5px;"> ( 注意：请认真填写下面的信息，只能输入英文！)</b></h3>';
    str += '<div style="padding-left:170px;">';
    str += '<table style="width:460px;">';
    str += tr_td_SS + '<b>账户名：</b>';
    str += '</td>';
    str += '<td style="text-align:left;"><input type="hidden" id="regUserName" value="' + userData[0].umail + '" />';
    str += userData[0].umail;
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>联系人：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="name" id="name" onfocus="resellerclub_keyFocus(this)" onblur="resellerclub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;width:150px;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>注册公司：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="company" id="company" onfocus="resellerclub_keyFocus(this)" onblur="resellerclub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;width:150px;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>国家：</b>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '<select name="country" id="country" style="cursor:pointer;margin-top:4px;">' +
        '<option value="AU">Australia</option>' +
        '<option value="CA">Canada</option>' +
        '<option value="CN" selected="selected">China</option>' +
        '<option value="CX">Christmas Island</option>' +
        '<option value="DK">Denmark</option>' +
        '<option value="DJ">Djibouti</option>' +
        '<option value="DM">Dominica</option>' +
        '<option value="DO">Dominican Republic</option>' +
        '<option value="TP">East Timor</option>' +
        '<option value="FR">France</option>' +
        '<option value="IN">India</option>' +
        '<option value="JP">Japan</option>' +
        '<option value="MA">Morocco</option>' +
        '<option value="NZ">New Zealand</option>' +
        '<option value="OM">Oman</option>' +
        '<option value="RU">Russia</option>' +
        '<option value="SB">Solomon Islands</option>' +
        '<option value="SO">Somalia</option>' +
        '<option value="ZA">South Africa</option>' +
        '<option value="ES">Spain</option>' +
        '<option value="LK">Sri Lanka</option>' +
        '<option value="SD">Sudan</option>' +
        '<option value="TW">Taiwan</option>' +
        '<option value="US">United States</option>';
    str += '</select>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>省份：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="province" id="province" onfocus="resellerclub_keyFocus(this)" onblur="resellerclub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 省/市</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>城市：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="city" id="city" onfocus="resellerclub_keyFocus(this)" onblur="resellerclub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 市/区</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>地址：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="address-line-1" id="address-line-1" onblur="resellerclub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>邮编：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="zipcode" id="zipcode" onblur="resellerclub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>联系电话：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="phone-cc" id="phone-cc" value="086" class="text" style="margin-top:4px;width:34px;">';
    str += '+<input name="phone" id="phone" style="margin-top:4px;width:115px;" class="text">';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 如：086+12345678</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>语言：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<select name="lang-pref" id="lang-pref" style="cursor:pointer;margin-top:4px;">' +
           '<option value="ch" style="cursor:pointer;">CN</option>' +
           '<option value="en"  selected="selected" style="cursor:pointer;">EN</option>';
    str += '</select>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>法律实体：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:360px;" colspan="2">';
    str += '<select  name="legalentitytype" id="legalentitytype" style="cursor:pointer;margin-top:4px;">';
    str += '<option value="naturalPerson" style="cursor:pointer;">自然人</option>';
    str += '<option value="corporation" style="cursor:pointer;">公司</option>';
    str += '<option value="cooperative" style="cursor:pointer;">合作社</option>';
    str += '<option value="partnership" style="cursor:pointer;">合伙企业</option>';
    str += '<option value="government" style="cursor:pointer;">政府机构</option>';
    str += '<option value="politicalParty" style="cursor:pointer;">政党</option>';
    str += '<option value="society" style="cursor:pointer;">社团</option>';
    str += '<option value="institution" style="cursor:pointer;">公共机构</option>';
    str += '</select>';
    str += '';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>证明文件类型：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:360px;" colspan="2">';
    str += '<select  name="identform" id="identform" style="cursor:pointer;margin-top:4px;">';
    str += '<option value="passport" style="cursor:pointer;">护照</option>';
    str += '<option value="certificate" style="cursor:pointer;">证书</option>';
    str += '<option value="legislation" style="cursor:pointer;">法规</option>';
    str += '<option value="societyRegistry" style="cursor:pointer;">社团注册表</option>';
    str += '<option value="politicalPartyRegistry" style="cursor:pointer;">政党注册表</option>';
    str += '</select>';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>文件证明号码：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="identnumber" id="identnumber" onblur="resellerclub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += '</table>';
    str += '</div>';
    $("#swin").html(str);
}

function resellerclub_gotoRegUserAccount_US(domainNameStr) {
    var name = $("#name"), company = $("#company"), province = $("#province"), city = $("#city"), addressline1 = $("#address-line-1");
    var zipcode = $("#zipcode"), phonecc = $("#phone-cc"), phone = $("#phone");
    var pObj = document.getElementsByName("Purpose");
    var PurposeValue;
    for (var i = 0; i < pObj.length; i++) {
        if (pObj[i].checked == "checked" || pObj[i].checked == true) {
            PurposeValue = pObj[i].value;
            break;
        }
    }
    var ncObj = document.getElementsByName("NexusCategory");
    var NexusCategoryValue;
    for (var i = 0; i < ncObj.length; i++) {
        if (ncObj[i].checked == "checked" || ncObj[i].checked == true) {
            NexusCategoryValue = ncObj[i].value;
            break;
        }
    }
    if ($.trim(name.val()) == "") {
        name.parent().next("td").html("<b style='color:red;'>*联系人不能为空！</span>");
        name.focus();
        return false;
    }
    if ($.trim(company.val()) == "") {
        company.parent().next("td").html("<b style='color:red;'>*公司不能为空！</span>");
        company.focus();
        return false;
    } else {
        if ($.trim(company.val()).indexOf(" ") < 0) {
            company.parent().next("td").html("<b style='color:red;'>*公司必需至少两个单词！</span>");
            company.focus();
            return false;
        }
    }
    if ($.trim(province.val()) == "") {
        province.parent().next("td").html("<b style='color:red;'>*省份不能为空！</span>");
        province.focus();
        return false;
    }

    if ($.trim(city.val()) == "") {
        city.parent().next("td").html("<b style='color:red;'>*城市不能为空！</span>");
        city.focus();
        return false;
    }

    if ($.trim(addressline1.val()) == "") {
        addressline1.parent().next("td").html("<b style='color:red;'>*街道地址不能为空！</span>");
        addressline1.focus();
        return false;
    }

    if ($.trim(zipcode.val()) == "") {
        zipcode.parent().next("td").html("<b style='color:red;'>*邮编不能为空！</span>");
        zipcode.focus();
        return false;
    }
    if ($.trim(phonecc.val()) == "") {
        phonecc.parent().next("td").html("<b style='color:red;'>*国家的编号不能为空！</span>");
        phonecc.focus();
        return false;
    }
    if ($.trim(phone.val()) == "") {
        phone.parent().next("td").html("<b style='color:red;'>*电话号码不能为空！</span>");
        phone.focus();
        return false;
    }
    else {
        if ($.trim(phone.val()).length < 4 || $.trim(phone.val()).length > 12) {
            phone.parent().next("td").html("<b style='color:red;'>*电话号码长度不对！</span>");
            phone.focus();
            return false;
        } else {
            phone.parent().next("td").html("");
        }
    }
    $("#suwin").dialog({ title: "提交注册账户信息", autoOpen: false, resizable: false, width: 300, height: 220, modal: true, buttons: { "关 闭": function () {
        $(this).dialog("close");
    }
    }
    }).dialog("open");
    var str = '';
    str += '<div style="width:100%; margin:0 auto; text-align:center; padding-top:30px;">提交中，请稍后...<br>';
    str += '<img src="files/images/loading.gif" />';
    str += '</div>';
    $("#suwin").html(str);
    var country = $("#country").val();
    var langpref = $("#lang-pref").val();
    var urlapi = '?c=module&productid=' + productData[0].pid + '&show=text&todo=resellerclub_regUserAccount_US' +
                '&userName=' + userData[0].umail + '&name=' + $.trim(name.val()) + '&tel=' + userData[0].tel +
                '&country=' + $.trim(country) + '&province=' + $.trim(province.val()) +
                '&city=' + $.trim(city.val()) + '&addressline1=' + $.trim(addressline1.val()) +
                '&zipcode=' + $.trim(zipcode.val()) + '&phonecc=' + $.trim(phonecc.val()) +
                '&phone=' + $.trim(phone.val()) + '&company=' + $.trim(company.val()) +
                '&langpref=' + $.trim(langpref) + "&NexusCategory=" + NexusCategoryValue + "&Purpose=" + PurposeValue;

    $.get(urlapi, function (data) {
        var flag = data.split('|')[0];
        switch (flag) {
            case "ok":
                $("#suwin div").html("<b style='color:green;'>注册账户成功！<br/>即将准备填写域名注册信息</b>");
                setTimeout(function () {
                    $("#suwin").dialog("close");
                    $("#swin").dialog("close");
                    resellerclub_regDomain_US(domainNameStr, data.split('|')[1], data.split('|')[2]);
                }, 2000);
                break;
            case "Exist":
                $("#suwin div").html("<b style='color:red;'>你已经注册过了，请刷新页面！</b>");
                setTimeout(function () {
                    window.location.reload();
                    $("#suwin").dialog("close");
                    $("#swin").dialog("close");
                }, 1000);
                break;
            case "Company is invalid":
                $("#suwin div").html("<b style='color:red;'>公司输入非法（*英文）</b>");
                break;
            case "CC is invalid":
                $("#suwin div").html("<b style='color:red;'>国家编号输入有误</b>");
                break;
            case "Mobile invalid":
                $("#suwin div").html("<b style='color:red;'>你的账户手机号码设置有误！</b>");
                break;
            case "State is invalid":
                $("#suwin div").html("<b style='color:red;'>省份输入非法（*英文）</b>");
                break;
            case "City is invalid":
                $("#suwin div").html("<b style='color:red;'>城市输入非法（*英文）</b>");
                break;
            case "Name is invalid":
                $("#suwin div").html("<b style='color:red;'>联系人输入非法（*英文）</b>");
                break;
            case "Telephone No. is invalid":
                $("#suwin div").html("<b style='color:red;'>联系电话输入有误（*区号）</b>");
                break;
            default:
                $("#suwin").html(data);
                break;
        }
    });
}
function resellerclub_gotoRegUserAccount_RU(domainNameStr) {
    var name = $("#name"), company = $("#company"), province = $("#province"), city = $("#city"), addressline1 = $("#address-line-1");
    var zipcode = $("#zipcode"), phonecc = $("#phone-cc"), phone = $("#phone");

    if ($.trim(name.val()) == "") {
        name.parent().next("td").html("<b style='color:red;'>*联系人不能为空！</span>");
        name.focus();
        return false;
    }
    if ($.trim(company.val()) == "") {
        company.parent().next("td").html("<b style='color:red;'>*公司不能为空！</span>");
        company.focus();
        return false;
    } else {
        if ($.trim(company.val()).indexOf(" ") < 0) {
            company.parent().next("td").html("<b style='color:red;'>*公司必需至少两个单词！</span>");
            company.focus();
            return false;
        }
    }
    if ($.trim(province.val()) == "") {
        province.parent().next("td").html("<b style='color:red;'>*省份不能为空！</span>");
        province.focus();
        return false;
    }

    if ($.trim(city.val()) == "") {
        city.parent().next("td").html("<b style='color:red;'>*城市不能为空！</span>");
        city.focus();
        return false;
    }

    if ($.trim(addressline1.val()) == "") {
        addressline1.parent().next("td").html("<b style='color:red;'>*街道地址不能为空！</span>");
        addressline1.focus();
        return false;
    }

    if ($.trim(zipcode.val()) == "") {
        zipcode.parent().next("td").html("<b style='color:red;'>*邮编不能为空！</span>");
        zipcode.focus();
        return false;
    }
    if ($.trim(phonecc.val()) == "") {
        phonecc.parent().next("td").html("<b style='color:red;'>*国家的编号不能为空！</span>");
        phonecc.focus();
        return false;
    }
    else {
        if ($.trim(phonecc.val()).length > 1) {
            phonecc.parent().next("td").html("<b style='color:red;'>*国家的编号不多于1位！</span>");
            phonecc.focus();
            return false;
        }
    }
    if ($.trim(phone.val()) == "") {
        phone.parent().next("td").html("<b style='color:red;'>*电话号码不能为空！</span>");
        phone.focus();
        return false;
    }
    else {
        if ($.trim(phone.val()).length != 7) {
            phone.parent().next("td").html("<b style='color:red;'>*电话号码长度不对！</span>");
            phone.focus();
            return false;
        } else {
            phone.parent().next("td").html("");
        }
    }
    $("#suwin").dialog({ title: "提交注册账户信息", autoOpen: false, resizable: false, width: 300, height: 220, modal: true, buttons: { "关 闭": function () {
        $(this).dialog("close");
    }
    }
    }).dialog("open");
    var str = '';
    str += '<div style="width:100%; margin:0 auto; text-align:center; padding-top:30px;">提交中，请稍后...<br>';
    str += '<img src="files/images/loading.gif" />';
    str += '</div>';
    $("#suwin").html(str);
    var country = $("#country").val();
    var langpref = $("#lang-pref").val();
    var urlapi = '?c=module&productid=' + productData[0].pid + '&show=text&todo=resellerclub_regUserAccount_RU' +
                '&userName=' + userData[0].umail + '&name=' + $.trim(name.val()) + '&tel=' + userData[0].tel +
                '&country=' + $.trim(country) + '&province=' + $.trim(province.val()) +
                '&city=' + $.trim(city.val()) + '&addressline1=' + $.trim(addressline1.val()) +
                '&zipcode=' + $.trim(zipcode.val()) + '&phonecc=' + $.trim(phonecc.val()) +
                '&phone=' + $.trim(phone.val()) + '&company=' + $.trim(company.val()) +
                '&langpref=' + $.trim(langpref);

    $.get(urlapi, function (data) {
        var flag = data.split('|')[0];
        switch (flag) {
            case "ok":
                $("#suwin div").html("<b style='color:green;'>注册账户成功！</b>");
                setTimeout(function () {
                    $("#suwin").dialog("close");
                    $("#swin").dialog("close");
                    resellerclub_regDomain_RU(domainNameStr, data.split('|')[1], data.split('|')[2]);
                }, 2000);
                break;
            case "Exist":
                $("#suwin div").html("<b style='color:red;'>你已经注册过了，请刷新页面！</b>");
                setTimeout(function () {
                    window.location.reload();
                    $("#suwin").dialog("close");
                    $("#swin").dialog("close");
                }, 1000);
                break;
            case "Company is invalid":
                $("#suwin div").html("<b style='color:red;'>公司输入非法（*英文）</b>");
                break;
            case "CC is invalid":
                $("#suwin div").html("<b style='color:red;'>国家编号输入有误</b>");
                break;
            case "Mobile invalid":
                $("#suwin div").html("<b style='color:red;'>你的账户手机号码设置有误！</b>");
                break;
            case "State is invalid":
                $("#suwin div").html("<b style='color:red;'>省份输入非法（*英文）</b>");
                break;
            case "City is invalid":
                $("#suwin div").html("<b style='color:red;'>城市输入非法（*英文）</b>");
                break;
            case "Name is invalid":
                $("#suwin div").html("<b style='color:red;'>联系人输入非法（*英文）</b>");
                break;
            case "Telephone No. is invalid":
                $("#suwin div").html("<b style='color:red;'>联系电话输入有误（*区号）</b>");
                break;
            default:
                $("#suwin").html(data);
                break;
        }
    });
}

function resellerclub_gotoRegUserAccount_ASIA(domainNameStr) {
    var name = $("#name"), company = $("#company"), province = $("#province"), city = $("#city"), addressline1 = $("#address-line-1");
    var zipcode = $("#zipcode"), phonecc = $("#phone-cc"), phone = $("#phone"), identnumber = $("#identnumber");

    var legalentitytype = $("#legalentitytype").val();
    var identform = $("#identform").val();

    if ($.trim(name.val()) == "") {
        name.parent().next("td").html("<b style='color:red;'>*联系人不能为空！</span>");
        name.focus();
        return false;
    }
    if ($.trim(company.val()) == "") {
        company.parent().next("td").html("<b style='color:red;'>*公司不能为空！</span>");
        company.focus();
        return false;
    } else {
        if ($.trim(company.val()).indexOf(" ") < 0) {
            company.parent().next("td").html("<b style='color:red;'>*公司必需至少两个单词！</span>");
            company.focus();
            return false;
        }
    }
    if ($.trim(province.val()) == "") {
        province.parent().next("td").html("<b style='color:red;'>*省份不能为空！</span>");
        province.focus();
        return false;
    }

    if ($.trim(city.val()) == "") {
        city.parent().next("td").html("<b style='color:red;'>*城市不能为空！</span>");
        city.focus();
        return false;
    }

    if ($.trim(addressline1.val()) == "") {
        addressline1.parent().next("td").html("<b style='color:red;'>*街道地址不能为空！</span>");
        addressline1.focus();
        return false;
    }

    if ($.trim(zipcode.val()) == "") {
        zipcode.parent().next("td").html("<b style='color:red;'>*邮编不能为空！</span>");
        zipcode.focus();
        return false;
    }
    if ($.trim(phonecc.val()) == "") {
        phonecc.parent().next("td").html("<b style='color:red;'>*国家的编号不能为空！</span>");
        phonecc.focus();
        return false;
    }
    if ($.trim(phone.val()) == "") {
        phone.parent().next("td").html("<b style='color:red;'>*电话号码不能为空！</span>");
        phone.focus();
        return false;
    }

    if ($.trim(identnumber.val()) == "") {
        identnumber.parent().next("td").html("<b style='color:red;'>*不能为空！</span>");
        identnumber.focus();
        return false;
    }

    else {
        if ($.trim(phone.val()).length < 4 || $.trim(phone.val()).length > 12) {
            phone.parent().next("td").html("<b style='color:red;'>*电话号码长度不对！</span>");
            phone.focus();
            return false;
        } else {
            phone.parent().next("td").html("");
        }
    }
    $("#suwin").dialog({ title: "提交注册账户信息", autoOpen: false, resizable: false, width: 300, height: 220, modal: true, buttons: { "关 闭": function () {
        $(this).dialog("close");
    }
    }
    }).dialog("open");
    var str = '';
    str += '<div style="width:100%; margin:0 auto; text-align:center; padding-top:30px;">提交中，请稍后...<br>';
    str += '<img src="files/images/loading.gif" />';
    str += '</div>';
    $("#suwin").html(str);
    var country = $("#country").val();
    var langpref = $("#lang-pref").val();
    var urlapi = '?c=module&productid=' + productData[0].pid + '&show=text&todo=resellerclub_regUserAccount_ASIA' +
                '&userName=' + userData[0].umail + '&name=' + $.trim(name.val()) + '&tel=' + userData[0].tel +
                '&country=' + $.trim(country) + '&province=' + $.trim(province.val()) +
                '&city=' + $.trim(city.val()) + '&addressline1=' + $.trim(addressline1.val()) +
                '&zipcode=' + $.trim(zipcode.val()) + '&phonecc=' + $.trim(phonecc.val()) +
                '&phone=' + $.trim(phone.val()) + '&company=' + $.trim(company.val()) +
                '&langpref=' + $.trim(langpref) + "&legalentitytype=" + legalentitytype +
                '&identform=' + identform + '&identnumber=' + $.trim(identnumber.val());

    $.get(urlapi, function (data) {
        var flag = data.split('|')[0];
        switch (flag) {
            case "ok":
                $("#suwin div").html("<b style='color:green;'>注册账户成功！</b>");
                setTimeout(function () {
                    $("#suwin").dialog("close");
                    $("#swin").dialog("close");
                    resellerclub_regDomain_ASIA(domainNameStr, data.split('|')[1], data.split('|')[2]);
                }, 1000);
                break;
            case "Exist":
                $("#suwin div").html("<b style='color:red;'>你已经注册过了，请刷新页面！</b>");
                setTimeout(function () {
                    window.location.reload();
                    $("#suwin").dialog("close");
                    $("#swin").dialog("close");
                }, 1000);
                break;
            case "Company is invalid":
                $("#suwin div").html("<b style='color:red;'>公司输入非法（*英文）</b>");
                break;
            case "CC is invalid":
                $("#suwin div").html("<b style='color:red;'>国家编号输入有误</b>");
                break;
            case "Mobile invalid":
                $("#suwin div").html("<b style='color:red;'>你的账户手机号码设置有误！</b>");
                break;
            case "State is invalid":
                $("#suwin div").html("<b style='color:red;'>省份输入非法（*英文）</b>");
                break;
            case "City is invalid":
                $("#suwin div").html("<b style='color:red;'>城市输入非法（*英文）</b>");
                break;
            case "Name is invalid":
                $("#suwin div").html("<b style='color:red;'>联系人输入非法（*英文）</b>");
                break;
            case "Telephone No. is invalid":
                $("#suwin div").html("<b style='color:red;'>联系电话输入有误（*区号）</b>");
                break;
            default:
                $("#suwin").html(data);
                break;
        }
    });
}


function resellerclub_regDomain_US(domainName, UID, ContactUserID) {
    var getUserContactByCIDURL = '?c=module&productid=' + productData[0].pid + '&show=text&todo=resellerclub_getUserContactByCID_US' +
                '&CID=' + ContactUserID + "&customerID=" + UID + "&t=" + new Date();
    $("#swin").dialog({ title: "【" + domainName + "】域名注册信息", autoOpen: false, resizable: false, width: 830, height: 590, modal: true, buttons: { "立即注册": function () {
        ContactUserID = $("#selectCName").val();
        resellerclub_gotoRegDomain(domainName, UID, ContactUserID);
    }, "关 闭": function () {
        $(this).dialog("close");
    }
    }
    }).dialog("open");
    $("#swin").html('<div style="width:100%;text-align:center; padding-top:50px;">Loading...<br><img src="files/images/loading.gif" /></div>');
    $.get(getUserContactByCIDURL, function (data) {
        if ($.trim(data) == "") {
            var reg = '';
            reg += '<div style="text-align:center;margin-top:30px;">';
            reg += '<h6 style="text-align:center;margin:20px auto;">抱歉，注册美国域名需要添加相应的联系人，请先添加！</h6>';
            reg += '<input type="button" value="添加联系人" class="submit" onclick="resellerclub_AddNewDomainContact_US(\'' + domainName + '\',\'' + UID + '\',\'' + ContactUserID + '\')" />';
            reg += '</div>';
            $("#swin").html(reg);
            return false;
        }
        if (data.indexOf("company") < -1) {
            var reg = '';
            reg += '<div style="text-align:center;margin-top:30px;">';
            reg += '<h6 style="text-align:center;margin:20px auto;">抱歉，注册美国域名需要添加相应的联系人，请先添加！</h6>';
            reg += '<input type="button" value="添加联系人" class="submit" onclick="resellerclub_AddNewDomainContact_US(\'' + domainName + '\',\'' + UID + '\',\'' + ContactUserID + '\')" />';
            reg += '</div>';
            $("#swin").html(reg);
            return false;
        }
        var cObj = data.split('|');
        var cNow = cObj[0];
        var company = cObjFindValue(cNow, "company"), country = cObjFindValue(cNow, "country");

        var name = cObjFindValue(cNow, "name"), telnocc = cObjFindValue(cNow, "telnocc");
        var zip = cObjFindValue(cNow, "zip"), contactid = cObjFindValue(cNow, "contactid");
        var city = cObjFindValue(cNow, "city"), address1 = cObjFindValue(cNow, "address1");
        var emailaddr = cObjFindValue(cNow, "emailaddr"), telno = cObjFindValue(cNow, "telno");
        var str = '';
        var tr_td_SS = '<tr style="height:29px;line-height:29px;border-bottom:1px dashed #ddd;"><td style="width:120px;text-align:right;">';
        var inputSS = 'class="text" style="margin-top:4px;width:185px;"';
        str += '<h3 style="padding-left:80px;height:40px;font-size:16px;">填写域名注册信息 <b style="color:red;font-size:12px;font-weight:normal;word-spacing: 5px;"> ( 注意：请认真填写下面的信息！)</b></h3>';
        str += '<div style="padding-left:170px;">';
        str += '<table style="width:450px;">';
        str += tr_td_SS + '<b>购买的域名：</b>';
        str += '</td>';
        str += '<td style="text-align:left;width:190px;"><input type="hidden" id="regDomainName" value="' + domainName + '" />';
        str += domainName;
        str += '</td>';
        str += '<td style="text-align:left;width:235px;">';
        str += '</td>';
        str += '</tr>';
        str += '<tr style="height:32px;line-height:32px;border-bottom:1px dashed #ddd;"><td style="width:120px;text-align:right;">';
        str += '<b>注册联系人：</b>';
        str += '</td>';
        str += '<td style="text-align:left;width:190px;">';
        str += '<select id="selectCName" name="selectCName" style="cursor:pointer;margin-top:5px;" onchange="resellerclub_selectCNameByHTML(\'' + data + '\')">';
        str += getContactInfo(cObj);
        str += '</select>';
        str += '</td>';
        str += '<td style="text-align:left;width:235px;">';
        str += '&nbsp;&nbsp;<input type="button" value="添加联系人" class="submit" onclick="resellerclub_AddNewDomainContact_US(\'' + domainName + '\',\'' + UID + '\',\'' + ContactUserID + '\')" />';
        str += '</td>';
        str += '</tr>';
        str += tr_td_SS + '<b>联系姓名：</b>';
        str += '</td>';
        str += '';
        str += '<td><span id="contactid" style="display:none;">' + contactid + '</span><span id="name">' + name + '</span>';
        str += '</td><td></td>';
        str += '</tr>';
        str += tr_td_SS + '<b>国家：</b>';
        str += '</td>';
        str += '<td>';
        str += getCountryByCode(country);
        str += '</td><td></td>';
        str += '</tr>';
        str += tr_td_SS + '<b>公司名称：</b>';
        str += '</td>';
        str += '<td><span id="company">' + company + '</span>';
        str += '</td><td></td>';
        str += '</tr>';
        str += tr_td_SS + '<b>城市：</b>';
        str += '</td>';
        str += '<td><span id="city">' + city + '</span>';
        str += '</td><td></td>';
        str += '</tr>';
        str += tr_td_SS + '<b>街道地址：</b>';
        str += '</td>';
        str += '<td><span id="address1">' + address1 + '</span>';
        str += '</td><td></td>';
        str += '</tr>';
        str += tr_td_SS + '<b>邮编：</b>';
        str += '</td>';
        str += '<td><span id="zip">' + zip + '</span>';
        str += '</td><td></td>';
        str += '</tr>';
        str += tr_td_SS + '<b>联系电话：</b>';
        str += '</td>';
        str += '<td>';
        str += '<span id="telnocc">' + telnocc + '</span>';
        str += '+<span id="telno">' + telno + '</span>';
        str += '</td><td></td>';
        str += '</tr>';
        str += tr_td_SS + '<b>电子邮箱：</b>';
        str += '</td>';
        str += '<td><span id="emailaddr">' + emailaddr + '</span>';
        str += '</td><td></td>';
        str += '</tr>';
        str += tr_td_SS + '<b>注册年限：</b>';
        str += '</td>';
        str += '<td style="text-align:left;width:190px;">';

        var priceArr = productData[0].pprice.cprice.split(',');
        str += '<select name="regYear" id="regYear" onchange="setRegYear()" style="cursor:pointer;margin-top:4px;">';
        if (priceArr[3] != 0) {
            str += '<option value="1" style="cursor:pointer;">1</option>';
        }
        if (priceArr[4] != 0) {
            str += '<option value="2" style="cursor:pointer;">2</option>';
        }
       // str += '<select name="regYear" id="regYear" onchange="setRegYear()" style="cursor:pointer;margin-top:4px;">' +
           //'<option value="1" style="cursor:pointer;">1</option><option value="2" style="cursor:pointer;">2</option> ';
        str += '</select> 年</td>';
        str += '<td style="text-align:left;width:235px;">';
        str += '</td>';
        str += '</tr>';
        str += tr_td_SS + '<b>DNS1：</b>';
        str += '</td>';
        str += '<td style="text-align:left;width:190px;">';
        str += '<input name="ns1" id="ns1" value="' + cObj[cObj.length-2] + '" onblur="resellerclub_keyUpCheck(this)" ' + inputSS + ' >';
        str += '</td>';
        str += '<td style="text-align:left;width:235px;">';
        str += '</td>';
        str += '</tr>';
        str += tr_td_SS + '<b>DNS2：</b>';
        str += '</td>';
        str += '<td style="text-align:left;width:190px;">';
        str += '<input name="ns2" id="ns2" value="' + cObj[cObj.length -1] + '" onblur="resellerclub_keyUpCheck(this)" ' + inputSS + ' >';
        str += '</td>';
        str += '<td style="text-align:left;width:235px;">';
        str += '</td>';
        str += '</tr>';
        str += '</table>';
        str += '</div>';
        $("#swin").html(str);
        $("#swin").append('<form id="OrderConfig"><div id="myStr"></div></form>');

        var rType = domainName.substr(domainName.indexOf("."));
        var discount = parseFloat(productData[0].discount);
        var myPrice = parseFloat(getPriceByType(rType, 'reg'));
        var yearNum = 1;
        var pStr = '';
        pStr += '<div style="float:left;height:44px;line-height:44px;" id="divprice"><input type="hidden" value="' + yearNum + '" id="yearNum" />';
        if (discount > 0 && discount < 1) {
            pStr += '<strong>总价格：<span style="color:blue;" id="OrderNormalPrice"><strike>' + myPrice + '</strike></span> <b style="">RMB</b>';
            myPrice = myPrice * discount;
            pStr += '<input type="hidden" value="' + myPrice + '" id="typePrice" />';
            pStr += '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
            pStr += '帐户优惠价(' + discount + '折)：<span style="color:blue;" id="OrderPrice">' + myPrice + '</span> <b style="">RMB</b></strong>';
        }
        else {
            myPrice = myPrice * discount;

            pStr += '<input type="hidden" value="' + myPrice + '" id="typePrice" />';
            pStr += '<strong>总价格：<span style="color:blue;" id="OrderPrice">' + myPrice + '</span> <b style="color:blue;">RMB</b></strong>';
        }
        pStr += '</div>';
        if ($("#divprice").length > 0) { $("#divprice").remove(); }
        //$(".ui-dialog-buttonset").before(pStr);
        $("#swin").next().before(pStr);
    })
}

function resellerclub_regDomain_RU(domainName, UID, ContactUserID) {
    var getUserContactByCIDURL = '?c=module&productid=' + productData[0].pid + '&show=text&todo=resellerclub_getUserContactByCID_RU' +
                '&CID=' + ContactUserID + "&customerID=" + UID + "&t=" + new Date();
    $("#swin").dialog({ title: "【" + domainName + "】域名注册信息", autoOpen: false, resizable: false, width: 830, height: 590, modal: true, buttons: { "立即注册": function () {
        ContactUserID = $("#selectCName").val();
        resellerclub_gotoRegDomain(domainName, UID, ContactUserID);
    }, "关 闭": function () {
        $(this).dialog("close");
    }
    }
    }).dialog("open");
    $("#swin").html('<div style="width:100%;text-align:center; padding-top:50px;">Loading...<br><img src="files/images/loading.gif" /></div>');
    $.get(getUserContactByCIDURL, function (data) {
        if (data.indexOf("company") < -1) {
            var reg = '';
            reg += '<div style="text-align:center;margin-top:30px;">';
            reg += '<h6 style="text-align:center;margin:20px auto;">抱歉，注册该域名需要添加相应的联系人，请先添加！</h6>';
            reg += '<input type="button" value="添加联系人" class="submit" onclick="resellerclub_AddNewDomainContact_RU(\'' + domainName + '\',\'' + UID + '\',\'' + ContactUserID + '\')" />';
            reg += '</div>';
            $("#swin").html(reg);
            return false;
        }
        var cObj = data.split('|');
        var cNow = cObj[0];
        var company = cObjFindValue(cNow, "company"), country = cObjFindValue(cNow, "country");
        var name = cObjFindValue(cNow, "name"), telnocc = cObjFindValue(cNow, "telnocc");
        var zip = cObjFindValue(cNow, "zip"), contactid = cObjFindValue(cNow, "contactid");
        var city = cObjFindValue(cNow, "city"), address1 = cObjFindValue(cNow, "address1");
        var emailaddr = cObjFindValue(cNow, "emailaddr"), telno = cObjFindValue(cNow, "telno");
        var str = '';
        var tr_td_SS = '<tr style="height:29px;line-height:29px;border-bottom:1px dashed #ddd;"><td style="width:120px;text-align:right;">';
        var inputSS = 'class="text" style="margin-top:4px;width:185px;"';
        str += '<h3 style="padding-left:80px;height:40px;font-size:16px;">填写域名注册信息 <b style="color:red;font-size:12px;font-weight:normal;word-spacing: 5px;"> ( 注意：请认真填写下面的信息！)</b></h3>';
        str += '<div style="padding-left:170px;">';
        str += '<table style="width:450px;">';
        str += tr_td_SS + '<b>购买的域名：</b>';
        str += '</td>';
        str += '<td style="text-align:left;width:190px;"><input type="hidden" id="regDomainName" value="' + domainName + '" />';
        str += domainName;
        str += '</td>';
        str += '<td style="text-align:left;width:235px;">';
        str += '</td>';
        str += '</tr>';
        str += '<tr style="height:32px;line-height:32px;border-bottom:1px dashed #ddd;"><td style="width:120px;text-align:right;">';
        str += '<b>注册联系人：</b>';
        str += '</td>';
        str += '<td style="text-align:left;width:190px;">';
        str += '<select id="selectCName" name="selectCName" style="cursor:pointer;margin-top:5px;" onchange="resellerclub_selectCNameByHTML(\'' + data + '\')">';
        str += getContactInfo(cObj);
        str += '</select>';
        str += '</td>';
        str += '<td style="text-align:left;width:235px;">';
        str += '&nbsp;&nbsp;<input type="button" value="添加联系人" class="submit" onclick="resellerclub_AddNewDomainContact_RU(\'' + domainName + '\',\'' + UID + '\',\'' + ContactUserID + '\')" />';
        str += '</td>';
        str += '</tr>';
        str += tr_td_SS + '<b>联系姓名：</b>';
        str += '</td>';
        str += '';
        str += '<td><span id="contactid" style="display:none;">' + contactid + '</span><span id="name">' + name + '</span>';
        str += '</td><td></td>';
        str += '</tr>';
        str += tr_td_SS + '<b>国家：</b>';
        str += '</td>';
        str += '<td>';
        str += getCountryByCode(country);
        str += '</td><td></td>';
        str += '</tr>';
        str += tr_td_SS + '<b>公司名称：</b>';
        str += '</td>';
        str += '<td><span id="company">' + company + '</span>';
        str += '</td><td></td>';
        str += '</tr>';
        str += tr_td_SS + '<b>城市：</b>';
        str += '</td>';
        str += '<td><span id="city">' + city + '</span>';
        str += '</td><td></td>';
        str += '</tr>';
        str += tr_td_SS + '<b>街道地址：</b>';
        str += '</td>';
        str += '<td><span id="address1">' + address1 + '</span>';
        str += '</td><td></td>';
        str += '</tr>';
        str += tr_td_SS + '<b>邮编：</b>';
        str += '</td>';
        str += '<td><span id="zip">' + zip + '</span>';
        str += '</td><td></td>';
        str += '</tr>';
        str += tr_td_SS + '<b>联系电话：</b>';
        str += '</td>';
        str += '<td>';
        str += '<span id="telnocc">' + telnocc + '</span>';
        str += '+<span id="telno">' + telno + '</span>';
        str += '</td><td></td>';
        str += '</tr>';
        str += tr_td_SS + '<b>电子邮箱：</b>';
        str += '</td>';
        str += '<td><span id="emailaddr">' + emailaddr + '</span>';
        str += '</td><td></td>';
        str += '</tr>';
        str += tr_td_SS + '<b>注册年限：</b>';
        str += '</td>';
        str += '<td style="text-align:left;width:190px;">';

        var priceArr = productData[0].pprice.cprice.split(',');
        str += '<select name="regYear" id="regYear" onchange="setRegYear()" style="cursor:pointer;margin-top:4px;">';
        if (priceArr[3] != 0) {
            str += '<option value="1" style="cursor:pointer;">1</option>';
        }
        if (priceArr[4] != 0) {
            str += '<option value="2" style="cursor:pointer;">2</option>';
        }

       // str += '<select name="regYear" id="regYear" onchange="setRegYear()" style="cursor:pointer;margin-top:4px;">' +
           //'<option value="1" style="cursor:pointer;">1</option><option value="2" style="cursor:pointer;">2</option>';
        str += '</select> 年 </td>';
        str += '<td style="text-align:left;width:235px;">';
        str += '</td>';
        str += '</tr>';
        str += tr_td_SS + '<b>DNS1：</b>';
        str += '</td>';
        str += '<td style="text-align:left;width:190px;">';
        str += '<input name="ns1" id="ns1" value="' + cObj[cObj.length - 2] + '" onblur="resellerclub_keyUpCheck(this)" ' + inputSS + ' >';
        str += '</td>';
        str += '<td style="text-align:left;width:235px;">';
        str += '</td>';
        str += '</tr>';
        str += tr_td_SS + '<b>DNS2：</b>';
        str += '</td>';
        str += '<td style="text-align:left;width:190px;">';
        str += '<input name="ns2" id="ns2" value="' + cObj[cObj.length - 1] + '" onblur="resellerclub_keyUpCheck(this)" ' + inputSS + ' >';
        str += '</td>';
        str += '<td style="text-align:left;width:235px;">';
        str += '</td>';
        str += '</tr>';
        str += '</table>';
        str += '</div>';
        $("#swin").html(str);
        $("#swin").append('<form id="OrderConfig"><div id="myStr"></div></form>');
        var rType = domainName.substr(domainName.indexOf("."));
        var discount = parseFloat(productData[0].discount);
        var myPrice = parseFloat(getPriceByType(rType, 'reg'));
        var yearNum = 1;
        var pStr = '';
        pStr += '<div style="float:left;height:44px;line-height:44px;" id="divprice"><input type="hidden" value="' + yearNum + '" id="yearNum" />';
        if (discount > 0 && discount < 1) {
            pStr += '<strong>总价格：<span style="color:blue;" id="OrderNormalPrice"><strike>' + myPrice + '</strike></span> <b style="">RMB</b>';
            myPrice = myPrice * discount;
            pStr += '<input type="hidden" value="' + myPrice + '" id="typePrice" />';
            pStr += '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
            pStr += '帐户优惠价(' + discount + '折)：<span style="color:blue;" id="OrderPrice">' + myPrice + '</span> <b style="">RMB</b></strong>';
        }
        else {
            myPrice = myPrice * discount;
            pStr += '<input type="hidden" value="' + myPrice + '" id="typePrice" />';
            pStr += '<strong>总价格：<span style="color:blue;" id="OrderPrice">' + myPrice + '</span> <b style="color:blue;">RMB</b></strong>';
        }
        pStr += '</div>';
        if ($("#divprice").length > 0) { $("#divprice").remove(); }
        // $(".ui-dialog-buttonset").before(pStr);
        $("#swin").next().before(pStr);
    })
}
function getContactInfo(cObj) {
    var contactname = '', str='';
    for (var i = 0; i < cObj.length; i++) {
        if (contactname != cObjFindValue(cObj[i], "name") && cObjFindValue(cObj[i], "name")!=undefined) {
            contactname = cObjFindValue(cObj[i], "name");
            str += '<option value="' + cObjFindValue(cObj[i], "contactid") + '">' + contactname + '</option>';
        }
    }
    return str;
}

function resellerclub_regDomain_ASIA(domainName, UID, ContactUserID) {
    var getUserContactByCIDURL = '?c=module&productid=' + productData[0].pid + '&show=text&todo=resellerclub_getUserContactByCID_ASIA' +
                '&CID=' + ContactUserID + "&customerID=" + UID + "&t=" + new Date();
    $("#swin").dialog({ title: "【" + domainName + "】域名注册信息", autoOpen: false, resizable: false, width: 830, height: 590, modal: true, buttons: { "立即注册": function () {
        ContactUserID = $("#selectCName").val();
        resellerclub_gotoRegDomain(domainName, UID, ContactUserID);
    }, "关 闭": function () {
        $(this).dialog("close");
    }
    }
    }).dialog("open");
    $("#swin").html('<div style="width:100%;text-align:center; padding-top:50px;">Loading...<br><img src="files/images/loading.gif" /></div>');
    $.get(getUserContactByCIDURL, function (data) {
        if (data.indexOf("company") < -1) {
            var reg = '';
            reg += '<div style="text-align:center;margin-top:30px;">';
            reg += '<h6 style="text-align:center;margin:20px auto;">抱歉，注册此类型的域名需要添加相应的联系人，请先添加！</h6>';
            reg += '<input type="button" value="添加联系人" class="submit" onclick="resellerclub_AddNewDomainContact_ASIA(\'' + domainName + '\',\'' + UID + '\',\'' + ContactUserID + '\')" />';
            reg += '</div>';
            $("#swin").html(reg);
            return false;
        }
        var cObj = data.split('|');
        var cNow = cObj[0];
        var company = cObjFindValue(cNow, "company"), country = cObjFindValue(cNow, "country");

        var name = cObjFindValue(cNow, "name"), telnocc = cObjFindValue(cNow, "telnocc");
        var zip = cObjFindValue(cNow, "zip"), contactid = cObjFindValue(cNow, "contactid");
        var city = cObjFindValue(cNow, "city"), address1 = cObjFindValue(cNow, "address1");
        var emailaddr = cObjFindValue(cNow, "emailaddr"), telno = cObjFindValue(cNow, "telno");
        var str = '';
        var tr_td_SS = '<tr style="height:29px;line-height:29px;border-bottom:1px dashed #ddd;"><td style="width:120px;text-align:right;">';
        var inputSS = 'class="text" style="margin-top:4px;width:185px;"';
        str += '<h3 style="padding-left:80px;height:40px;font-size:16px;">填写域名注册信息 <b style="color:red;font-size:12px;font-weight:normal;word-spacing: 5px;"> ( 注意：请认真填写下面的信息！)</b></h3>';
        str += '<div style="padding-left:80px;">';
        str += '<table style="width:600px;">';
        str += tr_td_SS + '<b>购买的域名：</b>';
        str += '</td>';
        str += '<td style="text-align:left;width:190px;"><input type="hidden" id="regDomainName" value="' + domainName + '" />';
        str += domainName;
        str += '</td>';
        str += '<td style="text-align:left;width:235px;">';
        str += '</td>';
        str += '</tr>';
        str += '<tr style="height:32px;line-height:32px;border-bottom:1px dashed #ddd;"><td style="width:120px;text-align:right;">';
        str += '<b>注册联系人：</b>';
        str += '</td>';
        str += '<td style="text-align:left;width:190px;">';
        str += '<select id="selectCName" name="selectCName" style="cursor:pointer;margin-top:5px;" onchange="resellerclub_selectCNameByHTML(\'' + data + '\')">';
        str += getContactInfo(cObj);
        str += '</select>';
        str += '</td>';
        str += '<td style="text-align:left;width:235px;">';
        str += '&nbsp;&nbsp;<input type="button" value="添加联系人" class="submit" onclick="resellerclub_AddNewDomainContact_ASIA(\'' + domainName + '\',\'' + UID + '\',\'' + ContactUserID + '\')" />';
        str += '</td>';
        str += '</tr>';
        str += tr_td_SS + '<b>联系姓名：</b>';
        str += '</td>';
        str += '';
        str += '<td><span id="contactid" style="display:none;">' + contactid + '</span><span id="name">' + name + '</span>';
        str += '</td><td></td>';
        str += '</tr>';
        str += tr_td_SS + '<b>国家：</b>';
        str += '</td>';
        str += '<td>';
        str += getCountryByCode(country);

        str += '</td><td></td>';
        str += '</tr>';
        str += tr_td_SS + '<b>公司名称：</b>';
        str += '</td>';
        str += '<td><span id="company">' + company + '</span>';
        str += '</td><td></td>';
        str += '</tr>';
        str += tr_td_SS + '<b>城市：</b>';
        str += '</td>';
        str += '<td><span id="city">' + city + '</span>';
        str += '</td><td></td>';
        str += '</tr>';
        str += tr_td_SS + '<b>街道地址：</b>';
        str += '</td>';
        str += '<td><span id="address1">' + address1 + '</span>';
        str += '</td><td></td>';
        str += '</tr>';
        str += tr_td_SS + '<b>邮编：</b>';
        str += '</td>';
        str += '<td><span id="zip">' + zip + '</span>';
        str += '</td><td></td>';
        str += '</tr>';
        str += tr_td_SS + '<b>联系电话：</b>';
        str += '</td>';
        str += '<td>';
        str += '<span id="telnocc">' + telnocc + '</span>';
        str += '+<span id="telno">' + telno + '</span>';
        str += '</td><td></td>';
        str += '</tr>';
        str += tr_td_SS + '<b>电子邮箱：</b>';
        str += '</td>';
        str += '<td><span id="emailaddr">' + emailaddr + '</span>';
        str += '</td><td></td>';
        str += '</tr>';
        str += tr_td_SS + '<b>注册年限：</b>';
        str += '</td>';
        str += '<td style="text-align:left;width:190px;">';
        var priceArr = productData[0].pprice.cprice.split(',');
        str += '<select name="regYear" id="regYear" onchange="setRegYear()" style="cursor:pointer;margin-top:4px;">';
        if (priceArr[3] != 0) {
            str += '<option value="1" style="cursor:pointer;">1</option>';
        }
        if (priceArr[4] != 0) {
            str += '<option value="2" style="cursor:pointer;">2</option>';
        }

       // str += '<select name="regYear" id="regYear" onchange="setRegYear()" style="cursor:pointer;margin-top:4px;">' +
           //'<option value="1" style="cursor:pointer;">1</option><option value="2" style="cursor:pointer;">2</option>';
        str += '</select> 年 </td>';
        str += '<td style="text-align:left;width:235px;">';
        str += '</td>';
        str += '</tr>';
        str += tr_td_SS + '<b>DNS1：</b>';
        str += '</td>';
        str += '<td style="text-align:left;width:190px;">';
        str += '<input name="ns1" id="ns1" value="' + cObj[cObj.length - 2] + '" onblur="resellerclub_keyUpCheck(this)" ' + inputSS + ' >';
        str += '</td>';
        str += '<td style="text-align:left;width:235px;">';
        str += '</td>';
        str += '</tr>';
        str += tr_td_SS + '<b>DNS2：</b>';
        str += '</td>';
        str += '<td style="text-align:left;width:190px;">';
        str += '<input name="ns2" id="ns2" value="' + cObj[cObj.length - 1] + '" onblur="resellerclub_keyUpCheck(this)" ' + inputSS + ' >';
        str += '</td>';
        str += '<td style="text-align:left;width:235px;">';
        str += '</td>';
        str += '</tr>';
        str += '</table>';
        str += '</div>';
        $("#swin").html(str);
        $("#swin").append('<form id="OrderConfig"><div id="myStr"></div></form>');
        var rType = domainName.substr(domainName.indexOf("."));
        var discount = parseFloat(productData[0].discount);
        var myPrice = parseFloat(getPriceByType(rType, 'reg'));
        var yearNum = 1;
        var pStr = '';
        pStr += '<div style="float:left;height:44px;line-height:44px;" id="divprice"><input type="hidden" value="' + yearNum + '" id="yearNum" />';
        if (discount > 0 && discount < 1) {
            pStr += '<strong>总价格：<span style="color:blue;" id="OrderNormalPrice"><strike>' + myPrice + '</strike></span> <b style="">RMB</b>';
            myPrice = myPrice * discount;
            pStr += '<input type="hidden" value="' + myPrice + '" id="typePrice" />';
            pStr += '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
            pStr += '帐户优惠价(' + discount + '折)：<span style="color:blue;" id="OrderPrice">' + myPrice + '</span> <b style="">RMB</b></strong>';
        }
        else {
            myPrice = myPrice * discount;

            pStr += '<input type="hidden" value="' + myPrice + '" id="typePrice" />';
            pStr += '<strong>总价格：<span style="color:blue;" id="OrderPrice">' + myPrice + '</span> <b style="color:blue;">RMB</b></strong>';
        }
        pStr += '</div>';
        if ($("#divprice").length > 0) { $("#divprice").remove(); }
        //$(".ui-dialog-buttonset").before(pStr);
        $("#swin").next().before(pStr);
    })
}

function getCountryByCode(country) {
    str = "";
    switch (country) {
        case 'CN':
            str= '<span id="country">China</span>';
            break;
        case 'AU':
            str= '<span id="country">Australia</span>';
            break;
        case 'CA':
            str= '<span id="country">Canada</span>';
            break;
        case 'US':
            str= '<span id="country">United States</span>';
            break;
        case 'RU':
            str= '<span id="country">Russia</span>';
            break;
        case 'CX':
            str= '<span id="country">Christmas Island</span>';
            break;
        case 'FR':
            str= '<span id="country">France</span>';
            break;
        case 'IN':
            str= '<span id="country">India</span>';
            break;
        case 'TW':
            str= '<span id="country">Taiwan</span>';
            break;
        case 'ES':
            str= '<span id="country">Spain</span>';
            break;
        case 'DK':
            str = '<span id="country">Denmark</span>';
            break;
        case 'DJ':
            str = '<span id="country">Djibouti</span>';
            break;
        case 'DM':
            str = '<span id="country">Dominica</span>';
            break;
        case 'DO':
            str = '<span id="country">Dominican Republic</span>';
            break;
        case 'TP':
            str = '<span id="country">East Timor</span>';
            break;
        case 'JP':
            str = '<span id="country">Japan</span>';
            break;
        case 'MA':
            str = '<span id="country">Morocco</span>';
            break;
        case 'NZ':
            str = '<span id="country">New Zealand</span>';
            break;
        case 'OM':
            str = '<span id="country">Oman</span>';
            break;
        case 'SB':
            str = '<span id="country">Solomon Islands</span>';
            break;
        case 'SO':
            str = '<span id="country">Somalia</span>';
            break;
        case 'ZA':
            str = '<span id="country">South Africa</span>';
            break;
        case 'LK':
            str = '<span id="country">Sri Lanka</span>';
            break;
        case 'SD':
            str = '<span id="country">Sudan</span>';
            break;
        case 'AX':
            str = '<span id="country">Åland Islands</span>';
            break
    }
    return str;
}
function resellerclub_regDomain_Common(domainName, UID, ContactUserID) {
    var getUserContactByCIDURL = '?c=module&productid=' + productData[0].pid + '&show=text&todo=resellerclub_getUserContactByCID' +
                '&CID=' + ContactUserID + "&customerID=" + UID + "&domainName=" + domainName + "&t=" + new Date();
    $("#swin").dialog({ title: "【" + domainName + "】域名注册信息", autoOpen: false, resizable: false, width: 830, height: 590, modal: true, buttons: { "立即注册": function () {
        resellerclub_gotoRegDomain(domainName, UID, ContactUserID);
    }, "关 闭": function () {
        $(this).dialog("close");
    }
    }
    }).dialog("open");
    $("#swin").html('<div style="width:100%;text-align:center; padding-top:50px;">Loading...<br><img src="files/images/loading.gif" /></div>');
    $.get(getUserContactByCIDURL, function (data) {
       
        if (data.indexOf("company") < -1) {
            var reg = '';
            reg += '<div style="text-align:center;margin-top:30px;">';
            reg += '<h6 style="text-align:center;margin:20px auto;">抱歉，注册该域名需要添加相应的联系人，请先添加！</h6>';
            reg += '<input type="button" value="添加联系人" class="submit" onclick="resellerclub_AddNewDomainContact(\'' + domainName + '\',\'' + UID + '\',\'' + ContactUserID + '\')" />';
            reg += '</div>';
            $("#swin").html(reg);
            return false;
        }
        var cObj = data.split('|');
        var cNow = cObj[0];
        var company = cObjFindValue(cNow, "company"), country = cObjFindValue(cNow, "country");
        var name = cObjFindValue(cNow, "name"), telnocc = cObjFindValue(cNow, "telnocc");
        var zip = cObjFindValue(cNow, "zip"), contactid = cObjFindValue(cNow, "contactid");
        var city = cObjFindValue(cNow, "city"), address1 = cObjFindValue(cNow, "address1");
        var emailaddr = cObjFindValue(cNow, "emailaddr"), telno = cObjFindValue(cNow, "telno");
        var str = '';
        var tr_td_SS = '<tr style="height:29px;line-height:29px;border-bottom:1px dashed #ddd;"><td style="width:120px;text-align:right;">';
        var inputSS = 'class="text" style="margin-top:4px;width:185px;"';
        str += '<h3 style="padding-left:80px;height:40px;font-size:16px;">填写域名注册信息 <b style="color:red;font-size:12px;font-weight:normal;word-spacing: 5px;"> ( 注意：请认真填写下面的信息！)</b></h3>';
        str += '<div style="padding-left:170px;">';
        str += '<table style="width:450px;">';
        str += tr_td_SS + '<b>购买的域名：</b>';
        str += '</td>';
        str += '<td style="text-align:left;width:190px;"><input type="hidden" id="regDomainName" value="' + domainName + '" />';
        str += domainName;
        str += '</td>';
        str += '<td style="text-align:left;width:235px;">';
        str += '</td>';
        str += '</tr>';
        str += '<tr style="height:32px;line-height:32px;border-bottom:1px dashed #ddd;"><td style="width:120px;text-align:right;">';
        str += '<b>注册联系人：</b>';
        str += '</td>';
        str += '<td style="text-align:left;width:190px;">';
        str += '<select id="selectCName" name="selectCName" style="cursor:pointer;margin-top:5px;" onchange="resellerclub_selectCNameByHTML(\'' + data + '\')">';
        str += getContactInfo(cObj);
        str += '</select>';
        str += '</td>';
        str += '<td style="text-align:left;width:235px;">';
        str += '&nbsp;&nbsp;<input type="button" value="添加联系人" class="submit" onclick="resellerclub_AddNewDomainContact(\'' + domainName + '\',\'' + UID + '\',\'' + ContactUserID + '\')" />';
        str += '</td>';
        str += '</tr>';
        str += tr_td_SS + '<b>联系姓名：</b>';
        str += '</td>';
        str += '';
        str += '<td><span id="contactid" style="display:none;">' + contactid + '</span><span id="name">' + name + '</span>';
        str += '</td><td></td>';
        str += '</tr>';
        str += tr_td_SS + '<b>国家：</b>';
        str += '</td>';
        str += '<td>';
        str += getCountryByCode(country);
        str += '</td><td></td>';
        str += '</tr>';
        str += tr_td_SS + '<b>公司名称：</b>';
        str += '</td>';
        str += '<td><span id="company">' + company + '</span>';
        str += '</td><td></td>';
        str += '</tr>';
        str += tr_td_SS + '<b>城市：</b>';
        str += '</td>';
        str += '<td><span id="city">' + city + '</span>';
        str += '</td><td></td>';
        str += '</tr>';
        str += tr_td_SS + '<b>街道地址：</b>';
        str += '</td>';
        str += '<td><span id="address1">' + address1 + '</span>';
        str += '</td><td></td>';
        str += '</tr>';
        str += tr_td_SS + '<b>邮编：</b>';
        str += '</td>';
        str += '<td><span id="zip">' + zip + '</span>';
        str += '</td><td></td>';
        str += '</tr>';
        str += tr_td_SS + '<b>联系电话：</b>';
        str += '</td>';
        str += '<td>';
        str += '<span id="telnocc">' + telnocc + '</span>';
        str += '+<span id="telno">' + telno + '</span>';
        str += '</td><td></td>';
        str += '</tr>';
        str += tr_td_SS + '<b>电子邮箱：</b>';
        str += '</td>';
        str += '<td><span id="emailaddr">' + emailaddr + '</span>';
        str += '</td><td></td>';
        str += '</tr>';
        str += tr_td_SS + '<b>注册年限：</b>';
        str += '</td>';
        str += '<td style="text-align:left;width:190px;">';
        var priceArr = productData[0].pprice.cprice.split(',');
        str += '<select name="regYear" id="regYear" onchange="setRegYear()" style="cursor:pointer;margin-top:4px;">';
        if (priceArr[3] != 0) {
            str += '<option value="1" style="cursor:pointer;">1</option>';
        }
        if (priceArr[4] != 0) {
            str += '<option value="2" style="cursor:pointer;">2</option>';
        }

        //str += '<select name="regYear" id="regYear" onchange="setRegYear()" style="cursor:pointer;margin-top:4px;">' +
           //'<option value="1" style="cursor:pointer;">1</option><option value="2" style="cursor:pointer;">2</option></select> 年 ';
        str += '</select> 年 </td>';
        str += '<td style="text-align:left;width:235px;">';
        str += '</td>';
        str += '</tr>';
        str += tr_td_SS + '<b>DNS1：</b>';
        str += '</td>';
        str += '<td style="text-align:left;width:190px;">';
        str += '<input name="ns1" id="ns1" value="' + cObj[cObj.length - 2] + '" onblur="resellerclub_keyUpCheck(this)" ' + inputSS + ' >';
        str += '</td>';
        str += '<td style="text-align:left;width:235px;">';
        str += '</td>';
        str += '</tr>';
        str += tr_td_SS + '<b>DNS2：</b>';
        str += '</td>';
        str += '<td style="text-align:left;width:190px;">';
        str += '<input name="ns2" id="ns2" value="' + cObj[cObj.length - 1] + '" onblur="resellerclub_keyUpCheck(this)" ' + inputSS + ' >';
        str += '</td>';
        str += '<td style="text-align:left;width:235px;">';
        str += '</td>';
        str += '</tr>';
        str += '</table>';
        str += '</div>';
        $("#swin").html(str);
        $("#swin").append('<form id="OrderConfig"><div id="myStr"></div></form>');
        var rType = domainName.substr(domainName.indexOf("."));
        var discount = parseFloat(productData[0].discount);
        var myPrice = getPriceByType(rType, 'reg');
        var yearNum = 1;
        var pStr = '';
        pStr += '<div style="float:left;height:44px;line-height:44px;" id="divprice"><input type="hidden" value="' + yearNum + '" id="yearNum" />';
        if (discount > 0 && discount < 1) {
            pStr += '<strong>总价格：<span style="color:blue;" id="OrderNormalPrice"><strike>' + myPrice + '</strike></span> <b style="">RMB</b>';
            myPrice =(parseFloat(getPriceByType(rType, 'reg')) * discount).toFixed(2);
            pStr += '<input type="hidden" value="' + myPrice + '" id="typePrice" />';
            pStr += '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
            pStr += '帐户优惠价(' + discount + '折)：<span style="color:blue;" id="OrderPrice">' + myPrice + '</span> <b style="">RMB</b></strong>';
        }
        else {
            myPrice = myPrice * discount;

            pStr += '<input type="hidden" value="' + myPrice + '" id="typePrice" />';
            pStr += '<strong>总价格：<span style="color:blue;" id="OrderPrice">' + myPrice + '</span> <b style="color:blue;">RMB</b></strong>';
        }
        pStr += '</div>';
        if ($("#divprice").length > 0) { $("#divprice").remove(); }
        //$(".ui-dialog-buttonset").before(pStr);
        $("#swin").next().before(pStr);
    })
}

function resellerclub_gotoRegDomain(domainName, UID, ContactUserID) {
    var ns1 = $("#ns1"), ns2 = $("#ns2");
    if ($.trim(ns1.val()) == "") {
        ns1.parent().next("td").html("<b style='color:red;'>*DNS1不能为空！</span>");
        ns1.focus();
        return false;
    }
    else {
        var ik = $.trim(ns1.val()).indexOf(".");
        if (ik > 1) {
            ns1.parent().next("td").html("");
        } else {
            ns1.parent().next("td").html("<span style='color:red;'>*DNS格式错误！</span>");
            return false;
        }
    }
    if ($.trim(ns2.val()) == "") {
        ns2.parent().next("td").html("<b style='color:red;'>*DNS2不能为空！</span>");
        ns2.focus();
        return false;
    }
    else {
        var ik = $.trim(ns2.val()).indexOf(".");
        if (ik > 1) {
            ns2.parent().next("td").html("");
        } else {
            ns2.parent().next("td").html("<span style='color:red;'>*DNS格式错误！</span>");
            return false;
        }
    }
    var theDomainName = $("#regDomainName").val();
    var theType = theDomainName.substr(theDomainName.indexOf("."));
    var yNum = $("#regYear").val();
    normalPrice = parseFloat(getPriceByType(theType, 'reg')) * parseInt($("#yearNum").val());
    finalPrice = parseFloat($("#typePrice").val()) * parseInt($("#yearNum").val());
    billingCycle = parseInt($("#yearNum").val()) * 12;
    billingMothod = 1;
    var myInputs = '<input type="hidden" value="' + getPriceByType(theType, 'reg') + '" name="typePrice" />' +
          '<input type="hidden" value="' + getPriceByType(theType, 'renew') + '" name="renewPrice" />' +
          '<input type="hidden" value="' + getPriceByType(theType, 'transfer') + '" name="transferPrice" />' +
          '<input type="hidden" value="' + $("#regDomainName").val() + '" name="domainName" />' +
          '<input type="hidden" value="' + yNum + '" name="regYearNum" />' +
          '<input type="hidden" value="' + $.trim(ns1.val()) + '" name="ns1" />' +
          '<input type="hidden" value="' + $.trim(ns2.val()) + '" name="ns2" />' +
          '<input type="hidden" value="' + $("#selectCName").val() + '" name="ContactUserID" />' +
          '<input type="hidden" value="' + UID + '" name="customerID" />' +
          '<input type="hidden" value="resellerclub" name="provider" />';
    $("#myStr").html(myInputs);

    checkout(0);
}




function cObjFindValue(cobj, key) {
    var obj = cobj.split(',');
    for (var i = 0; i < obj.length; i++) {
        var vArr = obj[i].split(':');
        if (vArr[0] == key) {
            return vArr[1];
            break;
        }
    }
}

function resellerclub_keyUpCheck(obj) {
    var checkName = $(obj).attr("name");
    var checkValue = $.trim($(obj).val());
    switch (checkName) {
        case "TransferDomainName":
            if (checkValue.indexOf(".cn") > -1 || checkValue.indexOf(".中国") > -1 || checkValue.indexOf(".公司") > -1 || checkValue.indexOf(".网络") > -1) {
                $("#comBox").hide();
                $(obj).parent().next("td").html("");
            }
            else {
                if (checkValue.indexOf(".") > -1) {
                    $("#comBox").show();
                    $(obj).parent().next("td").html("");
                }
                else {
                    if (checkValue == "") {
                        $(obj).parent().next("td").html("<span style='color:red;'>*请填写转入域名！</span>");
                    } else {
                        $(obj).parent().next("td").html("<span style='color:red;'>*域名格式错误！</span>");
                    } $(obj).focus(); return false;
                }
            }
            break;
        case "DomainPwd":
            if (checkValue.length > 4) {
                $(obj).parent().next("td").html("");
            }
            else {
                if (checkValue.length == 0) {
                    $(obj).parent().next("td").html("<span style='color:red;'>*密码不能为空！</span>");
                }
                else { $(obj).parent().next("td").html("<span style='color:red;'>*密码长度不符合要求!</span>"); }
            }
            break;
        case "email":
            var reg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
            if (!reg.test(checkValue)) {
                $(obj).parent().next("td").html("<span style='color:red;'>*邮箱格式错误！</span>");
            }
            else {
                $(obj).parent().next("td").html("");
            }
            break;
        case "phone":
            if (checkValue.length == 0) {
                $(obj).parent().next("td").html("<span style='color:red;'>*不能为空</span>");
            }
            else {
                //                var ik = checkValue.indexOf("-");
                //                if (ik == 3 || ik == 4) {
                //                    $(obj).parent().next("td").html(" 如：020-12345678");
                //                } else {
                //                    $(obj).parent().next("td").html("<span style='color:red;'>*格式错误！</span>");
                //                }
                if (checkValue.length < 10) {
                    $(obj).parent().next("td").html("<span style='color:red;'>*电话号码长度不对！</span>");
                }
            }
            break;
        case "fax":
            if (checkValue.length == 0) {
                $(obj).parent().next("td").html("<span style='color:red;'>*不能为空</span>");
            }
            else {
                var ik = checkValue.indexOf("-");
                if (ik == 3 || ik == 4) {
                    $(obj).parent().next("td").html(" 如：020-12345678");
                } else {
                    $(obj).parent().next("td").html("<span style='color:red;'>*格式错误！</span>");
                }
            }
            break;
        case "province":
            if (checkValue.length == 0) {
                $(obj).parent().next("td").html("<span style='color:red;'>*不能为空</span>");
            }
            else {
                $(obj).parent().next("td").html(" 省/市");
            }
            break;
        case "city":
            if (checkValue.length == 0) {
                $(obj).parent().next("td").html("<span style='color:red;'>*不能为空</span>");
            }
            else {
                $(obj).parent().next("td").html(" 市/区");
            }
            break;
        default:
            if (checkValue.length == 0) {
                $(obj).parent().next("td").html("<span style='color:red;'>*不能为空</span>");
            }
            else {
                $(obj).parent().next("td").html("");
            }
            break;
    }
}
function resellerclub_keyFocus(obj) {
    var checkName = $(obj).attr("name");
    var checkValue = $.trim($(obj).val());
    switch (checkName) {
        case "phone-cc":
            $(obj).parent().next("td").html(" 国家编号，如中国：086");
            break;
        case "phone":
            $(obj).parent().next("td").html(" 如：02012345678");
            break;
        case "fax":
            $(obj).parent().next("td").html(" 如：020-12345678");
            break;
        case "province":
            $(obj).parent().next("td").html(" 省/市");
            break;
        case "city":
            $(obj).parent().next("td").html(" 市/区");
            break;
    }
}

function resellerclub_gotoRegUserAccount(domain) {
    var name = $("#name"), company = $("#company"), province = $("#province"), city = $("#city"), addressline1 = $("#address-line-1");
    var zipcode = $("#zipcode"), phonecc = $("#phone-cc"), phone = $("#phone");

    if ($.trim(name.val()) == "") {
        name.parent().next("td").html("<b style='color:red;'>*联系人不能为空！</span>");
        name.focus();
        return false;
    }

    if ($.trim(company.val()) == "") {
        company.parent().next("td").html("<b style='color:red;'>*公司不能为空！</span>");
        company.focus();
        return false;
    }

    if ($.trim(province.val()) == "") {
        province.parent().next("td").html("<b style='color:red;'>*省份不能为空！</span>");
        province.focus();
        return false;
    }

    if ($.trim(city.val()) == "") {
        city.parent().next("td").html("<b style='color:red;'>*城市不能为空！</span>");
        city.focus();
        return false;
    }

    if ($.trim(addressline1.val()) == "") {
        addressline1.parent().next("td").html("<b style='color:red;'>*街道地址不能为空！</span>");
        addressline1.focus();
        return false;
    }

    if ($.trim(zipcode.val()) == "") {
        zipcode.parent().next("td").html("<b style='color:red;'>*邮编不能为空！</span>");
        zipcode.focus();
        return false;
    }

    if ($.trim(phonecc.val()) == "") {
        phonecc.parent().next("td").html("<b style='color:red;'>*国家的编号不能为空！</span>");
        return false;
    }

    if ($.trim(phone.val()) == "") {
        phone.parent().next("td").html("<b style='color:red;'>*电话号码不能为空！</span>");
        return false;
    }
    else {
        if ($.trim(phone.val()).length < 7) {
            phone.parent().next("td").html("<b style='color:red;'>*区号+座机号码！</span>");
            return false;
        } else {

            phone.parent().next("td").html("");
        }
    }


    //验证输入的账户资料，激活API
    $("#suwin").dialog({ title: "提交注册账户信息", autoOpen: false, resizable: false, width: 300, height: 220, modal: true, buttons: { "关 闭": function () {
        $(this).dialog("close");
    }
    }
    }).dialog("open");
    var str = '';
    str += '<div style="width:100%; margin:0 auto; text-align:center; padding-top:30px;">提交中，请稍后...<br>';
    str += '<img src="files/images/loading.gif" />';
    str += '</div>';
    $("#suwin").html(str);
    var country = $("#country").val();
    var langpref = $("#lang-pref").val();
    var urlapi = '?c=module&productid=' + productData[0].pid + '&show=text&todo=resellerclub_regUserAccount' +
                '&userName=' + userData[0].umail + '&name=' + $.trim(name.val()) + '&tel=' + userData[0].tel +
                '&country=' + $.trim(country) + '&province=' + $.trim(province.val()) +
                '&city=' + $.trim(city.val()) + '&addressline1=' + $.trim(addressline1.val()) +
                '&zipcode=' + $.trim(zipcode.val()) + '&phonecc=' + $.trim(phonecc.val()) +
                '&phone=' + $.trim(phone.val()) + '&company=' + $.trim(company.val()) +
                '&langpref=' + $.trim(langpref) + '&domain='+domain;

    $.get(urlapi, function (data) {
        var flag = data.split('|')[0];
        switch (flag) {
            case "ok":
                $("#suwin div").html("<b style='color:green;'>注册账户成功！</b>");
                setTimeout(function () {
                   $("#suwin").dialog("close");
                   $("#swin").dialog("close");
                   resellerclub_regDomain_Common(domain,data.split('|')[1], data.split('|')[2]);
                  
                }, 2000);
                break;
            case "Exist":
                $("#suwin div").html("<b style='color:red;'>你已经注册过了，请刷新页面！</b>");
                setTimeout(function () {
                    $("#suwin").dialog("close");
                    $("#swin").dialog("close");
                    window.location.reload();
                }, 1000);
                break;
            case "Company is invalid":
                $("#suwin div").html("<b style='color:red;'>公司输入非法（*英文）</b>");
                break;
            case "CC is invalid":
                $("#suwin div").html("<b style='color:red;'>国家编号输入有误</b>");
                break;
            case "Mobile invalid":
                $("#suwin div").html("<b style='color:red;'>你的账户手机号码设置有误！</b>");
                break;
            case "State is invalid":
                $("#suwin div").html("<b style='color:red;'>省份输入非法（*英文）</b>");
                break;
            case "City is invalid":
                $("#suwin div").html("<b style='color:red;'>城市输入非法（*英文）</b>");
                break;
            case "Name is invalid":
                $("#suwin div").html("<b style='color:red;'>联系人输入非法（*英文）</b>");
                break;
            case "Telephone No. is invalid":
                $("#suwin div").html("<b style='color:red;'>联系电话输入有误（*区号）</b>");
                break;
            default:
                $("#suwin").html(data);
                break;
        }
    });
}

function resellerclub_regUserAccount(domain) {
    var domainName = domain;
    $("#swin").dialog({ title: "注册账户信息", autoOpen: false, resizable: false, width: 860, height: 600, modal: true, buttons: { "注册账户": function () {
        resellerclub_gotoRegUserAccount(domainName);
       
    }, "关 闭": function () {
        $(this).dialog("close");
    }
    }
    }).dialog("open");
    var str = '';
    var tr_td_SS = '<tr style="height:29px;line-height:29px;border-bottom:1px dashed #ddd;"><td style="width:150px;text-align:right;">';
    var inputSS = 'class="text" style="margin-top:4px;"';
    str += '<h3 style="padding-left:80px;height:40px;font-size:16px;">填写域名帐号信息 <b style="color:red;font-size:12px;font-weight:normal;word-spacing: 5px;"> ( 注意：请认真填写下面的信息，只能输入英文！)</b></h3>';
    str += '<div style="padding-left:150px;">';
    str += '<table style="width:500px;">';
    str += tr_td_SS + '<b>账户名：</b>';
    str += '</td>';
    str += '<td style="text-align:left;"><input type="hidden" id="regUserName" value="' + userData[0].umail + '" />';
    str += userData[0].umail;
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>联系人：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="name" id="name" onfocus="resellerclub_keyFocus(this)" onblur="resellerclub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;width:150px;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>注册公司：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="company" id="company" onfocus="resellerclub_keyFocus(this)" onblur="resellerclub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;width:150px;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>国家：</b>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '<select name="country" id="country" style="cursor:pointer;margin-top:4px;">' +
        '<option value="AU">Australia</option>' +
        '<option value="CA">Canada</option>' +
        '<option value="CN" selected="selected">China</option>' +
        '<option value="US">United States</option>' +
        '<option value="CX">Christmas Island</option>' +
        '<option value="DK">Denmark</option>' +
        '<option value="DJ">Djibouti</option>' +
        '<option value="DM">Dominica</option>' +
        '<option value="DO">Dominican Republic</option>' +
        '<option value="TP">East Timor</option>' +
        '<option value="FR">France</option>' +
        '<option value="IN">India</option>' +
        '<option value="JP">Japan</option>' +
        '<option value="MA">Morocco</option>' +
        '<option value="NZ">New Zealand</option>' +
        '<option value="OM">Oman</option>' +
        '<option value="RU">Russia</option>' +
        '<option value="SB">Solomon Islands</option>' +
        '<option value="SO">Somalia</option>' +
        '<option value="ZA">South Africa</option>' +
        '<option value="ES">Spain</option>' +
        '<option value="LK">Sri Lanka</option>' +
        '<option value="SD">Sudan</option>' +
        '<option value="TW">Taiwan</option>' +
        '<option value="AX">Åland Islands</option>' +
        '<option selected="" value="ES">Spain</option>';
    str += '</select>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>省份：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="province" id="province" onfocus="resellerclub_keyFocus(this)" onblur="resellerclub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 省/市</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>城市：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="city" id="city" onfocus="resellerclub_keyFocus(this)" onblur="resellerclub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 市/区</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>地址：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="address-line-1" id="address-line-1" onblur="resellerclub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>邮编：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="zipcode" id="zipcode" onblur="resellerclub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>联系电话：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:220px;">';
    str += '<input name="phone-cc" id="phone-cc" value="086" onfocus="resellerclub_keyFocus(this)" onblur="resellerclub_keyUpCheck(this)" class="text" style="margin-top:4px;width:34px;">';
    str += '+<input name="phone" id="phone" onfocus="resellerclub_keyFocus(this)" onblur="resellerclub_keyUpCheck(this)"  style="margin-top:4px;width:145px;" class="text">';
    str += '</td>';
    str += '<td style="text-align:left;width:200px;">';
    str += ' 如：086+02012345678</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>语言：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<select name="lang-pref" id="lang-pref" style="cursor:pointer;margin-top:4px;">' +
           '<option value="ch"  selected="selected" style="cursor:pointer;">CN</option>' +
           '<option value="en" style="cursor:pointer;">EN</option>';
    str += '</select>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';

    str += '</table>';
    str += '</div>';
    //str = "正在检查你的账户...";
    $("#swin").html(str);
}

function resellerclub_gotoRegUserAccountFromTransfer(domainName, domainType, pwd, provider) {
    var name = $("#name"), company = $("#company"), province = $("#province"), city = $("#city"), addressline1 = $("#address-line-1");
    var zipcode = $("#zipcode"), phonecc = $("#phone-cc"), phone = $("#phone");

    if ($.trim(name.val()) == "") {
        name.parent().next("td").html("<b style='color:red;'>*联系人不能为空！</span>");
        name.focus();
        return false;
    }

    if ($.trim(company.val()) == "") {
        company.parent().next("td").html("<b style='color:red;'>*公司不能为空！</span>");
        company.focus();
        return false;
    }

    if ($.trim(province.val()) == "") {
        province.parent().next("td").html("<b style='color:red;'>*省份不能为空！</span>");
        province.focus();
        return false;
    }

    if ($.trim(city.val()) == "") {
        city.parent().next("td").html("<b style='color:red;'>*城市不能为空！</span>");
        city.focus();
        return false;
    }

    if ($.trim(addressline1.val()) == "") {
        addressline1.parent().next("td").html("<b style='color:red;'>*街道地址不能为空！</span>");
        addressline1.focus();
        return false;
    }

    if ($.trim(zipcode.val()) == "") {
        zipcode.parent().next("td").html("<b style='color:red;'>*邮编不能为空！</span>");
        zipcode.focus();
        return false;
    }

    if ($.trim(phonecc.val()) == "") {
        phonecc.parent().next("td").html("<b style='color:red;'>*国家的编号不能为空！</span>");
        phonecc.focus();
        return false;
    }

    var vphone = $.trim(phone.val());
    if (vphone.length<=0) {
        phone.parent().next("td").html("<b style='color:red;'>*电话号码不能为空！</span>");
        phone.focus();
        return false;
    }
    else if(vphone.length < 10) {
            phone.parent().next("td").html("<b style='color:red;'>*区号+座机号码！</span>");
            phone.focus();
            return false;
        }else {
            phone.parent().next("td").html("");
        }
    

    //验证输入的账户资料，激活API
    $("#suwin").dialog({ title: "提交注册账户信息", autoOpen: false, resizable: false, width: 300, height: 220, modal: true, buttons: { "关 闭": function () {
        $(this).dialog("close");
    }
    }
    }).dialog("open");
    var str = '';
    str += '<div style="width:100%; margin:0 auto; text-align:center; padding-top:30px;">提交中，请稍后...<br>';
    str += '<img src="files/images/loading.gif" />';
    str += '</div>';
    $("#suwin").html(str);
    var country = $("#country").val();
    var langpref = $("#lang-pref").val();
    var urlapi = '?c=module&productid=' + productData[0].pid + '&show=text&todo=resellerclub_regUserAccount' +
                '&userName=' + userData[0].umail + '&name=' + $.trim(name.val()) + '&tel=' + userData[0].tel +
                '&country=' + $.trim(country) + '&province=' + $.trim(province.val()) +
                '&city=' + $.trim(city.val()) + '&addressline1=' + $.trim(addressline1.val()) +
                '&zipcode=' + $.trim(zipcode.val()) + '&phonecc=' + $.trim(phonecc.val()) +
                '&phone=' + $.trim(phone.val()) + '&company=' + $.trim(company.val()) +
                '&langpref=' + $.trim(langpref);

    $.get(urlapi, function (data) {
        var flag = data.split('|')[0];
        switch (flag) {
            case "ok":
                $("#suwin div").html("<b style='color:green;'>注册账户成功！</b>");
                setTimeout(function () {
                    $("#suwin").dialog("close");
                    $("#swin").dialog("close");
                    resellerclub_gotoChkUserAccountToTransfer(domainName, domainType, pwd, provider);
                }, 2000);
                break;
            case "Exist":
                $("#suwin div").html("<b style='color:red;'>你已经注册过了，请重新页面！</b>");
                break;
            case "Company is invalid":
                $("#suwin div").html("<b style='color:red;'>公司输入非法（*英文）</b>");
                break;
            case "CC is invalid":
                $("#suwin div").html("<b style='color:red;'>国家编号输入有误</b>");
                break;
            case "State is invalid":
                $("#suwin div").html("<b style='color:red;'>省份输入非法（*英文）</b>");
                break;
            case "City is invalid":
                $("#suwin div").html("<b style='color:red;'>城市输入非法（*英文）</b>");
                break;
            case "Name is invalid":
                $("#suwin div").html("<b style='color:red;'>联系人输入非法（*英文）</b>");
                break;
            case "Telephone No. is invalid":
                $("#suwin div").html("<b style='color:red;'>联系电话输入有误（*区号）</b>");
                break;
            default:
                $("#suwin").html(data);
                break;
        }
    });
}

function resellerclub_gotoChkUserAccountToTransfer(domainName, domainType, pwd, provider) {
    $("#suwin").dialog({ title: "域名系统正在检查你的账户信息", autoOpen: false, resizable: false, width: 400, height: 280, modal: true, buttons: { "取 消": function () {
        $(this).dialog("close");
    }
    }
    }).dialog("open");
    var str = '';
    str += '<div style="width:100%; margin:0 auto; text-align:center; padding-top:50px;"><b>正在检查你的账户</b><br><br>';
    str += '<img src="files/images/loading.gif" />';
    str += '</div>';
    $("#suwin").html(str);
    if (userData[0].uconfig.mail_verified != '1') {
        $("#suwin").html("您的邮箱还没经过验证！");
        return;
    }
//    if (userData[0].uconfig.mobile_verified != '1') {
//        $("#suwin").html("您的手机号还没经过验证！");
//        return;
//    }
    var email = userData[0].umail;
    var url = "?c=module&productid=" + productData[0].pid + "&show=text&todo=resellerclub_checkUserAccountToTransfer&email=" + email;
    $.get(url, function (data) {
        var ChkFlag = data.substr(0, data.indexOf("|"));
        switch (ChkFlag) {
            case "ToTransfer":
                $("#suwin").dialog("close");
                var conStr = "";
                for (var i = 4; i < data.split('|').length; i++) {
                    conStr += data.split('|')[i] + "|";
                }
                conStr = conStr.substr(0, conStr.length - 1);
                resellerclub_showTransferDomain(data.split('|')[1], data.split('|')[2], data.split('|')[3], conStr, domainName, domainType, pwd, provider);
                break;
            case "Need Regist Account":
                $("#suwin").dialog("close");
                resellerclub_regUserAccountFromTransfer(domainName, domainType, pwd, provider);
                break;
            default:
                $("#suwin").html("返回格式错误" + data);
                break;
        }

    });
}


function resellerclub_regUserAccountFromTransfer(domainName, domainType, pwd, provider) {   
    $("#swin").dialog({ title: "注册账户信息", autoOpen: false, resizable: false, width: 860, height: 600, modal: true, buttons: { "注册账户": function () {
        
        resellerclub_gotoRegUserAccountFromTransfer(domainName, domainType, pwd, provider);
    }, "关 闭": function () {
        $(this).dialog("close");
    }
    }
    }).dialog("open");
    var str = '';
    var tr_td_SS = '<tr style="height:29px;line-height:29px;border-bottom:1px dashed #ddd;"><td style="width:150px;text-align:right;">';
    var inputSS = 'class="text" style="margin-top:4px;"';
    str += '<h3 style="padding-left:80px;height:40px;font-size:16px;">填写账户信息 <b style="color:red;font-size:12px;font-weight:normal;word-spacing: 5px;"> ( 注意：请认真填写下面的信息，只能输入英文！)</b></h3>';
    str += '<div style="padding-left:170px;">';
    str += '<table style="width:470px;">';

    str += tr_td_SS + '<b>转入的域名：</b>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += domainName + domainType;
    str += '</td>';
    str += '<td style="text-align:left;width:150px;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>转移密码：</b>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += pwd;
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
//    str += tr_td_SS + '<b>转入价格：</b>';
//    str += '</td>';
//    str += '<td style="text-align:left;">';
//    str += getPriceByType(domainType, 'transfer') + ' ' + userData[0].currency;
//    str += '</td>';
//    str += '<td style="text-align:left;width:150px;">';
//    str += '</td>';
//    str += '</tr>';
//    str += tr_td_SS + '<b>续费价格：</b>';
//    str += '</td>';
//    str += '<td style="text-align:left;">';
//    str += getPriceByType(domainType, 'renew') + ' ' + userData[0].currency;
//    str += '</td>';
//    str += '<td style="text-align:left;width:150px;">';
//    str += '</td>';
//    str += '</tr>';
    str += tr_td_SS + '<b>账户名：</b>';
    str += '</td>';
    str += '<td style="text-align:left;"><input type="hidden" id="regUserName" value="' + userData[0].umail + '" />';
    str += userData[0].umail;
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>联系人：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="name" id="name" onfocus="resellerclub_keyFocus(this)" onblur="resellerclub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;width:150px;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>注册公司：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="company" id="company" onfocus="resellerclub_keyFocus(this)" onblur="resellerclub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;width:150px;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>国家：</b>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '<select name="country" id="country" style="cursor:pointer;margin-top:4px;">' +
        '<option value="AU">Australia</option>' +
        '<option value="CA">Canada</option>' +
        '<option value="CN" selected="selected">China</option>' +
        '<option value="CX">Christmas Island</option>' +
        '<option value="DK">Denmark</option>' +
        '<option value="DJ">Djibouti</option>' +
        '<option value="DM">Dominica</option>' +
        '<option value="DO">Dominican Republic</option>' +
        '<option value="TP">East Timor</option>' +
        '<option value="FR">France</option>' +
        '<option value="IN">India</option>' +
        '<option value="JP">Japan</option>' +
        '<option value="MA">Morocco</option>' +
        '<option value="NZ">New Zealand</option>' +
        '<option value="OM">Oman</option>' +
        '<option value="RU">Russia</option>' +
        '<option value="SB">Solomon Islands</option>' +
        '<option value="SO">Somalia</option>' +
        '<option value="ZA">South Africa</option>' +
        '<option value="ES">Spain</option>' +
        '<option value="LK">Sri Lanka</option>' +
        '<option value="SD">Sudan</option>' +
        '<option value="TW">Taiwan</option>' +
        '<option value="US">United States</option>';
    str += '</select>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>省份：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="province" id="province" onfocus="resellerclub_keyFocus(this)" onblur="resellerclub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 省/市</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>城市：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="city" id="city" onfocus="resellerclub_keyFocus(this)" onblur="resellerclub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 市/区</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>地址：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="address-line-1" id="address-line-1" onblur="resellerclub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>邮编：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="zipcode" id="zipcode" onblur="resellerclub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>联系电话：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="phone-cc" id="phone-cc" value="86" onfocus="resellerclub_keyFocus(this)" onblur="resellerclub_keyUpCheck(this)" class="text" style="margin-top:4px;width:34px;">';
    str += '+<input name="phone" id="phone" class="text" onfocus="resellerclub_keyFocus(this)" onblur="resellerclub_keyUpCheck(this)"  style="margin-top:4px;width:145px;">';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 如：86+02012345678</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>语言：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<select name="lang-pref" id="lang-pref" style="cursor:pointer;margin-top:4px;">' +
           '<option value="ch"  selected="selected" style="cursor:pointer;">CN</option>' +
           '<option value="en" style="cursor:pointer;">EN</option>';
    str += '</select>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';

    str += '</table>';
    str += '</div>';
    //str = "正在检查你的账户...";
    $("#swin").html(str);
}

function resellerclub_gotoTransferDomain(UID, CID, DNS, Contacts, domainName, domainType, pwd, provider) {
    var dnsObj = DNS.split(',');
    var dns1 = dnsObj[dnsObj.length - 1];
    var dns2 = dnsObj[dnsObj.length - 2];
   
    normalPrice = getPriceByType(domainType, 'transfer');

    if (isNaN(normalPrice)) { alert("抱歉，你要转入的域名类型暂不支持！"); return false; }

    billingCycle = 12;
    var discount = parseFloat(productData[0].discount);
    if (discount > 0) { normalPrice = normalPrice * discount; }
    finalPrice = normalPrice * discount;


    var myInputs = '<input type="hidden" value="' + getPriceByType(domainType, 'transfer') + '" name="typePrice" />';
    myInputs += '<input type="hidden" value="' + getPriceByType(domainType, 'renew') + '" name="renewPrice" />';
    myInputs += '<input type="hidden" value="' + getPriceByType(domainType, 'transfer') + '" name="transferPrice" />';

    myInputs += '<input type="hidden" value="yes" name="transferFlag" />'; //标记此域名是转入的域名

    myInputs += '<input type="hidden" value="' + pwd + '" name="domainPwd" />';
    myInputs += '<input type="hidden" value="1" name="regYear" />';
    myInputs += '<input type="hidden" value="' + domainName+domainType + '" name="domainName" />';

    myInputs += '<input type="hidden" value="' + UID + '" name="customerID" />';
    myInputs += '<input type="hidden" value="' + $("#selectCName").val() + '" name="ContactUserID" />';
    myInputs += '<input type="hidden" value="' + dns1 + '" name="ns1" />';
    myInputs += '<input type="hidden" value="' + dns2 + '" name="ns2" />';
    myInputs += '<input type="hidden" value="resellerclub" name="provider" />';

    $("#swin").append('<form id="OrderConfig">' + myInputs + '</form>');
    $("#OrderConfig").append('<input type="hidden" id="couponcode" value="" />');

    $("#suwin").dialog({ title: "确认域名转入", autoOpen: false, resizable: false, width: 410, height: 320, modal: true, buttons: { "确定转入": function () {
        checkout(1);
    }, "取 消": function () {
        $(this).dialog("close");
    }
    }
    }).dialog("open");

    var qus = '<div style="padding-top:20px;"></div><table>';
    qus += '<tr style="height:35px;line-height:35px;"><td style="width:120px;text-align:right;">转入域名：';
    qus += '<td><b>' + domainName+domainType + '</b></td>';
    qus += '</tr>';
    qus += '<tr style="height:35px;line-height:35px;"><td style="width:120px;text-align:right;">转入密码：';
    qus += '<td><b>' +pwd + '</b></td>';
    qus += '</tr>';

    if (discount > 0 && discount < 1) {
        qus += '<tr style="height:35px;line-height:35px;"><td style="width:120px;text-align:right;">转入价格：';
        qus += '<td><strike>' + getPriceByType(domainType, 'transfer') + '</strike> RMB/1年</td>';
        qus += '</tr>';
        qus += '<tr style="height:35px;line-height:35px;"><td style="width:120px;text-align:right;">账户优惠价格：';
        qus += '<td>' + (getPriceByType(domainType, 'transfer') * discount).toFixed(2) + ' RMB/1年</td>';
        qus += '</tr>';
    } else {
        qus += '<tr style="height:35px;line-height:35px;"><td style="width:120px;text-align:right;">转入价格：';
        qus += '<td><b>' + normalPrice.toFixed(2) + ' RMB/1年</b></td>';
        qus += '</tr>';
    }

    qus += '</table>';
    qus += '<div style="color:red;font-size:15;padding-top:5px;"><b>*重要提示：</b>';
    qus += '<br>&nbsp;&nbsp;1 .请认真核对域名和密码，确认转入后会立即扣费。';
    qus += '<br>&nbsp;&nbsp;2 .系统会发送一封域名转移的确认邮件，请注意查收并确认！';
    qus += '</div>';
    $("#suwin").html(qus);

}
function resellerclub_showTransferDomain(UID, CID, DNS, Contacts, domainName, domainType, pwd, provider) {
    $("#swin").dialog({ title: "域名转入服务", autoOpen: false, resizable: false, width: 830, height: 568, modal: false, buttons: { "确定转入": function () {
        resellerclub_gotoTransferDomain(UID, CID, DNS, Contacts, domainName, domainType, pwd, provider);
    }, "关 闭": function () {
        $(this).dialog("close");
    }
    }
    }).dialog("open");
    var str = '';
    str += '<h3 style="padding-left:70px;height:40px;font-size:16px;">转入域名信息 <b style="color:red;font-size:12px;font-weight:normal;word-spacing: 5px;"> ( 注意：请认真核实下面的信息！)</b></h3>';
    str += '<div style="margin-left:150px;">';
    str += '<table>';
    var tr_td_SS = '<tr style="height:29px;line-height:29px;border-bottom:1px dashed #ddd;"><td style="width:120px;text-align:right;">';
    var inputSS = 'class="text" style="margin-top:4px;"';
    str += '<div style="padding-left:170px;">';
    str += '<table style="width:450px;">';
    str += tr_td_SS + '<b>转入的域名：</b>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += domainName + domainType;
    str += '</td>';
    str += '<td style="text-align:left;width:150px;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>转移密码：</b>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += pwd;
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
//    str += tr_td_SS + '<b>转入价格：</b>';
//    str += '</td>';
//    str += '<td style="text-align:left;">';
//    str += getPriceByType(domainType, 'transfer') + ' ' + userData[0].currency;
//    str += '</td>';
//    str += '<td style="text-align:left;width:150px;">';
//    str += '</td>';
//    str += '</tr>';
//    str += tr_td_SS + '<b>续费价格：</b>';
//    str += '</td>';
//    str += '<td style="text-align:left;">';
//    str += getPriceByType(domainType, 'renew') + ' ' + userData[0].currency;
//    str += '</td>';
//    str += '<td style="text-align:left;width:150px;">';
//    str += '</td>';
//    str += '</tr>';
    var cObj = Contacts.split('|');
    var cNow = cObj[0];
    var company = cObjFindValue(cNow, "company"), country = cObjFindValue(cNow, "country");
    var name = cObjFindValue(cNow, "name"), telnocc = cObjFindValue(cNow, "telnocc");
    var zip = cObjFindValue(cNow, "zip"), contactid = cObjFindValue(cNow, "contactid");
    var city = cObjFindValue(cNow, "city"), address1 = cObjFindValue(cNow, "address1");
    var emailaddr = cObjFindValue(cNow, "emailaddr"), telno = cObjFindValue(cNow, "telno");

    str += '<tr style="height:32px;line-height:32px;border-bottom:1px dashed #ddd;"><td style="width:120px;text-align:right;">';
    str += '<b>注册联系人：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:190px;">';
    str += '<select id="selectCName" name="selectCName" style="cursor:pointer;margin-top:5px;" onchange="resellerclub_selectCNameByHTML(\'' + Contacts + '\')">';
    str += getContactInfo(cObj);
    str += '</select>';
    str += '</td>';
    str += '<td style="text-align:left;width:235px;">';
    str += '&nbsp;&nbsp;<input type="button" value="添加联系人" class="submit" onclick="resellerclub_AddNewDomainContactFromTransfer(\'' + domainName + '\',\'' + UID + '\',\'' + CID + '\',\'' + domainType + '\',\'' + pwd + '\',\'' + provider + '\')" />';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>联系姓名：</b>';
    str += '</td>';
    str += '<input type="hidden" value="' + UID + '" name="uid" id="uid" />';
    str += '<td><span id="contactid" style="display:none;">' + contactid + '</span><span id="name">' + name + '</span>';
    str += '</td><td></td>';
    str += '</tr>';
    str += tr_td_SS + '<b>国家：</b>';
    str += '</td>';
    str += '<td>';
    str += getCountryByCode(country);
    str += '</td><td></td>';
    str += '</tr>';
    str += tr_td_SS + '<b>公司名称：</b>';
    str += '</td>';
    str += '<td><span id="company">' + company + '</span>';
    str += '</td><td></td>';
    str += '</tr>';
    str += tr_td_SS + '<b>城市：</b>';
    str += '</td>';
    str += '<td><span id="city">' + city + '</span>';
    str += '</td><td></td>';
    str += '</tr>';
    str += tr_td_SS + '<b>街道地址：</b>';
    str += '</td>';
    str += '<td><span id="address1">' + address1 + '</span>';
    str += '</td><td></td>';
    str += '</tr>';
    str += tr_td_SS + '<b>邮编：</b>';
    str += '</td>';
    str += '<td><span id="zip">' + zip + '</span>';
    str += '</td><td></td>';
    str += '</tr>';
    str += tr_td_SS + '<b>联系电话：</b>';
    str += '</td>';
    str += '<td>';
    str += '<span id="telnocc">' + telnocc + '</span>';
    str += '+<span id="telno">' + telno + '</span>';
    str += '</td><td></td>';
    str += '</tr>';
    str += tr_td_SS + '<b>电子邮箱：</b>';
    str += '</td>';
    str += '<td><span id="emailaddr">' + emailaddr + '</span>';
    str += '</td><td></td>';
    str += '</tr>';

    var dnsObj = DNS.split(',');
    var ns1 = dnsObj[dnsObj.length - 1];
    var ns2 = dnsObj[dnsObj.length - 2];
    str += '<tr style="display:none;"><td style="width:120px;text-align:right;">';
    str += '<b>DNS1：</b>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '<input name="dns1" id="dns1" value="' + ns1 + '"  onblur="resellerclub_keyUpCheck(this)" ' + inputSS + '/>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += '<tr style="display:none;"><td style="width:120px;text-align:right;">';
    str += '<b>DNS2：</b>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '<input name="dns2" id="dns2" value="' + ns2 + '" onblur="resellerclub_keyUpCheck(this)" ' + inputSS + '/>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += '</table>';
    str += '</div>';
    $("#swin").html(str);
}
function resellerclub_AddNewDomainContactFromTransfer(domainName, UID, ContactID, domainType, pwd, provider) {
    $("#suwin").dialog({ title: "添加新的联系人", autoOpen: false, resizable: false, width: 670, height: 550, modal: true, buttons: {
        "添 加": function () {
            resellerclub_gotoAddNewDomainContactFromTransfer(domainName, UID, ContactID, domainType, pwd, provider);
        }, "取 消": function () { $(this).dialog("close"); }
    }
    }).dialog("open");
    var str = '';
    str += '';
    var tr_td_SS = '<tr style="height:29px;line-height:29px;border-bottom:1px dashed #ddd;"><td style="width:120px;text-align:right;">';
    var inputSS = 'class="text" style="margin-top:4px;"';
    str += '<h3 style="height:40px;font-size:16px;">填写您的联系人信息 <b style="color:red;font-size:12px;word-spacing: 5px;"> ( 注意：请输入英文！)</b></h3>';
    str += '<div style="padding-left:70px;">';
    str += '<table style="width:450px;">';
    str += tr_td_SS + '<b>联系人：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="name" id="nameName" onfocus="resellerclub_keyFocus(this)" onblur="resellerclub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;width:150px;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>注册公司：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="company" id="companyName" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;width:150px;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>国家：</b>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '<select name="country" id="countryName" style="cursor:pointer;margin-top:4px;">' +
        '<option value="AU">Australia</option>' +
        '<option value="CA">Canada</option>' +
        '<option value="CN" selected="selected">China</option>' +
        '<option value="CX">Christmas Island</option>' +
        '<option value="DK">Denmark</option>' +
        '<option value="DJ">Djibouti</option>' +
        '<option value="DM">Dominica</option>' +
        '<option value="DO">Dominican Republic</option>' +
        '<option value="TP">East Timor</option>' +
        '<option value="FR">France</option>' +
        '<option value="IN">India</option>' +
        '<option value="JP">Japan</option>' +
        '<option value="MA">Morocco</option>' +
        '<option value="NZ">New Zealand</option>' +
        '<option value="OM">Oman</option>' +
        '<option value="RU">Russia</option>' +
        '<option value="SB">Solomon Islands</option>' +
        '<option value="SO">Somalia</option>' +
        '<option value="ZA">South Africa</option>' +
        '<option value="ES">Spain</option>' +
        '<option value="LK">Sri Lanka</option>' +
        '<option value="SD">Sudan</option>' +
        '<option value="TW">Taiwan</option>' +
        '<option value="US">United States</option>';
    str += '</select>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>省份：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="province" id="provinceName" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 省/市</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>城市：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="city" id="cityName" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 市/区</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>街道地址：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="address-line-1" id="address-line-1Name" onblur="resellerclub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>邮编：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="zipcode" id="zipcodeNum" onblur="resellerclub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>联系电话：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="phone-cc" id="phone-ccNum" value="86" onfocus="resellerclub_keyFocus(this)" onblur="resellerclub_keyUpCheck(this)" class="text" style="margin-top:4px;width:34px;">';
    str += '+<input name="phone" id="phoneNum" onfocus="resellerclub_keyFocus(this)" onblur="resellerclub_keyUpCheck(this)"  style="margin-top:4px;width:115px;" class="text">';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 如：86+02012345678</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>电子邮箱：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="email" id="emailName" onblur="resellerclub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>语言：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<select name="lang-pref" id="lang-prefName" style="cursor:pointer;margin-top:4px;">' +
           '<option value="ch"  selected="selected" style="cursor:pointer;">CN</option>' +
           '<option value="en" style="cursor:pointer;">EN</option>';
    str += '</select>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += '</table>';
    str += '</div>';
    str += '<div class="loading" style="margin-top:0px;text-align:center;"></div>';
    $("#suwin").html(str);
    //if ($("#divprice").length > 0) { $("#divprice").remove(); }
}
function resellerclub_gotoAddNewDomainContactFromTransfer(domainName, UID, ContactID, domainType, pwd, provider) {

    var name = $("#nameName").val(), company = $("#companyName").val(), province = $("#provinceName").val(), city = $("#cityName").val(), addressline1 = $("#address-line-1Name").val();
    var zipcode = $("#zipcodeNum").val(), phonecc = $("#phone-ccNum").val(), phone = $("#phoneNum").val();

    if ($.trim(name) == "") {
        alert("联系人不能为空！");
        return false;
    }
    if ($.trim(company) == "") {
        alert("公司名称不能为空！");
        return false;
    }
    if ($.trim(province) == "") {
        alert("省份名称不能为空！");
        return false;
    }
    if ($.trim(city) == "") {
        alert("城市名称不能为空！");
        return false;
    }
    if ($.trim(addressline1) == "") {
        alert("街道地址不能为空！");
        return false;
    }
    if ($.trim(zipcode) == "") {
        alert("邮编不能为空！");
        return false;
    }
    if ($.trim(phone) == "") {
        alert("电话号码不能为空！");
        return false;
    }
    var country = $("#countryName").val();
    var langpref = $("#lang-prefName").val();
    var email = $("#emailName").val();
    var reg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
    if (!reg.test($.trim(email))) {
        alert("邮箱格式错误！"); return false;
    }
    var str = '';
    str += '<div style="width:100%; margin:0 auto; text-align:center; padding-top:30px;">提交中，请稍后...<br>';
    str += '<img src="files/images/loading.gif" />';
    str += '</div>';
    $("#suwin .loading").html(str);
    var urlapi = '?c=module&productid=' + productData[0].pid + '&show=text&todo=resellerclub_AddNewDomainContact' +
                '&name=' + name + '&tel=' + userData[0].tel + '&email=' + email +
                '&country=' + country + '&province=' + province +
                '&city=' + city + '&addressline1=' + addressline1 +
                '&zipcode=' + zipcode + '&phonecc=' + phonecc +
                '&phone=' + phone + '&company=' + company +
                '&langpref=' + langpref + "&customerID=" + UID;

    $.get(urlapi, function (data) {
        if (data == "ok|") {
            $("#suwin").dialog("close");
            $("#suwin").dialog({ title: "添加联系人成功", autoOpen: false, resizable: false, width: 350, height: 250, modal: true, buttons: { "关 闭": function () {
                $(this).dialog("close");
            }
            }
            }).dialog("open");
            $("#suwin").html('<div style="text-align:center;margin-top:30px;color:green;"><b>添加成功！</b></div>');
            setTimeout(function () { $("#suwin").dialog("close"); resellerclub_gotoChkUserAccountToTransfer(domainName, domainType, pwd, provider); }, 2000);
            
        }
        else {
            var eflag = data.split('|');
            var es = "";
            switch (eflag[0]) {
                case "TelephoneNo":
                    es = "电话号码有误！";
                    break;
                case "Postal Code":
                    es = "邮编输入有误！";
                    break;
                case "Country Code":
                    es = "电话号码的国家编码有误！";
                    break;
                case "error":
                    es = "输入有错误，请检查输入！";
                    break;
                case "Name contains":
                    es = "联系人输入有误，请检查输入！";
                    break;
                case "Company Name contains":
                    es = "公司名称输入有误，请检查输入！";
                    break;
                case "City contains":
                    es = "城市地址输入有误，请检查输入！";
                    break;
                case "address1 contains":
                    es = "街道地址输入有误，请检查输入！";
                    break;
                default:
                    es = data;
                    break;
            }
            $("#suwin .loading").html('<div style="color:red;margin-top:5px;"><b>' + es + '</b></div>');
            return false;
        }
    });
}

function resellerclub_AddNewDomainContact(domainName, UID, ContactID) {
    $("#suwin").dialog({ title: "添加新的联系人", autoOpen: false, resizable: false, width: 670, height: 550, modal: true, buttons: {
        "添 加": function () {
            resellerclub_gotoAddNewDomainContact(domainName, UID, ContactID);
        }, "取 消": function () { $(this).dialog("close"); }
    }
    }).dialog("open");
    var str = '';
    str += '';
    var tr_td_SS = '<tr style="height:29px;line-height:29px;border-bottom:1px dashed #ddd;"><td style="width:120px;text-align:right;">';
    var inputSS = 'class="text" style="margin-top:4px;"';
    str += '<h3 style="height:40px;font-size:16px;">填写您的联系人信息 <b style="color:red;font-size:12px;word-spacing: 5px;"> ( 注意：请输入英文！)</b></h3>';
    str += '<div style="padding-left:70px;">';
    str += '<table style="width:450px;">';
    str += tr_td_SS + '<b>联系人：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="name1" id="name1" onfocus="resellerclub_keyFocus(this)" onblur="resellerclub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;width:150px;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>注册公司：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="company1" id="companyName1" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;width:150px;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>国家：</b>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '<select name="country" id="countryName" style="cursor:pointer;margin-top:4px;">' +
        '<option value="AU">Australia</option>' +
        '<option value="CA">Canada</option>' +
        '<option value="CN" selected="selected">China</option>' +
        '<option value="CX">Christmas Island</option>' +
        '<option value="DK">Denmark</option>' +
        '<option value="DJ">Djibouti</option>' +
        '<option value="DM">Dominica</option>' +
        '<option value="DO">Dominican Republic</option>' +
        '<option value="TP">East Timor</option>' +
        '<option value="FR">France</option>' +
        '<option value="IN">India</option>' +
        '<option value="JP">Japan</option>' +
        '<option value="MA">Morocco</option>' +
        '<option value="NZ">New Zealand</option>' +
        '<option value="OM">Oman</option>' +
        '<option value="RU">Russia</option>' +
        '<option value="SB">Solomon Islands</option>' +
        '<option value="SO">Somalia</option>' +
        '<option value="ZA">South Africa</option>' +
        '<option value="ES">Spain</option>' +
        '<option value="LK">Sri Lanka</option>' +
        '<option value="SD">Sudan</option>' +
        '<option value="TW">Taiwan</option>' +
        '<option value="US">United States</option>';
    str += '</select>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>省份：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="province" id="provinceName" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 省/市</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>城市：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="city" id="cityName" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 市/区</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>街道地址：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="address-line-1" id="address-line-1Name" onblur="resellerclub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>邮编：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="zipcode" id="zipcodeNum" onblur="resellerclub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>联系电话：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="phone-cc" id="phone-ccNum" value="86" onfocus="resellerclub_keyFocus(this)" onblur="resellerclub_keyUpCheck(this)" class="text" style="margin-top:4px;width:34px;">';
    str += '+<input name="phone" id="phoneNum" onfocus="resellerclub_keyFocus(this)" onblur="resellerclub_keyUpCheck(this)"  style="margin-top:4px;width:145px;" class="text">';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 如：86+02012345678</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>电子邮箱：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="email" id="emailName" onblur="resellerclub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>语言：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<select name="lang-pref" id="lang-prefName" style="cursor:pointer;margin-top:4px;">' +
           '<option value="ch"  selected="selected" style="cursor:pointer;">CN</option>' +
           '<option value="en" style="cursor:pointer;">EN</option>';
    str += '</select>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += '</table>';
    str += '</div>';
    str += '<div class="loading" style="margin-top:0px;text-align:center;"></div>';
    $("#suwin").html(str);
    //if ($("#divprice").length > 0) { $("#divprice").remove(); }
}
function resellerclub_AddNewDomainContact_RU(domainName, UID, ContactID) {
    $("#suwin").dialog({ title: "添加新的联系人", autoOpen: false, resizable: false, width: 670, height: 550, modal: true, buttons: {
        "添 加": function () {
            resellerclub_gotoAddNewDomainContact_RU(domainName, UID, ContactID);
        }, "取 消": function () { $(this).dialog("close"); }
    }
    }).dialog("open");
    var str = '';
    str += '';
    var tr_td_SS = '<tr style="height:29px;line-height:29px;border-bottom:1px dashed #ddd;"><td style="width:120px;text-align:right;">';
    var inputSS = 'class="text" style="margin-top:4px;"';
    str += '<h3 style="height:40px;font-size:16px;">填写您的联系人信息 <b style="color:red;font-size:12px;word-spacing: 5px;"> ( 注意：请输入英文！)</b></h3>';
    str += '<div style="padding-left:70px;">';
    str += '<table style="width:450px;">';
    str += tr_td_SS + '<b>联系人：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="name1" id="name1" onfocus="resellerclub_keyFocus(this)" onblur="resellerclub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;width:150px;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>注册公司：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="company1" id="companyName1" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;width:150px;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>国家：</b>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '<select name="country" id="countryName" style="cursor:pointer;margin-top:4px;">' +
        '<option value="AU">Australia</option>' +
        '<option value="CA">Canada</option>' +
        '<option value="CN" selected="selected">China</option>' +
        '<option value="CX">Christmas Island</option>' +
        '<option value="DK">Denmark</option>' +
        '<option value="DJ">Djibouti</option>' +
        '<option value="DM">Dominica</option>' +
        '<option value="DO">Dominican Republic</option>' +
        '<option value="TP">East Timor</option>' +
        '<option value="FR">France</option>' +
        '<option value="IN">India</option>' +
        '<option value="JP">Japan</option>' +
        '<option value="MA">Morocco</option>' +
        '<option value="NZ">New Zealand</option>' +
        '<option value="OM">Oman</option>' +
        '<option value="RU">Russia</option>' +
        '<option value="SB">Solomon Islands</option>' +
        '<option value="SO">Somalia</option>' +
        '<option value="ZA">South Africa</option>' +
        '<option value="ES">Spain</option>' +
        '<option value="LK">Sri Lanka</option>' +
        '<option value="SD">Sudan</option>' +
        '<option value="TW">Taiwan</option>' +
        '<option value="US">United States</option>';
    str += '</select>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>省份：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="province" id="provinceName" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 省/市</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>城市：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="city" id="cityName" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 市/区</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>街道地址：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="address-line-1" id="address-line-1Name" onblur="resellerclub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>邮编：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="zipcode" id="zipcodeNum" onblur="resellerclub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>联系电话：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="phone-cc" id="phone-ccNum" value="7" type="hidden" style="margin-top:4px;width:34px;"><span> 7 </span>';
    str += '+ <input name="phone" id="phoneNum" style="margin-top:4px;width:115px;" class="text">';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 如：7 + 1234567</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>电子邮箱：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="email" id="emailName" onblur="resellerclub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>语言：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<select name="lang-pref" id="lang-prefName" style="cursor:pointer;margin-top:4px;">' +
           '<option value="ch"  selected="selected" style="cursor:pointer;">CN</option>' +
           '<option value="en" style="cursor:pointer;">EN</option>';
    str += '</select>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += '</table>';
    str += '</div>';
    str += '<div class="loading" style="margin-top:0px;text-align:center;"></div>';
    $("#suwin").html(str);
    //if ($("#divprice").length > 0) { $("#divprice").remove(); }
}
function resellerclub_AddNewDomainContact_US(domainName, UID, ContactID) {
    $("#suwin").dialog({ title: "添加新的联系人", autoOpen: false, resizable: false, width: 670, height: 550, modal: true, buttons: {
        "添 加": function () {
            resellerclub_gotoAddNewDomainContact_US(domainName, UID, ContactID);
        }, "取 消": function () { $(this).dialog("close"); }
    }
    }).dialog("open");
    var str = '';
    str += '';
    var tr_td_SS = '<tr style="height:29px;line-height:29px;border-bottom:1px dashed #ddd;"><td style="width:120px;text-align:right;">';
    var inputSS = 'class="text" style="margin-top:4px;"';
    str += '<h3 style="height:40px;font-size:16px;">填写您的联系人信息 <b style="color:red;font-size:12px;word-spacing: 5px;"> ( 注意：请输入英文！)</b></h3>';
    str += '<div style="padding-left:70px;">';
    str += '<table style="width:450px;">';
    str += tr_td_SS + '<b>联系人：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="name1" id="name1" onfocus="resellerclub_keyFocus(this)" onblur="resellerclub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;width:150px;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>注册公司：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="company1" id="companyName1" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;width:150px;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>国家：</b>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '<select name="country" id="countryName" style="cursor:pointer;margin-top:4px;">' +
        '<option value="AU">Australia</option>' +
        '<option value="CA">Canada</option>' +
        '<option value="CN" selected="selected">China</option>' +
        '<option value="CX">Christmas Island</option>' +
        '<option value="DK">Denmark</option>' +
        '<option value="DJ">Djibouti</option>' +
        '<option value="DM">Dominica</option>' +
        '<option value="DO">Dominican Republic</option>' +
        '<option value="TP">East Timor</option>' +
        '<option value="FR">France</option>' +
        '<option value="IN">India</option>' +
        '<option value="JP">Japan</option>' +
        '<option value="MA">Morocco</option>' +
        '<option value="NZ">New Zealand</option>' +
        '<option value="OM">Oman</option>' +
        '<option value="RU">Russia</option>' +
        '<option value="SB">Solomon Islands</option>' +
        '<option value="SO">Somalia</option>' +
        '<option value="ZA">South Africa</option>' +
        '<option value="ES">Spain</option>' +
        '<option value="LK">Sri Lanka</option>' +
        '<option value="SD">Sudan</option>' +
        '<option value="TW">Taiwan</option>' +
        '<option value="US">United States</option>';
    str += '</select>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>省份：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="province" id="provinceName" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 省/市</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>城市：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="city" id="cityName" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 市/区</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>街道地址：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="address-line-1" id="address-line-1Name" onblur="resellerclub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>邮编：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="zipcode" id="zipcodeNum" onblur="resellerclub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>联系电话：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="phone-cc" id="phone-ccNum" value="86" onfocus="resellerclub_keyFocus(this)" onblur="resellerclub_keyUpCheck(this)" class="text" style="margin-top:4px;width:34px;">';
    str += '+<input name="phone" id="phoneNum" class="text" onfocus="resellerclub_keyFocus(this)" onblur="resellerclub_keyUpCheck(this)"  style="margin-top:4px;width:145px;">';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 如：86+02012345678</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>电子邮箱：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="email" id="emailName" onblur="resellerclub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>语言：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<select name="lang-pref" id="lang-prefName" style="cursor:pointer;margin-top:4px;">' +
           '<option value="ch"  selected="selected" style="cursor:pointer;">CN</option>' +
           '<option value="en" style="cursor:pointer;">EN</option>';
    str += '</select>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>域名用途：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:360px;" colspan="2">';
    str += '';
    str += '<input type="radio" name="Purpose" id="p1" checked="checked" value="P1"><label for="p1">盈利的商务组织</label>';
    str += '</br>';
    str += '<input type="radio" name="Purpose" id="p2" value="P2"><label for="p2">非盈利交易，组织等</label>';
    str += '</br>';
    str += '<input type="radio" name="Purpose" id="p3"  value="P3"><label for="p3">个人用途</label>';
    str += '</br>';
    str += '<input type="radio" name="Purpose" id="p4"  value="P4"><label for="p4">教育用途</label>';
    str += '</br>';
    str += '<input type="radio" name="Purpose" id="p5"  value="P5"><label for="p5">政府用途</label>';
    str += '';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>联系人类别：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:360px;" colspan="2">';
    str += '<input type="radio" checked="checked" name="NexusCategory" value="C11" id="nc1">';
    str += '<label for="nc1">美国公民自然人</label>';
    str += '</br>';
    str += '<input type="radio" name="NexusCategory" value="C12" id="nc2">';
    str += '<label for="nc2">美国永久居民自然人</label>';
    str += '</br>';
    str += '<input type="radio" name="NexusCategory" value="C21" id="nc3">';
    str += '<label for="nc3">总部设在美国的组织或公司—在美国领土上已成立的组织或公司或在美国法律下组建的组织</label>';
    str += '</br>';
    str += '<input type="radio" name="NexusCategory" value="C31" id="nc4">';
    str += '<label for="nc4">外国个体或组织—在美国进行道德和法律允许范围内的活动，如:销售产品、服务、商务交易、非商业性质、非盈利等</label>';
    str += '</br>';
    str += '<input type="radio" name="NexusCategory" value="C32" id="nc5">';
    str += '<label for="nc5">个体 — 在美国拥有办公室、物业</label>';
    str += '</br>';
    str += '</td>';
    str += '</tr>';
    str += '</table>';
    str += '</div>';
    str += '<div class="loading" style="margin-top:0px;text-align:center; height:60px;"></div>';
    $("#suwin").html(str);
    //if ($("#divprice").length > 0) { $("#divprice").remove(); }
}
function resellerclub_AddNewDomainContact_ASIA(domainName, UID, ContactID) {
    $("#suwin").dialog({ title: "添加新的联系人", autoOpen: false, resizable: false, width: 670, height: 550, modal: true, buttons: {
        "添 加": function () {
            resellerclub_gotoAddNewDomainContact_ASIA(domainName, UID, ContactID);
        }, "取 消": function () { $(this).dialog("close"); }
    }
    }).dialog("open");
    var str = '';
    str += '';
    var tr_td_SS = '<tr style="height:29px;line-height:29px;border-bottom:1px dashed #ddd;"><td style="width:120px;text-align:right;">';
    var inputSS = 'class="text" style="margin-top:4px;"';
    str += '<h3 style="height:40px;font-size:16px;">填写您的联系人信息 <b style="color:red;font-size:12px;word-spacing: 5px;"> ( 注意：请输入英文！)</b></h3>';
    str += '<div style="padding-left:70px;">';
    str += '<table style="width:500px;">';
    str += tr_td_SS + '<b>联系人：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="name1" id="name1" onfocus="resellerclub_keyFocus(this)" onblur="resellerclub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;width:150px;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>注册公司：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="company1" id="companyName1" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;width:150px;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>国家：</b>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '<select name="country" id="countryName" style="cursor:pointer;margin-top:4px;">' +
        '<option value="AU">Australia</option>' +
        '<option value="CA">Canada</option>' +
        '<option value="CN" selected="selected">China</option>' +
        '<option value="CX">Christmas Island</option>' +
        '<option value="DK">Denmark</option>' +
        '<option value="DJ">Djibouti</option>' +
        '<option value="DM">Dominica</option>' +
        '<option value="DO">Dominican Republic</option>' +
        '<option value="TP">East Timor</option>' +
        '<option value="FR">France</option>' +
        '<option value="IN">India</option>' +
        '<option value="JP">Japan</option>' +
        '<option value="MA">Morocco</option>' +
        '<option value="NZ">New Zealand</option>' +
        '<option value="OM">Oman</option>' +
        '<option value="RU">Russia</option>' +
        '<option value="SB">Solomon Islands</option>' +
        '<option value="SO">Somalia</option>' +
        '<option value="ZA">South Africa</option>' +
        '<option value="ES">Spain</option>' +
        '<option value="LK">Sri Lanka</option>' +
        '<option value="SD">Sudan</option>' +
        '<option value="TW">Taiwan</option>' +
        '<option value="US">United States</option>';
    str += '</select>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>省份：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="province" id="provinceName" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 省/市</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>城市：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="city" id="cityName" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 市/区</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>街道地址：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="address-line-1" id="address-line-1Name" onblur="resellerclub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>邮编：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="zipcode" id="zipcodeNum" onblur="resellerclub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>联系电话：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="phone-cc" id="phone-ccNum" value="86" onfocus="resellerclub_keyFocus(this)" onblur="resellerclub_keyUpCheck(this)" class="text" style="margin-top:4px;width:34px;">';
    str += '+<input name="phone" id="phoneNum" class="text" onfocus="resellerclub_keyFocus(this)" onblur="resellerclub_keyUpCheck(this)"  style="margin-top:4px;width:145px;">';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 如：86+02012345678</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>电子邮箱：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="email" id="emailName" onblur="resellerclub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>语言：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<select name="lang-pref" id="lang-prefName" style="cursor:pointer;margin-top:4px;">' +
           '<option value="ch"  selected="selected" style="cursor:pointer;">CN</option>' +
           '<option value="en" style="cursor:pointer;">EN</option>';
    str += '</select>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>法律实体：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:360px;" colspan="2">';
    str += '<select  name="legalentitytype" id="legalentitytype" style="cursor:pointer;margin-top:4px;">';
    str += '<option value="naturalPerson" style="cursor:pointer;">自然人</option>';
    str += '<option value="corporation" style="cursor:pointer;">公司</option>';
    str += '<option value="cooperative" style="cursor:pointer;">合作社</option>';
    str += '<option value="partnership" style="cursor:pointer;">合伙企业</option>';
    str += '<option value="government" style="cursor:pointer;">政府机构</option>';
    str += '<option value="politicalParty" style="cursor:pointer;">政党</option>';
    str += '<option value="society" style="cursor:pointer;">社团</option>';
    str += '<option value="institution" style="cursor:pointer;">公共机构</option>';
    str += '</select>';
    str += '';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>证明文件类型：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:360px;" colspan="2">';
    str += '<select  name="identform" id="identform" style="cursor:pointer;margin-top:4px;">';
    str += '<option value="passport" style="cursor:pointer;">护照</option>';
    str += '<option value="certificate" style="cursor:pointer;">证书</option>';
    str += '<option value="legislation" style="cursor:pointer;">法规</option>';
    str += '<option value="societyRegistry" style="cursor:pointer;">社团注册表</option>';
    str += '<option value="politicalPartyRegistry" style="cursor:pointer;">政党注册表</option>';
    str += '</select>';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>文件证明号码：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="identnumber" id="identnumber" onblur="resellerclub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += '</table>';
    str += '</div>';
    str += '<div class="loading" style="margin-top:0px;text-align:center; height:60px;"></div>';
    $("#suwin").html(str);
   // if ($("#divprice").length > 0) { $("#divprice").remove(); }
}

function resellerclub_gotoAddNewDomainContact(domainName, UID, ContactID) {
    var name = $("#name1").val(), company = $("#companyName1").val(), province = $("#provinceName").val(), city = $("#cityName").val(), addressline1 = $("#address-line-1Name").val();
    var zipcode = $("#zipcodeNum").val(), phonecc = $("#phone-ccNum").val(), phone = $("#phoneNum").val();

    if ($.trim(name) == "") {
        alert("联系人不能为空！");
        return false;
    }
    if ($.trim(company) == "") {
        alert("公司名称不能为空！");
        return false;
    }
    if ($.trim(province) == "") {
        alert("省份名称不能为空！");
        return false;
    }
    if ($.trim(city) == "") {
        alert("城市名称不能为空！");
        return false;
    }
    if ($.trim(addressline1) == "") {
        alert("街道地址不能为空！");
        return false;
    }
    if ($.trim(zipcode) == "") {
        alert("邮编不能为空！");
        return false;
    }
    if ($.trim(phone) == "") {
        alert("电话号码不能为空！");
        return false;
    }
    var country = $("#countryName").val();
    var langpref = $("#lang-prefName").val();
    var email = $("#emailName").val();
    var reg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
    if (!reg.test($.trim(email))) {
        alert("邮箱格式错误！"); return false;
    }
    var str = '';
    str += '<div style="width:100%; margin:0 auto; text-align:center; padding-top:30px;">提交中，请稍后...<br>';
    str += '<img src="files/images/loading.gif" />';
    str += '</div>';
    $("#suwin .loading").html(str);
    var urlapi = '?c=module&productid=' + productData[0].pid + '&show=text&todo=resellerclub_AddNewDomainContact' +
                '&name=' + name + '&tel=' + userData[0].tel + '&email=' + email +
                '&country=' + country + '&province=' + province +
                '&city=' + city + '&addressline1=' + addressline1 +
                '&zipcode=' + zipcode + '&phonecc=' + phonecc +
                '&phone=' + phone + '&company=' + company + "&domainName=" + domainName +
                '&langpref=' + langpref + "&customerID=" + UID + "&t=" + new Date();

    $.get(urlapi, function (data) {
        if (data == "ok|") {
            $("#suwin").dialog("close");
            $("#suwin").dialog({ title: "添加联系人成功", autoOpen: false, resizable: false, width: 350, height: 250, modal: true, buttons: { "关 闭": function () {
                $(this).dialog("close");
            }
            }
            }).dialog("open");
            $("#suwin").html('<div style="text-align:center;margin-top:30px;color:green;"><b>添加成功！</b></div>');
            setTimeout(function () { $("#suwin").dialog("close"); resellerclub_regDomain_Common(domainName, UID, ContactID); }, 1000);
        }
        else {
            var eflag = data.split('|');
            var es = "";
            switch (eflag[0]) {
                case "TelephoneNo":
                    es = "电话号码有误！";
                    break;
                case "Postal Code":
                    es = "邮编输入有误！";
                    break;
                case "Country Code":
                    es = "国家选择有误，请选择欧盟成员国！";
                    break;
                case "error":
                    es = "输入有错误，请检查输入！";
                    break;
                case "Name contains":
                    es = "联系人输入有误，请检查输入！";
                    break;
                case "Company Name contains":
                    es = "公司名称输入有误，请检查输入！";
                    break;
                case "City contains":
                    es = "城市地址输入有误，请检查输入！";
                    break;
                case "address1 contains":
                    es = "街道地址输入有误，请检查输入！";
                    break;
                default:
                    es = data;
                    break;
            }
            $("#suwin .loading").html('<div style="color:red;margin-top:5px;"><b>' + es + '</b></div>');
            return false;
        }
    });


}


function resellerclub_gotoAddNewDomainContact_RU(domainName, UID, ContactID) {

    var name = $("#name1").val(), company = $("#companyName1").val(), province = $("#provinceName").val(), city = $("#cityName").val(), addressline1 = $("#address-line-1Name").val();
    var zipcode = $("#zipcodeNum").val(), phonecc = $("#phone-ccNum").val(), phone = $("#phoneNum").val();

    if ($.trim(name) == "") {
        alert("联系人不能为空！");
        return false;
    }
    if ($.trim(company) == "") {
        alert("公司名称不能为空！");
        return false;
    }
    else {
        if ($.trim(company).indexOf(" ") < 0) {
            alert("公司名称至少包含两个单词！");
            return false;
        }
    }
    if ($.trim(province) == "") {
        alert("省份名称不能为空！");
        return false;
    }
    if ($.trim(city) == "") {
        alert("城市名称不能为空！");
        return false;
    }
    if ($.trim(addressline1) == "") {
        alert("街道地址不能为空！");
        return false;
    }
    if ($.trim(zipcode) == "") {
        alert("邮编不能为空！");
        return false;
    }
    if ($.trim(phone).length != 7) {
        alert("电话号码应该为7位数！");
        return false;
    }
    var country = $("#countryName").val();
    var langpref = $("#lang-prefName").val();
    var email = $("#emailName").val();
    var reg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
    if (!reg.test($.trim(email))) {
        alert("邮箱格式错误！"); return false;
    }
    var str = '';
    str += '<div style="width:100%; margin:0 auto; text-align:center; padding-top:30px;">提交中，请稍后...<br>';
    str += '<img src="files/images/loading.gif" />';
    str += '</div>';
    $("#suwin .loading").html(str);
    var urlapi = '?c=module&productid=' + productData[0].pid + '&show=text&todo=resellerclub_AddNewDomainContact_RU' +
                '&name=' + name + '&tel=' + userData[0].tel + '&email=' + email +
                '&country=' + country + '&province=' + province +
                '&city=' + city + '&addressline1=' + addressline1 +
                '&zipcode=' + zipcode + '&phonecc=' + phonecc +
                '&phone=' + phone + '&company=' + company +
                '&langpref=' + langpref + "&customerID=" + UID + "&t=" + new Date();

    $.get(urlapi, function (data) {
        if (data == "ok|") {
            $("#suwin").dialog("close");
            $("#suwin").dialog({ title: "添加联系人成功", autoOpen: false, resizable: false, width: 350, height: 250, modal: true, buttons: { "关 闭": function () {
                $(this).dialog("close");
            }
            }
            }).dialog("open");
            $("#suwin").html('<div style="text-align:center;margin-top:30px;color:green;"><b>添加成功！</b></div>');
            $("#suwin .ui-dialog-buttonset").siblings().hide();
            setTimeout(function () { $("#suwin").dialog("close"); }, 300);
            resellerclub_regDomain_RU(domainName, UID, ContactID);
        }
        else {
            var eflag = data.split('|');
            var es = "";
            switch (eflag[0]) {
                case "TelephoneNo":
                    es = "电话号码有误！";
                    break;
                case "Postal Code":
                    es = "邮编输入有误！";
                    break;
                case "Country Code":
                    es = "电话号码的国家编码有误！";
                    break;
                case "error":
                    es = "输入有错误，请检查输入！";
                    break;
                case "Name contains":
                    es = "联系人输入有误，请检查输入！";
                    break;
                case "Company Name contains":
                    es = "公司名称输入有误，请检查输入！";
                    break;
                case "City contains":
                    es = "城市地址输入有误，请检查输入！";
                    break;
                case "address1 contains":
                    es = "街道地址输入有误，请检查输入！";
                    break;
                default:
                    es = data;
                    break;
            }
            $("#suwin .loading").html('<div style="color:red;margin-top:5px;"><b>' + es + '</b></div>');
            return false;
        }
    });
}
function resellerclub_gotoAddNewDomainContact_US(domainName, UID, ContactID) {
    var name = $("#name1").val(), company = $("#companyName1").val(), province = $("#provinceName").val(), city = $("#cityName").val(), addressline1 = $("#address-line-1Name").val();
    var zipcode = $("#zipcodeNum").val(), phonecc = $("#phone-ccNum").val(), phone = $("#phoneNum").val();

    var pObj = document.getElementsByName("Purpose");
    var PurposeValue;
    for (var i = 0; i < pObj.length; i++) {
        if (pObj[i].checked == "checked" || pObj[i].checked == true) {
            PurposeValue = pObj[i].value;
            break;
        }
    }
    var ncObj = document.getElementsByName("NexusCategory");
    var NexusCategoryValue;
    for (var i = 0; i < ncObj.length; i++) {
        if (ncObj[i].checked == "checked" || ncObj[i].checked == true) {
            NexusCategoryValue = ncObj[i].value;
            break;
        }
    }

    if ($.trim(name) == "") {
        alert("联系人不能为空！");
        return false;
    }
    if ($.trim(company) == "") {
        alert("公司名称不能为空！");
        return false;
    }
    if ($.trim(province) == "") {
        alert("省份名称不能为空！");
        return false;
    }
    if ($.trim(city) == "") {
        alert("城市名称不能为空！");
        return false;
    }
    if ($.trim(addressline1) == "") {
        alert("街道地址不能为空！");
        return false;
    }
    if ($.trim(zipcode) == "") {
        alert("邮编不能为空！");
        return false;
    }
    if ($.trim(phone) == "") {
        alert("电话号码不能为空！");
        return false;
    }
    var country = $("#countryName").val();
    var langpref = $("#lang-prefName").val();
    var email = $("#emailName").val();
    var reg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
    if (!reg.test($.trim(email))) {
        alert("邮箱格式错误！"); return false;
    }
    var str = '';
    str += '<div style="width:100%; margin:0 auto; text-align:center; padding-top:30px;">提交中，请稍后...<br>';
    str += '<img src="files/images/loading.gif" />';
    str += '</div>';
    $("#suwin .loading").html(str);
    var urlapi = '?c=module&productid=' + productData[0].pid + '&show=text&todo=resellerclub_AddNewDomainContact_US' +
                '&name=' + name + '&tel=' + userData[0].tel + '&email=' + email +
                '&country=' + country + '&province=' + province +
                '&city=' + city + '&addressline1=' + addressline1 +
                '&zipcode=' + zipcode + '&phonecc=' + phonecc +
                '&phone=' + phone + '&company=' + company +
                '&langpref=' + langpref + "&customerID=" + UID + "&NexusCategory=" + NexusCategoryValue + "&Purpose=" + PurposeValue + "&t=" + new Date();

    $.get(urlapi, function (data) {
        if (data == "ok|") {
            $("#suwin").dialog("close");
            $("#suwin").dialog({ title: "添加联系人成功", autoOpen: false, resizable: false, width: 350, height: 250, modal: true, buttons: { "关 闭": function () {
                $(this).dialog("close");
            }
            }
            }).dialog("open");
            $("#suwin").html('<div style="text-align:center;margin-top:30px;color:green;"><b>添加成功！</b></div>');
            setTimeout(function () { $("#suwin").dialog("close"); }, 1000);
            resellerclub_regDomain_US(domainName, UID, ContactID);
        }
        else {
            var eflag = data.split('|');
            var es = "";
            switch (eflag[0]) {
                case "TelephoneNo":
                    es = "电话号码有误！";
                    break;
                case "Postal Code":
                    es = "邮编输入有误！";
                    break;
                case "Country Code":
                    es = "电话号码的国家编码有误！";
                    break;
                case "error":
                    es = "输入有错误，请检查输入！";
                    break;
                case "Name contains":
                    es = "联系人输入有误，请检查输入！";
                    break;
                case "Company Name contains":
                    es = "公司名称输入有误，请检查输入！";
                    break;
                case "City contains":
                    es = "城市地址输入有误，请检查输入！";
                    break;
                case "address1 contains":
                    es = "街道地址输入有误，请检查输入！";
                    break;
                default:
                    es = data;
                    break;
            }
            $("#suwin .loading").html('<div style="color:red;margin-top:5px;"><b>' + es + '</b></div>');
            return false;
        }
    });
}
function resellerclub_gotoAddNewDomainContact_ASIA(domainName, UID, ContactID) {
    var name = $("#name1").val(), company = $("#companyName1").val(), province = $("#provinceName").val(), city = $("#cityName").val(), addressline1 = $("#address-line-1Name").val();
    var zipcode = $("#zipcodeNum").val(), phonecc = $("#phone-ccNum").val(), phone = $("#phoneNum").val(), identnumber = $("#identnumber").val();

    var legalentitytype = $("#legalentitytype").val();
    var identform = $("#identform").val();

    if ($.trim(name) == "") {
        alert("联系人不能为空！");
        return false;
    }
    if ($.trim(company) == "") {
        alert("公司名称不能为空！");
        return false;
    }
    if ($.trim(province) == "") {
        alert("省份名称不能为空！");
        return false;
    }
    if ($.trim(city) == "") {
        alert("城市名称不能为空！");
        return false;
    }
    if ($.trim(addressline1) == "") {
        alert("街道地址不能为空！");
        return false;
    }
    if ($.trim(zipcode) == "") {
        alert("邮编不能为空！");
        return false;
    }
    if ($.trim(phone) == "") {
        alert("电话号码不能为空！");
        return false;
    }
    var country = $("#countryName").val();
    var langpref = $("#lang-prefName").val();
    var email = $("#emailName").val();
    var reg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
    if (!reg.test($.trim(email))) {
        alert("邮箱格式错误！"); return false;
    }
    var str = '';
    str += '<div style="width:100%; margin:0 auto; text-align:center; padding-top:30px;">提交中，请稍后...<br>';
    str += '<img src="files/images/loading.gif" />';
    str += '</div>';
    $("#suwin .loading").html(str);
    var urlapi = '?c=module&productid=' + productData[0].pid + '&show=text&todo=resellerclub_AddNewDomainContact_ASIA&customerID=' + UID +
    '&name=' + name + '&tel=' + userData[0].tel + '&email=' + email +
                '&country=' + country + '&province=' + province +
                '&city=' + city + '&addressline1=' + addressline1 +
                '&zipcode=' + zipcode + '&phonecc=' + phonecc +
                '&phone=' + phone + '&company=' + company +
                '&langpref=' + langpref + "&legalentitytype=" + legalentitytype +
                '&identform=' + identform + '&identnumber=' + identnumber + "&t=" + new Date();
    $.get(urlapi, function (data) {
        if (data == "ok|") {
            $("#suwin").dialog("close");
            $("#suwin").dialog({ title: "添加联系人成功", autoOpen: false, resizable: false, width: 350, height: 250, modal: true, buttons: { "关 闭": function () {
                $(this).dialog("close");
            }
            }
            }).dialog("open");
            $("#suwin").html('<div style="text-align:center;margin-top:30px;color:green;"><b>添加成功！</b></div>');
            setTimeout(function () { $("#suwin").dialog("close"); resellerclub_regDomain_ASIA(domainName, UID, ContactID); }, 1000);
            
        }
        else {
            var eflag = data.split('|');
            var es = "";
            switch (eflag[0]) {
                case "TelephoneNo":
                    es = "电话号码有误！";
                    break;
                case "Postal Code":
                    es = "邮编输入有误！";
                    break;
                case "Country Code":
                    es = "电话号码的国家编码有误！";
                    break;
                case "error":
                    es = "输入有错误，请检查输入！";
                    break;
                case "Name contains":
                    es = "联系人输入有误，请检查输入！";
                    break;
                case "Company Name contains":
                    es = "公司名称输入有误，请检查输入！";
                    break;
                case "City contains":
                    es = "城市地址输入有误，请检查输入！";
                    break;
                case "address1 contains":
                    es = "街道地址输入有误，请检查输入！";
                    break;
                default:
                    es = data;
                    break;
            }
            $("#suwin .loading").html('<div style="color:red;margin-top:5px;"><b>' + es + '</b></div>');
            return false;
        }
    });
}

function resellerclub_selectCNameByHTML(mStr) {
    var company = "", name = "", telnocc = "", telno = "", zip = "", contactid = "", city = "", country = "", address1 = "", emailaddr = "";
    var cNowID = $("#selectCName").val();
    var SOBj = mStr.split('|');
    var cNow;
    var cID;
    for (var i = 0; i < SOBj.length; i++) {
        cNow = SOBj[i];
        cID = cObjFindValue(cNow, "contactid");
        if (cID == cNowID) {
            break;
        }
    }
    company = cObjFindValue(cNow, "company"); country = cObjFindValue(cNow, "country");
    name = cObjFindValue(cNow, "name"); telnocc = cObjFindValue(cNow, "telnocc");
    zip = cObjFindValue(cNow, "zip"); contactid = cObjFindValue(cNow, "contactid");
    city = cObjFindValue(cNow, "city"); address1 = cObjFindValue(cNow, "address1");
    emailaddr = cObjFindValue(cNow, "emailaddr"); telno = cObjFindValue(cNow, "telno");
    $("#contactid").html(contactid);
    $("#name").html(name);
    $("#company").html(company);
    if (country == "CN") {
        country = "China";
    }
    if (country == "AU") {
        country = "Australia";
    }
    if (country == "CA") {
        country = "Canada";
    }
    if (country == "US") {
        country = "United States";
    }
    if (country == "RU") {
        country = "Russia";
    }
    if (country == "CX") {
        country = "Christmas Island";
    }
    if (country == "FR") {
        country = "France";
    }
    if (country == "IN") {
        country = "India";
    }
    if (country == "TW") {
        country = "Taiwan";
    }
    if (country == "ES") {
        country = "Spain";
    }
    if (country == "AX") {
        country = "Åland Islands";
    }
    if (country == "BG") {
        country = "Belgium";
    }
    $("#country").html(country);
    $("#telnocc").html(telnocc);
    $("#telno").html(telno);
    $("#city").html(city);
    $("#address1").html(address1);
    $("#emailaddr").html(emailaddr);
    $("#zip").html(zip);
}