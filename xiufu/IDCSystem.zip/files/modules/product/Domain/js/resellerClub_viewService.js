﻿/// <reference path="jquery-vsdoc.js" />
/// <reference path="jquery-ui.min.js" />
function resellerclub_view() {
    var str = '<table width="100%" border="0" cellspacing="0" cellpadding="0" class="table grid"><thead><tr><th  style="text-align: right;">当前域名信息：</th><th class=\"full\">&nbsp;</th></tr></thead><tbody>';
    var title = '';
    if (serviceData[0].ssid == 0) {
        title = '域名服务还在申请中...';
    }
    else {
        title = '管理我的域名 ' + serviceData[0].sconfig.domainName + '';
    }
    str += '<tr><td class="title">域名：</td><td><span id="spandomain" title="">' + serviceData[0].sconfig.domainName + '</span></td></tr>';
    if (serviceData[0].ssid != 0) {
        str += '<tr><td class="title">注册时间：</td><td><span id="regTime" title="">' + serviceData[0].sconfig.regDate + '</span></td></tr>';
        str += "<tr id='domainBtnBox' style='display:none;'>";
        str += "<td class=\"title\" style=\"text-align: right;\">";
        str += "域名管理：";
        str += "</td>";
        str += "<td>";
        str += "<form action=\"http://cloudgoing.myorderbox.com/customer\"  target=\"_blank\" method=\"POST\" name=\"form\">";
        str += "<input type=hidden name=referer value=\"/\" />";
        str += "<input type=\"hidden\" value=\"\" name=\"username\">";
        str += "<input type=\"hidden\" value=\"\" name=\"password\">";
        str += "<input type=\"submit\" value=\"域名自助管理\" class=\"submit\" style=\"cursor:pointer;\">";
        //str += "<input type=\"submit\" name='btn_login' value=\"域名自助管理\" class=\"submit\" style=\"cursor:pointer;\"></form>";
        str += "<a class=\"submit\" style=\"padding: 3px 5px 3px 5px;font-weight:blod;\" href=\"http://cloudgoing.myorderbox.com/customer\" target=\"_blank\">域名自助管理</a>";
        str += "</td></tr>";
    }
    if (serviceData[0].sconfig.transferType == "cn") { } else {
        str += '<tr><td class="title">联系人：</td><td><span id=""></span><span title="">' + serviceData[0].sconfig.username + '</span></td></tr>';
        str += '<tr><td class="title">联系电话：</td><td><span id=""></span><span title="">' + serviceData[0].sconfig.telno + '</span></td></tr>';
        str += '<tr><td class="title">联系邮箱：</td><td><span id=""></span><span title="">' + userData[0].umail + '</span></td></tr>';
        str += '<tr><td class="title">公司名称：</td><td><span id=""></span><span title="">' + serviceData[0].sconfig.company + '</span></td></tr>';
    } str += ''
    $("#pageTitle").html(title);
    document.title = title;
    var statusText = serviceStatus[parseInt(serviceData[0].sstatus) + 2];
    switch (serviceData[0].sstatus) {
        case "-1": statusText = '<strong style="color:#0000FF;">' + statusText + '</strong>'; break;
        case "0": statusText = '<strong style="color:#005B00;">' + statusText + '</strong>'; break;
        case "3": statusText = '<strong style="color:#CC3300;">' + statusText + '</strong>'; break;
        case "1":
        case "2":
        case "4": statusText = '<strong style="color:#FF0000;">' + statusText + '</strong>'; break;
    }
    str += '<tr><td class="title">续费价格：</td><td><b>' + serviceData[0].sprice + ' ' + userData[0].currency + '<b> / ' + serviceData[0].spcycle / 12 + ' 年&nbsp;&nbsp;&nbsp;<b>账户余额：</b>' + parseFloat(userData[0].balance).toFixed(2) + ' ' + userData[0].currency + ' &nbsp;&nbsp;<a href="javascript:_renew();">『马上续费』</a></td></tr>' +
            '<tr><td class="title">到期时间：</td><td><span id="endTime">' + getUnixTime(serviceData[0].etime) + '</span>&nbsp;&nbsp;<span style="color:#999;">请确保你的账户余额充足</span>&nbsp;&nbsp;&nbsp;<input id="autorenew" type="checkbox" ' + (serviceData[0].autorenew == '0' ? 'checked="checked"' : '') + '/><label for="autorenew">自动续费</label></td></tr>' +
            '<tr><td class="title">服务状态：</td><td id="statusFlag">' + statusText + ' &nbsp;&nbsp;';
    if (serviceData[0].sstatus == "-1") {
        str += '<input type=\"submit\" value=\"立即刷新状态\" class=\"submit\" onclick=\"resellerclub_reloadpage()\" />';
    }
    str += '</td></tr>';

    str += '</tbody></table>';
    str += '<table width="100%" border="0" cellspacing="0" cellpadding="0" class="table grid"><thead><tr><th style="text-align: left;">当前服务其它信息：</th><th class=\"full\">&nbsp;</th></tr></thead><tbody>';
    str += "";
    if (serviceData[0].sconfig.other != undefined && serviceData[0].sconfig.other.length > 0) {
        str += "<tr>";
        str += "<td class=\"title\" style=\"text-align: right;\">";
        str += "其它描述：";
        str += "</td>";
        str += "<td>";
        str += serviceData[0].sconfig.other;
        str += "</td></tr>";
    }
    if (serviceData[0].ssid != 0) {
       
        str += "<tr>";
        str += "<td class=\"title\" style=\"text-align: right;\">";
        str += "域名联系人管理：";
        str += "</td>";
        str += "<td>";
        str += "<input type=\"submit\" value=\"注册联系人\" onclick=\"resellerclub_DomainContact('reg')\" class=\"submit\" style=\"cursor:pointer;\">&nbsp;&nbsp;";
        if (serviceData[0].sconfig.domainName.indexOf(".eu") < 0) {
            str += "<input type=\"submit\" value=\"管理联系人\" onclick=\"resellerclub_DomainContact('admin')\" class=\"submit\" style=\"cursor:pointer;\">&nbsp;&nbsp;";
            str += "<input type=\"submit\" value=\"账单联系人\" onclick=\"resellerclub_DomainContact('billing')\" class=\"submit\" style=\"cursor:pointer;\">&nbsp;&nbsp;";
            str += "<input type=\"submit\" value=\"技术联系人\" onclick=\"resellerclub_DomainContact('tech')\" class=\"submit\" style=\"cursor:pointer;\">&nbsp;&nbsp;";
        }
        str += "<input type=\"submit\" value=\"修改联系人资料\" onclick=\"resellerclub_DomainContactAdmin()\" class=\"submit\" style=\"cursor:pointer;\">&nbsp;&nbsp;";
        if (serviceData[0].sconfig.domainName.indexOf(".us") > 0) {
            str += "<input type=\"submit\" value=\"添加新的联系人\" onclick=\"resellerclub_AddNewDomainContact_US()\" class=\"submit\" style=\"cursor:pointer;\">&nbsp;&nbsp;";
        } else {
            if (serviceData[0].sconfig.domainName.indexOf(".ru") > 0) {
                str += "<input type=\"submit\" value=\"添加新的联系人\" onclick=\"resellerclub_AddNewDomainContact_RU()\" class=\"submit\" style=\"cursor:pointer;\">&nbsp;&nbsp;";
            } else {
                if (serviceData[0].sconfig.domainName.indexOf(".asis") > 0) {
                    str += "<input type=\"submit\" value=\"添加新的联系人\" onclick=\"resellerclub_AddNewDomainContact_ASIA()\" class=\"submit\" style=\"cursor:pointer;\">&nbsp;&nbsp;";
                } else {
                    str += "<input type=\"submit\" value=\"添加新的联系人\" onclick=\"resellerclub_AddNewDomainContact()\" class=\"submit\" style=\"cursor:pointer;\">&nbsp;&nbsp;";
                }
            }
        }
        str += "</td></tr>";
        if (serviceData[0].sconfig.domainName.indexOf(".eu") > 0) { } else {
            str += "<tr>";
            str += "<td class=\"title\" style=\"text-align: right;\">";
            str += "域名安全保护：";
            str += "</td>";
            str += "<td>";
            if (serviceData[0].sconfig.domainName.indexOf(".us") > 0 || serviceData[0].sconfig.domainName.indexOf(".in") > 0 || serviceData[0].sconfig.domainName.indexOf(".eu") > 0) { } else {
                str += "<input type=\"submit\" value=\"隐私保护管理\" onclick=\"resellerclub_protectAdmin()\" class=\"submit\" style=\"cursor:pointer;\">&nbsp;&nbsp;";
            }
            if (serviceData[0].sconfig.domainName.indexOf(".eu") > 0) { } else {
                str += "<input type=\"submit\" value=\"防盗保护锁\" onclick=\"resellerclub_ProtectionLockAdmin()\" class=\"submit\" style=\"cursor:pointer;\">&nbsp;&nbsp;";
            } str += "</td></tr>";
        }
        str += "<tr>";
        str += "<td class=\"title\" style=\"text-align: right;\">";
        str += "域名DNS管理：";
        str += "</td>";
        str += "<td>";
        str += "<input type=\"submit\" value=\"域名DNS修改\" onclick=\"resellerclub_EditDomainDNS()\" class=\"submit\" style=\"cursor:pointer;\">&nbsp;&nbsp;";
        str += "&nbsp;&nbsp;";
        str += "</td></tr>";
        str += "<tr>";
        str += "<td class=\"title\" style=\"text-align: right;\">";
        str += "账户密码管理：";
        str += "</td>";
        str += "<td>";
        str += "<input type=\"submit\" value=\"获取账户密码\" onclick=\"resellerclub_getBackCustomerPwd()\" class=\"submit\" style=\"cursor:pointer;\">&nbsp;&nbsp;";

        str += "</td>";
        str += "</tr>";
    }
    str += "<tr style='display:none;'>";
    str += "<td class=\"title\" style=\"text-align: right;\">";
    str += "同步域名服务时间：";
    str += "</td>";
    str += "<td>"
    str += "<span id=\"ajaxFlag\">未同步</span>";
    str += "</td></tr>";
    str += "</tbody></table>";
    $("#ViewService").html(str);
    $("#ViewService .title").css("text-align", "right");



    var url = "?c=module&productid=" + productData[0].pid + "&show=text&todo=resellerclub_ajaxDomainInfo";
    url += "&orderid=" + serviceData[0].sconfig.OrderID;
    if (serviceData[0].ssid == 0) {
        if (serviceData[0].sconfig.transferFlag == "yes") {
            $("#ajaxFlag").html("<b style='color:red;'>域名正在转入中，请刷新页面或联系销售人员</b><input type=\"submit\" value=\"立即刷新状态\" class=\"submit\" onclick=\"resellerclub_reloadpage()\" />");
        } else {
            $("#ajaxFlag").html("<b style='color:red;'>域名正在注册中，请刷新页面或联系销售人员</b><input type=\"submit\" value=\"立即刷新状态\" class=\"submit\" onclick=\"resellerclub_reloadpage()\" />");
        } return false;
    }
    $("#ajaxFlag").html("正在加载<img src=\"/files/images/loading.gif\" />");
    $.get(url, function (data) {
        if (data.indexOf("ok") > -1) {
            $("#ajaxFlag").html("<b style='color:green;'>已经完成</b>");
            setTimeout(function () { $("#ajaxFlag").parent().parent().remove(); }, 2000);
        } else {
            if (parseInt(data) == 0) {
                $("#ajaxFlag").html("<b style='color:red;'>服务器繁忙，请点击</b><input type=\"submit\" value=\"立即刷新状态\" class=\"submit\" onclick=\"resellerclub_reloadpage()\" />");
            } else {
                if (data.indexOf("106") > -1) {
                    if (serviceData[0].sconfig.transferFlag == "yes") {
                        $("#ajaxFlag").html("<b style='color:red;'>您的域名还在转入中</b>");
                    } else {
                        $("#ajaxFlag").html("<b style='color:red;'>您的域名还没有备案或域名信息没有审核通过！</b>");
                    }
                } else {
                    $("#ajaxFlag").html("<b style='color:red;'>" + data + "</b>");
                }
            }
        }
        var LoginPath = data.split('|')[1];
        var domainBtnBox = '';
        domainBtnBox += "<td class=\"title\" style=\"text-align: right;\">";
        domainBtnBox += "域名管理：";
        domainBtnBox += "</td>";
        domainBtnBox += "<td>";
        domainBtnBox += "<form action=\"" + LoginPath + "\" style=\"display:none;\" target=\"_blank\" method=\"POST\" name=\"form\">";
        domainBtnBox += "<input type=hidden name=referer value=\"/\" />";
        domainBtnBox += "<input type=\"hidden\" value=\"\" name=\"username\">";
        domainBtnBox += "<input type=\"hidden\" value=\"\" name=\"password\">";
        domainBtnBox += "<input type=\"submit\" value=\"域名自助管理\" class=\"submit\" style=\"cursor:pointer;\">";
        domainBtnBox += "</form>";
        domainBtnBox += "<a class=\"submit\" style=\"padding: 3px 5px 3px 5px;color:white;font-weight:blod;\" href=\"" + LoginPath + "\" target=\"_blank\">域名自助管理</a>";
        domainBtnBox += "</td>";
        $("#domainBtnBox").html(domainBtnBox);
        $("#domainBtnBox").show();
        var whois = 'http://whois.chinaz.com/' + serviceData[0].sconfig.domainName;
        var mmStr = "";
        mmStr += "<tr>";
        mmStr += "<td class=\"title\" style=\"text-align: right;\">";
        mmStr += "Whois查询工具：";
        mmStr += "</td>";
        mmStr += "<td>";
        mmStr += "<span style='background-color:#444;font-weight:bold; color:White;padding:3px 5px;'><a style='font-weight:bold;text-decoration:none; color:White;' target='_blank' href='" + whois + "'>" + serviceData[0].sconfig.domainName + "</a></span>";
        mmStr += "</td></tr>";
        $("#ajaxFlag").parent().parent().parent().append(mmStr);

        var domainObj = $.parseJSON(data.split('|')[2]);
        if (domainObj.classkey == "dotcn" && domainObj.orderstatus.length <= 0) {
            $("#spandomain").append(" <span style='color:red;font-weight:bolder'>(正在审核)</span>");
        }

    });

    $("#ViewService #autorenew").css("cursor", "pointer").click(function () {
        var autorenew = $(this).prop("checked") ? '0' : '1';
        setAutorenew(serviceData[0].sid, autorenew);
    });
}

function resellerclub_reloadpage() {
    window.location.reload();
}
function resellerclub_keyUpCheck(obj) {
    var checkName = $(obj).attr("name");
    var checkValue = $.trim($(obj).val());
    switch (checkName) {
        case "TransferDomainName":
            if (checkValue.indexOf(".cn") > -1 || checkValue.indexOf(".中国") > -1 || checkValue.indexOf(".公司") > -1 || checkValue.indexOf(".网络") > -1) {
                $("#comBox").hide();
                $(obj).parent().next("td").html("");
            }
            else {
                if (checkValue.indexOf(".") > -1) {
                    $("#comBox").show();
                    $(obj).parent().next("td").html("");
                }
                else {
                    if (checkValue == "") {
                        $(obj).parent().next("td").html("<span style='color:red;'>*请填写转入域名！</span>");
                    } else {
                        $(obj).parent().next("td").html("<span style='color:red;'>*域名格式错误！</span>");
                    }
                    $(obj).focus();
                    return false;
                }
            }
            break;
        case "DomainPwd":
            if (checkValue.length > 4) {
                $(obj).parent().next("td").html("");
            }
            else {
                if (checkValue.length == 0) {
                    $(obj).parent().next("td").html("<span style='color:red;'>*密码不能为空！</span>");
                }
                else { $(obj).parent().next("td").html("<span style='color:red;'>*密码长度不符合要求!</span>"); }
                $(obj).focus(); return false;
            }
            break;
        case "domainPwd1":
            if (checkValue.length > 4) {
                $(obj).parent().next("td").html("");
            }
            else {
                if (checkValue.length == 0) {
                    $(obj).parent().next("td").html("<span style='color:red;'>*密码不能为空！</span>");
                }
                else { $(obj).parent().next("td").html("<span style='color:red;'>*6到16位!</span>"); }
                return false;
            }
            break;

        case "domainPwd2":
            if (checkValue.length > 4) {
                $(obj).parent().next("td").html("");
                var pwd1 = $.trim($("#domainPwd1").val());
                if (checkValue != pwd1) {
                    $(obj).parent().next("td").html("<span style='color:red;'>*确认密码不对</span>");
                }
                else {
                    $(obj).parent().next("td").html("<span style='color:red;'></span>");
                }
            }
            else {
                if (checkValue.length == 0) {
                    $(obj).parent().next("td").html("<span style='color:red;'>*密码不能为空！</span>");
                }
                else {
                    var pwd1 = $.trim($("#domainPwd1").val());
                    if (checkValue != pwd1) {
                        $(obj).parent().next("td").html("<span style='color:red;'>*确认密码不对</span>");
                    }
                    else {
                        $(obj).parent().next("td").html("<span style='color:red;'></span>");
                    }
                }
                return false;
            }
            break;
        case "email":
            var reg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
            if (!reg.test(checkValue)) {
                $(obj).parent().next("td").html("<span style='color:red;'>*邮箱格式错误！</span>");
                $(obj).focus(); return false;
            }
            else {
                $(obj).parent().next("td").html("");
            }
            break;
        case "province":
            if (checkValue.length == 0) {
                $(obj).parent().next("td").html("<span style='color:red;'>*不能为空</span>");
            }
            else {
                $(obj).parent().next("td").html(" 省/市");
            }
            break;
        case "city":
            if (checkValue.length == 0) {
                $(obj).parent().next("td").html("<span style='color:red;'>*不能为空</span>");
            }
            else {
                $(obj).parent().next("td").html(" 市/区");
            }
            break;
        default:
            if (checkValue.length == 0) {
                $(obj).parent().next("td").html("<span style='color:red;'>*不能为空</span>");
                $(obj).focus(); return false;
            }
            else {
                $(obj).parent().next("td").html("");
            }
            break;
    }
}
function resellerclub_keyFocus(obj) {
    var checkName = $(obj).attr("name");
    var checkValue = $.trim($(obj).val());
    switch (checkName) {
        case "province":
            $(obj).parent().next("td").html(" 省/市");
            break;
        case "city":
            $(obj).parent().next("td").html(" 市/区");
            break;
    }

}
function resellerclub_gotoEditDomainInfo() {
    var fname = $("#fname"), lname = $("#lname"), fnameE = $("#fnameE"), lnameE = $("#lnameE"), phone = $("#phone"), fax = $("#fax"), email = $("#email");
    var province = $("#province"), city = $("#city"), street = $("#street"), streetE = $("#streetE"), zipcode = $("#zipcode"), org = $("#org"), orgE = $("#orgE");
    if ($.trim(fname.val()) == "") { fname.parent().next("td").html("<b style='color:red;'>*名子不能为空！</span>"); fname.focus(); return false; }
    if ($.trim(lname.val()) == "") { lname.parent().next("td").html("<b style='color:red;'>*姓氏不能为空！</span>"); lname.focus(); return false; }
    if ($.trim(fnameE.val()) == "") { fnameE.parent().next("td").html("<b style='color:red;'>*英文名子不能为空！</span>"); fnameE.focus(); return false; }
    if ($.trim(lnameE.val()) == "") { lnameE.parent().next("td").html("<b style='color:red;'>*英文姓氏不能为空！</span>"); lnameE.focus(); return false; }
    if ($.trim(phone.val()) == "") { phone.parent().next("td").html("<b style='color:red;'>*联系电话不能为空！</span>"); phone.focus(); return false; }
    if ($.trim(fax.val()) == "") { fax.parent().next("td").html("<b style='color:red;'>*传真不能为空！</span>"); fax.focus(); return false; }
    if ($.trim(email.val()) == "") {
        email.parent().next("td").html("<b style='color:red;'>*邮箱不能为空！</span>");
        email.focus();
        return false;
    }
    else {
        var reg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
        if (!reg.test($.trim(email.val()))) {
            email.parent().next("td").html("<b style='color:red;'>*邮箱格式不正确！</span>");
            email.focus();
            return false;
        }
        else {
            email.parent().next("td").html("<b style='font-size:1px;'>&nbsp;</b>");
        }
    }
    if ($.trim(province.val()) == "") { province.parent().next("td").html("<b style='color:red;'>*省份不能为空！</span>"); province.focus(); return false; }
    if ($.trim(city.val()) == "") { city.parent().next("td").html("<b style='color:red;'>*城市不能为空！</span>"); city.focus(); return false; }
    if ($.trim(street.val()) == "") { street.parent().next("td").html("<b style='color:red;'>*街道地址不能为空！</span>"); street.focus(); return false; }
    if ($.trim(streetE.val()) == "") { streetE.parent().next("td").html("<b style='color:red;'>*英文街道地址不能为空！</span>"); streetE.focus(); return false; }
    if ($.trim(zipcode.val()) == "") { zipcode.parent().next("td").html("<b style='color:red;'>*邮编不能为空！</span>"); zipcode.focus(); return false; }
    if ($.trim(org.val()) == "") { org.parent().next("td").html("<b style='color:red;'>*公司名称不能为空！</span>"); org.focus(); return false; }
    if ($.trim(orgE.val()) == "") { orgE.parent().next("td").html("<b style='color:red;'>*英文公司名称不能为空！</span>"); orgE.focus(); return false; }
    //检查当前服务器域名
    var url = "?c=module&productid=" + productData[0].pid + "&show=text&todo=resellerclub_EditDomainInfo";
    url += "&domainName=" + serviceData[0].sconfig.domainName + "&fname=" + encodeURI($.trim(fname.val())) + "&lname=" + encodeURI($.trim(lname.val()));
    url += "&fnameE=" + $.trim(fnameE.val()) + "&lnameE=" + $.trim(lnameE.val()) + "&phone=" + $.trim(phone.val()) + "&fax=" + $.trim(fax.val());
    url += "&email=" + $.trim(email.val()) + "&province=" + encodeURI($.trim(province.val())) + "&city=" + encodeURI($.trim(city.val())) + "&street=" + encodeURI($.trim(street.val()));
    url += "&streetE=" + $.trim(streetE.val()) + "&zipcode=" + $.trim(zipcode.val()) + "&org=" + encodeURI($.trim(org.val())) + "&orgE=" + $.trim(orgE.val());

    var loadingStr = "<div class='loading' style='height:140px;text-align:center;width:330px;'>";
    loadingStr += "<img style='margin-top:50px;' src='files/images/loading.gif' /><br/>修改中，请稍后...</div>";
    $("#suwin").html(loadingStr);
    $("#suwin").dialog({ title: "正在修改域名【" + serviceData[0].sconfig.domainName + "】的信息", autoOpen: false, resizable: false, width: 380, height: 268, modal: true, buttons: {
        "关 闭": function () {
            $(this).dialog("close");
        }
    }
    }).dialog("open");
    $.get(url, function (data) {
        if (data.indexOf("800") > -1) {
            $("#suwin").dialog("close");
            $("#suwin").dialog({ title: "修改域名【" + serviceData[0].sconfig.domainName + "】的信息成功", autoOpen: false, resizable: false, width: 400, height: 280, modal: false, buttons: { "关  闭": function () { $(this).dialog("close"); } } }).dialog("open");
            $("#suwin").html("<div style='height:140px;line-height: 140px;text-align:center;width:330px;color:green;'>恭喜，域名信息修改成功！</p>");
            setTimeout(function () { $("#suwin").dialog("close"); $("#swin").dialog("close"); }, 5000);
        } else {
            $("#suwin").html("<div style='height:140px;line-height: 140px;text-align:center;width:330px;color:red;'>" + data.substr(3) + "</p>");
        }
    });

}
function resellerclub_EditDomainDNS() {
    var txtStr = '<div style="height:10px;"></div>';
    txtStr += '<table>';
    txtStr += '<tr style="height:30px;line-height: 30px;">';
    txtStr += '<td style="width:90px;text-align:right;"><b>域 名：</b></td>';
    txtStr += '<td style="text-align:left;">' + serviceData[0].sconfig.domainName + '</td><td style="width:70px;">&nbsp;</td></tr>';
    txtStr += '<tr style="height:30px;line-height: 30px;"><td style="width:90px;text-align:right;">';
    txtStr += '<b>DNS1：</b>';
    txtStr += '</td><td style="text-align:left;">';
    txtStr += '<input id="dns1" name="dns1" onblur="resellerClub_keyUpCheck(this)" class="text" style="width:180px;margin-top:5px;" />';
    txtStr += '</td><td style="width:70px;">';
    txtStr += '</td></tr>';
    txtStr += '<tr style="height:30px;line-height: 30px;"><td style="width:90px;text-align:right;">';
    txtStr += '<b>DNS2：</b>';
    txtStr += '</td><td style="text-align:left;">';
    txtStr += '<input id="dns2" name="dns2" class="text" style="width:180px;margin-top:5px;" />';
    txtStr += '</td><td style="width:90px;">';
    txtStr += '</td></tr>';
    txtStr += '</table>';
    txtStr += '';
    txtStr += '<div class="loading" style="height:35px;line-height: 35px;text-align:center;padding-top:20px;"></div>';
    $("#suwin").html('<div class="loading" style="height:35px;line-height: 35px;text-align:center;padding-top:30px;"><br>正在读取DNS信息<br><img src="files/images/loading.gif" /></div>');
    //先获取DNS信息 GetBackInfo
    var dns = '';
    var olddns1 = '', olddns2 = '';
    var getInfourl = "?c=module&productid=" + productData[0].pid + "&show=text&todo=resellerclub_GetBackDNSInfo" +
                     "&domainName=" + serviceData[0].sconfig.domainName + "&cID=" + serviceData[0].sconfig.customerID;
    $.get(getInfourl, function (data) {
        if (data == "error") {
            var b = "获取域名信息失败！可能原因如下：<br><ul style='margin-left:110px;'><li style='text-align:left;width:160px;'>1.订单不存在；</li><li style='text-align:left;width:160px;'>2.订单还没有确认。</li></ul>";
            $("#suwin").html('<div style="color:red;text-align:center;padding-top:40px;"><b>' + b + '</b></div>');
            return false;
        }
        var nObj = $.parseJSON(data);
        $("#suwin").html(txtStr);
        olddns1 = nObj.ns1;
        olddns2 = nObj.ns2;
        $("#dns1").val(olddns1); $("#dns2").val(olddns2);
    });
    $("#suwin").dialog({ title: "修改域名【" + serviceData[0].sconfig.domainName + "】的DNS信息", autoOpen: false, resizable: false, width: 400, height: 300, modal: false, buttons: {
        "立即修改": function () {

            if ($.trim($("#dns1").val()) == olddns1 && $.trim($("#dns2").val()) == olddns2) {
                $("#suwin").html('<div style="color:red;text-align:center;padding-top:40px;"><b>新的DNS与旧的DNS一样，无需修改！</b></div>');
                setTimeout(function () { $("#suwin").dialog("close"); }, 5000);
                return false;
            }

            if ($.trim($("#dns1").val()) != "") {
                $("#dns1").parent().next("td").html("");
            } else {
                if ($.trim($("#dns1").val()) == "") {
                    $("#dns1").parent().next("td").html("<b style='color:red;'> *DNS1不能为空！</b>");
                } else {
                }
                $("#dns1").focus();
                return false;
            }
            if ($.trim($("#dns2").val()) != "") {
                $("#dns2").parent().next("td").html("");
            } else {
                if ($.trim($("#dns2").val()) == "") {
                    $("#dns2").parent().next("td").html("<b style='color:red;'> *不能为空！</b>");
                } else {
                }
                return false;
            }
            var url = "?c=module&productid=" + productData[0].pid + "&show=text&todo=resellerclub_EditDomainDNS" +
                      "&dns1=" + $.trim($("#dns1").val()) + "&dns2=" + $.trim($("#dns2").val()) +
                      "&domainName=" + serviceData[0].sconfig.domainName;
            $("#suwin .loading").html("<img style='' src='files/images/loading.gif' /><br/>修改中...");
            $.get(url, function (data) {
                if (data.split('|')[0] == "ok") {
                    $("#suwin").dialog("close");
                    $("#suwin").dialog({ title: "修改域名【" + serviceData[0].sconfig.domainName + "】的DNS信息", autoOpen: false, resizable: false, width: 400, height: 280, modal: false, buttons: { "关  闭": function () { $(this).dialog("close"); } } }).dialog("open");
                    $("#suwin").html("<div style='height:140px;line-height: 140px;text-align:center;width:330px;color:green;'>恭喜，DNS信息修改成功！</p>");
                    setTimeout(function () { $("#suwin").dialog("close"); }, 3000);
                } else {
                    $("#suwin .loading").html("");
                    $("#suwin").dialog("close");
                    $("#suwin").dialog({ title: "修改域名【" + serviceData[0].sconfig.domainName + "】的DNS信息", autoOpen: false, resizable: false, width: 400, height: 280, modal: false, buttons: { "关  闭": function () { $(this).dialog("close"); } } }).dialog("open");
                    $("#suwin").html("<div style='height:140px;line-height: 140px;text-align:center;width:330px;color:red;'>" + data.split('|')[0] + "</p>");
                }
            });

        }, "取 消": function () {
            $(this).dialog("close");
        }
    }
    }).dialog("open");
}
//function resellerclub_ViewTransferDomain() {
//    var local = window.location.href;
//    local = local.replace("http://");
//    var url = "?c=module&productid=" + productData[0].pid + "&show=text&todo=custom_TransferStatus";
//    url += "&domainName=" + serviceData[0].sconfig.domainName;
//    var txtStr = '<div style="height:30px;"></div>';
//    txtStr += '<table>';
//    txtStr += '<tr style="height:30px;line-height: 30px;">';
//    txtStr += '<td style="width:120px;text-align:right;">服务ID：</td>';
//    txtStr += '<td style="text-align:left;">D' + serviceData[0].sid + '</td></tr>';
//    txtStr += '<tr style="height:30px;line-height: 30px;"><td style="width:120px;text-align:right;">';
//    txtStr += '转入域名：';
//    txtStr += '</td><td style="text-align:left;">';
//    txtStr += serviceData[0].sconfig.domainName;
//    txtStr += '</td></tr>';
//    txtStr += '</table>';
//    txtStr += '<div class="loading" style="height:35px;line-height: 35px;text-align:center;padding-top:20px;"></div>';
//    $("#suwin").html(txtStr);
//    $("#suwin").dialog({ title: "查询服务[#D" + serviceData[0].sid + "]域名转入状态", autoOpen: false, resizable: false, width: 380, height: 268, modal: false, buttons: {
//        "立即查看": function () {
//            $("#suwin .loading").html("<img style='' src='files/images/loading.gif' /><br/>查询中...");
//            $.get(url, function (data) {
//                if (data.indexOf("1000") > -1) {
//                    $("#suwin").html("<div style='height:140px;line-height: 140px;text-align:center;width:330px;color:green;'>恭喜，你的域名已经转入成功！</p>");
//                    //setTimeout(function () { $("#suwin").dialog("close"); }, 3000);
//                } else {
//                    $("#suwin .loading").html("");
//                    if (data.indexOf("1003") > -1) {
//                        $("#suwin").html("<div style='height:140px;line-height: 140px;text-align:center;width:330px;color:green;'>您好，你的域名正在转入中,请稍后！</p>");
//                    } else {
//                        $("#suwin").html("<div style='height:140px;line-height: 140px;text-align:center;width:330px;color:red;'>抱歉，你的转入出现错误：" + data.substr(4) + "</p>");
//                    }
//                }
//            });

//        }, "取 消": function () {
//            $(this).dialog("close");
//        }
//    }
//    }).dialog("open");

//}

function resellerclub_protectAdmin() {
    $("#suwin").html(ajaxLoading("正在加载信息，请稍等......"))
    $("#suwin").dialog({ title: "操作提示", autoOpen: false, resizable: false, width: 350, height: 200, modal: true, buttons: { "关 闭": function () { $(this).dialog("close"); } } }).dialog("open");

    var url = "?c=module&productid=" + productData[0].pid + "&show=text&todo=resellerclub_CHKUserRoleAndDomainProtect&orderID=" + serviceData[0].sconfig.OrderID;
    var role = "", lock = false;
    $.get(url, function (data) {
        if (data.split('|')[0] == "admin") {
            role = "admin";
        }
        if (data.split('|')[1] == "true") {
            lock = true;
        }
        var txtStr = '';

        txtStr = '<div style="margin-top:5px;margin-left:15px;">';
        txtStr += '<table>';
        txtStr += '<tr style="height:30px;line-height: 30px;"><td style="width:100px;text-align:right;">';
        txtStr += '<b>域 名：</b>';
        txtStr += '</td><td style="text-align:left;">';
        txtStr += serviceData[0].sconfig.domainName;
        txtStr += '</td></tr>';
        txtStr += '<tr style="height:30px;line-height: 30px;"><td style="width:100px;text-align:right;">';
        txtStr += '<b>隐私保护状态：</b>';
        txtStr += '</td><td style="text-align:left;">';
        if (lock) {
            txtStr += '<input type="radio" checked="checked" name="sendToName" value="true" style="cursor:pointer;" id="t111" /><lable for="t111">开启(目前状态)</lable> &nbsp;&nbsp;';
            txtStr += '<input type="radio" name="sendToName" value="false" style="cursor:pointer;" id="f111" /><lable for="f111">关闭</lable>';
        }
        else {
            txtStr += '<input type="radio" name="sendToName" value="true" style="cursor:pointer;" id="t111" /><lable for="t111">开启</lable> &nbsp;&nbsp;';
            txtStr += '<input type="radio" checked="checked" name="sendToName" value="false" style="cursor:pointer;" id="f111" /><lable for="f111">关闭(目前状态)</lable>';
        }
        txtStr += '</td></tr>';
        var height = 250, width = 380;
        if (role != "admin" && (emailchk_ResellerClub != "0" || smschk_ResellerClub != "0")) {
            height = 280, width = 380;
            txtStr += '<tr style="height:30px;line-height: 30px;"><td style="width:100px;text-align:right;">';
            txtStr += '<b>发送验证码：</b>';
            txtStr += '</td><td style="text-align:left;">';

            if (emailchk_ResellerClub != "0") {
                txtStr += '<input type="button" class="submit" value="发到邮箱" id="mailBtn" onclick="sendCodeToEmail(3)" /> &nbsp;&nbsp;';
            }
            if (smschk_ResellerClub != "0") {
                txtStr += '<input type="button" class="submit" value="发到手机" id="phoneBtn" onclick="sendCodeToPhone(3)" />';
            }
            txtStr += '</td></tr>';
            txtStr += '<tr style="height:30px;line-height: 30px;"><td style="width:100px;text-align:right;">';
            txtStr += '<b><input type="hidden" id="codeFlag" value="-1">输入验证码：</b>';
            txtStr += '</td><td style="text-align:left;">';
            txtStr += '<input name="vcode" id="vcode" class="text" style="width:110px;margin-top:3px;" />';
            txtStr += '</td></tr>';
        }

        txtStr += '</td></tr>';
        txtStr += '</table></div>';

        $("#suwin").html(txtStr);
        $("#suwin").dialog({ title: "域名【" + serviceData[0].sconfig.domainName + "】隐私保护管理", autoOpen: false, resizable: false, width: width, height: height, modal: true, buttons: {
            "立即修改": function () {

                processing("正在处理，请稍等...");
                var chkCode = "";
                if (userData[0].isAdmin != "True" && (emailchk_ResellerClub != "0" || smschk_ResellerClub != "0") && $.trim($("#vcode").val()) == "") {
                    showResults('验证码不能为空！', 3000, "close");
                    return false;
                }
                else {
                    chkCode = $.trim($("#vcode").val());
                }
                var sendTo = $("input[name=sendToName]:checked").val();
                var todo = 'resellerclub_OffProtect';
                if (sendTo == 'true') {
                    todo = 'resellerclub_OnProtect';
                }
                url = "?c=module&productid=" + productData[0].pid + "&show=text&todo=" + todo + "&orderID=" + serviceData[0].sconfig.OrderID + "&vcode=" + chkCode + "&domainName=" + serviceData[0].sconfig.domainName;

                $.get(url, function (data) {
                    var vArr = data.split('|');
                    var bFlag = vArr[0];
                    var bStr = "";
                    if (bFlag == "ok" || bFlag == "lock") {
                        switch (bFlag) {
                            case "ok":
                                if (sendTo == "true") {
                                    bStr = "<b style='color:green;'>恭喜，隐私保护开启成功！</b>";
                                } else {
                                    bStr = "<b style='color:green;'>恭喜，隐私保护关闭成功！</b>";
                                }
                                break;
                            case "lock":
                                bStr = "<b style='color:red;'>防盗保护锁已是关闭状态！</b>";
                                break;
                        }
                        $("#suwin").dialog("close");
                        showResults(bStr, 3000, "close");
                    } else {
                        showResults(vArr[1], 3000, "close");
                    }
                });

            }, "取 消": function () {
                $(this).dialog("close");
            }
        }
        }).dialog("open");
    });
}
function resellerclub_ProtectionLockAdmin() {
    $("#suwin").html(ajaxLoading("正在加载信息，请稍等......"))
    $("#suwin").dialog({ title: "操作提示", autoOpen: false, resizable: false, width: 350, height: 200, modal: true, buttons: { "关 闭": function () { $(this).dialog("close"); } } }).dialog("open");

    var url = "?c=module&productid=" + productData[0].pid + "&show=text&todo=resellerclub_CHKUserRoleAndDomainLock&orderID=" + serviceData[0].sconfig.OrderID;
    var role = "", aflag = false, lock = false;
    $.get(url, function (data) {
        if (data.split('|')[0] == "admin") {
            role = "admin";
        }
        if (data.split('|')[1] == "true") {
            lock = true;
        }
        var txtStr = '';
        txtStr = '<div style="margin-top:5px;margin-left:15px;">';
        txtStr += '<table>';
        txtStr += '<tr style="height:30px;line-height: 30px;"><td style="width:100px;text-align:right;">';
        txtStr += '<b>域 名：</b>';
        txtStr += '</td><td style="text-align:left;">';
        txtStr += serviceData[0].sconfig.domainName;
        txtStr += '</td></tr>';

        txtStr += '<tr style="height:30px;line-height: 30px;"><td style="width:100px;text-align:right;">';
        txtStr += '<b>防盗锁状态：</b>';
        txtStr += '</td><td style="text-align:left;">';

        if (lock) {
            txtStr += '<input type="radio" checked="checked" name="sendToName" value="true" style="cursor:pointer;" id="t111" /><lable for="t111">开启(目前状态)</lable> &nbsp;&nbsp;';
            txtStr += '<input type="radio" name="sendToName" value="false" style="cursor:pointer;" id="f111" /><lable for="f111">关闭</lable>';
        }
        else {
            txtStr += '<input type="radio" name="sendToName" value="true" style="cursor:pointer;" id="t111" /><lable for="t111">开启</lable> &nbsp;&nbsp;';
            txtStr += '<input type="radio" checked="checked" name="sendToName" value="false" style="cursor:pointer;" id="f111" /><lable for="f111">关闭(目前状态)</lable>';
        }
        txtStr += '</td></tr>';

        var height = 250, width = 380;
        if (role != "admin" && (emailchk_ResellerClub != "0" || smschk_ResellerClub != "0")) {
            height = 280, width = 380;
            txtStr += '<tr style="height:30px;line-height: 30px;"><td style="width:100px;text-align:right;">';
            txtStr += '<b>发送验证码：</b>';
            txtStr += '</td><td style="text-align:left;">';
            if (emailchk_ResellerClub != "0") {
                txtStr += '<input type="button" class="submit" value="发到邮箱" id="mailBtn" onclick="sendCodeToEmail(3)" /> &nbsp;&nbsp;';
            }
            if (smschk_ResellerClub != "0") {
                txtStr += '<input type="button" class="submit" value="发到手机" id="phoneBtn" onclick="sendCodeToPhone(3)" />';
            }
            txtStr += '</td></tr>';
            txtStr += '<tr style="height:30px;line-height: 30px;"><td style="width:100px;text-align:right;">';
            txtStr += '<b><input type="hidden" id="codeFlag" value="-1">输入验证码：</b>';
            txtStr += '</td><td style="text-align:left;">';
            txtStr += '<input name="vcode" id="vcode" class="text" style="width:110px;margin-top:3px;" />';
            txtStr += '</td></tr>';
        }

        txtStr += '</table></div>';
        txtStr += '<div class="loading" style="text-align:center;padding-top:2px;"></div>';
        $("#suwin").html(txtStr);

        $("#suwin").dialog({ title: "域名【" + serviceData[0].sconfig.domainName + "】的防盗保护锁", autoOpen: false, resizable: false, width: width, height: height, modal: true, buttons: {
            "立即修改": function () {
                processing("正在处理，请稍等...");
                var chkCode = "";
                if (userData[0].isAdmin != "True" && (emailchk_ResellerClub != "0" || smschk_ResellerClub != "0") && $.trim($("#vcode").val()) == "") {
                    showResults('验证码不能为空！', 3000, "close");
                    return false;
                }
                else {
                    chkCode = $.trim($("#vcode").val());
                }
                var sendTo = $("input[name=sendToName]:checked").val();
                var todo = 'resellerclub_OffLock';
                if (sendTo == 'true') {
                    todo = 'resellerclub_OnLock';
                }
                url = "?c=module&productid=" + productData[0].pid + "&show=text&todo=" + todo + "&orderID=" + serviceData[0].sconfig.OrderID + "&vcode=" + chkCode + "&domainName=" + serviceData[0].sconfig.domainName;
                $.get(url, function (data) {
                    var vArr = data.split('|');
                    var bFlag = vArr[0];
                    var bStr = "";
                    if (bFlag == "ok" || bFlag == "lock") {

                        switch (bFlag) {
                            case "ok":
                                if (sendTo == "true") {
                                    bStr = "<b style='color:green;'>恭喜，防盗保护锁开启成功！</b>";
                                } else {
                                    bStr = "<b style='color:green;'>恭喜，防盗保护锁关闭成功！</b>";
                                }
                                break;
                            case "lock":
                                bStr = "<b style='color:red;'>防盗保护锁已是关闭状态！</b>";
                                break;
                        }
                        $("#suwin").dialog("close");
                        showResults(bStr, 3000, "close");
                    } else {
                        showResults(vArr[1], 3000, "close");
                    }
                });

            }, "取 消": function () { $(this).dialog("close"); }
        }
        }).dialog("open");
    });
}

function resellerclub_DomainContact(obj) {
    var cType = "", lFlag = false;
    switch (obj) {
        case "reg":
            cType = "注册";
            break;
        case "admin":
            cType = "管理";
            break;
        case "billing":
            cType = "账单";
            break;
        case "tech":
            cType = "技术";
            break;
    }
    $("#swin").dialog({ title: "域名【" + serviceData[0].sconfig.domainName + "】" + cType + "联系人管理", autoOpen: false, resizable: false, width: 650, height: 490, modal: false, buttons: {
        "更换联系人": function () {
            if (lFlag) {
                $("#swin").dialog("close");
                $("#hidCName").hide();
                $("#showCName").show();
                $("#swin").dialog({ title: "更换域名【" + serviceData[0].sconfig.domainName + "】的" + cType + "联系人", autoOpen: false, resizable: false, width: 650, height: 490, modal: false, buttons: {
                    "保存更换": function () {
                        var selectCName = $("#selectCName").val();
                        if (changeNewContactID == selectCName) { alert("联系人没有更改！"); return false; } else {
                            resellerclub_changeDomainContact(obj, selectCName);
                        }
                    }, "取 消": function () { $(this).dialog("close"); }
                }
                }).dialog("open");
            } else { alert("请等待页面加载完成！"); return false; }
        }, "关 闭": function () { $(this).dialog("close"); }
    }
    }).dialog("open");
    $("#swin").html('<div class="loading" style="text-align:center;padding-top:40px;"><img src="files/images/loading.gif" /><br/>Loading...</div>');
    var urlStr = "?c=module&productid=" + productData[0].pid + "&show=text&todo=resellerclub_GetDomainContact&cType=" + obj + "&domainName=" + serviceData[0].sconfig.domainName + "&orderID=" + serviceData[0].sconfig.OrderID + "&customerID=" + serviceData[0].sconfig.customerID + "&t=" + (new Date().getTime()).valueOf();
    var changeNewContactID = "";
    $.get(urlStr, function (data) {
        lFlag = true;
        if (data.indexOf("-1|") > -1 || data.indexOf("Error Page") > 0) {
            $("#swin").html("<div style='color:red;text-align:center;margin-top:150px;'><b>抱歉，没有找到域名" + serviceData[0].sconfig.domainName + "相关的订单信息！</b></div>");
            return false;
        }
        var company = "", name = "", telnocc = "", telno = "", zip = "", contactid = "", city = "", country = "", address1 = "", emailaddr = "";
        var cObj = data.split('|');
        changeNewContactID = cObj[0];
        var cNow = cObj[1];
        company = cObjFindValue(cNow, "company"); country = cObjFindValue(cNow, "country");
        name = cObjFindValue(cNow, "name"); telnocc = cObjFindValue(cNow, "telnocc");
        zip = cObjFindValue(cNow, "zip"); contactid = cObjFindValue(cNow, "contactid");
        city = cObjFindValue(cNow, "city"); address1 = cObjFindValue(cNow, "address1");
        emailaddr = cObjFindValue(cNow, "emailaddr"); telno = cObjFindValue(cNow, "telno");
        var str = '';
        var tr_td_SS = '<tr style="height:29px;line-height:29px;border-bottom:1px dashed #ddd;"><td style="width:120px;text-align:right;">';
        var inputSS = 'class="text" style="margin-top:4px;"';
        str += '<div style="margin:55px auto auto 120px;">';
        str += '<table style="width:380px;">';
        str += tr_td_SS + '<b>联系人：</b>';
        str += '</td>';
        str += '<td>';
        str += '<span id="hidCName">' + cObjFindValue(cNow, "name") + '</span>';
        str += '<span style="display:none;" id="showCName"><select id="selectCName" name="selectCName" style="cursor:pointer;height:23px;" onchange="resellerclub_selectCNameByHTML(\'' + data + '\')">';
        str += getContactInfo(cObj);

        // str += '<option value="' + cObjFindValue(cNow, "contactid") + '">' + cObjFindValue(cNow, "name") + '</option>';
        // for (var i = 2; i < cObj.length; i++) {
        // str += '<option value="' + cObjFindValue(cObj[i], "contactid") + '">' + cObjFindValue(cObj[i], "name") + '</option>';
        // }
        str += '</select></span>';
        str += '</td>';
        str += '</tr>';
        str += tr_td_SS + '<b>联系姓名：</b>';
        str += '</td>';
        str += '<span id="contactid" style="display:none;">' + contactid + '</span>';
        str += '<td><span id="name">' + name + '</span>';
        str += '</td>';
        str += '</tr>';
        if (country != undefined) {
            str += tr_td_SS + '<b>国家：</b>';
            str += '</td>';
            str += '<td>';
            if (country == "CN") {
                str += '<span id="country">China</span>';
            }
            if (country == "AU") {
                str += '<span id="country">Australia</span>';
            }
            if (country == "CA") {
                str += '<span id="country">Canada</span>';
            }
            if (country == "US") {
                str += '<span id="country">United States</span>';
            }
            if (country == "CX") {
                str += '<span id="country">Christmas Island</span>';
            }
            if (country == "FR") {
                str += '<span id="country">France</span>';
            }
            if (country == "IN") {
                str += '<span id="country">India</span>';
            }
            if (country == "TW") {
                str += '<span id="country">Taiwan</span>';
            }
            if (country == "ES") {
                str += '<span id="country">Spain</span>';
            }
            if (country == "AX") {
                str += '<span id="country">Åland Islands</span>';
            }
            if (country == "BG") {
                str += '<span id="country">Belgium</span>';
            }
            str += '</td>';
            str += '</tr>';
        }
        str += tr_td_SS + '<b>公司名称：</b>';
        str += '</td>';
        str += '<td><span id="company">' + company + '</span>';
        str += '</td>';
        str += '</tr>';
        str += tr_td_SS + '<b>城市：</b>';
        str += '</td>';
        str += '<td><span id="city">' + city + '</span>';
        str += '</td>';
        str += '</tr>';
        str += tr_td_SS + '<b>街道地址：</b>';
        str += '</td>';
        str += '<td><span id="address1">' + address1 + '</span>';
        str += '</td>';
        str += '</tr>';
        str += tr_td_SS + '<b>邮编：</b>';
        str += '</td>';
        str += '<td><span id="zip">' + zip + '</span>';
        str += '</td>';
        str += '</tr>';
        str += tr_td_SS + '<b>联系电话：</b>';
        str += '</td>';
        str += '<td>';
        str += '<span id="telnocc">' + telnocc + '</span>';
        str += '+<span id="telno">' + telno + '</span>';
        str += '</td>';
        str += '</tr>';
        str += tr_td_SS + '<b>电子邮箱：</b>';
        str += '</td>';
        str += '<td><span id="emailaddr">' + emailaddr + '</span>';
        str += '</td>';
        str += '</tr>';
        str += '</table>';
        str += '<div>';
        $("#swin").html(str);

    });

}

function getContactInfo(cObj) {
    var contactname = '', str = '';
    var i = cObj.length==1 ? 0 : 1;
    for (; i < cObj.length; i++) {
        if (contactname != cObjFindValue(cObj[i], "name")) {
            contactname = cObjFindValue(cObj[i], "name");
            str += '<option value="' + cObjFindValue(cObj[i], "contactid") + '">' + contactname + '</option>';
        }
    }
    return str;
}
function resellerclub_changeDomainContact(cType, selectCID) {
    var url = "?c=module&productid=" + productData[0].pid + "&show=text&todo=resellerclub_ChangeDomainContactID" +
              "&contactid=" + selectCID + "&cType=" + cType + "&domainName=" + serviceData[0].sconfig.domainName + "&orderID=" + serviceData[0].sconfig.OrderID + "&t=" + (new Date()).valueOf();
    $.get(url, function (data) {
        if (data == "ok|") {
            $("#suwin").html('<div style="text-align:center;padding-top:40px;color:green;"></b>恭喜，修改成功！</b></div>');
            setTimeout(function () { $("#suwin").dialog("close"); $("#swin").dialog("close"); resellerclub_reloadpage(); }, 1000);
        } else {
            if (data == "existOK|") {
                $("#suwin").html('<div style="text-align:center;padding-top:40px;color:green;"></b>恭喜，修改成功！</b></div>');
                setTimeout(function () { $("#suwin").dialog("close"); $("#swin").dialog("close"); resellerclub_reloadpage(); }, 1000);
            } else {
                $("#suwin").html('<div style="text-align:center;padding-top:40px;color:red;"></b>抱歉，修改失败，请稍候再试！</b></div>');
            }
        }
    });
    $("#suwin").dialog({ title: "正在保存联系人信息", autoOpen: false, resizable: false, width: 300, height: 200, modal: true, buttons: {
        "关 闭": function () { $(this).dialog("close"); }
    }
    }).dialog("open");
    $("#suwin").html('<div style="text-align:center;padding-top:40px;">正在保存中...<br/><img src="files/images/loading.gif" /></div>');

}
function resellerclub_DomainContactAdmin() {
    var url = "?c=module&productid=" + productData[0].pid + "&show=text&todo=resellerclub_GetDomainContactList&domainName=" + serviceData[0].sconfig.domainName + "&orderID=" + serviceData[0].sconfig.OrderID + "&customerID=" + serviceData[0].sconfig.customerID + "&t=" + (new Date().getTime()).valueOf();
    $.get(url, function (data) {
        var company = "", name = "", telnocc = "", telno = "", zip = "", contactid = "", city = "", country = "", address1 = "", emailaddr = "";
        if (data == "error") {
            $("#swin").html('<div style="text-align:center;padding-top:40px;color:red;"><b>抱歉，获取该订单信息时出错！<br/>请登录自己的个人账户管理联系人！</b></div>');
        } else {
            if (data == "none") {
                $("#swin").html('<div style="text-align:center;padding-top:40px;"><b>抱歉，联系人为空，请增加联系人！</b></div>');
            } else {
               
                var cObj = data.split('|');
                var cNow = cObj[0];
                company = cObjFindValue(cNow, "company"); country = cObjFindValue(cNow, "country");
                name = cObjFindValue(cNow, "name"); telnocc = cObjFindValue(cNow, "telnocc");
                zip = cObjFindValue(cNow, "zip"); contactid = cObjFindValue(cNow, "contactid");
                city = cObjFindValue(cNow, "city"); address1 = cObjFindValue(cNow, "address1");
                emailaddr = cObjFindValue(cNow, "emailaddr"); telno = cObjFindValue(cNow, "telno");
                var str = '';
                var tr_td_SS = '<tr style="height:29px;line-height:29px;border-bottom:1px dashed #ddd;"><td style="width:120px;text-align:right;">';
                var inputSS = 'class="text" style="margin-top:4px;"';
                str += '<div style="margin:55px auto auto 120px;">';
                str += '<table style="width:380px;">';
                str += tr_td_SS + '<b>联系人：</b>';
                str += '</td>';
                str += '<td>';
                str += '<select id="selectCName" name="selectCName" style="cursor:pointer;height:23px;" onchange="resellerclub_selectCName(\'' + data + '\')">';
                str += getContactInfo(cObj);
                //str += '<option value="' + cObjFindValue(cNow, "contactid") + '">' + cObjFindValue(cNow, "name") + '</option>';
                // for (var i = 1; i < cObj.length; i++) {
                // str += '<option value="' + cObjFindValue(cObj[i], "contactid") + '">' + cObjFindValue(cObj[i], "name") + '</option>';
                //}
                str += '</select>';
                str += '</td>';
                str += '</tr>';
                str += tr_td_SS + '<b>联系姓名：</b>';
                str += '</td>';
                str += '<input id="contactid" name="contactid" value="' + contactid + '" type="hidden" />';
                str += '<td><input id="name" name="name" value="' + name + '" ' + inputSS + ' />';
                str += '</td>';
                str += '</tr>';
                str += tr_td_SS + '<b>国家：</b>';
                str += '</td>';
                str += '<td>';
                str += '<select name="country" id="country" style="cursor:pointer;margin-top:4px;">';
                if (country == "CN") { str += '<option value="CN" selected="selected">China</option>'; } else {
                    str += '<option value="CN">China</option>';
                } if (country == "AU") { str += '<option value="AU" selected="selected">Australia</option>'; } else {
                    str += '<option value="AU">Australia</option>';
                }
                if (country == "CA") { str += '<option value="CA" selected="selected">Canada</option>'; } else {
                    str += '<option value="CA">Canada</option>';
                }
                if (country == "US") { str += '<option value="US" selected="selected">United States</option>'; } else {
                    str += '<option value="US">United States</option>';
                }
                if (country == "CX") { str += '<option value="CX" selected="selected">Christmas Island</option>'; } else {
                    str += '<option value="CX">Christmas Island</option>';
                }
                if (country == "FR") { str += '<option value="FR" selected="selected">France</option>'; } else {
                    str += '<option value="FR">France</option>';
                }
                if (country == "IN") { str += '<option value="IN" selected="selected">India</option>'; } else {
                    str += '<option value="IN">India</option>';
                }
                if (country == "TW") { str += '<option value="TW" selected="selected">Taiwan</option>'; } else {
                    str += '<option value="TW">Taiwan</option>';
                }
                if (country == "ES") { str += '<option value="ES" selected="selected">Spain</option>'; } else {
                    str += '<option value="ES">Spain</option>';
                }
                str += '<option value="DK">Denmark</option>';
                str += '<option value="DJ">Djibouti</option>';
                str += '<option value="DM">Dominica</option>';
                str += '<option value="DO">Dominican Republic</option>';
                str += '<option value="TP">East Timor</option>';
                str += '<option value="JP">Japan</option>';
                str += '<option value="OM">Oman</option>';
                str += '<option value="NZ">New Zealand</option>';
                str += '<option value="MA">Morocco</option>';
                str += '<option value="RU">Russia</option>';
                str += '<option value="SB">Solomon Islands</option>';
                str += '<option value="SO">Somalia</option>';
                str += '<option value="ZA">South Africa</option>';

                str += '<option value="LK">Sri Lanka</option>';
                str += '<option value="SD">Sudan</option>';
                str += '</select>';
                str += '</td>';
                str += '</tr>';
                str += tr_td_SS + '<b>公司名称：</b>';
                str += '</td>';
                str += '<td><input id="company" name="company" value="' + company + '" ' + inputSS + ' />';
                str += '</td>';
                str += '</tr>';
                str += tr_td_SS + '<b>城市：</b>';
                str += '</td>';
                str += '<td><input id="city" name="city" value="' + city + '" ' + inputSS + ' />';
                str += '</td>';
                str += '</tr>';
                str += tr_td_SS + '<b>街道地址：</b>';
                str += '</td>';
                str += '<td><input id="address1" name="address1" value="' + address1 + '" ' + inputSS + ' />';
                str += '</td>';
                str += '</tr>';
                str += tr_td_SS + '<b>邮编：</b>';
                str += '</td>';
                str += '<td><input id="zip" name="zip" value="' + zip + '" ' + inputSS + ' />';
                str += '</td>';
                str += '</tr>';
                str += tr_td_SS + '<b>联系电话：</b>';
                str += '</td>';
                str += '<td>';
                str += '<input name="telnocc" id="telnocc" value="' + telnocc + '" onfocus="resellerclub_keyFocus(this)" onblur="resellerClub_keyUpCheck(this)" class="text" style="margin-top:4px;width:34px;">';
                str += '+<input name="telno" id="telno" value="' + telno + '" onfocus="resellerclub_keyFocus(this)" onblur="resellerClub_keyUpCheck(this)"  style="margin-top:4px;width:115px;" class="text">';
                str += '</td>';
                str += '</tr>';
                str += tr_td_SS + '<b>电子邮箱：</b>';
                str += '</td>';
                str += '<td><input id="emailaddr" name="emailaddr" value="' + emailaddr + '" ' + inputSS + ' />';
                str += '</td>';
                str += '</tr>';
                str += '</table>';
                str += '<div>';
                $("#swin").html(str);
            }
        }
    });
    $("#swin").dialog({ title: "域名【" + serviceData[0].sconfig.domainName + "】联系人管理", autoOpen: false, resizable: false, width: 680, height: 500, modal: false, buttons: {
        "保存修改": function () {
            resellerclub_gotoEditDomainContactList();
        },
        "关 闭": function () { $(this).dialog("close"); }
    }
    }).dialog("open");
    $("#swin").html('<div class="loading" style="text-align:center;padding-top:40px;"><img src="files/images/loading.gif" /><br/>Loading...</div>');

}

function resellerclub_gotoEditDomainContactList() {
    var company = "", name = "", telnocc = "", telno = "", zip = "", contactid = "", city = "", country = "", address1 = "", emailaddr = "";
    contactid = $.trim($("#contactid").val()); name = $.trim($("#name").val());
    company = $.trim($("#company").val()); telnocc = $.trim($("#telnocc").val());
    telno = $.trim($("#telno").val()); zip = $.trim($("#zip").val());
    city = $.trim($("#city").val()); country = $.trim($("#country").val());
    address1 = $.trim($("#address1").val()); emailaddr = $.trim($("#emailaddr").val());
    if (company.length != company.replace(/[^\x00-\xff]/g, "**").length) { alert("公司名称请输入英文！"); return false; }
    if (telnocc.length != telnocc.replace(/[^\x00-\xff]/g, "**").length) { alert("国家电话号码编码请输入数字！"); return false; }
    if (telno.length != telno.replace(/[^\x00-\xff]/g, "**").length) { alert("电话号码请输入数字！"); return false; }
    if (zip.length != zip.replace(/[^\x00-\xff]/g, "**").length) { alert("邮编请输入数字！"); return false; }
    if (city.length != city.replace(/[^\x00-\xff]/g, "**").length) { alert("城市名称请输入英文！"); return false; }
    if (address1.length != address1.replace(/[^\x00-\xff]/g, "**").length) { alert("街道地址请输入英文！"); return false; }
    var reg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
    if (!reg.test(emailaddr)) {
        alert("邮箱格式错误！"); return false;
    }
    var url = "?c=module&productid=" + productData[0].pid + "&show=text&todo=resellerclub_SaveDomainContactList" +
              "&contactid=" + contactid + "&name=" + name + "&company=" + company + "&domainName=" + serviceData[0].sconfig.domainName +
              "&telnocc=" + telnocc + "&telno=" + telno + "&zip=" + zip + "&emailaddr=" + emailaddr +
              "&city=" + city + "&country=" + country + "&address1=" + address1 + "&t=" + (new Date()).valueOf();
    $.get(url, function (data) {
        if (data == "ok|") {
            $("#suwin").html('<div style="text-align:center;padding-top:40px;color:green;"></b>恭喜，保存成功！</b></div>');

            setTimeout(function () { resellerclub_reloadpage(); $("#suwin").dialog("close"); }, 1000);

        } else {
            if (data.indexOf("European Union member states") > 0) { $("#suwin").html("<b>请选择欧盟国家！</b>"); } else {
                $("#suwin").html(data);
            }
        }
    });
    $("#suwin").dialog({ title: "正在保存联系人信息", autoOpen: false, resizable: false, width: 300, height: 200, modal: true, buttons: {
        "关 闭": function () { $(this).dialog("close"); }
    }
    }).dialog("open");
    $("#suwin").html('<div style="text-align:center;padding-top:40px;">正在保存中...<br/><img src="files/images/loading.gif" /></div>');
};

function resellerclub_AddNewDomainContact() {
    $("#swin").dialog({ title: "添加新的联系人", autoOpen: false, resizable: false, width: 650, height: 520, modal: false, buttons: {
        "添 加": function () {
            resellerclub_gotoAddNewDomainContact();
        }, "取 消": function () { $(this).dialog("close"); }
    }
    }).dialog("open");
    var str = '';
    str += '';
    var tr_td_SS = '<tr style="height:29px;line-height:29px;border-bottom:1px dashed #ddd;"><td style="width:120px;text-align:right;">';
    var inputSS = 'class="text" style="margin-top:4px;"';
    str += '<h3 style="height:40px;font-size:16px;">填写您的联系人信息 <b style="color:red;font-size:12px;font-weight:normal;word-spacing: 5px;"> ( 注意：请输入英文！)</b></h3>';
    str += '<div style="padding-left:70px;">';
    str += '<table style="width:450px;">';
    str += tr_td_SS + '<b>联系人：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="name" id="name" onfocus="resellerclub_keyFocus(this)" onblur="resellerClub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;width:150px;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>注册公司：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="company" id="company" onfocus="resellerclub_keyFocus(this)" onblur="resellerClub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;width:150px;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>国家：</b>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '<select name="country" id="country" style="cursor:pointer;margin-top:4px;">' +
        '<option value="AU">Australia</option>' +
        '<option value="CA">Canada</option>' +
        '<option value="CN" selected="selected">China</option>' +
        '<option value="CX">Christmas Island</option>' +
        '<option value="DK">Denmark</option>' +
        '<option value="DJ">Djibouti</option>' +
        '<option value="DM">Dominica</option>' +
        '<option value="DO">Dominican Republic</option>' +
        '<option value="TP">East Timor</option>' +
        '<option value="FR">France</option>' +
        '<option value="IN">India</option>' +
        '<option value="JP">Japan</option>' +
        '<option value="MA">Morocco</option>' +
        '<option value="NZ">New Zealand</option>' +
        '<option value="OM">Oman</option>' +
        '<option value="RU">Russia</option>' +
        '<option value="SB">Solomon Islands</option>' +
        '<option value="SO">Somalia</option>' +
        '<option value="ZA">South Africa</option>' +
        '<option value="ES">Spain</option>' +
        '<option value="LK">Sri Lanka</option>' +
        '<option value="SD">Sudan</option>' +
        '<option value="TW">Taiwan</option>' +
        '<option value="US">United States</option>';
    str += '</select>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>省份：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="province" id="province" onfocus="resellerclub_keyFocus(this)" onblur="resellerClub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 省/市</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>城市：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="city" id="city" onfocus="resellerclub_keyFocus(this)" onblur="resellerClub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 市/区</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>地址：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="address-line-1" id="address-line-1" onblur="resellerClub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>邮编：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="zipcode" id="zipcode" onblur="resellerClub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>联系电话：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="phone-cc" id="phone-cc" value="86" onfocus="resellerclub_keyFocus(this)" onblur="resellerClub_keyUpCheck(this)" class="text" style="margin-top:4px;width:34px;">';
    str += '+<input name="phone" id="phone" onfocus="resellerclub_keyFocus(this)" onblur="resellerClub_keyUpCheck(this)"  style="margin-top:4px;width:115px;"  class="text" >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 如：86+02012345678</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>电子邮箱：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="email" id="email" onblur="resellerClub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>语言：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<select name="lang-pref" id="lang-pref" style="cursor:pointer;margin-top:4px;">' +
           '<option value="ch"  selected="selected" style="cursor:pointer;">CN</option>' +
           '<option value="en" style="cursor:pointer;">EN</option>';
    str += '</select>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += '</table>';
    str += '</div>';
    $("#swin").html(str);
}
function resellerclub_AddNewDomainContact_RU() {
    $("#suwin").dialog({ title: "添加新的联系人", autoOpen: false, resizable: false, width: 670, height: 550, modal: true, buttons: {
        "添 加": function () {
            resellerclub_gotoAddNewDomainContact_RU();
        }, "取 消": function () { $(this).dialog("close"); }
    }
    }).dialog("open");
    var str = '';
    str += '';
    var tr_td_SS = '<tr style="height:29px;line-height:29px;border-bottom:1px dashed #ddd;"><td style="width:120px;text-align:right;">';
    var inputSS = 'class="text" style="margin-top:4px;"';
    str += '<h3 style="height:40px;font-size:16px;">填写您的联系人信息 <b style="color:red;font-size:12px;word-spacing: 5px;"> ( 注意：请输入英文！)</b></h3>';
    str += '<div style="padding-left:70px;">';
    str += '<table style="width:450px;">';
    str += tr_td_SS + '<b>联系人：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="name1" id="name1" onfocus="resellerclub_keyFocus(this)" onblur="resellerClub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;width:150px;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>注册公司：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="company1" id="companyName1" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;width:150px;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>国家：</b>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '<select name="country" id="countryName" style="cursor:pointer;margin-top:4px;">' +
        '<option value="AU">Australia</option>' +
        '<option value="CA">Canada</option>' +
        '<option value="CN" selected="selected">China</option>' +
        '<option value="CX">Christmas Island</option>' +
        '<option value="DK">Denmark</option>' +
        '<option value="DJ">Djibouti</option>' +
        '<option value="DM">Dominica</option>' +
        '<option value="DO">Dominican Republic</option>' +
        '<option value="TP">East Timor</option>' +
        '<option value="FR">France</option>' +
        '<option value="IN">India</option>' +
        '<option value="JP">Japan</option>' +
        '<option value="MA">Morocco</option>' +
        '<option value="NZ">New Zealand</option>' +
        '<option value="OM">Oman</option>' +
        '<option value="RU">Russia</option>' +
        '<option value="SB">Solomon Islands</option>' +
        '<option value="SO">Somalia</option>' +
        '<option value="ZA">South Africa</option>' +
        '<option value="ES">Spain</option>' +
        '<option value="LK">Sri Lanka</option>' +
        '<option value="SD">Sudan</option>' +
        '<option value="TW">Taiwan</option>' +
        '<option value="US">United States</option>';
    str += '</select>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>省份：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="province" id="provinceName" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 省/市</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>城市：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="city" id="cityName" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 市/区</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>街道地址：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="address-line-1" id="address-line-1Name" onblur="resellerClub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>邮编：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="zipcode" id="zipcodeNum" onblur="resellerClub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>联系电话：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="phone-cc" id="phone-ccNum" value="7" type="hidden" style="margin-top:4px;width:34px;"><span> 7 </span>';
    str += '+ <input name="phone" id="phoneNum" style="margin-top:4px;width:115px;" class="text">';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 如：7 + 1234567</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>电子邮箱：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="email" id="emailName" onblur="resellerClub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>语言：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<select name="lang-pref" id="lang-prefName" style="cursor:pointer;margin-top:4px;">' +
           '<option value="ch"  selected="selected" style="cursor:pointer;">CN</option>' +
           '<option value="en" style="cursor:pointer;">EN</option>';
    str += '</select>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += '</table>';
    str += '</div>';
    str += '<div class="loading" style="margin-top:0px;text-align:center;"></div>';
    $("#suwin").html(str);
}
function resellerclub_AddNewDomainContact_US() {
    $("#suwin").dialog({ title: "添加新的联系人", autoOpen: false, resizable: false, width: 670, height: 550, modal: true, buttons: {
        "添 加": function () {
            resellerclub_gotoAddNewDomainContact_US();
        }, "取 消": function () { $(this).dialog("close"); }
    }
    }).dialog("open");
    var str = '';
    str += '';
    var tr_td_SS = '<tr style="height:29px;line-height:29px;border-bottom:1px dashed #ddd;"><td style="width:120px;text-align:right;">';
    var inputSS = 'class="text" style="margin-top:4px;"';
    str += '<h3 style="height:40px;font-size:16px;">填写您的联系人信息 <b style="color:red;font-size:12px;word-spacing: 5px;"> ( 注意：请输入英文！)</b></h3>';
    str += '<div style="padding-left:70px;">';
    str += '<table style="width:450px;">';
    str += tr_td_SS + '<b>联系人：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="name1" id="name1" onfocus="resellerclub_keyFocus(this)" onblur="resellerClub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;width:150px;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>注册公司：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="company1" id="companyName1" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;width:150px;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>国家：</b>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '<select name="country" id="countryName" style="cursor:pointer;margin-top:4px;">' +
        '<option value="AU">Australia</option>' +
        '<option value="CA">Canada</option>' +
        '<option value="CN" selected="selected">China</option>' +
        '<option value="CX">Christmas Island</option>' +
        '<option value="DK">Denmark</option>' +
        '<option value="DJ">Djibouti</option>' +
        '<option value="DM">Dominica</option>' +
        '<option value="DO">Dominican Republic</option>' +
        '<option value="TP">East Timor</option>' +
        '<option value="FR">France</option>' +
        '<option value="IN">India</option>' +
        '<option value="JP">Japan</option>' +
        '<option value="MA">Morocco</option>' +
        '<option value="NZ">New Zealand</option>' +
        '<option value="OM">Oman</option>' +
        '<option value="RU">Russia</option>' +
        '<option value="SB">Solomon Islands</option>' +
        '<option value="SO">Somalia</option>' +
        '<option value="ZA">South Africa</option>' +
        '<option value="ES">Spain</option>' +
        '<option value="LK">Sri Lanka</option>' +
        '<option value="SD">Sudan</option>' +
        '<option value="TW">Taiwan</option>' +
        '<option value="US">United States</option>';
    str += '</select>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>省份：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="province" id="provinceName" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 省/市</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>城市：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="city" id="cityName" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 市/区</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>街道地址：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="address-line-1" id="address-line-1Name" onblur="resellerClub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>邮编：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="zipcode" id="zipcodeNum" onblur="resellerClub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>联系电话：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="phone-cc" id="phone-ccNum" value="86" onfocus="resellerclub_keyFocus(this)" onblur="resellerClub_keyUpCheck(this)" class="text" style="margin-top:4px;width:34px;">';
    str += '+<input name="phone" id="phoneNum" onfocus="resellerclub_keyFocus(this)" onblur="resellerClub_keyUpCheck(this)"  style="margin-top:4px;width:115px;" class="text">';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 如：86+02012345678</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>电子邮箱：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="email" id="emailName" onblur="resellerClub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>语言：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<select name="lang-pref" id="lang-prefName" style="cursor:pointer;margin-top:4px;">' +
           '<option value="ch"  selected="selected" style="cursor:pointer;">CN</option>' +
           '<option value="en" style="cursor:pointer;">EN</option>';
    str += '</select>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>域名用途：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:360px;" colspan="2">';
    str += '';
    str += '<input type="radio" name="Purpose" id="p1" checked="checked" value="P1"><label for="p1">盈利的商务组织</label>';
    str += '</br>';
    str += '<input type="radio" name="Purpose" id="p2" value="P2"><label for="p2">非盈利交易，组织等</label>';
    str += '</br>';
    str += '<input type="radio" name="Purpose" id="p3"  value="P3"><label for="p3">个人用途</label>';
    str += '</br>';
    str += '<input type="radio" name="Purpose" id="p4"  value="P4"><label for="p4">教育用途</label>';
    str += '</br>';
    str += '<input type="radio" name="Purpose" id="p5"  value="P5"><label for="p5">政府用途</label>';
    str += '';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>联系人类别：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:360px;" colspan="2">';
    str += '<input type="radio" checked="checked" name="NexusCategory" value="C11" id="nc1">';
    str += '<label for="nc1">美国公民自然人</label>';
    str += '</br>';
    str += '<input type="radio" name="NexusCategory" value="C12" id="nc2">';
    str += '<label for="nc2">美国永久居民自然人</label>';
    str += '</br>';
    str += '<input type="radio" name="NexusCategory" value="C21" id="nc3">';
    str += '<label for="nc3">总部设在美国的组织或公司—在美国领土上已成立的组织或公司或在美国法律下组建的组织</label>';
    str += '</br>';
    str += '<input type="radio" name="NexusCategory" value="C31" id="nc4">';
    str += '<label for="nc4">外国个体或组织—在美国进行道德和法律允许范围内的活动，如:销售产品、服务、商务交易、非商业性质、非盈利等</label>';
    str += '</br>';
    str += '<input type="radio" name="NexusCategory" value="C32" id="nc5">';
    str += '<label for="nc5">个体 — 在美国拥有办公室、物业</label>';
    str += '</br>';
    str += '</td>';
    str += '</tr>';
    str += '</table>';
    str += '</div>';
    str += '<div class="loading" style="margin-top:0px;text-align:center; height:60px;"></div>';
    $("#suwin").html(str);
}
function resellerclub_AddNewDomainContact_ASIA() {
    $("#suwin").dialog({ title: "添加新的联系人", autoOpen: false, resizable: false, width: 670, height: 550, modal: true, buttons: {
        "添 加": function () {
            resellerclub_gotoAddNewDomainContact_ASIA();
        }, "取 消": function () { $(this).dialog("close"); }
    }
    }).dialog("open");
    var str = '';
    str += '';
    var tr_td_SS = '<tr style="height:29px;line-height:29px;border-bottom:1px dashed #ddd;"><td style="width:120px;text-align:right;">';
    var inputSS = 'class="text" style="margin-top:4px;"';
    str += '<h3 style="height:40px;font-size:16px;">填写您的联系人信息 <b style="color:red;font-size:12px;word-spacing: 5px;"> ( 注意：请输入英文！)</b></h3>';
    str += '<div style="padding-left:70px;">';
    str += '<table style="width:450px;">';
    str += tr_td_SS + '<b>联系人：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="name1" id="name1" onfocus="resellerclub_keyFocus(this)" onblur="resellerClub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;width:150px;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>注册公司：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="company1" id="companyName1" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;width:150px;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>国家：</b>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '<select name="country" id="countryName" style="cursor:pointer;margin-top:4px;">' +
        '<option value="AU">Australia</option>' +
        '<option value="CA">Canada</option>' +
        '<option value="CN" selected="selected">China</option>' +
        '<option value="CX">Christmas Island</option>' +
        '<option value="DK">Denmark</option>' +
        '<option value="DJ">Djibouti</option>' +
        '<option value="DM">Dominica</option>' +
        '<option value="DO">Dominican Republic</option>' +
        '<option value="TP">East Timor</option>' +
        '<option value="FR">France</option>' +
        '<option value="IN">India</option>' +
        '<option value="JP">Japan</option>' +
        '<option value="MA">Morocco</option>' +
        '<option value="NZ">New Zealand</option>' +
        '<option value="OM">Oman</option>' +
        '<option value="RU">Russia</option>' +
        '<option value="SB">Solomon Islands</option>' +
        '<option value="SO">Somalia</option>' +
        '<option value="ZA">South Africa</option>' +
        '<option value="ES">Spain</option>' +
        '<option value="LK">Sri Lanka</option>' +
        '<option value="SD">Sudan</option>' +
        '<option value="TW">Taiwan</option>' +
        '<option value="US">United States</option>';
    str += '</select>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>省份：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="province" id="provinceName" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 省/市</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>城市：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="city" id="cityName" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 市/区</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>街道地址：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="address-line-1" id="address-line-1Name" onblur="resellerClub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>邮编：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="zipcode" id="zipcodeNum" onblur="resellerClub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>联系电话：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="phone-cc" id="phone-ccNum" value="86" onfocus="resellerclub_keyFocus(this)" onblur="resellerClub_keyUpCheck(this)" class="text" style="margin-top:4px;width:34px;">';
    str += '+<input name="phone" id="phoneNum" onfocus="resellerclub_keyFocus(this)" onblur="resellerClub_keyUpCheck(this)"  style="margin-top:4px;width:115px;" class="text">';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += ' 如：86+02012345678</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>电子邮箱：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="email" id="emailName" onblur="resellerClub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>语言：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<select name="lang-pref" id="lang-prefName" style="cursor:pointer;margin-top:4px;">' +
           '<option value="ch"  selected="selected" style="cursor:pointer;">CN</option>' +
           '<option value="en" style="cursor:pointer;">EN</option>';
    str += '</select>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>法律实体：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:360px;" colspan="2">';
    str += '<select  name="legalentitytype" id="legalentitytype" style="cursor:pointer;margin-top:4px;">';
    str += '<option value="naturalPerson" style="cursor:pointer;">自然人</option>';
    str += '<option value="corporation" style="cursor:pointer;">公司</option>';
    str += '<option value="cooperative" style="cursor:pointer;">合作社</option>';
    str += '<option value="partnership" style="cursor:pointer;">合伙企业</option>';
    str += '<option value="government" style="cursor:pointer;">政府机构</option>';
    str += '<option value="politicalParty" style="cursor:pointer;">政党</option>';
    str += '<option value="society" style="cursor:pointer;">社团</option>';
    str += '<option value="institution" style="cursor:pointer;">公共机构</option>';
    str += '</select>';
    str += '';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>证明文件类型：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:360px;" colspan="2">';
    str += '<select  name="identform" id="identform" style="cursor:pointer;margin-top:4px;">';
    str += '<option value="passport" style="cursor:pointer;">护照</option>';
    str += '<option value="certificate" style="cursor:pointer;">证书</option>';
    str += '<option value="legislation" style="cursor:pointer;">法规</option>';
    str += '<option value="societyRegistry" style="cursor:pointer;">社团注册表</option>';
    str += '<option value="politicalPartyRegistry" style="cursor:pointer;">政党注册表</option>';
    str += '</select>';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>文件证明号码：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="identnumber" id="identnumber" onblur="resellerClub_keyUpCheck(this)" ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += '</table>';
    str += '</div>';
    str += '<div class="loading" style="margin-top:0px;text-align:center; height:60px;"></div>';
    $("#suwin").html(str);
}
function resellerclub_gotoAddNewDomainContact() {
    var name = $("#name"), company = $("#company"), province = $("#province"), city = $("#city"), addressline1 = $("#address-line-1");
    var zipcode = $("#zipcode"), phonecc = $("#phone-cc"), phone = $("#phone");

    if ($.trim(name.val()) == "") {
        name.parent().next("td").html("<b style='color:red;'>*联系人不能为空！</span>");
        return false;
    }
    if ($.trim(name.val()).length != $.trim(name.val()).replace(/[^\x00-\xff]/g, "**").length) { alert("联系人请输入英文！"); return false; }
    if ($.trim(company.val()).length != $.trim(company.val()).replace(/[^\x00-\xff]/g, "**").length) { alert("公司名称请输入英文！"); return false; }
    if ($.trim(province.val()).length != $.trim(province.val()).replace(/[^\x00-\xff]/g, "**").length) { alert("省份名称请输入英文！"); return false; }
    if ($.trim(city.val()).length != $.trim(city.val()).replace(/[^\x00-\xff]/g, "**").length) { alert("城市名称请输入英文！"); return false; }
    if ($.trim(addressline1.val()).length != $.trim(addressline1.val()).replace(/[^\x00-\xff]/g, "**").length) { alert("街道地址请输入英文！"); return false; }
    if ($.trim(zipcode.val()).length != $.trim(zipcode.val()).replace(/[^\x00-\xff]/g, "**").length) { alert("邮编请输入不正确！"); return false; }
    if ($.trim(phonecc.val()).length != $.trim(phonecc.val()).replace(/[^\x00-\xff]/g, "**").length) { alert("国家的编号请输入数字！"); return false; }
    if ($.trim(phone.val()).length != $.trim(phone.val()).replace(/[^\x00-\xff]/g, "**").length) { alert("电话号码请输入有误！"); return false; }
    if ($.trim(company.val()) == "") {
        company.parent().next("td").html("<b style='color:red;'>*公司不能为空！</span>");
        return false;
    }
    if ($.trim(province.val()) == "") {
        province.parent().next("td").html("<b style='color:red;'>*省份不能为空！</span>");
        return false;
    }
    if ($.trim(city.val()) == "") {
        city.parent().next("td").html("<b style='color:red;'>*城市不能为空！</span>");
        return false;
    }
    if ($.trim(addressline1.val()) == "") {
        addressline1.parent().next("td").html("<b style='color:red;'>*街道地址不能为空！</span>");
        return false;
    }
    if ($.trim(zipcode.val()) == "") {
        zipcode.parent().next("td").html("<b style='color:red;'>*邮编不能为空！</span>");
        return false;
    }
    if ($.trim(phonecc.val()) == "") {
        phonecc.parent().next("td").html("<b style='color:red;'>*国家的编号不能为空！</span>");
        return false;
    }
    if ($.trim(phone.val()) == "") {
        phone.parent().next("td").html("<b style='color:red;'>*电话号码不能为空！</span>");
        return false;
    }
    else {
        if ($.trim(phone.val()).length < 10) {
            phone.parent().next("td").html("<b style='color:red;'>*区号+座机号码！</span>");
            return false;
        } else {
            phone.parent().next("td").html("");
        }
    }
    var country = $("#country").val();
    var langpref = $("#lang-pref").val();
    var email = $("#email");
    var reg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
    if (!reg.test($.trim(email.val()))) {
        alert("邮箱格式错误！"); return false;
    }
    //验证输入的账户资料，激活API
    $("#suwin").dialog({ title: "添加联系人信息", autoOpen: false, resizable: false, width: 300, height: 220, modal: true, buttons: { "关 闭": function () {
        $(this).dialog("close");
    }
    }
    }).dialog("open");
    var str = '';
    str += '<div style="width:100%; margin:0 auto; text-align:center; padding-top:30px;">提交中，请稍后...<br>';
    str += '<img src="files/images/loading.gif" />';
    str += '</div>';
    $("#suwin").html(str);
    var urlapi = '?c=module&productid=' + productData[0].pid + '&show=text&todo=resellerclub_AddNewDomainContact' +
                '&name=' + $.trim(name.val()) + '&tel=' + userData[0].tel + '&email=' + $.trim(email.val()) +
                '&country=' + $.trim(country) + '&province=' + $.trim(province.val()) +
                '&city=' + $.trim(city.val()) + '&addressline1=' + $.trim(addressline1.val()) +
                '&zipcode=' + $.trim(zipcode.val()) + '&phonecc=' + $.trim(phonecc.val()) +
                '&phone=' + $.trim(phone.val()) + '&company=' + $.trim(company.val()) +
                '&langpref=' + $.trim(langpref) + "&customerID=" + serviceData[0].sconfig.customerID + "&domainName=" + serviceData[0].sconfig.domainName;
    $.post(urlapi, function (data) {

        if (data == "ok|") {
            $("#suwin").html('<div style="text-align:center;margin-top:30px;color:green;"><b>添加成功！</b></div>');
            setTimeout(function () { $("#suwin").dialog("close"); $("#swin").dialog("close"); resellerclub_reloadpage(); }, 1000);
        }
        else {
            var eflag = data.split('|');
            var es = "";
            switch (eflag[0]) {
                case "TelephoneNo":
                    es = "电话号码有误！";
                    break;
                case "Postal Code":
                    es = "邮编输入有误！";
                    break;
                case "Country Code":
                    es = "电话号码的国家编码有误！";
                    break;
                case "error":
                    es = "请求错误，请稍后再试！";
                    break;
                default:
                    es = eflag[0];
                    break;
            }
            $("#suwin").html('<div style="text-align:center;margin-top:30px;color:red;"><b>' + es + '</b></div>');
        }
    });


}
function resellerclub_gotoAddNewDomainContact_RU() {
    var name = $("#name1").val(), company = $("#companyName1").val(), province = $("#provinceName").val(), city = $("#cityName").val(), addressline1 = $("#address-line-1Name").val();
    var zipcode = $("#zipcodeNum").val(), phonecc = $("#phone-ccNum").val(), phone = $("#phoneNum").val();
    if ($.trim(name) == "") {
        alert("联系人不能为空！");
        return false;
    }
    if ($.trim(company) == "") {
        alert("公司名称不能为空！");
        return false;
    }
    else {
        if ($.trim(company).indexOf(" ") < 0) {
            alert("公司名称至少包含两个单词！");
            return false;
        }
    }
    if ($.trim(province) == "") {
        alert("省份名称不能为空！");
        return false;
    }
    if ($.trim(city) == "") {
        alert("城市名称不能为空！");
        return false;
    }
    if ($.trim(addressline1) == "") {
        alert("街道地址不能为空！");
        return false;
    }
    if ($.trim(zipcode) == "") {
        alert("邮编不能为空！");
        return false;
    }
    if ($.trim(phone).length != 7) {
        alert("电话号码应该为7位数！");
        return false;
    }
    var country = $("#countryName").val();
    var langpref = $("#lang-prefName").val();
    var email = $("#emailName").val();
    var reg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
    if (!reg.test($.trim(email))) {
        alert("邮箱格式错误！"); return false;
    }
    var str = '';
    str += '<div style="width:100%; margin:0 auto; text-align:center; padding-top:30px;">提交中，请稍后...<br>';
    str += '<img src="files/images/loading.gif" />';
    str += '</div>';
    $("#suwin .loading").html(str);
    var urlapi = '?c=module&productid=' + productData[0].pid + '&show=text&todo=resellerclub_AddNewDomainContact_RU' +
                '&name=' + name + '&tel=' + userData[0].tel + '&email=' + email +
                '&country=' + country + '&province=' + province +
                '&city=' + city + '&addressline1=' + addressline1 +
                '&zipcode=' + zipcode + '&phonecc=' + phonecc +
                '&phone=' + phone + '&company=' + company +
                '&langpref=' + langpref + "&customerID=" + serviceData[0].sconfig.customerID + "&t=" + new Date();

    $.get(urlapi, function (data) {
        if (data == "ok|") {
            $("#suwin").dialog("close");
            $("#suwin").dialog({ title: "添加联系人成功", autoOpen: false, resizable: false, width: 350, height: 250, modal: true, buttons: { "关 闭": function () {
                $(this).dialog("close");
            }
            }
            }).dialog("open");
            $("#suwin").html('<div style="text-align:center;margin-top:30px;color:green;"><b>添加成功！</b></div>');
            $("#suwin .ui-dialog-buttonset").siblings().hide();
            setTimeout(function () { $("#suwin").dialog("close"); }, 1000);
        }
        else {
            var eflag = data.split('|');
            var es = "";
            switch (eflag[0]) {
                case "TelephoneNo":
                    es = "电话号码有误！";
                    break;
                case "Postal Code":
                    es = "邮编输入有误！";
                    break;
                case "Country Code":
                    es = "电话号码的国家编码有误！";
                    break;
                case "error":
                    es = "输入有错误，请检查输入！";
                    break;
                case "Name contains":
                    es = "联系人输入有误，请检查输入！";
                    break;
                case "Company Name contains":
                    es = "公司名称输入有误，请检查输入！";
                    break;
                case "City contains":
                    es = "城市地址输入有误，请检查输入！";
                    break;
                case "address1 contains":
                    es = "街道地址输入有误，请检查输入！";
                    break;
                default:
                    es = data;
                    break;
            }
            $("#suwin .loading").html('<div style="color:red;margin-top:5px;"><b>' + es + '</b></div>');
            return false;
        }
    });
}
function resellerclub_gotoAddNewDomainContact_US() {
    var name = $("#name1").val(), company = $("#companyName1").val(), province = $("#provinceName").val(), city = $("#cityName").val(), addressline1 = $("#address-line-1Name").val();
    var zipcode = $("#zipcodeNum").val(), phonecc = $("#phone-ccNum").val(), phone = $("#phoneNum").val();
    var pObj = document.getElementsByName("Purpose");
    var PurposeValue;
    for (var i = 0; i < pObj.length; i++) {
        if (pObj[i].checked == "checked" || pObj[i].checked == true) {
            PurposeValue = pObj[i].value;
            break;
        }
    }
    var ncObj = document.getElementsByName("NexusCategory");
    var NexusCategoryValue;
    for (var i = 0; i < ncObj.length; i++) {
        if (ncObj[i].checked == "checked" || ncObj[i].checked == true) {
            NexusCategoryValue = ncObj[i].value;
            break;
        }
    }
    if ($.trim(name) == "") {
        alert("联系人不能为空！");
        return false;
    }
    if ($.trim(company) == "") {
        alert("公司名称不能为空！");
        return false;
    }
    if ($.trim(province) == "") {
        alert("省份名称不能为空！");
        return false;
    }
    if ($.trim(city) == "") {
        alert("城市名称不能为空！");
        return false;
    }
    if ($.trim(addressline1) == "") {
        alert("街道地址不能为空！");
        return false;
    }
    if ($.trim(zipcode) == "") {
        alert("邮编不能为空！");
        return false;
    }
    if ($.trim(phone) == "") {
        alert("电话号码不能为空！");
        return false;
    }
    var country = $("#countryName").val();
    var langpref = $("#lang-prefName").val();
    var email = $("#emailName").val();
    var reg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
    if (!reg.test($.trim(email))) {
        alert("邮箱格式错误！"); return false;
    }
    var str = '';
    str += '<div style="width:100%; margin:0 auto; text-align:center; padding-top:30px;">提交中，请稍后...<br>';
    str += '<img src="files/images/loading.gif" />';
    str += '</div>';
    $("#suwin .loading").html(str);
    var urlapi = '?c=module&productid=' + productData[0].pid + '&show=text&todo=resellerclub_AddNewDomainContact_US' +
                '&name=' + name + '&tel=' + userData[0].tel + '&email=' + email +
                '&country=' + country + '&province=' + province +
                '&city=' + city + '&addressline1=' + addressline1 +
                '&zipcode=' + zipcode + '&phonecc=' + phonecc +
                '&phone=' + phone + '&company=' + company +
                '&langpref=' + langpref + "&customerID=" + serviceData[0].sconfig.customerID + "&NexusCategory=" + NexusCategoryValue + "&Purpose=" + PurposeValue + "&t=" + new Date();
    $.get(urlapi, function (data) {
        if (data == "ok|") {
            $("#suwin").dialog("close");
            $("#suwin").dialog({ title: "添加联系人成功", autoOpen: false, resizable: false, width: 350, height: 250, modal: true, buttons: { "关 闭": function () {
                $(this).dialog("close");
            }
            }
            }).dialog("open");
            $("#suwin").html('<div style="text-align:center;margin-top:30px;color:green;"><b>添加成功！</b></div>');
            setTimeout(function () { $("#suwin").dialog("close"); }, 1000);
        }
        else {
            var eflag = data.split('|');
            var es = "";
            switch (eflag[0]) {
                case "TelephoneNo":
                    es = "电话号码有误！";
                    break;
                case "Postal Code":
                    es = "邮编输入有误！";
                    break;
                case "Country Code":
                    es = "电话号码的国家编码有误！";
                    break;
                case "error":
                    es = "输入有错误，请检查输入！";
                    break;
                case "Name contains":
                    es = "联系人输入有误，请检查输入！";
                    break;
                case "Company Name contains":
                    es = "公司名称输入有误，请检查输入！";
                    break;
                case "City contains":
                    es = "城市地址输入有误，请检查输入！";
                    break;
                case "address1 contains":
                    es = "街道地址输入有误，请检查输入！";
                    break;
                default:
                    es = data;
                    break;
            }
            $("#suwin .loading").html('<div style="color:red;margin-top:5px;"><b>' + es + '</b></div>');
            return false;
        }
    });


}
function resellerclub_gotoAddNewDomainContact_ASIA() {
    var name = $("#name1").val(), company = $("#companyName1").val(), province = $("#provinceName").val(), city = $("#cityName").val(), addressline1 = $("#address-line-1Name").val();
    var zipcode = $("#zipcodeNum").val(), phonecc = $("#phone-ccNum").val(), phone = $("#phoneNum").val(), identnumber = $("#identnumber").val();
    var legalentitytype = $("#legalentitytype").val();
    var identform = $("#identform").val();
    if ($.trim(name) == "") {
        alert("联系人不能为空！");
        return false;
    }
    if ($.trim(company) == "") {
        alert("公司名称不能为空！");
        return false;
    }
    if ($.trim(province) == "") {
        alert("省份名称不能为空！");
        return false;
    }
    if ($.trim(city) == "") {
        alert("城市名称不能为空！");
        return false;
    }
    if ($.trim(addressline1) == "") {
        alert("街道地址不能为空！");
        return false;
    }
    if ($.trim(zipcode) == "") {
        alert("邮编不能为空！");
        return false;
    }
    if ($.trim(phone) == "") {
        alert("电话号码不能为空！");
        return false;
    }
    var country = $("#countryName").val();
    var langpref = $("#lang-prefName").val();
    var email = $("#emailName").val();
    var reg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
    if (!reg.test($.trim(email))) {
        alert("邮箱格式错误！"); return false;
    }
    var str = '';
    str += '<div style="width:100%; margin:0 auto; text-align:center; padding-top:30px;">提交中，请稍后...<br>';
    str += '<img src="files/images/loading.gif" />';
    str += '</div>';
    $("#suwin .loading").html(str);
    var urlapi = '?c=module&productid=' + productData[0].pid + '&show=text&todo=resellerclub_AddNewDomainContact_ASIA&customerID=' + serviceData[0].sconfig.customerID +
    '&name=' + name + '&tel=' + userData[0].tel + '&email=' + email +
                '&country=' + country + '&province=' + province +
                '&city=' + city + '&addressline1=' + addressline1 +
                '&zipcode=' + zipcode + '&phonecc=' + phonecc +
                '&phone=' + phone + '&company=' + company +
                '&langpref=' + langpref + "&legalentitytype=" + legalentitytype +
                '&identform=' + identform + '&identnumber=' + identnumber + "&t=" + new Date();
    $.get(urlapi, function (data) {
        if (data == "ok|") {
            $("#suwin").dialog("close");
            $("#suwin").dialog({ title: "添加联系人成功", autoOpen: false, resizable: false, width: 350, height: 250, modal: true, buttons: { "关 闭": function () {
                $(this).dialog("close");
            }
            }
            }).dialog("open");
            $("#suwin").html('<div style="text-align:center;margin-top:30px;color:green;"><b>添加成功！</b></div>');
            setTimeout(function () { $("#suwin").dialog("close"); }, 1000);
        }
        else {
            var eflag = data.split('|');
            var es = "";
            switch (eflag[0]) {
                case "TelephoneNo":
                    es = "电话号码有误！";
                    break;
                case "Postal Code":
                    es = "邮编输入有误！";
                    break;
                case "Country Code":
                    es = "电话号码的国家编码有误！";
                    break;
                case "error":
                    es = "输入有错误，请检查输入！";
                    break;
                case "Name contains":
                    es = "联系人输入有误，请检查输入！";
                    break;
                case "Company Name contains":
                    es = "公司名称输入有误，请检查输入！";
                    break;
                case "City contains":
                    es = "城市地址输入有误，请检查输入！";
                    break;
                case "address1 contains":
                    es = "街道地址输入有误，请检查输入！";
                    break;
                default:
                    es = data;
                    break;
            }
            $("#suwin .loading").html('<div style="color:red;margin-top:5px;"><b>' + es + '</b></div>');
            return false;
        }
    });
}
function cObjFindValue(cobj, key) {
    var obj = cobj.split(',');
    for (var i = 0; i < obj.length; i++) {
        if (obj[i].split(':')[0] == key) {
            return obj[i].split(':')[1];
            break;
        }
    }
}

function resellerclub_selectCName(mStr) {
    var company = "", name = "", telnocc = "", telno = "", zip = "", contactid = "", city = "", country = "", address1 = "", emailaddr = "";
    var cNowID = $("#selectCName").val();
    var SOBj = mStr.split('|');
    var cNow;
    var cID;
    for (var i = 0; i < SOBj.length; i++) {
        cNow = SOBj[i];
        cID = cObjFindValue(cNow, "contactid");
        if (cID == cNowID) {
            break;
        }
    }
    company = cObjFindValue(cNow, "company"); country = cObjFindValue(cNow, "country");
    name = cObjFindValue(cNow, "name"); telnocc = cObjFindValue(cNow, "telnocc");
    zip = cObjFindValue(cNow, "zip"); contactid = cObjFindValue(cNow, "contactid");
    city = cObjFindValue(cNow, "city"); address1 = cObjFindValue(cNow, "address1");
    emailaddr = cObjFindValue(cNow, "emailaddr"); telno = cObjFindValue(cNow, "telno");
    $("#contactid").val(contactid);
    $("#name").val(name);
    $("#company").val(company);
    $("#country").val(country);
    $("#telnocc").val(telnocc);
    $("#telno").val(telno);
    $("#city").val(city);
    $("#address1").val(address1);
    $("#emailaddr").val(emailaddr);
    $("#zip").val(zip);
}
function resellerclub_selectCNameByHTML(mStr) {
    var company = "", name = "", telnocc = "", telno = "", zip = "", contactid = "", city = "", country = "", address1 = "", emailaddr = "";
    var cNowID = $("#selectCName").val();
    var SOBj = mStr.split('|');
    var cNow;
    var cID;
    for (var i = 0; i < SOBj.length; i++) {
        cNow = SOBj[i];
        cID = cObjFindValue(cNow, "contactid");
        if (cID == cNowID) {
            break;
        }
    }
    company = cObjFindValue(cNow, "company"); country = cObjFindValue(cNow, "country");
    name = cObjFindValue(cNow, "name"); telnocc = cObjFindValue(cNow, "telnocc");
    zip = cObjFindValue(cNow, "zip"); contactid = cObjFindValue(cNow, "contactid");
    city = cObjFindValue(cNow, "city"); address1 = cObjFindValue(cNow, "address1");
    emailaddr = cObjFindValue(cNow, "emailaddr"); telno = cObjFindValue(cNow, "telno");
    $("#contactid").html(contactid);
    $("#name").html(name);
    $("#company").html(company);
    if (country == "CN") {
        country = "China";
    }
    if (country == "AU") {
        country = "Australia";
    }
    if (country == "CA") {
        country = "Canada";
    }
    if (country == "US") {
        country = "United States";
    }
    if (country == "CX") {
        country = "Christmas Island";
    }
    if (country == "FR") {
        country = "France";
    }
    if (country == "IN") {
        country = "India";
    }
    if (country == "TW") {
        country = "Taiwan";
    }
    if (country == "ES") {
        country = "Spain";
    }
    $("#country").html(country);
    $("#telnocc").html(telnocc);
    $("#telno").html(telno);
    $("#city").html(city);
    $("#address1").html(address1);
    $("#emailaddr").html(emailaddr);
    $("#zip").html(zip);
}

function resellerclub_getBackCustomerPwd() {
    $("#suwin").html(ajaxLoading("正在加载信息，请稍等......"))
    $("#suwin").dialog({ title: "操作提示", autoOpen: false, resizable: false, width: 350, height: 200, modal: true, buttons: { "关 闭": function () { $(this).dialog("close"); } } }).dialog("open");

    var url = "?c=module&productid=" + productData[0].pid + "&show=text&todo=resellerclub_CHKUserRoleAndGetUserInfo&orderID=" + serviceData[0].sconfig.OrderID + "&customerID=" + serviceData[0].sconfig.customerID;
    var role = "", lock = false, loginName = "", loginPath;
    $.get(url, function (data) {
        if (data.split('|')[0] == "admin") {
            role = "admin";
        }

        loginName = data.split('|')[1];
        loginPath = data.split('|')[2];
        loginPath = loginPath.replace("\\", "").replace("\\", "").replace("\\", "").replace("\\", "").replace("\\", "").replace("/customer", "");
        var txtStr = '';
        txtStr = '<div style="margin-top:5px;margin-left:15px;">';
        txtStr += '<table>';
        txtStr += '<tr style="height:30px;line-height: 30px;"><td style="width:100px;text-align:right;">';
        txtStr += '<b>登录账户名：</b>';
        txtStr += '</td><td style="text-align:left;">';
        txtStr += data.split('|')[1];
        txtStr += '</td></tr>';

        var height = 180, width = 300;
        if (role != "admin" && (emailchk_ResellerClub != "0" || smschk_ResellerClub != "0")) {
            height = 250, width = 420;

            txtStr += '<tr style="height:30px;line-height: 30px;"><td style="width:100px;text-align:right;">';
            txtStr += '<b>发送验证码：</b>';
            txtStr += '</td><td style="text-align:left;">';
            if (emailchk_ResellerClub != "0") {
                txtStr += '<input type="button" class="submit" value="发到邮箱" id="mailBtn" onclick="sendCodeToEmail(3)" /> &nbsp;&nbsp;';
            }
            if (smschk_ResellerClub != "0") {
                txtStr += '<input type="button" class="submit" value="发到手机" id="phoneBtn" onclick="sendCodeToPhone(3)" />';
            }

            txtStr += '</td></tr>';
            txtStr += '<tr style="height:30px;line-height: 30px;"><td style="width:100px;text-align:right;">';
            txtStr += '<b><input type="hidden" id="codeFlag" value="-1">输入验证码：</b>';
            txtStr += '</td><td style="text-align:left;">';
            txtStr += '<input name="vcode" id="vcode" class="text" style="width:110px;margin-top:3px;" />';
            txtStr += '</td></tr>';
        }

        txtStr += '</table></div>';
        txtStr += '<div class="loading" style="text-align:center;padding-top:2px;"></div>';
        $("#suwin").html(txtStr);

        $("#suwin").dialog({ title: "获取域名【" + serviceData[0].sconfig.domainName + "】的账户密码", autoOpen: false, resizable: false, width: width, height: height, modal: true, buttons: {
            "立即获取": function () {
                processing("正在获取中...");
                var chkCode = "";
                if (userData[0].isAdmin != "True" && (emailchk_ResellerClub != "0" || smschk_ResellerClub != "0") && $.trim($("#vcode").val()) == "") {
                    showResults('验证码不能为空！', 3000, "close");
                    return false;
                }
                else {
                    chkCode = $.trim($("#vcode").val());
                }

                url = "?c=module&serviceid=" + serviceData[0].sid + "&show=text&todo=resellerclub_GetUserPwd&customerID=" + serviceData[0].sconfig.customerID +
                      "&vcode=" + chkCode;
                $.get(url, function (data) {
                    var vArr = data.split('|');
                    if (vArr[0] == "0") {
                        // $("#suwin").dialog("close");
                        $("#processing").dialog("close");
                        // showTipWin(vArr[1], serviceData[0].sconfig.domainName);

                        var txtStr = '<p style="padding-left:70px;padding-top:20px;"><b>域 名：</b>' + serviceData[0].sconfig.domainName + '</p><p style="padding-left:70px;"><b>密 码：</b>' + vArr[1] + '</p>';

                        //txtStr += '<div style="height:120;margin-top:50px;text-align:center;">';
                        //  txtStr += '<div style="text-algin:center;color:green;"><b>密码成功发送到你的邮箱，请注意查收！</b></div><br>';
                        txtStr += '<form action="https://www.foundationapi.com/servlet/AuthenticationServlet" target="_blank" method="POST" name="LoginForm">';
                        txtStr += '<input type="hidden" name="redirectpage" value="null"><input type="hidden" name="currenturl" value="' + loginPath + '">' +
                        '<input type="hidden" name="logo_url" value="null"><input type="hidden" name="logo_height" value="null"><input type="hidden" name="tablebackground" value="null">' +
                        '<input type="hidden" name="support_url" value="null"><input type="hidden" name="pid" value="' + vArr[2] + '"><input type="hidden" name="role" value="customer"><input type="hidden" name="headingrole" value="customer">';
                        txtStr += '<input type="hidden" value="' + loginName + '" name="username" ><input type="hidden" value="' + vArr[1] + '" name="password">';
                        txtStr += '<p style="padding-left:70px;padding-top:10px;">马上：<input type="submit" value="账户登录" class="submit" style="cursor:pointer;"></p></form>';
                        $("#suwin").html(txtStr);
                        $("#suwin").dialog({ title: "操作提示", autoOpen: false, resizable: false, width: 350, height: 250, modal: true, buttons: { "关 闭": function () { $(this).dialog("close"); } } }).dialog("open");


                    } else {
                        // $("#suwin .loading").html("<b style='color:red;'>" + vArr[1] + "！</b>");
                        showResults(vArr[1], 3000, "close");
                    }


                    //                    var bFlag = data.split('|');
                    //                    switch (bFlag[0]) {
                    //                        case "vcode error":
                    //                            $("#suwin .loading").html('<div style="color:red;text-align:center;"><b>验证码错误，请检查！</b></div>');
                    //                            break;
                    //                        case "vcode none":
                    //                            $("#suwin .loading").html('<div style="color:red;text-align:center;"><b>验证码不存在或失效，请先发送验证码或刷新页面重试！</b></div>');
                    //                            break;
                    //                        case "ok":
                    //                            if (sendTo == "email") {
                    //                                $("#suwin .loading").html("<br/><img style='' src='files/images/loading.gif' /><br/>正在发送密码到你的邮箱中...");
                    //                                url = "?c=module&productid=" + productData[0].pid + "&show=text&customerID=" + serviceData[0].sconfig.customerID +
                    //                                      "&domainName=" + serviceData[0].sconfig.domainName + "&action=send_email&todo=resellerclub_SendPwdToEmail" +
                    //                                      "&pwd=" + bFlag[1] + "&loginName=" + loginName;
                    //                                $.get(url, function (data) {
                    //                                    if (data == "0") {
                    //                                        $("#suwin").dialog("close");
                    //                                        $("#suwin").dialog({ title: "获取账户密码成功", autoOpen: false, resizable: false, width: 350, height: 280, modal: false, buttons: {
                    //                                            "关 闭": function () { $(this).dialog("close"); }
                    //                                        }
                    //                                        }).dialog("open");
                    //                                        var ls = '';
                    //                                        ls += '<div style="height:120;margin-top:50px;text-align:center;">';
                    //                                        ls += '<div style="text-algin:center;color:green;"><b>密码成功发送到你的邮箱，请注意查收！</b></div><br>';
                    //                                        ls += '<form action="' + loginPath + '" target="_blank" method="POST" name="form">';
                    //                                        ls += '<input type="hidden" name="referer" value="/">';
                    //                                        ls += '<input type="hidden" value="" name="username"><input type="hidden" value="" name="password">';
                    //                                        ls += '马上：<input type="submit" value="账户登录" class="submit" style="cursor:pointer;"></form>';
                    //                                        $("#suwin").html(ls);

                    //                                    } else {
                    //                                        $("#suwin .loading").html('<div style="color:red;text-align:center;"><b>' + data + '</b></div>');
                    //                                    }

                    //                                });

                    //                            }
                    //                            else {
                    //                                $("#suwin .loading").html("<br/><img style='' src='files/images/loading.gif' /><br/>正在发送密码到你的手机...");
                    //                                url = "?c=module&productid=" + productData[0].pid + "&show=text&customerID=" + serviceData[0].sconfig.customerID +
                    //                                      "&domainName=" + serviceData[0].sconfig.domainName + "&action=send_sms&todo=resellerclub_SendPwdToPhone" +
                    //                                      "&pwd=" + bFlag[1] + "&loginName=" + loginName;
                    //                                $.get(url, function (data) {
                    //                                    if (data == "0") {
                    //                                        $("#suwin").dialog("close");
                    //                                        $("#suwin").dialog({ title: "获取账户密码成功", autoOpen: false, resizable: false, width: 350, height: 250, modal: false, buttons: {
                    //                                            "关 闭": function () { $(this).dialog("close"); }
                    //                                        }
                    //                                        }).dialog("open");
                    //                                        var ls = '';
                    //                                        ls += '<div style="height:120;margin-top:50px;text-align:center;">';
                    //                                        ls += '<div style="text-algin:center;color:green;"><b>密码成功发送到你的手机，请注意查收！</b></div><br>';
                    //                                        ls += '<form action="' + loginPath + '" target="_blank" method="POST" name="form">';
                    //                                        ls += '<input type="hidden" name="referer" value="/">';
                    //                                        ls += '<input type="hidden" value="" name="username"><input type="hidden" value="" name="password">';
                    //                                        ls += '马上：<input type="submit" value="账户登录" class="submit" style="cursor:pointer;"></form>';
                    //                                        $("#suwin").html(ls);

                    //                                    } else {
                    //                                        $("#suwin .loading").html('<div style="color:red;text-align:center;"><b>' + data + '</b></div>');
                    //                                    }
                    //                                });
                    //                            }
                    //                            break;
                    //                        default:
                    //                            $("#suwin .loading").html('<div style="color:red;text-align:center;"><b>' + data + '</b></div>');
                    //                            break;
                    //                            break;

                    //                    }

                });

                // }
            }, "关 闭": function () { $(this).dialog("close"); }
        }
        }).dialog("open");
    });
    // $("#swin").html('<div class="loading" style="text-align:center;padding-top:40px;"><img src="files/images/loading.gif" /><br/>Loading...</div>');
}
