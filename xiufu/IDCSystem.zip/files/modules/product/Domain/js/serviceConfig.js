﻿/// <reference path="jquery.min.js" />
function aiming_serviceConfig() {
   // var service_data = serviceData;
    var str = '';
    var trs = 'style="height:29px;line-height:29px;border-bottom:1px dashed #ddd;"';
    var tds1 = 'style="width:120px;text-align:right;"';
    var tds2 = 'style="text-align:left;"';
    var inputS = 'class="text" style="margin-top:3px;"';
    str += '<div style="margin-left:140px;">';
    str += '<table style="width:420px;">';
    str += '<tr ' + trs + '>';
    str += '<td ' + tds1 + '><b>域名商：</b>';
    str += '</td>';
    str += '<td ' + tds2 + '>' + getProvider();
    str += '</td>';
    str += '</tr>';
    str += '<tr ' + trs + '>';
    str += '<td ' + tds1 + '><b>域名：</b>';
    str += '</td>';
    str += '<td ' + tds2 + '>';
    str += '<input value="' + (serviceData[0].sconfig.domainName == undefined ? "" : serviceData[0].sconfig.domainName) + '" name="domainName" ' + inputS + ' /> ';
    if (serviceData[0].sconfig.transferFlag == "yes") {
        str += '<b style="color:red;"> &nbsp;（转入域名）</b>';
    }
    str += '</td>';
    str += '</tr>';

//        str += '<tr ' + trs + '>';
//        str += '<td ' + tds1 + '><b>注册日期：</b>';
//        str += '</td>';
//        str += '<td ' + tds2 + '><input value="' + (serviceData[0].sconfig.regDate == undefined ? "" : serviceData[0].sconfig.regDate) + '" name="regDate" ' + inputS + '/>';
//        str += '</td>';
//        str += '</tr>';

        str += '<tr ' + trs + '>';
        str += '<td ' + tds1 + '><b>姓：</b>';
        str += '</td>';
        str += '<td ' + tds2 + '>';
        str += '<input value="' +(serviceData[0].sconfig.lname == undefined ? "" : serviceData[0].sconfig.lname)  + '" name="lname" ' + inputS + ' /> ';
        str += '</td>';
        str += '</tr>';

   
        str += '<tr ' + trs + '>';
        str += '<td ' + tds1 + '><b>名：</b>';
        str += '</td>';
        str += '<td ' + tds2 + '>';
        str += '<input value="' + (serviceData[0].sconfig.fname == undefined ? "" : serviceData[0].sconfig.fname)+ '" name="fname" ' + inputS + ' /> ';
        str += '</td>';
        str += '</tr>';
  
    
        str += '<tr ' + trs + '>';
        str += '<td ' + tds1 + '><b>英文姓：</b>';
        str += '</td>';
        str += '<td ' + tds2 + '>';
        str += '<input value="' +(serviceData[0].sconfig.lnameE == undefined ? "" : serviceData[0].sconfig.lnameE)+ '" name="lnameE" ' + inputS + ' /> ';
        str += '</td>';

 
        str += '<tr ' + trs + '>';
        str += '<td ' + tds1 + '><b>英文名：</b>';
        str += '</td>';
        str += '<td ' + tds2 + '>';
        str += '<input value="' + (serviceData[0].sconfig.fnameE == undefined ? "" : serviceData[0].sconfig.fnameE)+ '" name="fnameE" ' + inputS + ' /> ';
        str += '</td>';
        str += '</tr>';
 

        str += '<tr ' + trs + '>';
        str += '<td ' + tds1 + '><b>联系电话：</b>';
        str += '</td>';
        str += '<td ' + tds2 + '>';
        str += '<input value="' + (serviceData[0].sconfig.phone == undefined ? "" : serviceData[0].sconfig.phone)+ '" name="phone" ' + inputS + ' /> ';
        str += '</td>';
        str += '</tr>';
    
        str += '<tr ' + trs + '>';
        str += '<td ' + tds1 + '><b>传真：</b>';
        str += '</td>';
        str += '<td ' + tds2 + '>';
        str += '<input value="' +(serviceData[0].sconfig.fax == undefined ? "" : serviceData[0].sconfig.fax)+ '" name="fax" ' + inputS + ' /> ';
        str += '</td>';
        str += '</tr>';
  
        str += '<tr ' + trs + '>';
        str += '<td ' + tds1 + '><b>电子邮箱：</b>';
        str += '</td>';
        str += '<td ' + tds2 + '>';
        str += '<input value="' + (serviceData[0].sconfig.email == undefined ? "" : serviceData[0].sconfig.email)+ '" name="email" ' + inputS + ' /> ';
        str += '</td>';
        str += '</tr>';
    
  
        str += '<tr ' + trs + '>';
        str += '<td ' + tds1 + '><b>省份：</b>';
        str += '</td>';
        str += '<td ' + tds2 + '>';
        str += '<input value="' +(serviceData[0].sconfig.province == undefined ? "" : serviceData[0].sconfig.province)+ '" name="province" ' + inputS + ' /> ';
        str += '</td>';
        str += '</tr>';
 
 
        str += '<tr ' + trs + '>';
        str += '<td ' + tds1 + '><b>城市：</b>';
        str += '</td>';
        str += '<td ' + tds2 + '>';
        str += '<input value="' + (serviceData[0].sconfig.city == undefined ? "" : serviceData[0].sconfig.city)+ '" name="city" ' + inputS + ' /> ';
        str += '</td>';
        str += '</tr>';
  
  
        str += '<tr ' + trs + '>';
        str += '<td ' + tds1 + '><b>街道：</b>';
        str += '</td>';
        str += '<td ' + tds2 + '>';
        str += '<input value="' + (serviceData[0].sconfig.street == undefined ? "" : serviceData[0].sconfig.street)+ '" name="street" ' + inputS + ' /> ';
        str += '</td>';
        str += '</tr>';
  
   
        str += '<tr ' + trs + '>';
        str += '<td ' + tds1 + '><b>英文街道：</b>';
        str += '</td>';
        str += '<td ' + tds2 + '>';
        str += '<input value="' +  (serviceData[0].sconfig.streetE == undefined ? "" : serviceData[0].sconfig.streetE)+ '" name="streetE" ' + inputS + ' /> ';
        str += '</td>';
        str += '</tr>';
    
        str += '<tr ' + trs + '>';
        str += '<td ' + tds1 + '><b>邮编：</b>';
        str += '</td>';
        str += '<td ' + tds2 + '>';
        str += '<input value="' + (serviceData[0].sconfig.zipcode == undefined ? "" : serviceData[0].sconfig.zipcode)+ '" name="zipcode" ' + inputS + ' /> ';
        str += '</td>';
        str += '</tr>';
    
        str += '<tr ' + trs + '>';
        str += '<td ' + tds1 + '><b>公司名称：</b>';
        str += '</td>';
        str += '<td ' + tds2 + '>';
        str += '<input value="' + (serviceData[0].sconfig.org == undefined ? "" : serviceData[0].sconfig.org)+ '" name="org" ' + inputS + ' /> ';
        str += '</td>';
        str += '</tr>';
  
        str += '<tr ' + trs + '>';
        str += '<td ' + tds1 + '><b>英文公司名称：</b>';
        str += '</td>';
        str += '<td ' + tds2 + '>';
        str += '<input value="' + (serviceData[0].sconfig.orgE == undefined ? "" : serviceData[0].sconfig.orgE)+ '" name="orgE" ' + inputS + ' /> ';
        str += '</td>';
        str += '</tr>';
//    if (serviceData[0].sconfig.other != undefined) {
//        str += '<tr ' + trs + '>';
//        str += '<td ' + tds1 + '><b>其他描述：</b>';
//        str += '</td>';
//        str += '<td ' + tds2 + '>';
//        str += '<input value="' + serviceData[0].sconfig.other + '" name="other" ' + inputS + ' /> ';
//        str += '</td>';
//        str += '</tr>';
//    }
    str += '</table>';
    str += '</div>';
    str += '';
    str += '<input type="hidden" value="' + serviceData[0].sconfig.transferFlag + '" name="transferFlag" />';
    str += '<input type="hidden" value="' + serviceData[0].sconfig.regYear + '" name="regYear" />';
    str += '<input type="hidden" value="' + serviceData[0].sconfig.typePrice + '" name="typePrice" />';
    str += '<input type="hidden" value="' + serviceData[0].sconfig.renewPrice + '" name="renewPrice" />';
    str += '<input type="hidden" value="' + serviceData[0].sconfig.transferPrice + '" name="transferPrice" />';
    str += '<input type="hidden" value="' + serviceData[0].sconfig.provider + '" name="provider" />';
    str += '<input type="hidden" value="' + serviceData[0].sconfig.regDate + '" name="regDate" />';
    // str += '<input type="hidden" value="' + serviceData[0].sconfig.vregPrice + '" name="vregPrice" />';
    //str += '<input type="hidden" value="' + serviceData[0].sconfig.vrenewPrice + '" name="vrenewPrice" />';
    // str += '<input type="hidden" value="' + serviceData[0].sconfig.vtransferPrice + '" name="vtransferPrice" />';
    $("#ServiceConfig").html('&nbsp;<br /><p style="line-height:30px">' + str + '</p>');
     
}
function getProvider() {
    var providerName = "";
    switch (serviceData[0].sconfig.provider) {
        case "aiming":
            providerName = '爱名网';
            break;
        case "resellerclub":
            providerName = 'Resellerclub';
            break;
        case "xinnet":
            providerName = '新网互联';
            break;
        case "xinwang":
            providerName = '新网';
            break;
    }
    return providerName;
}
function resellerClub_serviceConfig() {
    //var service_data = serviceData;
    var str = '';
    var trs = 'style="height:29px;line-height:29px;border-bottom:1px dashed #ddd;"';
    var tds1 = 'style="width:180px;text-align:right;"';
    var tds2 = 'style="text-align:left;"';
    var inputS = 'class="text" style="margin-top:3px;"';
    str += '<div style="margin-left:100px;">';
    str += '<table style="width:550px;">';

    str += '<tr ' + trs + '>';
    str += '<td ' + tds1 + '><b>域名商：</b>';
    str += '</td>';
    str += '<td ' + tds2 + '>' + getProvider();
    str += '</td>';
    str += '</tr>';

    str += '<tr ' + trs + '>';
    str += '<td ' + tds1 + '><b>域名：</b>';
    str += '</td>';
    str += '<td ' + tds2 + '>';
    str += '<input value="' + (serviceData[0].sconfig.domainName == undefined ? "" : serviceData[0].sconfig.domainName) + '" name="domainName" ' + inputS + ' /> ';
    if (serviceData[0].sconfig.transferFlag == "yes") {
        str += '<b style="color:red;"> &nbsp;（转入域名）</b>';
    }
    str += '</td>';
    str += '</tr>';

    str += '<tr ' + trs + '>';
    str += '<td ' + tds1 + '><b>ResellerClub账户ID：</b>';
    str += '</td>';
    str += '<td ' + tds2 + '><input value="' + (serviceData[0].sconfig.customerID == undefined ? "" : serviceData[0].sconfig.customerID) + '" name="customerID" ' + inputS + '  />';
    str += '</td>';
    str += '</tr>';
    str += '<tr ' + trs + '>';
    str += '<td ' + tds1 + '><b>域名联系人ID：</b>';
    str += '</td>';
    str += '<td ' + tds2 + '><input value="' + (serviceData[0].sconfig.ContactUserID == undefined ? "" : serviceData[0].sconfig.ContactUserID) + '" name="ContactUserID" ' + inputS + '  />';
    str += '</td>';
    str += '</tr>';
    str += '<tr ' + trs + '>';
    str += '<td ' + tds1 + '><b>订单ID：</b>';
    str += '</td>';
    str += '<td ' + tds2 + '>';
    str += '<input value="' + (serviceData[0].sconfig.OrderID == undefined ? "" : serviceData[0].sconfig.OrderID) + '" name="OrderID" ' + inputS + ' /> ';
    str += '</td>';
    str += '</tr>';
    str += '<tr ' + trs + '>';
    str += '<td ' + tds1 + '><b>注册日期：</b>';
    str += '</td>';
    str += '<td ' + tds2 + '><input value="' + (serviceData[0].sconfig.regDate == undefined ? "" : serviceData[0].sconfig.regDate) + '" name="regDate" ' + inputS + '  />';
    str += '</td>';
    str += '</tr>';
    str += '<tr ' + trs + '>';
    str += '<td ' + tds1 + '><b>注册年限：</b>';
    str += '</td>';
    str += '<td ' + tds2 + '><input value="' + (serviceData[0].sconfig.regYear == undefined ? "" : serviceData[0].sconfig.regYear) + '" name="regYear" ' + inputS + '  />';
    str += '</td>';
    str += '</tr>';
    str += '<tr ' + trs + '>';
    str += '<td ' + tds1 + '><b>联系人：</b>';
    str += '</td>';
    str += '<td ' + tds2 + '>';
    str += '<input value="' + (serviceData[0].sconfig.username == undefined ? "" : serviceData[0].sconfig.username) + '" name="username" ' + inputS + ' /> ';
    str += '</td>';
    str += '</tr>';
    str += '<tr ' + trs + '>';
    str += '<td ' + tds1 + '><b>注册公司：</b>';
    str += '</td>';
    str += '<td ' + tds2 + '>';
    str += '<input value="' + (serviceData[0].sconfig.company == undefined ? "" : serviceData[0].sconfig.company) + '" name="company" ' + inputS + ' /> ';
    str += '</td>';
    str += '</tr>';
    str += '</tr>';
    str += '<tr ' + trs + '>';
    str += '<td ' + tds1 + '><b>联系电话：</b>';
    str += '</td>';
    str += '<td ' + tds2 + '>';
    str += '<input value="' + (serviceData[0].sconfig.telno == undefined ? "" : serviceData[0].sconfig.telno) + '" name="telno" ' + inputS + ' /> ';
    str += '</td>';
    str += '</tr>';
    if (serviceData[0].sconfig.other != undefined) {
        str += '<tr ' + trs + '>';
        str += '<td ' + tds1 + '><b>其他描述：</b>';
        str += '</td>';
        str += '<td ' + tds2 + '>';
        str += '<input value="' + serviceData[0].sconfig.other + '" name="other" ' + inputS + ' /> ';
        str += '</td>';
        str += '</tr>';
    }
    else {
        str += '<tr ' + trs + '>';
        str += '<td ' + tds1 + '><b>其他描述：</b>';
        str += '</td>';
        str += '<td ' + tds2 + '>';
        str += '<input value="" name="other" ' + inputS + ' /> ';
        str += '</td>';
        str += '</tr>';
    }
    str += '</table>';
    str += '';
    str += '<div style="padding-top:20px;width:600">';

    str += '</div>';

    str += '</div>';
    str += '';
    str += '<input type="hidden" value="' + serviceData[0].sconfig.transferFlag + '" name="transferFlag" />';
    //  str += '<input type="hidden" value="' + serviceData[0].sconfig.regYear + '" name="regYear" />';
    str += '<input type="hidden" value="' + serviceData[0].sconfig.typePrice + '" name="typePrice" />';
    str += '<input type="hidden" value="' + serviceData[0].sconfig.renewPrice + '" name="renewPrice" />';
    str += '<input type="hidden" value="' + serviceData[0].sconfig.transferPrice + '" name="transferPrice" />';
    str += '<input type="hidden" value="' + serviceData[0].sconfig.provider + '" name="provider" />';
    // str += '<input type="hidden" value="' + serviceData[0].sconfig.vdomain + '" name="vdomain" />';
    // str += '<input type="hidden" value="' + serviceData[0].sconfig.vregPrice + '" name="vregPrice" />';
    // str += '<input type="hidden" value="' + serviceData[0].sconfig.vrenewPrice + '" name="vrenewPrice" />';
    // str += '<input type="hidden" value="' + serviceData[0].sconfig.vtransferPrice + '" name="vtransferPrice" />';
    $("#ServiceConfig").html('&nbsp;<br /><p style="line-height:30px">' + str + '</p>');
}
function xinnet_serviceConfig() {
    $("#suwin").next().find(".ui-dialog-buttonset button").eq(0).attr("disabled", true);
    var url = "?c=module&serviceid=" + serviceData[0].sid + "&show=text&todo=xinnet_GetDomainContactList&t=" + new Date();
    $.get(url, function (data) {
        var vdata = data.split('|');
        if (vdata[0] == "-1") {
            if (vdata[1].indexOf('没有域名') > -1 && serviceData[0].sconfig.transferFlag == "yes") {
                $("#ServiceConfig").html('<div style="text-align:center;padding-top:40px;color:red;"><b>域名正在转入中，域名转入需要6-11天，需要您耐心等待...</b></div>');
            } else {
                $("#ServiceConfig").html('<div style="text-align:center;padding-top:40px;color:red;"><b>' + vdata[1] + '</b></div>');
            }
        } else {
            $("#suwin").next().find(".ui-dialog-buttonset button").eq(0).attr("disabled", false); ;
            var jsonObj = $.parseJSON(vdata[0]);
            var str = '';
            var tr_td_SS = '<tr style="height:29px;line-height:29px;border-bottom:1px dashed #ddd;"><td style="width:120px;text-align:right;">';
            var inputSS = 'class="text" style="margin-top:4px;"';
            // str += '<h3 style="padding-left:80px;height:40px;font-size:16px;">填写域名注册信息 <b style="color:red;font-size:12px;font-weight:normal;word-spacing: 5px;"> ( 注意：请认真填写下面的信息！)</b></h3>';
            str += '<div style="padding-left:100px;">';
            str += '<table style="width:600px;" id="tbContact">';
            str += tr_td_SS + '<b>域名商：</b>';
            str += '</td>';
            str += '<td style="text-align:left;width:38%;">' + getProvider();
            str += '</td>';
            str += '<td style="text-align:left;">';
            str += '</td>';
            str += '</tr>';

            str += tr_td_SS + '<b>域名：</b>';
            str += '</td>';
            str += '<td style="text-align:left;width:38%;">';
            str += '<input value="' + (serviceData[0].sconfig.domainName == undefined ? "" : serviceData[0].sconfig.domainName) + '" name="domainName" ' + inputS + ' /> ';

            if (serviceData[0].sconfig.transferFlag == "yes") {
                str += '<b style="color:red;"> &nbsp;（转入域名）</b>';
            }
            str += '</td>';
            str += '<td style="text-align:left;">';
            str += '</td>';
            str += '</tr>';

            //            str += tr_td_SS + '<b>注册日期：</b>';
            //            str += '</td>';
            //            str += '<td style="text-align:left;">' + vdata[1].split(' ')[0] + '</td>';
            //            str += '<td style="text-align:left;">';
            //            str += '</td>';
            //            str += '</tr>';

            //            str += tr_td_SS + '<b>到期日期：</b>';
            //            str += '</td>';
            //            str += '<td style="text-align:left;">' + vdata[2].split(' ')[0] + '</td>';
            //            str += '<td style="text-align:left;">';
            //            str += '</td>';
            //            str += '</tr>';
            str += xinnet_getContactInfo(tr_td_SS, inputSS, jsonObj);
            str += '</table>';
            str += '</div>';
            str += '<input type="hidden" value="' + serviceData[0].sconfig.transferFlag + '" name="transferFlag" />';
            str += '<input type="hidden" value="' + serviceData[0].sconfig.regDate + '" name="regDate" />';
            str += '<input type="hidden" value="' + serviceData[0].sconfig.typePrice + '" name="typePrice" />';
            str += '<input type="hidden" value="' + serviceData[0].sconfig.renewPrice + '" name="renewPrice" />';
            str += '<input type="hidden" value="' + serviceData[0].sconfig.transferPrice + '" name="transferPrice" />';
            str += '<input type="hidden" value="' + serviceData[0].sconfig.provider + '" name="provider" />';
            $("#ServiceConfig").html(str);
            $("#Country").val(jsonObj.Country);
            $("#Province").val(jsonObj.Province);
            $("#Trade").val(jsonObj.Trade);
        }
    });

}
function xinnet_getContactInfo(tr_td_SS, inputSS, obj) {
    var str = tr_td_SS + '<b>联系人姓名(中文)：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="NameZH" id="NameZH" onblur="xinnet_keyUpCheck(this)" value=' + obj.NameZH + ' ' + inputSS + '>';
    str += '</td>';
    str += '<td style="text-align:left;" class="tip">';
    str += '</td>';
    str += '</tr>';

    str += tr_td_SS + '<b>单位名称(中文)：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="OrganizationZH" id="OrganizationZH" onblur="xinnet_keyUpCheck(this)" value=' + obj.OrganizationZH + ' ' + inputSS + '>';
    str += '</td>';
    str += '<td style="text-align:left;" class="tip">';
    str += '</td>';
    str += '</tr>';

    str += tr_td_SS + '<b>国家：</b>';
    str += '</td>';
    str += '<td style="text-align:left;">' + xinnet_getCountryList() + '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';

    str += tr_td_SS + '<b>省份：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">' + xinnet_getProvinceList() + '</td>';
    str += '<td style="text-align:left;width:250px;">注：如果国家不为中国，省份请选择“外国”';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>城市名称(中文)：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="CityZH" id="CityZH" onblur="xinnet_keyUpCheck(this)" value=' + obj.CityZH + ' ' + inputSS + '>';
    str += '</td>';
    str += '<td style="text-align:left;" class="tip">';
    str += '</td>';
    str += '</tr>';

    str += tr_td_SS + '<b>街道地址(中文)：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="StreetZH" id="StreetZH" onblur="xinnet_keyUpCheck(this)" value=' + obj.StreetZH + ' ' + inputSS + '>';
    str += '</td>';
    str += '<td style="text-align:left;" class="tip">';
    str += '</td>';
    str += '</tr>';

    str += tr_td_SS + '<b>邮政编码：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="Postcode" id="Postcode" onblur="xinnet_keyUpCheck(this)" value=' + obj.Postcode + ' ' + inputSS + '>';
    str += '</td>';
    str += '<td style="text-align:left;" class="tip">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>联系电话：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="PhoneRegionCode" id="PhoneRegionCode" value=' + obj.PhoneRegionCode + ' onblur="xinnet_keyUpCheck(this)" class="text" style="margin-top:4px;width:34px;">';
    str += '+<input name="phone" id="phone" style="margin-top:4px;width:145px;" onblur="xinnet_keyUpCheck(this)" value=' + (obj.PhoneAreaCode + "-" + obj.PhoneNumber) + ' class="text">';
    str += '</td>';
    str += '<td style="text-align:left;" class="tip">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>传真：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="FaxRegionCode" id="FaxRegionCode" value="86" onblur="xinnet_keyUpCheck(this)" value=' + obj.FaxRegionCode + ' class="text" style="margin-top:4px;width:34px;">';
    str += '+<input name="fax" id="fax" style="margin-top:4px;width:145px;" onblur="xinnet_keyUpCheck(this)" value=' + (obj.FaxAreaCode + "-" + obj.FaxNumber) + ' class="text">';
    str += '</td>';
    str += '<td style="text-align:left;" class="tip">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>电子邮箱：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="email" id="email" onblur="xinnet_keyUpCheck(this)" value=' + obj.Email + ' ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;" class="tip">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>行业类型：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">' + xinnet_getTradeList() + '</td>';
    str += '<td style="text-align:left;width:200px;">';
    str += '</td>';
    str += '</tr>';
    return str;
}

function xinwang_serviceConfig() {
    var str = '';
    var tr_td_SS = '<tr style="height:29px;line-height:29px;border-bottom:1px dashed #ddd;"><td style="width:180px;text-align:right;">';
    var inputSS = 'class="text" style="margin-top:4px;"';
    str += '<div style="padding-left:100px;">';
    str += '<table style="width:600px;" id="tbContact">';

    str += tr_td_SS + '<b>域名商：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:38%;">' + getProvider();
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';

    str += tr_td_SS + '<b>域名：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:38%;">';
    str += '<input value="' + (serviceData[0].sconfig.domainName == undefined ? "" : serviceData[0].sconfig.domainName) + '" name="domainName" ' + inputSS + ' /> ';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
   
    str += tr_td_SS + '<b>注册日期：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:38%;"><input value="' + (serviceData[0].sconfig.regDate == undefined? "" : serviceData[0].sconfig.regDate) + '" name="regDate" ' + inputSS + '  />';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';


    str += tr_td_SS + '<b>联系人姓名(中文)：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="chinaname" id="chinaname" onfocus="xinwang_keyFocus(this)" onblur="xinwang_keyUpCheck(this)" ' + inputSS + ' value="' + serviceData[0].sconfig.chinaname + '"/>';
    str += '</td>';
    str += '<td style="text-align:left;" class="tip">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>国家：</b>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '<select name="country" id="country" style="cursor:pointer;margin-top:4px;">' +
        '<option value="AU">澳大利亚</option>' +
        '<option value="CA">加拿大</option>' +
        '<option value="CN">中国</option>' +
        '<option value="CX">圣诞岛</option>' +
        '<option value="DK">丹麦</option>' +
        '<option value="DJ">吉布提</option>' +
        '<option value="DM">多米尼加联邦</option>' +
        '<option value="DO">多米尼加共和国</option>' +
        '<option value="TP">东帝汶</option>' +
        '<option value="FR">法国</option>' +
        '<option value="IN">印度</option>' +
        '<option value="JP">日本</option>' +
        '<option value="MA">摩洛哥</option>' +
        '<option value="NZ">新西兰</option>' +
        '<option value="OM">阿曼</option>' +
        '<option value="RU">俄罗斯联邦</option>' +
        '<option value="SB">所罗门群岛</option>' +
        '<option value="SO">索马里</option>' +
        '<option value="ZA">南非</option>' +
        '<option value="ES">西班牙</option>' +
        '<option value="LK">斯里兰卡</option>' +
        '<option value="SD">苏丹</option>' +
        '<option value="TW">台湾</option>' +
        '<option value="US">美国</option>';
    str += '</select>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>省份：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="province" id="province" onfocus="xinwang_keyFocus(this)" onblur="xinwang_keyUpCheck(this)" ' + inputSS + ' value="' + serviceData[0].sconfig.province + '"/>';
    str += '</td>';
    str += '<td style="text-align:left;" class="tip">';
    str += ' 省/市</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>城市：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="city" id="city" onfocus="xinwang_keyFocus(this)" onblur="xinwang_keyUpCheck(this)" ' + inputSS + ' value="' + serviceData[0].sconfig.city + '"/>';
    str += '</td>';
    str += '<td style="text-align:left;" class="tip">';
    str += ' 市/区</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>街道地址：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="street" id="street" onblur="xinwang_keyUpCheck(this)" ' + inputSS + ' value="' + serviceData[0].sconfig.street + '"/>';
    str += '</td>';
    str += '<td style="text-align:left;" class="tip">';
    str += '如：广东软件园A栋101号</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>邮政编码：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="zipcode" id="zipcode" onblur="xinwang_keyUpCheck(this)" ' + inputSS + '  value="' + serviceData[0].sconfig.zipcode + '"/>';
    str += '</td>';
    str += '<td style="text-align:left;" class="tip">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>联系电话：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="phone" id="phone" onfocus="xinwang_keyFocus(this)" onblur="xinwang_keyUpCheck(this)" ' + inputSS + ' value="' + serviceData[0].sconfig.phone + '"/>';
    str += '</td>';
    str += '<td style="text-align:left;width:240px" class="tip">';
    str += ' 手机/电话</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>电话区号：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="phonecode" id="phonecode" ' + inputSS + ' value="' + serviceData[0].sconfig.phonecode + '"/>';
    str += '</td>';
    str += '<td style="text-align:left;" class="tip">';
    str += ' 如果为手机，此项为空</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>传真号码：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="fax" id="fax" onfocus="xinwang_keyFocus(this)" onblur="xinwang_keyUpCheck(this)" ' + inputSS + '  value="' + serviceData[0].sconfig.fax + '"/>';
    str += '</td>';
    str += '<td style="text-align:left;width:240px" class="tip">';
    str += ' 手机/电话</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>传真区号：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="faxcode" id="faxcode" ' + inputSS + ' value="' + serviceData[0].sconfig.faxcode + '"/>';
    str += '</td>';
    str += '<td style="text-align:left;" class="tip">';
    str += ' 如果为手机，此项为空</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>电子邮箱：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="email" id="email" onblur="xinwang_keyUpCheck(this)" ' + inputSS + ' value="' + serviceData[0].sconfig.email + '"/>';
    str += '</td>';
    str += '<td style="text-align:left;" class="tip">';
    str += '</td>';
    str += '</tr>';

    str += tr_td_SS + '<b>联系人单位名称(中文) ：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="org" id="org" onblur="xinwang_keyUpCheck(this)" ' + inputSS + ' value="' + serviceData[0].sconfig.org + '"/>';
    str += '</td>';
    str += '<td style="text-align:left;" class="tip">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>联系人单位所在地：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="location" id="location" onblur="xinwang_keyUpCheck(this)" ' + inputSS + ' value="' + serviceData[0].sconfig.location + '" />';
    str += '</td>';
    str += '<td style="text-align:left;width:150px;" class="tip">如：广东广州';
    str += '</td>';
    str += '</tr>';
    
    str += '</table>';
    str += '</div>';
    str += '';
    str += '<input type="hidden" value="' + serviceData[0].sconfig.transferFlag + '" name="transferFlag" />';
    str += '<input type="hidden" value="' + serviceData[0].sconfig.regYear + '" name="regYear" />';
    str += '<input type="hidden" value="' + serviceData[0].sconfig.typePrice + '" name="typePrice" />';
    str += '<input type="hidden" value="' + serviceData[0].sconfig.renewPrice + '" name="renewPrice" />';
    str += '<input type="hidden" value="' + serviceData[0].sconfig.transferPrice + '" name="transferPrice" />';
    str += '<input type="hidden" value="' + serviceData[0].sconfig.provider + '" name="provider" />';

    str += '<input type="hidden" value="' + serviceData[0].sconfig.certcode + '" name="certcode" />';
    str += '<input type="hidden" value="' + serviceData[0].sconfig.uincode + '" name="uincode" />';
    str += '<input type="hidden" value="' + serviceData[0].sconfig.entitytype + '" name="entitytype" />';
    str += '<input type="hidden" value="' + serviceData[0].sconfig.certtype + '" name="certtype" />';
    $("#ServiceConfig").html('&nbsp;<br /><p style="line-height:30px">' + str + '</p>');
     $("#country").val(serviceData[0].sconfig.country);

   
}
function serviceConfig() {
    switch (serviceData[0].sconfig.provider) {
        case 'aiming':
            aiming_serviceConfig();
            break;
        case 'resellerclub':
            resellerClub_serviceConfig();
            break;
        case 'xinnet':
            xinnet_serviceConfig();
            break;
        case 'xinwang':
            xinwang_serviceConfig();
            break;
    }
}
serviceConfig();