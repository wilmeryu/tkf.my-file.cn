﻿function xinnet_getTradeList() {
    return '<select name="Trade" id="Trade" style="cursor:pointer;margin-top:4px;width:150px;">' +
          '<option label="党和政府部门" value="S1">党和政府部门</option><option label="信息咨询服务业" value="S2">信息咨询服务业</option><option label="社会福利事业业" value="S3">社会福利事业业</option>' +
     '<option label="商业税务部门" value="S4">商业税务部门</option><option label="体育、娱乐行业" value="S5">体育、娱乐行业</option><option label="运输业" value="S6">运输业</option>' +
     '<option label="媒体、广告业" value="S7">媒体、广告业</option><option label="商业" value="S8" selected>商业</option><option label="科学研究、教育业" value="S9">科学研究、教育业</option>' +
     ' <option label="房地产业" value="S10">房地产业</option><option label="邮电业" value="S11">邮电业</option><option label="IT业" value="S12">IT业</option>' +
     ' <option label="产品制造业" value="S13">产品制造业</option><option label="公共事业" value="S14">公共事业</option><option label="建筑业" value="S15">建筑业</option>' +
     '<option label="农、林、渔业" value="S16">农、林、渔业</option><option label="采矿业" value="S17">采矿业</option><option label="其他" value="S18">其他</option></select>';
}
function xinnet_getProvinceList() {
    return '<select name="Province" id="Province" style="cursor:pointer;margin-top:4px;width:150px;">' +
          '<option label="北京" value="BJ">北京</option><option label="香港" value="HK">香港</option><option label="澳门" value="MO">澳门</option>' +
     '<option label="台湾" value="TW">台湾</option><option label="上海" value="SH">上海</option><option label="深圳特区" value="SZ">深圳特区</option>' +
     '<option label="广东" value="GD">广东</option><option label="山东" value="SD">山东</option><option label="四川" value="SC">四川</option>' +
     '<option label="福建" value="FJ">福建</option><option label="江苏" value="JS">江苏</option><option label="浙江" value="ZJ">浙江</option>' +
     '<option label="天津" value="TJ">天津</option><option label="重庆" value="CQ">重庆</option><option label="河北" value="HE">河北</option>' +
     '<option label="河南" value="HA">河南</option><option label="黑龙江" value="HL">黑龙江</option><option label="吉林" value="JL">吉林</option>' +
     '<option label="辽宁" value="LN">辽宁</option><option label="内蒙古" value="NM">内蒙古</option><option label="海南" value="HI">海南</option>' +
     '<option label="山西" value="SX">山西</option><option label="陕西" value="SN">陕西</option><option label="安徽" value="AH">安徽</option>' +
     '<option label="江西" value="JX">江西</option><option label="甘肃" value="GS">甘肃</option><option label="新疆" value="XJ">新疆</option>' +
     ' <option label="湖北" value="HB">湖北</option><option label="湖南" value="HN">湖南</option><option label="云南" value="YN">云南</option>' +
     '<option label="广西" value="GX">广西</option><option label="宁夏" value="NX">宁夏</option><option label="贵州" value="GZ">贵州</option>' +
     '<option label="青海" value="QH">青海</option><option label="西藏" value="XZ">西藏</option><option label="外国" value="WG">外国</option></select>';
}
function xinnet_getCountryList() {
    return '<select name="Country" id="Country" style="cursor:pointer;margin-top:4px;">' +
        '<option label="阿富汗" value="AF">阿富汗</option><option label="阿尔巴尼亚" value="AL">阿尔巴尼亚</option><option label="阿尔及利亚" value="DZ">阿尔及利亚</option>' +
        '<option label="东萨摩亚" value="AS">东萨摩亚</option><option label="安道尔" value="AD">安道尔</option><option label="安哥拉" value="AO">安哥拉</option>' +
        '<option label="安圭拉" value="AI">安圭拉</option><option label="南极洲" value="AQ">南极洲</option><option label="安提瓜和巴布达" value="AG">安提瓜和巴布达</option>' +
        '<option label="阿根廷" value="AR">阿根廷</option><option label="亚美尼亚" value="AM">亚美尼亚</option><option label="阿鲁巴" value="AW">阿鲁巴</option>' +
        '<option label="澳大利亚" value="AU">澳大利亚</option><option label="奥地利" value="AT">奥地利</option><option label="阿塞拜疆" value="AZ">阿塞拜疆</option>' +
        '<option label="巴哈马" value="BS">巴哈马</option><option label="巴林" value="BH">巴林</option><option label="孟加拉国" value="BD">孟加拉国</option>' +
        '<option label="巴巴多斯" value="BB">巴巴多斯</option><option label="白俄罗斯" value="BY">白俄罗斯</option><option label="比利时" value="BE">比利时</option>' +
        '<option label="伯利兹" value="BZ">伯利兹</option><option label="贝宁" value="BJ">贝宁</option><option label="百慕大" value="BM">百慕大</option>' +
        '<option label="不丹" value="BT">不丹</option><option label="玻利维亚" value="BO">玻利维亚</option><option label="波黑" value="BA">波黑</option>' +
        '<option label="博茨瓦纳" value="BW">博茨瓦纳</option><option label="布维岛" value="BV">布维岛</option><option label="巴西" value="BR">巴西</option>' +
        '<option label="英属印度洋领地" value="IO">英属印度洋领地</option><option label="文莱达鲁萨兰国" value="BN">文莱达鲁萨兰国</option><option label="保加利亚" value="BG">保加利亚</option>' +
        '<option label="布基纳法索" value="BF">布基纳法索</option><option label="布隆迪" value="BI">布隆迪</option><option label="柬埔塞" value="KH">柬埔塞</option>' +
        '<option label="喀麦隆" value="CM">喀麦隆</option><option label="加拿大" value="CA">加拿大</option><option label="佛得角" value="CV">佛得角</option>' +
        '<option label="开曼群岛" value="KY">开曼群岛</option><option label="中非共和国" value="CF">中非共和国</option><option label="乍得" value="TD">乍得</option>' +
        '<option label="智利" value="CL">智利</option><option label="中国" value="CN" selected="selected">中国</option><option label="圣诞岛" value="CX">圣诞岛</option>' +
        '<option label="科科斯群岛" value="CC">科科斯群岛</option><option label="哥伦比亚" value="CO">哥伦比亚</option><option label="科摩罗" value="KM">科摩罗</option>' +
        '<option label="刚果" value="CG">刚果</option><option label="库克群岛" value="CK">库克群岛</option><option label="哥斯达黎加" value="CR">哥斯达黎加</option>' +
        '<option label="克罗地亚" value="HR">克罗地亚</option><option label="古巴" value="CU">古巴</option><option label="塞浦路斯" value="CY">塞浦路斯</option>' +
        '<option label="捷克共和国" value="CZ">捷克共和国</option><option label="丹麦" value="DK">丹麦</option><option label="吉布提" value="DJ">吉布提</option>' +
        '<option label="多米尼加联邦" value="DM">多米尼加联邦</option><option label="多米尼加共和国" value="DO">多米尼加共和国</option><option label="东帝汶" value="TP">东帝汶</option>' +
        '<option label="厄瓜多尔" value="EC">厄瓜多尔</option><option label="埃及" value="EG">埃及</option><option label="萨尔瓦多" value="SV">萨尔瓦多</option>' +
        '<option label="赤道几内亚" value="GQ">赤道几内亚</option><option label="爱沙尼亚" value="EE">爱沙尼亚</option><option label="埃塞俄比亚" value="ET">埃塞俄比亚</option>' +
        '<option label="福克兰群岛" value="FK">福克兰群岛</option><option label="法罗群岛" value="FO">法罗群岛</option><option label="斐济" value="FJ">斐济</option>' +
       '<option label="芬兰" value="FI">芬兰</option><option label="前捷克斯洛伐克" value="CS">前捷克斯洛伐克</option><option label="前苏联" value="SU">前苏联</option>' +
        '<option label="法国" value="FR">法国</option><option label="法属欧洲领地" value="FX">法属欧洲领地</option><option label="法属圭亚那" value="GF">法属圭亚那</option>' +
         '<option label="法属南半球领地" value="TF">法属南半球领地</option><option label="加蓬" value="GA">加蓬</option><option label="冈比亚" value="GM">冈比亚</option>' +
          '<option label="格鲁吉亚" value="GE">格鲁吉亚</option><option label="德国" value="DE">德国</option><option label="加纳" value="GH">加纳</option>' +
          '<option label="直布罗陀" value="GI">直布罗陀</option><option label="大不列颠联合王国" value="GB">大不列颠联合王国</option><option label="希腊" value="GR">希腊</option>' +
           '<option label="格陵兰" value="GL">格陵兰</option><option label="格林纳达" value="GD">格林纳达</option><option label="瓜德罗普（法属）" value="GP">瓜德罗普（法属）</option>' +
            '<option label="关岛（美属）" value="GU">关岛（美属）</option><option label="危地马拉" value="GT">危地马拉</option><option label="几内亚比绍" value="GW">几内亚比绍</option>' +
            '<option label="圭亚那" value="GY">圭亚那</option><option label="海地" value="HT">海地</option><option label="洪都拉斯" value="HN">洪都拉斯</option>' +
            '<option label="匈牙利" value="HU">匈牙利</option><option label="冰岛" value="IS">冰岛</option><option label="印度" value="IN">印度</option>' +
            '<option label="印度尼西亚" value="ID">印度尼西亚</option><option label="伊朗" value="IR">伊朗</option><option label="伊拉克" value="IQ">伊拉克</option>' +
            '<option label="爱尔兰" value="IE">爱尔兰</option><option label="以色列" value="IL">以色列</option><option label="意大利" value="IT">意大利</option>' +
            '<option label="象牙海岸" value="CI">象牙海岸</option><option label="牙买加" value="JM">牙买加</option><option label="日本" value="JP">日本</option>' +
            '<option label="约旦" value="JO">约旦</option><option label="哈萨克斯坦" value="KZ">哈萨克斯坦</option><option label="肯尼亚" value="KE">肯尼亚</option><option label="基里巴斯" value="KI">基里巴斯</option>' +
            '<option label="科威特" value="KW">科威特</option><option label="吉尔吉斯斯坦" value="KG">吉尔吉斯斯坦</option><option label="老挝" value="LA">老挝</option>' +
            '<option label="拉脱维亚" value="LV">拉脱维亚</option><option label="黎巴嫩" value="LB">黎巴嫩</option><option label="莱索托" value="LS">莱索托</option>' +
            ' <option label="利比里亚" value="LR">利比里亚</option><option label="利比亚" value="LY">利比亚</option><option label="列支敦士登" value="LI">列支敦士登</option>' +
            '<option label="立陶宛" value="LT">立陶宛</option><option label="卢森堡" value="LU">卢森堡</option><option label="马其顿" value="MK">马其顿</option>' +
            '<option label="马达加斯加" value="MG">马达加斯加</option><option label="马拉维" value="MW">马拉维</option><option label="马来西亚" value="MY">马来西亚</option>' +
             '<option label="马尔代夫" value="MV">马尔代夫</option><option label="马里" value="ML">马里</option><option label="马耳他" value="MT">马耳他</option>' +
              '<option label="马绍尔群岛" value="MH">马绍尔群岛</option><option label="马提尼克（法属）" value="MQ">马提尼克（法属）</option><option label="毛利塔尼亚" value="MR">毛利塔尼亚</option>' +
             '<option label="毛里求斯" value="MU">毛里求斯</option><option label="马约特" value="YT">马约特</option><option label="墨西哥" value="MX">墨西哥</option>' +
            '<option label="密克罗尼西亚" value="FM">密克罗尼西亚</option><option label="摩尔多瓦" value="MD">摩尔多瓦</option><option label="摩纳哥" value="MC">摩纳哥</option>' +
            '<option label="蒙古" value="MN">蒙古</option><option label="蒙特塞拉特" value="MS">蒙特塞拉特</option><option label="摩洛哥" value="MA">摩洛哥</option>' +
           '<option label="莫桑比克" value="MZ">莫桑比克</option><option label="缅甸" value="MM">缅甸</option><option label="纳米比亚" value="NA">纳米比亚</option>' +
          '<option label="瑙鲁" value="NR">瑙鲁</option><option label="尼泊尔" value="NP">尼泊尔</option><option label="荷兰" value="NL">荷兰</option>' +
          '<option label="荷兰属地" value="AN">荷兰属地</option><option label="新喀里多尼亚（法属）" value="NC">新喀里多尼亚（法属）</option><option label="新西兰" value="NZ">新西兰</option>' +
          '<option label="尼加拉瓜" value="NI">尼加拉瓜</option><option label="尼日尔" value="NE">尼日尔</option><option label="尼日利亚" value="NG">尼日利亚</option>' +
         ' <option label="纽埃" value="NU">纽埃</option><option label="诺福克岛" value="NF">诺福克岛</option><option label="朝鲜" value="KP">朝鲜</option>' +
         ' <option label="北马里亚纳群岛" value="MP">北马里亚纳群岛</option><option label="挪威" value="NO">挪威</option><option label="阿曼" value="OM">阿曼</option>' +
          ' <option label="巴基斯坦" value="PK">巴基斯坦</option><option label="帕劳" value="PW">帕劳</option><option label="巴拿马" value="PA">巴拿马</option>' +
           ' <option label="巴布亚新几内亚" value="PG">巴布亚新几内亚</option><option label="巴拉圭" value="PY">巴拉圭</option><option label="秘鲁" value="PE">秘鲁</option>' +
            '<option label="菲律宾" value="PH">菲律宾</option><option label="皮特克恩岛" value="PN">皮特克恩岛</option><option label="波兰" value="PL">波兰</option>' +
         '<option label="玻利尼西亚（法属）" value="PF">玻利尼西亚（法属）</option><option label="葡萄牙" value="PT">葡萄牙</option><option label="波多黎各" value="PR">波多黎各</option>' +
         ' <option label="卡塔尔" value="QA">卡塔尔</option><option label="留尼汪（法属）" value="RE">留尼汪（法属）</option><option label="罗马尼亚" value="RO">罗马尼亚</option>' +
         '<option label="俄罗斯联邦" value="RU">俄罗斯联邦</option><option label="卢旺达" value="RW">卢旺达</option><option label="海伦娜" value="SH">海伦娜</option>' +
         ' <option label="圣卢西亚" value="LC">圣卢西亚</option><option label="萨摩亚" value="WS">萨摩亚</option><option label="圣马力诺" value="SM">圣马力诺</option>' +
         '<option label="沙特阿拉伯" value="SA">沙特阿拉伯</option><option label="塞内加尔" value="SN">塞内加尔</option><option label="塞舌尔" value="SC">塞舌尔</option>' +
         '<option label="塞拉利昂" value="SL">塞拉利昂</option><option label="新加坡" value="SG">新加坡</option><option label="斯洛伐克共和国" value="SK">斯洛伐克共和国</option>' +
         '<option label="斯洛文尼亚" value="SI">斯洛文尼亚</option><option label="所罗门群岛" value="SB">所罗门群岛</option><option label="索马里" value="SO">索马里</option>' +
         '<option label="南非" value="ZA">南非</option><option label="韩国" value="KR">韩国</option><option label="西班牙" value="ES">西班牙</option>' +
         '<option label="斯里兰卡" value="LK">斯里兰卡</option><option label="苏丹" value="SD">苏丹</option><option label="苏里南" value="SR">苏里南</option>' +
         '<option label="斯瓦尔巴特" value="SJ">斯瓦尔巴特</option><option label="斯威士兰" value="SZ">斯威士兰</option><option label="瑞典" value="SE">瑞典</option>' +
          ' <option label="瑞士" value="CH">瑞士</option><option label="叙利亚" value="SY">叙利亚</option><option label="塔吉克斯坦" value="TJ">塔吉克斯坦</option>' +
         ' <option label="坦桑尼亚" value="TZ">坦桑尼亚</option><option label="泰国" value="TH">泰国</option><option label="多哥" value="TG">多哥</option>' +
         '<option label="托克劳" value="TK">托克劳</option><option label="汤加" value="TO">汤加</option><option label="特立尼达和多巴哥" value="TT">特立尼达和多巴哥</option>' +
         ' <option label="突尼斯" value="TN">突尼斯</option><option label="土耳其" value="TR">土耳其</option><option label="土库曼斯坦" value="TM">土库曼斯坦</option>' +
         '<option label="凯科斯群岛" value="TC">凯科斯群岛</option><option label="图瓦卢" value="TV">图瓦卢</option><option label="乌干达" value="UG">乌干达</option>' +
         ' <option label="乌克兰" value="UA">乌克兰</option><option label="阿联酋" value="AE">阿联酋</option><option label="英国" value="UK">英国</option>' +
         '<option label="美国" value="US">美国</option><option label="乌拉圭" value="UY">乌拉圭</option><option label="美属边远群岛" value="UM">美属边远群岛</option>' +
         ' <option label="乌兹别克斯坦" value="UZ">乌兹别克斯坦</option><option label="瓦努阿图" value="VU">瓦努阿图</option><option label="梵蒂冈" value="VA">梵蒂冈</option>' +
         '<option label="委内瑞拉" value="VE">委内瑞拉</option><option label="越南" value="VN">越南</option><option label="维京群岛（英属）" value="VG">维京群岛（英属）</option>' +
         ' <option label="维京群岛（美属）" value="VI">维京群岛（美属）</option><option label="西萨摩亚" value="EH">西萨摩亚</option><option label="也门" value="YE">也门</option>' +
         ' <option label="南斯拉夫" value="YU">南斯拉夫</option><option label="扎伊尔" value="ZR">扎伊尔</option><option label="赞比亚" value="ZM">赞比亚</option><option label="津巴布韦" value="ZW">津巴布韦</option></select>';
}

function sendCodeToEmail(tum) {
    // $("#suwin .loading").html("<img style='' src='images/loading.gif' /><br/>正在发送验证码到邮箱中...");
    processing("正在发送验证码到邮箱中...", 370,168);
    var url = "?c=module&productid=" + productData[0].pid + "&show=text&action=send_email&todo=send_emailCode&domainName=" + serviceData[0].sconfig.domainName;
    url += "&token=" + (new Date()).valueOf() + "&leftTime=" + tum;
    var leftTime = parseInt(tum) * 60;
    $("#mailBtn").attr("disabled", "disabled").attr("value", "还剩" + leftTime + "秒").css({ "color": "gray", "cursor": "default" });
    $("#phoneBtn").attr("disabled", "disabled").attr("value", "还剩" + leftTime + "秒").css({ "color": "gray", "cursor": "default" });
    var myTimer = setInterval(function () {
        if (leftTime > 1) {
            leftTime -= 1;
            $("#mailBtn").attr("disabled", "disabled").attr("value", "还剩" + leftTime + "秒");
            $("#phoneBtn").attr("disabled", "disabled").attr("value", "还剩" + leftTime + "秒");
        }
        else {
            clearInterval(myTimer);
            $("#mailBtn").removeAttr("disabled").attr("value", "发送到邮箱").css({ "color": "white", "cursor": "pointer" });
            $("#phoneBtn").removeAttr("disabled").attr("value", "发送到手机").css({ "color": "white", "cursor": "pointer" });
        }
    }, 1000);
    $.get(url, function (data) {
        if (parseInt(data) == 0) {

            showResults("验证码已发送到您的邮箱[" + userData[0].umail + "]，请查收！", 3000, "close");
            // $("#codeFlag").val("0");
            $("#vcode").focus();
        } else {
            if (data.indexOf("Email is not verified") > -1) {
                data = "抱歉，邮箱不合法，请检查你的用户资料！";
                // $("#suwin .loading").html("<b style='color:red;'>抱歉，邮箱不合法，请检查你的用户资料！</b>");
            }
            else {
                // $("#suwin .loading").html("<b style='color:red;'>" + data.substr(3) + "</b>");
                data = data.substr(3);
            }
            showResults(data, 5000, "close");
        }

    });
}
function sendCodeToPhone(tum) {
    // $("#suwin .loading").html("<img style='' src='images/loading.gif' /><br/>正在发送验证码到手机中...");
    processing("正在发送验证码到手机中...");
    var url = "?c=module&productid=" + productData[0].pid + "&show=text&action=send_sms&todo=send_phoneCode&domainName=" + serviceData[0].sconfig.domainName;
    url += "&token=" + (new Date()).valueOf() + "&leftTime=" + tum;
    var leftTime = parseInt(tum) * 60;
    $("#mailBtn").attr("disabled", "disabled").attr("value", "还剩" + leftTime + "秒").css({ "color": "gray", "cursor": "default" });
    $("#phoneBtn").attr("disabled", "disabled").attr("value", "还剩" + leftTime + "秒").css({ "color": "gray", "cursor": "default" });
    var myTimer = setInterval(function () {
        if (leftTime > 1) {
            leftTime -= 1;
            $("#mailBtn").attr("disabled", "disabled").attr("value", "还剩" + leftTime + "秒");
            $("#phoneBtn").attr("disabled", "disabled").attr("value", "还剩" + leftTime + "秒");
        }
        else {
            clearInterval(myTimer);
            $("#mailBtn").removeAttr("disabled").attr("value", "发送到邮箱").css({ "color": "white", "cursor": "pointer" });
            $("#phoneBtn").removeAttr("disabled").attr("value", "发送到手机").css({ "color": "white", "cursor": "pointer" });
        }
    }, 1000);
    $.get(url, function (data) {
        if (parseInt(data) == 0) {
            // $("#suwin .loading").html("<b style='color:green;'>验证码已发送到您的手机[" + userData[0].tel + "]，请查收！</b>");
            // $("#codeFlag").val("0");
            //$("#vcode").focus();

            showResults("验证码已发送到您的手机[" + userData[0].tel + "]，请查收！", 3000, "close");
            // $("#codeFlag").val("0");
            $("#vcode").focus();
        } else {
            showResults(data.substr(3), 5000, "close");
            //$("#suwin .loading").html("<b style='color:red;'>" + data.substr(3) + "</b>");
        }


    });
}

function showPwdWin(pwd, domain) {
    $("#suwin").dialog({ title: "操作提示", autoOpen: false, resizable: false, width: 300, height: 200, modal: true, buttons: { "关 闭": function () { $(this).dialog("close"); } } }).dialog("open");
    var txtStr = '<p style="padding-left:70px;padding-top:20px;"><b>域 名：</b>' + domain + '</p><p style="padding-left:70px;"><b>密 码：</b>' + pwd + '</p>';
    $("#suwin").html(txtStr);
}