﻿
function xinnet_regDomain(domainType, domainName, vprovider, data, templatesid) {
       $("#swin").html(ajaxLoading("正在加载信息，请稍等..."));
    $("#swin").dialog({ title: "操作提示", autoOpen: false, resizable: false, width: 400, height: 280, modal: true, buttons: { "取 消": function () {
        $(this).dialog("close");
    }
    }
    }).dialog("open");

    var jsonArr = $.parseJSON(data);
    var domain = domainName + domainType;
    var str = '';
    var tr_td_SS = '<tr style="height:29px;line-height:29px;border-bottom:1px dashed #ddd;"><td style="width:120px;text-align:right;">';
    var inputSS = 'class="text" style="margin-top:4px;"';
    str += '<h3 style="padding-left:80px;height:40px;font-size:16px;">填写域名注册信息 <b style="color:red;font-size:12px;font-weight:normal;word-spacing: 5px;"> ( 注意：请认真填写下面的信息！)</b></h3>';
    str += '<div style="padding-left:100px;">';
    str += '<table style="width:600px;">';
    str += tr_td_SS + '<b>购买的域名：</b>';
    str += '</td>';
    str += '<td style="text-align:left;"><input type="hidden" id="regDomainName" value="' + domain + '" />';
    str += domain;
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>注册年限：</b>';
    str += '</td>';
    str += '<td style="text-align:left;">';
   
    var priceArr = productData[0].pprice.cprice.split(',');
    str += '<select name="regYear" id="regYear" onchange="setRegYear()" style="cursor:pointer;margin-top:4px;">';
    if (priceArr[3] != 0) {
        str += '<option value="1" style="cursor:pointer;">1</option>';
    }
    if (priceArr[4] != 0) {
        str += '<option value="2" style="cursor:pointer;">2</option>';
    }
    str += '</select> 年</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';

    str += tr_td_SS + '<b>选择联系人信息：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:250px;">';
    str += '<select id=\"selcontact\" name=\"selcontact\" style=\"height:auto;cursor:pointer;\">';

    for (var i = 0; i < jsonArr.length; i++) {
        str += '<option value="' + i + '">' + jsonArr[i].lname + jsonArr[i].fname + "-" + (i + 1) + '</option>';
    }

    str += '</select>&nbsp;&nbsp;&nbsp;<input type="button" value="联系人模板管理" class="submit" id="btntemplates" style="cursor:pointer;"></td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';

    str += getdomaininfo(tr_td_SS, inputSS);
    str += '</table>';
    str += '</div>';
    $("#swin").html(str);
    $("#swin").append('<form id="OrderConfig"><div id="myStr"></div></form>');

    $("#selcontact").change(function () {
        var i = $(this).val();
        $("#OrganizationZH").val(jsonArr[i].company);
        $("#NameZH").val(jsonArr[i].fname + jsonArr[i].lname);
        $("#Country").val(jsonArr[i].countrycode);
        var vprovince = jsonArr[i].province;
        vprovince = vprovince.substr(0, 2);
        $("#Province option").each(function (i) {
            if ($(this).text().indexOf(vprovince) > -1) {
                $("#Province").val($(this).val());
            }
        });
        $("#CityZH").val(jsonArr[i].city);
        $("#StreetZH").val(jsonArr[i].street);
        $("#Postcode").val(jsonArr[i].zipcode);
        $("#phone").val(jsonArr[i].phonecode + '-' + jsonArr[i].phone);
        $("#fax").val(jsonArr[i].faxcode + '-' + jsonArr[i].fax);
        $("#email").val(jsonArr[i].email);

        $("#swin input").focus();
    });

    $("#selcontact").val(templatesid).change();
    $("#btntemplates").click(function () {
        common_ListDomainContact(domainType, domainName, vprovider, '', "reg", templatesid);
    });

    $("#swin").dialog({ title: "【" + domain + "】域名注册信息", autoOpen: false, resizable: false, width: 830, height: 590, modal: true, buttons: { "立即注册": function () {
        xinnet_gotoRegDomain();
    }, "关 闭": function () {
        $(this).dialog("close");
    }
    }
    }).dialog("open");
    // var rType = domain.substr(domain.indexOf("."));
    var discount = parseFloat(productData[0].discount);
    var myPrice = getPriceByType(domainType, 'reg');
    var yearNum = 1;
    $("#divprice").remove();
    var pStr = '<div style="float:left;height:44px;line-height:44px;" id="divprice"><input type="hidden" value="' + yearNum + '" id="yearNum" />';
    if (discount > 0 && discount < 1) {
        pStr += '<strong>总价格：<span style="color:blue;" id="OrderNormalPrice"><strike>' + myPrice + '</strike></span> <b style="">RMB</b>';
        myPrice = parseFloat(getPriceByType(domainType, 'reg')) * discount;
        pStr += '<input type="hidden" value="' + myPrice + '" id="typePrice" />';
        pStr += '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
        pStr += '帐户优惠价(' + discount + '折)：<span style="color:blue;" id="OrderPrice">' + myPrice + '</span> <b style="">RMB</b></strong>';
    }
    else {

        myPrice = parseFloat(getPriceByType(domainType, 'reg')) * discount;

        pStr += '<input type="hidden" value="' + myPrice + '" id="typePrice" />';
        pStr += '<strong>总价格：<span style="color:blue;" id="OrderPrice">' + myPrice + '</span> <b style="color:blue;">RMB</b></strong>';
    }
    pStr += '</div>';
    $(".ui-dialog-buttonset").before(pStr);
}
function xinnet_gotoRegDomain() {
    var isok = true;
    $("td.tip").each(function () {
        if ($(this).find("span").length > 0) {
            isok = false;
            return;
        }
    });
    if (!isok) return;

    var theDomainName = $("#regDomainName").val();
    var theType = theDomainName.substr(theDomainName.indexOf("."));
    var yNum = $("#regYear").val();
    normalPrice = parseFloat(getPriceByType(theType, 'reg')) * parseInt($("#yearNum").val());
    finalPrice = parseFloat($("#typePrice").val()) * parseInt($("#yearNum").val());
    billingCycle = parseInt($("#yearNum").val()) * 12;
    billingMothod = 1;
    var myInputs = '<input type="hidden" value="' + getPriceByType(theType, 'reg') + '" name="typePrice" />' +
          '<input type="hidden" value="' + getPriceByType(theType, 'renew') + '" name="renewPrice" />' +
          '<input type="hidden" value="' + getPriceByType(theType, 'transfer') + '" name="transferPrice" />' +
          '<input type="hidden" value="' + $("#regDomainName").val() + '" name="domainName" />' +
          '<input type="hidden" value="' + yNum + '" name="regYearNum" />' +
          '<input type="hidden" value="' + $.trim($("#OrganizationZH").val()) + '" name="OrganizationZH" />' +
          '<input type="hidden" value="' + $.trim($("#NameZH").val()) + '" name="NameZH" />' +
          '<input type="hidden" value="' + $.trim($("#Country").val()) + '" name="Country" />' +
          '<input type="hidden" value="' + $.trim($("#Province").val()) + '" name="Province" />' +
          '<input type="hidden" value="' + $.trim($("#CityZH").val()) + '" name="CityZH" />' +
          '<input type="hidden" value="' + $.trim($("#StreetZH").val()) + '" name="StreetZH" />' +
          '<input type="hidden" value="' + $.trim($("#Postcode").val()) + '" name="Postcode" />' +
          '<input type="hidden" value="' + $.trim($("#PhoneRegionCode").val()) + '" name="PhoneRegionCode" />' +
          '<input type="hidden" value="' + $.trim($("#phone").val()) + '" name="phone" />' +
          '<input type="hidden" value="' + $.trim($("#FaxRegionCode").val()) + '" name="FaxRegionCode" />' +
          '<input type="hidden" value="' + $.trim($("#fax").val()) + '" name="fax" />' +
          '<input type="hidden" value="' + $.trim($("#email").val()) + '" name="email" />' +
          '<input type="hidden" value="' + $.trim($("#Trade").val()) + '" name="Trade" />' +
    // '<input type="hidden" value="' + $.trim($("#dns1").val()) + '" name="dns1" />' +
    //'<input type="hidden" value="' + $.trim($("#dns2").val()) + '" name="dns2" />' +        
          '<input type="hidden" value="xinnet" name="provider" />';
    $("#myStr").html(myInputs);
    suwin.next().find("#divprice").remove();
    suwin.dialog({ title: "购买确认", autoOpen: false, resizable: false, width: 399, height: 368, modal: true, buttons: { "确定购买": function () { checkout(1); }, "继续配置": function () { $(this).dialog("close"); }, "在线充值": function () { window.open('?c=finance', '_blank'); } } }).dialog("open");
    checkout(0);
}
function xinnet_gotoChkTransferDomain(domainName, domainType, pwd, provider, data, templatesid) {
//    $("#suwin").html(ajaxLoading("<b>正在检查你的域名信息</b>"));
//    var url = "?c=module&productid=" + productData[0].pid + "&show=text&todo=xinnet_checkDomainTransfer&domain=" + domainName + domainType;
//    $.get(url, function (rdata) {
//        if (rdata == "0") {
//            $("#suwin").dialog("close");
//            xinnet_transferDomain(domainName, domainType, pwd, provider, data, templatesid);
//        } else {
//            $("#suwin").html('<div class="ui-state-highlight ui-corner-all" style="padding: 10px;margin-top:50px;text-align:center;"><strong>' + rdata + '</strong></div>');
//        }
//    });
//    $("#suwin").dialog({ title: "操作提示", autoOpen: false, resizable: false, width: 400, height: 280, modal: true, buttons: { "取 消": function () {
//        $(this).dialog("close");
//    }
//    }
    //    }).dialog("open");
    xinnet_transferDomain(domainName, domainType, pwd, provider, data, templatesid);

}
function xinnet_transferDomain(domainName, domainType, pwd, provider, data, templatesid) {
    $("#swin").dialog({ title: "域名转入服务", autoOpen: false, resizable: false, width: 800, height: 568, modal: true, buttons: { "确定转入": function () {

        xinnet_gotoTransferDomain(domainName, domainType, pwd, provider);
    }, "关 闭": function () {
        $(this).dialog("close");
    }
    }
    }).dialog("open");
    var jsonArr = $.parseJSON(data);
    var str = '<h3 style="padding-left:70px;height:40px;font-size:16px;">请填写下面的转入域名信息 <b style="color:red;font-size:12px;font-weight:normal;word-spacing: 5px;"> ( 注意：请认真填写下面的信息！)</b></h3>';
    str += '<div style="margin-left:150px;">';
    str += '<table>';
    var tr_td_SS = '<tr style="height:29px;line-height:29px;border-bottom:1px dashed #ddd;"><td style="width:120px;text-align:right;">';
    var inputSS = 'class="text" style="margin-top:4px;"';
    str += '<div style="padding-left:170px;">';
    str += '<table style="width:450px;">';
    str += tr_td_SS + '<b>转入的域名：</b>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += domainName + domainType;
    str += '</td>';
    str += '<td style="text-align:left;width:150px;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>转移密码：</b>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += pwd;
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += '</table>';
    str += '<table id="comBox">';

    str += tr_td_SS + '<b>选择联系人信息：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:250px;">';
    str += '<select id=\"selcontact\" name=\"selcontact\" style=\"height:auto;cursor:pointer;\">';

    for (var i = 0; i < jsonArr.length; i++) {
        str += '<option value="' + i + '">' + jsonArr[i].lname + jsonArr[i].fname + "-" + (i + 1) + '</option>';
    }
    str += '</select>&nbsp;&nbsp;&nbsp;<input type="button" value="联系人模板管理" class="submit" id="btntemplates" style="cursor:pointer;"></td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += getdomaininfo(tr_td_SS, inputSS);
    str += '</table>';
    str += '</div>';
    $("#swin").html(str);
    $("#selcontact").change(function () {
        var i = $(this).val();
        $("#OrganizationZH").val(jsonArr[i].company);
        $("#NameZH").val(jsonArr[i].fname + jsonArr[i].lname);
        $("#Country").val(jsonArr[i].countrycode);
        var vprovince = jsonArr[i].province;
        vprovince = vprovince.substr(0, 2);
        $("#Province option").each(function (i) {
            if ($(this).text().indexOf(vprovince) > -1) {
                $("#Province").val($(this).val());
            }
        });
        $("#CityZH").val(jsonArr[i].city);
        $("#StreetZH").val(jsonArr[i].street);
        $("#Postcode").val(jsonArr[i].zipcode);
        $("#phone").val(jsonArr[i].phonecode + '-' + jsonArr[i].phone);
        $("#fax").val(jsonArr[i].faxcode + '-' + jsonArr[i].fax);
        $("#email").val(jsonArr[i].email);

        $("#swin input").focus();
    });

    $("#selcontact").val(templatesid).change();
    $("#swin #OrganizationZH").focus();
    
    $("#btntemplates").click(function () {
        common_ListDomainContact(domainType, domainName, provider, pwd, 'transfer', templatesid);
    });

}
function xinnet_gotoTransferDomain(domainName, domainType, pwd, provider) {

    var isok = true;
    $("td.tip").each(function () {
        if ($(this).find("span").length > 0) {
            isok = false;
            return;
        }
    });
    if (!isok) return;

    normalPrice = getPriceByType(domainType, 'transfer'); ;
    if (isNaN(normalPrice)) { alert("抱歉，你要转入的域名类型暂不支持！"); return false; }
    billingCycle = 12;
    var discount = parseFloat(productData[0].discount);
    if (discount > 0) { normalPrice = normalPrice * discount; }
    finalPrice = normalPrice * discount;
    var myInputs = '<input type="hidden" value="' + getPriceByType(domainType, 'reg') + '" name="typePrice" />' +
     '<input type="hidden" value="' + getPriceByType(domainType, 'renew') + '" name="renewPrice" />' +
     '<input type="hidden" value="' + getPriceByType(domainType, 'transfer') + '" name="transferPrice" />' +
     '<input type="hidden" value="yes" name="transferFlag" />' +
    '<input type="hidden" value="' + domainType.replace(new RegExp(/(\.)/g), '') + '" name="transferType" />' +
    '<input type="hidden" value="' + pwd + '" name="domainPwd" />' +
    '<input type="hidden" value="1" name="regYear" />' +
    '<input type="hidden" value="' + domainName + domainType + '" name="domainName" />' +
      '<input type="hidden" value="' + $.trim($("#OrganizationZH").val()) + '" name="OrganizationZH" />' +
          '<input type="hidden" value="' + $.trim($("#NameZH").val()) + '" name="NameZH" />' +
          '<input type="hidden" value="' + $.trim($("#Country").val()) + '" name="Country" />' +
          '<input type="hidden" value="' + $.trim($("#Province").val()) + '" name="Province" />' +
          '<input type="hidden" value="' + $.trim($("#CityZH").val()) + '" name="CityZH" />' +
          '<input type="hidden" value="' + $.trim($("#StreetZH").val()) + '" name="StreetZH" />' +
           '<input type="hidden" value="' + $.trim($("#Postcode").val()) + '" name="Postcode" />' +
            '<input type="hidden" value="' + $.trim($("#PhoneRegionCode").val()) + '" name="PhoneRegionCode" />' +
          '<input type="hidden" value="' + $.trim($("#phone").val()) + '" name="phone" />' +
          '<input type="hidden" value="' + $.trim($("#FaxRegionCode").val()) + '" name="FaxRegionCode" />' +
          '<input type="hidden" value="' + $.trim($("#fax").val()) + '" name="fax" />' +
          '<input type="hidden" value="' + $.trim($("#email").val()) + '" name="email" />' +
          '<input type="hidden" value="' + $.trim($("#Trade").val()) + '" name="Trade" />' +
    // '<input type="hidden" value="' + $.trim($("#dns1").val()) + '" name="dns1" />' +
    //'<input type="hidden" value="' + $.trim($("#dns2").val()) + '" name="dns2" />' +
          '<input type="hidden" value="xinnet" name="provider" />';
    $("#swin").append('<form id="OrderConfig">' + myInputs + '</form>');
    $("#OrderConfig").append('<input type="hidden" id="couponcode" value="" />');
    suwin.next().find("#divprice").remove(); 
    $("#suwin").dialog({ title: "确认域名转入", autoOpen: false, resizable: false, width: 350, height: 300, modal: true, buttons: { "确定转入": function () {
        checkout(1);
    }, "取 消": function () {
        $(this).dialog("close");
    }
    }
    }).dialog("open");
    var qus = '<div style="padding-top:20px;"></div><table>';
    qus += '<tr style="height:35px;line-height:35px;"><td style="width:120px;text-align:right;">转入域名：';
    qus += '<td><b>' + domainName + domainType + '</b></td>';
    qus += '</tr>';
    qus += '<tr style="height:35px;line-height:35px;"><td style="width:120px;text-align:right;">转入密码：';
    qus += '<td><b>' + pwd + '</b></td>';
    qus += '</tr>';

    if (discount > 0 && discount < 1) {
        qus += '<tr style="height:35px;line-height:35px;"><td style="width:120px;text-align:right;">转入价格：';
        qus += '<td><strike>' + getPriceByType(domainType, 'transfer') + '</strike> RMB/1年</td>';
        qus += '</tr>';
        qus += '<tr style="height:35px;line-height:35px;"><td style="width:120px;text-align:right;">账户优惠价格：';
        qus += '<td>' + (getPriceByType(domainType, 'transfer') * discount).toFixed(2) + ' RMB/1年</td>';
        qus += '</tr>';
    } else {
        qus += '<tr style="height:35px;line-height:35px;"><td style="width:120px;text-align:right;">转入价格：';
        qus += '<td><b>' + normalPrice.toFixed(2) + ' RMB/1年</b></td>';
        qus += '</tr>';
    }
    qus += '</table>';
    qus += '<div style="color:red;font-size:15;padding-top:20px;"><b>*请认真核对域名和密码，确认转入后会立即扣费。</b></div>';
    $("#suwin").html(qus);
}

function xinnet_keyUpCheck(obj) {
    var checkName = $(obj).attr("name");
    var checkValue = $.trim($(obj).val());
    switch (checkName) {
        case "TransferDomainName":
            if (checkValue.length <= 0) {
                $(obj).parent().next("td").html("<span style='color:red;'>*请填写域名名称！</span>");
            } else if (checkValue.indexOf(".") > -1) {
                $(obj).parent().next("td").html("<span style='color:red;'>*域名名称不能包含域名后缀！</span>");
            } else {
                $(obj).parent().next("td").html("");
            }
            break;
        case "DomainPwd":
            if (checkValue.length > 4) {
                $(obj).parent().next("td").html("");
            }
            else {
                if (checkValue.length == 0) {
                    $(obj).parent().next("td").html("<span style='color:red;'>*密码不能为空！</span>");
                }
                else { $(obj).parent().next("td").html("<span style='color:red;'>*密码长度不符合要求!</span>"); }
            }
            break;
        case "OrganizationZH":
            if (!ischinese(checkValue) || checkValue.length > 80) {
                $(obj).parent().next("td").html("<span style='color:red;'>*请填写中文，长度为1-80个字符</span>");
            }
            else {
                $(obj).parent().next("td").html("");
            }
            break;
        case "NameZH":
            if (!ischinese(checkValue) || checkValue.length > 20) {
                $(obj).parent().next("td").html("<span style='color:red;'>*请填写中文，长度为1-20个字符</span>");
            }
            else {
                $(obj).parent().next("td").html("");
            }
            break;
        case "CityZH":
            if (!ischinese(checkValue) || checkValue.length > 20) {
                $(obj).parent().next("td").html("<span style='color:red;'>*请填写中文，长度为1-20个字符</span>");
            }
            else {
                $(obj).parent().next("td").html("");
            }
            break;
        case "StreetZH":
            if (!ischinese(checkValue) || checkValue.length > 20) {
                $(obj).parent().next("td").html("<span style='color:red;'>*请填写中文，长度为1-100个字符</span>");
            }
            else {
                $(obj).parent().next("td").html("");
            }
            break;
        case "email":
            var reg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
            if (!reg.test(checkValue)) {
                $(obj).parent().next("td").html("<span style='color:red;'>*邮箱格式错误！</span>");
            }
            else {
                $(obj).parent().next("td").html("");
            }
            break;
        case "Postcode":
            var reg = /^[0-9]{6}$/;
            if (!reg.test(checkValue)) {
                $(obj).parent().next("td").html("<span style='color:red;'>*邮政编码填写错误！</span>");
            }
            else {
                $(obj).parent().next("td").html("");
            }
            break;
        case "PhoneRegionCode":
            if (checkValue.length <= 0) {
                $(obj).parent().next("td").html("<span style='color:red;'>*联系电话必须包含国家编码,如 中国 86</span>");
            }
            else {
                $(obj).parent().next("td").html("");
            }
            break;
        case "FaxRegionCode":
            if (checkValue.length <= 0) {
                $(obj).parent().next("td").html("<span style='color:red;'>*传真号码必须包含国家编码,如 中国 86</span>");
            }
            else {
                $(obj).parent().next("td").html("");
            }
            break;
        case "phone":
            if (checkValue.length == 0) {
                $(obj).parent().next("td").html("<span style='color:red;'>*不能为空</span>");
            }
            else {
                var ik = checkValue.indexOf("-");
                if (ik == 3 || ik == 4) {
                    //$(obj).parent().next("td").html(" 如：020-12345678");
                    var phonelen = checkValue.split('-')[1].length;
                    if (phonelen < 7 || phonelen > 8) {
                        $(obj).parent().next("td").html("<span style='color:red;'>*格式错误，如：020-12345678</span>");
                    } else {
                        $(obj).parent().next("td").html("");
                    }

                } else {
                    $(obj).parent().next("td").html("<span style='color:red;'>*格式错误，如：020-12345678</span>");
                }
            }
            break;
        case "fax":
            if (checkValue.length == 0) {
                $(obj).parent().next("td").html("<span style='color:red;'>*不能为空</span>");
            }
            else {
                var ik = checkValue.indexOf("-");
                if (ik == 3 || ik == 4) {
                    // $(obj).parent().next("td").html(" 如：020-12345678")
                    var faxlen = checkValue.split('-')[1].length;
                    if (faxlen < 7 || faxlen > 8) {
                        $(obj).parent().next("td").html("<span style='color:red;'>*格式错误，如：020-12345678</span>");
                    } else {
                        $(obj).parent().next("td").html("");
                    }
                } else {
                    $(obj).parent().next("td").html("<span style='color:red;'>*格式错误，如：020-12345678</span>");
                }
            }
            break;
        case "dns1":
        case "dns2":
            if (checkValue.length <= 0) {
                $(obj).parent().next("td").html("<span style='color:red;'>*dns不能为空</span>");
            }
            else {
                $(obj).parent().next("td").html("");
            }
            break;

        //        case "province":  
        //            if (checkValue.length == 0) {  
        //                $(obj).parent().next("td").html("<span style='color:red;'>*不能为空</span>");  
        //            }  
        //            else {  
        //                $(obj).parent().next("td").html(" 省/市");  
        //            }  
        //            break;  
        //        case "city":  
        //            if (checkValue.length == 0) {  
        //                $(obj).parent().next("td").html("<span style='color:red;'>*不能为空</span>");  
        //            }  
        //            else {  
        //                $(obj).parent().next("td").html(" 市/区");  
        //            }  
        //            break;  
        default:
            if (checkValue.length == 0) {
                $(obj).parent().next("td").html("<span style='color:red;'>*不能为空</span>");
            }
            else {
                $(obj).parent().next("td").html("");
            }
            break;
    }
}
function xinnet_keyFocus(obj) {
    var checkName = $(obj).attr("name");
    var checkValue = $.trim($(obj).val());
    switch (checkName) {
        case "phone":
            $(obj).parent().next("td").html(" 如：020-12345678");
            break;
        case "fax":
            $(obj).parent().next("td").html(" 如：020-12345678");
            break;
        case "province":
            $(obj).parent().next("td").html(" 省/市");
            break;
        case "city":
            $(obj).parent().next("td").html(" 市/区");
            break;
    }
}
function ischinese(value) {
    var reg = /[\u4e00-\u9fa5]+/;
    return reg.test(value);
}
function getdomaininfo(tr_td_SS, inputSS) {
    var str = tr_td_SS + '<b>单位名称(中文)：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="OrganizationZH" id="OrganizationZH" onblur="xinnet_keyUpCheck(this)" ' + inputSS + '>';
    str += '</td>';
    str += '<td style="text-align:left;" class="tip">注：单位名称 中文必须为1-80个字符';
    str += '</td>';
    str += '</tr>';

    str += tr_td_SS + '<b>注册人姓名(中文)：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="NameZH" id="NameZH" onblur="xinnet_keyUpCheck(this)" ' + inputSS + '>';
    str += '</td>';
    str += '<td style="text-align:left;" class="tip">注：注册人姓名 中文必须为1-20个字符';
    str += '</td>';
    str += '</tr>';

    str += tr_td_SS + '<b>国家：</b>';
    str += '</td>';
    str += '<td style="text-align:left;">' + xinnet_getCountryList() + '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';

    str += tr_td_SS + '<b>省份：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">' + xinnet_getProvinceList() + '</td>';
    str += '<td style="text-align:left;width:250px;">注：如果国家不为中国，省份请选择“外国”';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>城市名称(中文)：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="CityZH" id="CityZH" onblur="xinnet_keyUpCheck(this)" ' + inputSS + '>';
    str += '</td>';
    str += '<td style="text-align:left;" class="tip">注：城市名称 中文必须为1-20个字符';
    str += '</td>';
    str += '</tr>';

    str += tr_td_SS + '<b>街道地址(中文)：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="StreetZH" id="StreetZH" onblur="xinnet_keyUpCheck(this)" ' + inputSS + '>';
    str += '</td>';
    str += '<td style="text-align:left;" class="tip">注：街道地址 中文必须为1-100个字符';
    str += '</td>';
    str += '</tr>';

    str += tr_td_SS + '<b>邮政编码：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="Postcode" id="Postcode" onblur="xinnet_keyUpCheck(this)" ' + inputSS + '>';
    str += '</td>';
    str += '<td style="text-align:left;" class="tip">';
    str += '</td>';
    str += '</tr>';

    str += tr_td_SS + '<b>联系电话：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="PhoneRegionCode" id="PhoneRegionCode" value="86" onblur="xinnet_keyUpCheck(this)" class="text" style="margin-top:4px;width:34px;">';
    str += '+<input name="phone" id="phone" style="margin-top:4px;width:145px;" onblur="xinnet_keyUpCheck(this)" class="text">';
    str += '</td>';
    str += '<td style="text-align:left;" class="tip">';
    str += ' 如：020-12345678</td>';
    str += '</tr>';

    str += tr_td_SS + '<b>传真：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="FaxRegionCode" id="FaxRegionCode" value="86" onblur="xinnet_keyUpCheck(this)" class="text" style="margin-top:4px;width:34px;">';
    str += '+<input name="fax" id="fax" style="margin-top:4px;width:145px;" onblur="xinnet_keyUpCheck(this)" class="text">';
    str += '</td>';
    str += '<td style="text-align:left;" class="tip">';
    str += ' 如：020-12345678</td>';
    str += '</tr>';

    str += tr_td_SS + '<b>电子邮箱：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="email" id="email" onblur="xinnet_keyUpCheck(this)" value=' + userData[0].umail + ' ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;" class="tip">';
    str += '</td>';
    str += '</tr>';

    str += tr_td_SS + '<b>行业类型：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">' + xinnet_getTradeList() + '</td>';
    str += '<td style="text-align:left;width:200px;">';
    str += '</td>';
    str += '</tr>';
    //    str += tr_td_SS + '<b>DNS1：</b>';
    //    str += '</td>';
    //    str += '<td style="text-align:left;width:190px;">';
    //    str += '<input name="dns1" id="dns1" value="ns1.dns.com.cn" onblur="xinnet_keyUpCheck(this)" ' + inputSS + ' >';
    //    str += '</td>';
    //    str += '<td style="text-align:left;width:235px;">';
    //    str += '</td>';
    //    str += '</tr>';
    //    str += tr_td_SS + '<b>DNS2：</b>';
    //    str += '</td>';
    //    str += '<td style="text-align:left;width:190px;">';
    //    str += '<input name="dns2" id="dns2" value="ns2.dns.com.cn" onblur="xinnet_keyUpCheck(this)" ' + inputSS + ' >';
    //    str += '</td>';
    //    str += '<td style="text-align:left;width:235px;">';
    //    str += '</td>';
    //    str += '</tr>';
    return str;
}

