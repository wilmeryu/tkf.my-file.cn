﻿/// <reference path="jquery-vsdoc.js" />
/// <reference path="jquery-ui.min.js" />
function xinnet_view() {
    var str = '<table width="100%" border="0" cellspacing="0" cellpadding="0" class="table grid"><thead><tr><th  style="text-align: right;">当前域名信息：</th><th class=\"full\">&nbsp;</th></tr></thead><tbody>';
    var title = '';
    if (serviceData[0].ssid == 0) {
        title = '域名服务还在申请中...';
    }
    else {
        title = '管理我的域名 ' + serviceData[0].sconfig.domainName + '';
    }
    str += '<tr><td class="title">域名：</td><td><span id=""></span><span title="">' + serviceData[0].sconfig.domainName + '</span></td></tr>';
    if (serviceData[0].ssid != 0) {
        str += '<tr><td class="title">注册时间：</td><td><span id="regTime" title="">' + serviceData[0].sconfig.regDate + '</span></td></tr>';
        str += "<tr>";
        str += "<td class=\"title\" style=\"text-align: right;\">";
        str += "域名管理：";
        str += "</td>";
        str += "<td>";
        str += "<form action=\"http://mgt.dns.com.cn\" target=\"_blank\" method=\"POST\" name=\"form1\" id=\"form1\">";
       // str += "<input type=hidden name=referer value=\"/\" />";
       // str += "<input type=\"hidden\" value=\"\" name=\"username\" id=\"username\">";
       // str += "<input type=\"hidden\" value=\"\" name='password' id='password'>";
        str += "<input type=\"submit\" name='btn_login' value=\"域名自助管理\" class=\"submit\" style=\"cursor:pointer;\">";
        str += "</form>";
        str += "</td></tr>";
    }
    if (serviceData[0].sconfig.transferType == "cn") { } else {
        str += '<tr><td class="title">联系人姓名：</td><td><span></span><span id="NameZH">' + serviceData[0].sconfig.NameZH + '</span></td></tr>';
        str += '<tr><td class="title">联系电话：</td><td><span></span><span id="phone">' + serviceData[0].sconfig.phone + '</span></td></tr>';
        str += '<tr><td class="title">传 真：</td><td><span></span><span id="fax">' + serviceData[0].sconfig.fax + '</span></td></tr>';
        str += '<tr><td class="title">联系邮箱：</td><td><span></span><span id="email">' + serviceData[0].sconfig.email + '</span></td></tr>';
        //        str += '<tr><td class="title">联系地址：</td><td><span id=""></span><span title="">';
        //        str += serviceData[0].sconfig.Province + ' ';
        //        str += serviceData[0].sconfig.CityZH + ' ';
        //        str += serviceData[0].sconfig.StreetZH;
        //        str += '</span></td></tr>';
        str += '<tr><td class="title">邮 编：</td><td><span></span><span id="Postcode">' + serviceData[0].sconfig.Postcode + '</span></td></tr>';
        str += '<tr><td class="title">公司名称：</td><td><span></span><span id="OrganizationZH">' + serviceData[0].sconfig.OrganizationZH + '</span></td></tr>';
    }
    $("#pageTitle").html(title);
    document.title = title;
    var statusText = serviceStatus[parseInt(serviceData[0].sstatus) + 2];
    switch (serviceData[0].sstatus) {
        case "-1": statusText = '<strong style="color:#0000FF;">' + statusText + '</strong>'; break;
        case "0": statusText = '<strong style="color:#005B00;">' + statusText + '</strong>'; break;
        case "3": statusText = '<strong style="color:#CC3300;">' + statusText + '</strong>'; break;
        case "1":
        case "2":
        case "4": statusText = '<strong style="color:#FF0000;">' + statusText + '</strong>'; break;
    }
    str += '<tr><td class="title">续费价格：</td><td><b>' + serviceData[0].sprice + ' ' + userData[0].currency + '</b> / ' + serviceData[0].spcycle / 12 + ' 年&nbsp;&nbsp;&nbsp;<b>账户余额：</b>' + parseFloat(userData[0].balance).toFixed(2) + ' ' + userData[0].currency + ' &nbsp;&nbsp;<a href="javascript:_renew();">『马上续费』</a></td></tr>' +
            '<tr><td class="title">到期时间：</td><td><span id="endTime">' + getUnixTime(serviceData[0].etime) + '</span>&nbsp;&nbsp;<span style="color:#999;">请确保你的账户余额充足</span>&nbsp;&nbsp;&nbsp;<input id="autorenew" type="checkbox" ' + (serviceData[0].autorenew == '0' ? 'checked="checked"' : '') + '/><label for="autorenew">自动续费</label></td></tr>' +
            '<tr><td class="title">服务状态：</td><td id="statusFlag">' + statusText + ' &nbsp;&nbsp;';
    if (serviceData[0].sstatus == "-1") {
        str += '<input type=\"submit\" value=\"立即刷新状态\" class=\"submit\" onclick=\"xinnet_reloadpage()\" />';
    }
    str += '</td></tr>';

    str += '</tbody></table>';
    str += '<table width="100%" border="0" cellspacing="0" cellpadding="0" class="table grid"><thead><tr><th style="text-align: right;">当前服务其它信息：</th><th class=\"full\">&nbsp;</th></tr></thead>';
    str += "";
    if (serviceData[0].sconfig.other != undefined && serviceData[0].sconfig.other.length > 0) {
        str += "<tr>";
        str += "<td class=\"title\" style=\"text-align: right;\">";
        str += "其它描述：";
        str += "</td>";
        str += "<td>";
        str += serviceData[0].sconfig.other;
        str += "</td></tr>";
    }
    if (serviceData[0].ssid != 0) {
        str += "<tr>";
        str += "<td class=\"title\" style=\"text-align: right;\">";
        str += "联系人模板管理：";
        str += "</td>";
        str += "<td>";
        str += "<input type=\"submit\" value=\"注册联系人模板信息管理\" onclick=\"common_ListDomainContact()\" class=\"submit\" style=\"cursor:pointer;\">&nbsp;&nbsp;";
        str += "</td></tr>";

        str += "<tr>";
        str += "<td class=\"title\" style=\"text-align: right;\">";
        str += "域名联系人管理：";
        str += "</td>";
        str += "<td>";
        str += "<input type=\"submit\" id=\"xinnet_editDomainContact\" value=\"修改联系人资料\" onclick=\"xinnet_editDomainContact()\" class=\"submit\" style=\"cursor:pointer;\">&nbsp;&nbsp;";
        str += "</td></tr>";

        str += "<tr>";
        str += "<td class=\"title\" style=\"text-align: right;\">";
        str += "域名密码管理：";
        str += "</td>";
        str += "<td>";
        str += "<input type=\"submit\" id=\"xinnet_getBackPwd\" value=\"获取密码\" onclick=\"xinnet_getBackPwd()\" class=\"submit\" style=\"cursor:pointer;\">&nbsp;&nbsp;";
        str += "</td></tr>";
        str += "<tr>";
        str += "<td class=\"title\" style=\"text-align: right;\">";
        str += "域名DNS管理：";
        str += "</td>";
        str += "<td>";
        str += "<input type=\"submit\" id=\"xinnet_EditDomainDNS\" value=\"域名DNS修改\" onclick=\"xinnet_EditDomainDNS()\" class=\"submit\" style=\"cursor:pointer;\">&nbsp;&nbsp;";
        str += "&nbsp;&nbsp;";
        str += "</td></tr>";
    }

    str += "<td class=\"title\" style=\"text-align: right;\">";
    str += "同步域名服务时间：";
    str += "</td>";
    str += "<td>"
    str += "<span id=\"ajaxFlag\">未同步</span>";
    str += "</td></tr>";
    str += "</table>";
    $("#ViewService").html(str);
    $("#ViewService .title").css("text-align", "right");
    var url = "?c=module&serviceid=" + serviceData[0].sid + "&show=text&todo=xinnet_getDomainInfo";
    if (serviceData[0].ssid == 0) {
        if (serviceData[0].sconfig.transferFlag == "yes") {
            $("#ajaxFlag").html("<b style='color:red;'>域名正在转入中，请刷新页面或联系销售人员</b><input type=\"submit\" value=\"立即刷新状态\" class=\"submit\" onclick=\"xinnet_reloadpage()\" />");
        } else {
            $("#ajaxFlag").html("<b style='color:red;'>域名正在注册中，请刷新页面或联系销售人员</b><input type=\"submit\" value=\"立即刷新状态\" class=\"submit\" onclick=\"xinnet_reloadpage()\" />");
        }
        return false;
    }
    $("#ajaxFlag").html("正在加载<img src=\"/images/loading.gif\" />");
    $.post(url, function (data) {
        var vArr = data.split('|');
        if (vArr[0] == "0") {
            var json = $.parseJSON(vArr[1]);
            $("#NameZH").html(json.NameZH);
            $("#phone").html(json.PhoneAreaCode + '-' + json.PhoneNumber);
            $("#fax").html(json.FaxAreaCode + '-' + json.FaxNumber);
            $("#email").html(json.Email);
            $("#Postcode").html(json.Postcode);
            $("#OrganizationZH").html(json.OrganizationZH);
            if (json.regTime != 0) {
                $("#regTime").html(json.regTime.split(' ')[0]);
                $("#endTime").html(json.endTime.split(' ')[0]);
            }
            $("#ajaxFlag").html("<b style='color:green;'>已经完成</b>");
            setTimeout(function () { $("#ajaxFlag").parent().parent().remove(); }, 2000);
        } else {
            if (data.indexOf('XML解析错误') > -1) {
                $("#ajaxFlag").html("<b style='color:red;'>服务器繁忙，请点击</b><input type=\"submit\" value=\"立即刷新状态\" class=\"submit\" onclick=\"xinnet_reloadpage()\" />");
            } else if (data.indexOf('没有域名') > -1 && serviceData[0].sconfig.transferFlag == "yes") {
                $("#ajaxFlag").html("<b style='color:red;'>域名正在转入中，域名转入需要6-11天，需要您耐心等待...</b>");
                $("#xinnet_editDomainContact").attr("disabled", true);
                $("#xinnet_getBackPwd").attr("disabled", true);
                $("#xinnet_EditDomainDNS").attr("disabled", true);
            } else
                $("#ajaxFlag").html("<b style='color:red;'>" + vArr[1] + "</b>");
        }
        var whois = 'http://whois.chinaz.com/' + serviceData[0].sconfig.domainName;
        var mmStr = "";
        mmStr += "<tr>";
        mmStr += "<td class=\"title\" style=\"text-align: right;\">";
        mmStr += "Whois查询工具：";
        mmStr += "</td>";
        mmStr += "<td>";
        mmStr += "<span style='background-color:#444;font-weight:bold; color:White;padding:3px 5px;'><a style='font-weight:bold;text-decoration:none; color:White;' target='_blank' href='" + whois + "'>" + serviceData[0].sconfig.domainName + "</a></span>";
        mmStr += "</td></tr>";
        $("#ajaxFlag").parent().parent().parent().append(mmStr);
    });


    $("#ViewService #autorenew").css("cursor", "pointer").click(function () {
        var autorenew = $(this).prop("checked") ? '0' : '1';
        setAutorenew(serviceData[0].sid, autorenew);
    });
}

function xinnet_reloadpage() {
    window.location.reload();
}

function xinnet_keyUpCheck(obj) {
    var checkName = $(obj).attr("name");
    var checkValue = $.trim($(obj).val());
    switch (checkName) {
        case "TransferDomainName":
            if (checkValue.indexOf(".cn") > -1 || checkValue.indexOf(".中国") > -1 || checkValue.indexOf(".公司") > -1 || checkValue.indexOf(".网络") > -1) {
                $("#comBox").hide();
                $(obj).parent().next("td").html("");
            }
            else {
                if (checkValue.indexOf(".") > -1) {
                    $("#comBox").show();
                    $(obj).parent().next("td").html("");
                }
                else {
                    if (checkValue == "") {
                        $(obj).parent().next("td").html("<span style='color:red;'>*请填写转入域名！</span>");
                    } else {
                        $(obj).parent().next("td").html("<span style='color:red;'>*域名格式错误！</span>");
                    }
                    $(obj).focus();
                    return false;
                }
            }
            break;
        case "DomainPwd":
            if (checkValue.length > 4) {
                $(obj).parent().next("td").html("");
            }
            else {
                if (checkValue.length == 0) {
                    $(obj).parent().next("td").html("<span style='color:red;'>*密码不能为空！</span>");
                }
                else { $(obj).parent().next("td").html("<span style='color:red;'>*密码长度不符合要求!</span>"); }
                $(obj).focus(); return false;
            }
            break;
        case "domainPwd1":
            if (checkValue.length > 4) {
                $(obj).parent().next("td").html("");
            }
            else {
                if (checkValue.length == 0) {
                    $(obj).parent().next("td").html("<span style='color:red;'>*密码不能为空！</span>");
                }
                else { $(obj).parent().next("td").html("<span style='color:red;'>*6到16位!</span>"); }
                return false;
            }
            break;

        case "domainPwd2":
            if (checkValue.length > 4) {
                $(obj).parent().next("td").html("");
                var pwd1 = $.trim($("#domainPwd1").val());
                if (checkValue != pwd1) {
                    $(obj).parent().next("td").html("<span style='color:red;'>*确认密码不对</span>");
                }
                else {
                    $(obj).parent().next("td").html("<span style='color:red;'></span>");
                }
            }
            else {
                if (checkValue.length == 0) {
                    $(obj).parent().next("td").html("<span style='color:red;'>*密码不能为空！</span>");
                }
                else {
                    var pwd1 = $.trim($("#domainPwd1").val());
                    if (checkValue != pwd1) {
                        $(obj).parent().next("td").html("<span style='color:red;'>*确认密码不对</span>");
                    }
                    else {
                        $(obj).parent().next("td").html("<span style='color:red;'></span>");
                    }
                }
                return false;
            }
            break;
        case "OrganizationZH":
            if (!ischinese(checkValue) || checkValue.length > 80) {
                $(obj).parent().next("td").html("<span style='color:red;'>*请填写中文，长度为1-80个字符</span>");
            }
            else {
                $(obj).parent().next("td").html("");
            }
            break;
        case "NameZH":
            if (!ischinese(checkValue) || checkValue.length > 20) {
                $(obj).parent().next("td").html("<span style='color:red;'>*请填写中文，长度为1-20个字符</span>");
            }
            else {
                $(obj).parent().next("td").html("");
            }
            break;
        case "CityZH":
            if (!ischinese(checkValue) || checkValue.length > 20) {
                $(obj).parent().next("td").html("<span style='color:red;'>*请填写中文，长度为1-20个字符</span>");
            }
            else {
                $(obj).parent().next("td").html("");
            }
            break;
        case "StreetZH":
            if (!ischinese(checkValue) || checkValue.length > 20) {
                $(obj).parent().next("td").html("<span style='color:red;'>*请填写中文，长度为1-100个字符</span>");
            }
            else {
                $(obj).parent().next("td").html("");
            }
            break;
        case "email":
            var reg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
            if (!reg.test(checkValue)) {
                $(obj).parent().next("td").html("<span style='color:red;'>*邮箱格式错误！</span>");
            }
            else {
                $(obj).parent().next("td").html("");
            }
            break;
        case "Postcode":
            var reg = /^[0-9]{6}$/;
            if (!reg.test(checkValue)) {
                $(obj).parent().next("td").html("<span style='color:red;'>*邮政编码填写错误！</span>");
            }
            else {
                $(obj).parent().next("td").html("");
            }
            break;
        case "PhoneRegionCode":
            if (checkValue.length <= 0) {
                $(obj).parent().next("td").html("<span style='color:red;'>*联系电话必须包含国家编码,如 中国 86</span>");
            }
            else {
                $(obj).parent().next("td").html("");
            }
            break;
        case "FaxRegionCode":
            if (checkValue.length <= 0) {
                $(obj).parent().next("td").html("<span style='color:red;'>*传真号码必须包含国家编码,如 中国 86</span>");
            }
            else {
                $(obj).parent().next("td").html("");
            }
            break;
        case "phone":
            if (checkValue.length == 0) {
                $(obj).parent().next("td").html("<span style='color:red;'>*不能为空</span>");
            }
            else {
                var ik = checkValue.indexOf("-");
                if (ik == 3 || ik == 4) {
                    //$(obj).parent().next("td").html(" 如：020-12345678");
                    var phonelen = checkValue.split('-')[1].length;
                    if (phonelen < 7 || phonelen > 8) {
                        $(obj).parent().next("td").html("<span style='color:red;'>*格式错误，如：020-12345678</span>");
                    } else {
                        $(obj).parent().next("td").html("");
                    }

                } else {
                    $(obj).parent().next("td").html("<span style='color:red;'>*格式错误，如：020-12345678</span>");
                }
            }
            break;
        case "fax":
            if (checkValue.length == 0) {
                $(obj).parent().next("td").html("<span style='color:red;'>*不能为空</span>");
            }
            else {
                var ik = checkValue.indexOf("-");
                if (ik == 3 || ik == 4) {
                    // $(obj).parent().next("td").html(" 如：020-12345678")
                    var faxlen = checkValue.split('-')[1].length;
                    if (faxlen < 7 || faxlen > 8) {
                        $(obj).parent().next("td").html("<span style='color:red;'>*格式错误，如：020-12345678</span>");
                    } else {
                        $(obj).parent().next("td").html("");
                    }
                } else {
                    $(obj).parent().next("td").html("<span style='color:red;'>*格式错误，如：020-12345678</span>");
                }
            }
            break;

        default:
            if (checkValue.length == 0) {
                $(obj).parent().next("td").html("<span style='color:red;'>*不能为空</span>");
                $(obj).focus(); return false;
            }
            else {
                $(obj).parent().next("td").html("");
            }
            break;
    }
}

function xinnet_keyFocus(obj) {
    var checkName = $(obj).attr("name");
    var checkValue = $.trim($(obj).val());
    switch (checkName) {
        case "province":
            $(obj).parent().next("td").html(" 省/市");
            break;
        case "city":
            $(obj).parent().next("td").html(" 市/区");
            break;
    }

}
function ischinese(value) {
    var reg = /[\u4e00-\u9fa5]+/;
    return reg.test(value);
}
function xinnet_editDomainContact() {
    var url = "?c=module&serviceid=" + serviceData[0].sid + "&show=text&todo=xinnet_GetDomainContactList&t=" + new Date();
    $.get(url, function (data) {
        var vdata = data.split('|');
        if (vdata[0] == "-1") {
            $("#swin").html('<div style="text-align:center;padding-top:40px;color:red;"><b>' + vdata[1] + '</b></div>');
        } else {

            var jsonObj = $.parseJSON(vdata[0]);

            var str = '';
            var tr_td_SS = '<tr style="height:29px;line-height:29px;border-bottom:1px dashed #ddd;"><td style="width:120px;text-align:right;">';
            var inputSS = 'class="text" style="margin-top:4px;"';
            str += '<div style="padding-left:100px;"><form name="frmsave" id="frmsave" action="?c=module&serviceid=' + serviceData[0].sid + '&show=text&todo=xinnet_SaveDomainContact" onsubmit="return xinnet_gotoSaveDomainContact();">';
            str += '<table style="width:600px;" id="tbContact">';
            str += xinnet_getContactInfo(tr_td_SS, inputSS, jsonObj);
            str += '</table></form>';
            str += '</div>';
            $("#swin").html(str);
            $("#Country").val(jsonObj.Country);
            $("#Province").val(jsonObj.Province);
            $("#Trade").val(jsonObj.Trade);
        }
    });
    $("#swin").dialog({ title: "域名【" + serviceData[0].sconfig.domainName + "】联系人管理", autoOpen: false, resizable: false, width: 720, height: 540, modal: false, buttons: {
        "保存修改": function () {
            xinnet_gotoSaveDomainContact();
        },
        "关 闭": function () { $(this).dialog("close"); }
    }
    }).dialog("open");
    $("#swin").html('<div class="loading" style="text-align:center;padding-top:40px;"><img src="images/loading.gif" /><br/>Loading...</div>');

}
function xinnet_gotoSaveDomainContact() {
    var isok = true;
    $("td.tip").each(function () {
        if ($.trim($(this).html()).length > 0) {
            isok = false;
            return;
        }
    });
    if (!isok) return false;

    processing("正在执行操作，请稍等...");
    var cmd = '';
    var delay = 0;
    $.post($("#frmsave").attr("action"), $("#frmsave").serialize(), function (rdata) {
        if (rdata == '0') {
            rdata = '操作成功！';
            delay = 3000;
            $("#swin").dialog('close');
            cmd = 'close';
        }
        showResults(rdata, delay, cmd);
    });
    return false;


}
function xinnet_getContactInfo(tr_td_SS, inputSS, obj) {
    var str = tr_td_SS + '<b>联系人姓名(中文)：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="NameZH" id="NameZH" onblur="xinnet_keyUpCheck(this)" value=' + obj.NameZH + ' ' + inputSS + '>';
    str += '</td>';
    str += '<td style="text-align:left;" class="tip">';
    str += '</td>';
    str += '</tr>';

    str += tr_td_SS + '<b>单位名称(中文)：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="OrganizationZH" id="OrganizationZH" onblur="xinnet_keyUpCheck(this)" value=' + obj.OrganizationZH + ' ' + inputSS + '>';
    str += '</td>';
    str += '<td style="text-align:left;" class="tip">';
    str += '</td>';
    str += '</tr>';

    str += tr_td_SS + '<b>国家：</b>';
    str += '</td>';
    str += '<td style="text-align:left;">' + xinnet_getCountryList() + '</td>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';

    str += tr_td_SS + '<b>省份：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">' + xinnet_getProvinceList() + '</td>';
    str += '<td style="text-align:left;width:250px;">注：如果国家不为中国，省份请选择“外国”';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>城市名称(中文)：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="CityZH" id="CityZH" onblur="xinnet_keyUpCheck(this)" value=' + obj.CityZH + ' ' + inputSS + '>';
    str += '</td>';
    str += '<td style="text-align:left;" class="tip">';
    str += '</td>';
    str += '</tr>';

    str += tr_td_SS + '<b>街道地址(中文)：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="StreetZH" id="StreetZH" onblur="xinnet_keyUpCheck(this)" value=' + obj.StreetZH + ' ' + inputSS + '>';
    str += '</td>';
    str += '<td style="text-align:left;" class="tip">';
    str += '</td>';
    str += '</tr>';

    str += tr_td_SS + '<b>邮政编码：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="Postcode" id="Postcode" onblur="xinnet_keyUpCheck(this)" value=' + obj.Postcode + ' ' + inputSS + '>';
    str += '</td>';
    str += '<td style="text-align:left;" class="tip">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>联系电话：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="PhoneRegionCode" id="PhoneRegionCode" value=' + obj.PhoneRegionCode + ' onblur="xinnet_keyUpCheck(this)" class="text" style="margin-top:4px;width:34px;">';
    str += '+<input name="phone" id="phone" style="margin-top:4px;width:145px;" onblur="xinnet_keyUpCheck(this)" value=' + (obj.PhoneAreaCode + "-" + obj.PhoneNumber) + ' class="text">';
    str += '</td>';
    str += '<td style="text-align:left;" class="tip">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>传真：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="FaxRegionCode" id="FaxRegionCode" value="86" onblur="xinnet_keyUpCheck(this)" value=' + obj.FaxRegionCode + ' class="text" style="margin-top:4px;width:34px;">';
    str += '+<input name="fax" id="fax" style="margin-top:4px;width:145px;" onblur="xinnet_keyUpCheck(this)" value=' + (obj.FaxAreaCode + "-" + obj.FaxNumber) + ' class="text">';
    str += '</td>';
    str += '<td style="text-align:left;" class="tip">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>电子邮箱：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="email" id="email" onblur="xinnet_keyUpCheck(this)" value=' + obj.Email + ' ' + inputSS + ' >';
    str += '</td>';
    str += '<td style="text-align:left;" class="tip">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>行业类型：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">' + xinnet_getTradeList() + '</td>';
    str += '<td style="text-align:left;width:200px;">';
    str += '</td>';
    str += '</tr>';
    return str;
}
function xinnet_EditDomainDNS() {
    var url = "?c=module&serviceid=" + serviceData[0].sid + "&show=text&todo=xinnet_EditDomainDNS";
    var txtStr = '<div style="height:10px;"></div>';
    txtStr += '<table>';
    txtStr += '<tr style="height:30px;line-height: 30px;">';
    txtStr += '<td style="width:90px;text-align:right;"><b>域 名：</b></td>';
    txtStr += '<td style="text-align:left;">' + serviceData[0].sconfig.domainName + '</td><td style="width:70px;">&nbsp;</td></tr>';
    txtStr += '<tr style="height:30px;line-height: 30px;"><td style="width:90px;text-align:right;">';
    txtStr += '<b>DNS1：</b>';
    txtStr += '</td><td style="text-align:left;">';
    txtStr += '<input id="dns1" name="dns1" class="text" style="width:150px;margin-top:5px;" />';
    txtStr += '</td><td style="width:120px;">';
    txtStr += '</td></tr>';
    txtStr += '<tr style="height:30px;line-height: 30px;"><td style="width:90px;text-align:right;">';
    txtStr += '<b>DNS2：</b>';
    txtStr += '</td><td style="text-align:left;">';
    txtStr += '<input id="dns2" name="dns2" class="text" style="width:150px;margin-top:5px;" />';
    txtStr += '</td><td style="width:120px;">';
    txtStr += '</td></tr>';
    txtStr += '</table>';
    txtStr += '<div class="loading" style="height:35px;line-height: 35px;text-align:center;padding-top:20px;"></div>';
    $("#suwin").html(ajaxLoading("正在加载信息，请稍等..."));
    var dns = '';
    var getInfourl = "?c=module&serviceid=" + serviceData[0].sid + "&show=text&todo=xinnet_GetDnsInfo";
    var vArr = [];
    $.get(getInfourl, function (data) {
        vArr = data.split('|');
        if (vArr[0] == '0') {
            $("#suwin").html(txtStr);
            $("#dns1").val(vArr[1]);
            $("#dns2").val(vArr[2]);
        }
        else {
            $("#suwin").html(data);
        }
    });
    $("#suwin").dialog({ title: "修改域名【" + serviceData[0].sconfig.domainName + "】的DNS信息", autoOpen: false, resizable: false, width: 430, height: 330, modal: false, buttons: {
        "立即修改": function () {
            if ($.trim($("#dns1").val()) != "") {
                $("#dns1").parent().next("td").html("");
            } else {
                if ($.trim($("#dns1").val()) == "") {
                    $("#dns1").parent().next("td").html("<b style='color:red;'> *DNS1不能为空！</b>");
                } else {
                }
                $("#dns1").focus();
                return false;
            }
            if ($.trim($("#dns2").val()) != "") {
                $("#dns2").parent().next("td").html("");
            } else {
                if ($.trim($("#dns2").val()) == "") {
                    $("#dns2").parent().next("td").html("<b style='color:red;'> *不能为空！</b>");
                } else {
                }
                return false;
            }
            url += "&dns1=" + $.trim($("#dns1").val()) + "&dns2=" + $.trim($("#dns2").val());
            $("#suwin .loading").html("<img style='' src='images/loading.gif' /><br/>修改中...");

            if ($.trim($("#dns1").val()) == vArr[1] && $.trim($("#dns2").val()) == vArr[2]) {
                $("#suwin").html("<div style='height:140px;line-height: 140px;text-align:center;width:330px;color:green;'>恭喜，DNS信息修改成功！</p>");
                setTimeout(function () { $("#suwin").dialog("close"); }, 3000);
                return false ;
            }

            $.get(url, function (data) {
                if (data == "0") {
                    $("#suwin").dialog("close");
                    $("#suwin").dialog({ title: "修改域名【" + serviceData[0].sconfig.domainName + "】的DNS信息", autoOpen: false, resizable: false, width: 400, height: 280, modal: false, buttons: { "关  闭": function () { $(this).dialog("close"); } } }).dialog("open");
                    $("#suwin").html("<div style='height:140px;line-height: 140px;text-align:center;width:330px;color:green;'>恭喜，DNS信息修改成功！</p>");
                    setTimeout(function () { $("#suwin").dialog("close"); }, 3000);
                } else {
                    $("#suwin .loading").html("");
                    $("#suwin").html("<div style='height:140px;line-height: 140px;text-align:center;width:330px;color:red;'>" + data + "</p>");
                }
            });

        }, "取 消": function () {
            $(this).dialog("close");
        }
    }
    }).dialog("open");
}
function xinnet_getBackPwd() {

    var txtStr = '<div style="height:5px;"></div>';
    txtStr += '<table id="tbsendcode">';
    txtStr += '<tr style="height:30px;line-height: 30px;"><td style="width:100px;text-align:right;">';
    txtStr += '<b>域 名：</b>';
    txtStr += '</td><td style="text-align:left;">';
    txtStr += serviceData[0].sconfig.domainName;
    txtStr += '</td></tr>';
    var height = 190, width = 300;
    if (userData[0].isAdmin != "True" && (emailchk_Xinnet != "0" || smschk_Xinnet != "0")) {
        height = 280, width = 420;
        txtStr += '<tr style="height:30px;line-height: 30px;"><td style="width:100px;text-align:right;">';
        txtStr += '<b>发送验证码：</b>';
        txtStr += '</td><td style="text-align:left;">';

        if (emailchk_Xinnet != "0") {
            txtStr += '<input type="button" class="submit" value="发到邮箱" id="mailBtn" onclick="sendCodeToEmail(3)" /> &nbsp;&nbsp;';
        }
        if (smschk_Xinnet != "0") {
            txtStr += '<input type="button" class="submit" value="发到手机" id="phoneBtn" onclick="sendCodeToPhone(3)" />';
        }
        txtStr += '</td></tr>';
        txtStr += '<tr style="height:30px;line-height: 30px;"><td style="width:100px;text-align:right;">';
        txtStr += '<b><input type="hidden" id="codeFlag" value="-1">输入验证码：</b>';
        txtStr += '</td><td style="text-align:left;">';
        txtStr += '<input name="vcode" id="vcode" class="text" style="width:110px;margin-top:3px;" />';
        txtStr += '</td></tr>';

        $("#tbsendcode").css("paddingLeft", "40px");
    }
    txtStr += '</table>';
    txtStr += '<div class="loading" style="text-align:center;padding-top:2px;"></div>';
    $("#suwin").html(txtStr);

    $("#suwin").dialog({ title: "获取域名【" + serviceData[0].sconfig.domainName + "】的密码", autoOpen: false, resizable: false, width: width, height: height, modal: true, buttons: {
        "立即获取": function () {
            processing("正在获取中...");
            if (userData[0].isAdmin != "True" && (emailchk_Xinnet != "0" || smschk_Xinnet != "0") && $.trim($("#vcode").val()) == "") {
                showResults('验证码不能为空！', 3000, "close");
                return false;
            }
            var url = "?c=module&serviceid=" + serviceData[0].sid + "&show=text&todo=xinnet_GetBackPwd&vcode=" + $("#vcode").val();
            $.get(url, function (data) {
                var vArr = data.split('|');
                if (vArr[0] == "0") {
                    $("#suwin").dialog("close");
                    $("#processing").dialog("close");
                    showPwdWin(vArr[1], serviceData[0].sconfig.domainName);
                } else {
                    showResults(vArr[1], 3000, "close");
                }
            });

        }, "取 消": function () {
            $(this).dialog("close");
        }
    }
    }).dialog("open");
   
   
   
//    var txtStr = '<div style="height:5px;"></div>';
//    txtStr += '<table>';
//    txtStr += '<tr style="height:30px;line-height: 30px;"><td style="width:100px;text-align:right;">';
//    txtStr += '<b>域 名：</b>';
//    txtStr += '</td><td style="text-align:left;">';
//    txtStr += serviceData[0].sconfig.domainName;
//    txtStr += '</td></tr>';
//    if (userData[0].isAdmin != "True" && (emailchk_Xinnet != "0" || smschk_Xinnet != "0")) {
//        txtStr += '<tr style="height:30px;line-height: 30px;"><td style="width:100px;text-align:right;">';
//        txtStr += '<b>发送验证码：</b>';
//        txtStr += '</td><td style="text-align:left;">';
//        txtStr += '<input type="button" class="submit" value="发到邮箱" id="mailBtn" onclick="sendCodeToEmail(3)" /> &nbsp;&nbsp;';
//        txtStr += '<input type="button" class="submit" value="发到手机" id="phoneBtn" onclick="sendCodeToPhone(3)" />';
//        txtStr += '</td></tr>';
//        txtStr += '<tr style="height:30px;line-height: 30px;"><td style="width:100px;text-align:right;">';
//        txtStr += '<b><input type="hidden" id="codeFlag" value="-1">输入验证码：</b>';
//        txtStr += '</td><td style="text-align:left;">';
//        txtStr += '<input name="vcode" id="vcode" class="text" style="width:110px;margin-top:3px;" />';
//        txtStr += '</td></tr>';
//    }
//    txtStr += '<tr style="height:30px;line-height: 30px;"><td style="width:100px;text-align:right;">';
//    txtStr += '<b>密码发送到：</b>';
//    txtStr += '</td><td style="text-align:left;">';
//    txtStr += '<input type="radio" checked="checked" name="sendToName" value="email" style="cursor:pointer;" />邮箱 &nbsp;&nbsp;<input type="radio" name="sendToName" value="phone" style="cursor:pointer;" />手机';
//    txtStr += '</td></tr>';
//    txtStr += '</table>';
//    var sendObj = document.getElementsByName("sendToName");
//    var sendTo = "";
//    txtStr += '<div class="loading" style="text-align:center;padding-top:2px;"></div>';
//    $("#suwin").html(txtStr);
//    $("#suwin").dialog({ title: "获取域名【" + serviceData[0].sconfig.domainName + "】的密码", autoOpen: false, resizable: false, width: 400, height: 310, modal: false, buttons: {
//        "立即获取": function () {
//            if (userData[0].isAdmin != "True" && (emailchk_Xinnet != "0" || smschk_Xinnet != "0") && $.trim($("#vcode").val()) == "") { alert("请填写刚刚收到的验证码！"); return false; }
//            for (var i = 0; i < sendObj.length; i++) {
//                if (sendObj[i].checked == "checked" || sendObj[i].checked == true) {
//                    sendTo = sendObj[i].value;
//                    break;
//                }
//            }
//            $("#suwin .loading").html("<img style='' src='images/loading.gif' /><br/>正在获取中...");
//            var url = "?c=module&serviceid=" + serviceData[0].sid + "&show=text&todo=xinnet_GetBackPwd&vcode=" + $("#vcode").val();
//            $.get(url, function (data) {
//                var vArr = data.split('|');
//                if (vArr[0] == "0") {
//                    var sendUrl = "?c=module&productid=" + productData[0].pid + "&show=text";
//                    sendUrl += "&domainName=" + serviceData[0].sconfig.domainName + "&DomainPwd=" + vArr[1];
//                    if (sendTo == "email") {
//                        $("#suwin .loading").html("<img style='' src='images/loading.gif' /><br/>正在发送密码到你的邮箱中...");
//                        sendUrl += "&action=send_email&todo=xinnet_SendPwdToEmail";
//                    }
//                    else {
//                        $("#suwin .loading").html("<img style='' src='images/loading.gif' /><br/>正在发送密码到你的手机...");
//                        sendUrl += "&action=send_sms&todo=xinnet_SendPwdToPhone";
//                    }
//                    $.get(sendUrl, function (sendData) {
//                        var newData = "";
//                        if (parseInt(sendData) == 0) {
//                            if (sendTo == "email") {
//                                newData = "<div style='height:80px;line-height: 80px;text-align:center;width:400px;color:green;'><b>密码成功发送到您的邮箱[" + userData[0].umail + "]，请您查收！</b></div>";
//                            }
//                            else {
//                                newData = "<div style='height:80px;line-height: 80px;text-align:center;width:400px;color:green;'><b>密码成功发送到您的手机[" + userData[0].tel + "]，请您查收！</b></div>";
//                            }
//                        }
//                        else {
//                            newData = "<div style='height:140px;line-height: 140px;text-align:center;width:330px;'>" + sendData + "</div>";
//                        }
//                        $("#suwin").dialog("close");
//                        $("#suwin").dialog({ title: "获取域名【" + serviceData[0].sconfig.domainName + "】的密码", autoOpen: false, resizable: false, width: 420, height: 300, modal: false, buttons: { "关  闭": function () { $(this).dialog("close"); } } }).dialog("open");
//                        $("#suwin").html(newData);
//                        setTimeout(function () { $("#suwin").dialog("close"); }, 3000);
//                    });
//                } else {
//                    $("#suwin .loading").html("");
//                    $("#suwin .loading").html("<div style='text-align:center;width:330px;color:red;'>" + vArr[1] + "</p>");
//                }
//            });

//        }, "取 消": function () {
//            $(this).dialog("close");
//        }
//    }
//    }).dialog("open");
}
//function showTipWin(pwd, domain) {
//    $("#suwin").dialog({ title: "操作提示", autoOpen: false, resizable: false, width: 300, height: 200, modal: true, buttons: { "关 闭": function () { $(this).dialog("close"); } } }).dialog("open");
//    var txtStr = '<p style="padding-left:70px;padding-top:20px;"><b>域 名：</b>' + domain + '</p><p style="padding-left:70px;"><b>密 码：</b>' + pwd + '</p>';
//    $("#suwin").html(txtStr);
//}
//function sendCodeToEmail(tum) {
//    // $("#suwin .loading").html("<img style='' src='images/loading.gif' /><br/>正在发送验证码到邮箱中...");
//    processing("正在发送验证码到邮箱中...");
//    var url = "?c=module&productid=" + productData[0].pid + "&show=text&action=send_email&todo=send_emailCode&domainName=" + serviceData[0].sconfig.domainName;
//    url += "&token=" + (new Date()).valueOf() + "&leftTime=" + tum;
//    var leftTime = parseInt(tum) * 60;
//    $("#mailBtn").attr("disabled", "disabled").attr("value", "还剩" + leftTime + "秒").css({ "color": "gray", "cursor": "default" });
//    $("#phoneBtn").attr("disabled", "disabled").attr("value", "还剩" + leftTime + "秒").css({ "color": "gray", "cursor": "default" });
//    var myTimer = setInterval(function () {
//        if (leftTime > 1) {
//            leftTime -= 1;
//            $("#mailBtn").attr("disabled", "disabled").attr("value", "还剩" + leftTime + "秒");
//            $("#phoneBtn").attr("disabled", "disabled").attr("value", "还剩" + leftTime + "秒");
//        }
//        else {
//            clearInterval(myTimer);
//            $("#mailBtn").removeAttr("disabled").attr("value", "发送到邮箱").css({ "color": "white", "cursor": "pointer" });
//            $("#phoneBtn").removeAttr("disabled").attr("value", "发送到手机").css({ "color": "white", "cursor": "pointer" });
//        }
//    }, 1000);
//    $.get(url, function (data) {
//        if (parseInt(data) == 0) {
//            showResults("验证码已发送到您的邮箱[" + userData[0].umail + "]，请查收！", 3000, "close");
//            // $("#codeFlag").val("0");
//            $("#vcode").focus();
//        } else {
//            if (data.indexOf("Email is not verified") > -1) {
//                data = "抱歉，邮箱不合法，请检查你的用户资料！";
//               // $("#suwin .loading").html("<b style='color:red;'>抱歉，邮箱不合法，请检查你的用户资料！</b>");
//            }
//            else {
//                // $("#suwin .loading").html("<b style='color:red;'>" + data.substr(3) + "</b>");
//                data = data.substr(3);
//            }
//            showResults(data, 5000, "close");
//        }

//    });
//}
//function sendCodeToPhone(tum) {
//    // $("#suwin .loading").html("<img style='' src='images/loading.gif' /><br/>正在发送验证码到手机中...");
//    processing("正在发送验证码到手机中...");
//    var url = "?c=module&productid=" + productData[0].pid + "&show=text&action=send_sms&todo=send_phoneCode&domainName=" + serviceData[0].sconfig.domainName;
//    url += "&token=" + (new Date()).valueOf() + "&leftTime=" + tum;
//    var leftTime = parseInt(tum) * 60;
//    $("#mailBtn").attr("disabled", "disabled").attr("value", "还剩" + leftTime + "秒").css({ "color": "gray", "cursor": "default" });
//    $("#phoneBtn").attr("disabled", "disabled").attr("value", "还剩" + leftTime + "秒").css({ "color": "gray", "cursor": "default" });
//    var myTimer = setInterval(function () {
//        if (leftTime > 1) {
//            leftTime -= 1;
//            $("#mailBtn").attr("disabled", "disabled").attr("value", "还剩" + leftTime + "秒");
//            $("#phoneBtn").attr("disabled", "disabled").attr("value", "还剩" + leftTime + "秒");
//        }
//        else {
//            clearInterval(myTimer);
//            $("#mailBtn").removeAttr("disabled").attr("value", "发送到邮箱").css({ "color": "white", "cursor": "pointer" });
//            $("#phoneBtn").removeAttr("disabled").attr("value", "发送到手机").css({ "color": "white", "cursor": "pointer" });
//        }
//    }, 1000);
//    $.get(url, function (data) {
//        if (parseInt(data) == 0) {
//           // $("#suwin .loading").html("<b style='color:green;'>验证码已发送到您的手机[" + userData[0].tel + "]，请查收！</b>");
//           // $("#codeFlag").val("0");
//            //$("#vcode").focus();

//            showResults("验证码已发送到您的手机[" + userData[0].tel + "]，请查收！", 3000, "close");
//            // $("#codeFlag").val("0");
//            $("#vcode").focus();
//        } else {
//            showResults(data.substr(3), 5000, "close");
//            //$("#suwin .loading").html("<b style='color:red;'>" + data.substr(3) + "</b>");
//        }


//    });
//}

function xinnet_getBackInfo() {
    var local = window.location.href;
    local = local.replace("http://");
    var url = "?c=module&productid=" + productData[0].pid + "&show=text&todo=xinnet_GetBackInfo";
    url += "&domainName=" + serviceData[0].sconfig.domainName;
    var txtStr = '<div style="height:30px;"></div>';
    txtStr += '<table>';
    txtStr += '<tr style="height:30px;line-height: 30px;"><td style="width:120px;text-align:right;">';
    txtStr += '域 名：';
    txtStr += '</td><td style="text-align:left;">';
    txtStr += serviceData[0].sconfig.domainName;
    txtStr += '</td></tr>';
    txtStr += '</table>';
    txtStr += '<div class="loading" style="height:35px;line-height: 35px;text-align:center;padding-top:20px;"></div>';
    $("#suwin").html(txtStr);
    $("#suwin").dialog({ title: "获取域名【" + serviceData[0].sconfig.domainName + "]的信息", autoOpen: false, resizable: false, width: 380, height: 268, modal: false, buttons: {
        "立即获取": function () {
            $("#suwin .loading").html("<img style='' src='images/loading.gif' /><br/>查询中...");
            $.get(url, function (data) {
                if (data.indexOf("320") > -1) {
                    var mydata = data.split(',');
                    var str = '<table>';
                    str += '<tr style="height:26px;line-height: 26px;"><td style="text-align:right;width:130px;"><b>域名：</b>';
                    str += '</td>';
                    str += '<td style="text-align:left;width:130px;">' + serviceData[0].sconfig.domainName;
                    str += '</td></tr>';
                    for (var i = 1; i < 6; i++) {
                        str += '<tr style="height:26px;line-height: 26px;"><td style="text-align:right;width:130px;"><b>' + mydata[i].split(':')[0] + '：</b>';
                        str += '</td>';
                        str += '<td style="text-align:left;width:130px;">' + mydata[i].split(':')[1];
                        str += '</td></tr>';
                    }
                    str += '</table>';
                    $("#suwin").html("<div style='height:140px;line-height: 140px;text-align:center;width:330px;'>" + str + "</p>");
                } else {
                    $("#suwin .loading").html("");
                    $("#suwin").html("<div style='height:140px;line-height: 140px;text-align:center;width:330px;color:red;'>" + data.substr(0) + "</p>");
                }
            });

        }, "取 消": function () {
            $(this).dialog("close");
        }
    }
    }).dialog("open");
}
