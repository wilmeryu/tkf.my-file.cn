﻿
function xinwang_regDomain(domainType, domainName, vprovider, rdata, templatesid) {
    //var domainName = $.trim($("#domainName").val());
    var domain = domainName + domainType;
    $("#swin").html(ajaxLoading("正在加载信息，请稍等......"))
    $("#swin").dialog({ title: "【" + domain + "】域名注册信息", autoOpen: false, resizable: false, width: 830, height: 590, modal: true, buttons: { "立即注册": function () {
        xinwang_gotoRegDomain();
    }, "关 闭": function () {
        $(this).dialog("close");
    }
    }
    }).dialog("open");


    $.post("?c=module&productid=" + productData[0].pid + "&show=text&todo=xinwang_GetDefaultDns&t=" + new Date(), function (data) {
        var jsonArr = $.parseJSON(rdata);
        var str = '';
        var tr_td_SS = '<tr style="height:29px;line-height:29px;border-bottom:1px dashed #ddd;"><td style="width:180px;text-align:right;">';
        var inputSS = 'class="text" style="margin-top:4px;"';
        str += '<h3 style="padding-left:80px;height:40px;font-size:16px;">填写域名注册信息 <b style="color:red;font-size:12px;font-weight:normal;word-spacing: 5px;"> ( 注意：请认真填写下面的信息！)</b></h3>';
        str += '<div style="padding-left:100px;">';
        str += '<table style="width:600px;">';
        str += tr_td_SS + '<b>购买的域名：</b>';
        str += '</td>';
        str += '<td style="text-align:left;"><input type="hidden" id="regDomainName" value="' + domain + '" />';
        str += domain;
        str += '</td>';
        str += '<td style="text-align:left;">';
        str += '</td>';
        str += '</tr>';
        str += tr_td_SS + '<b>注册年限：</b>';
        str += '</td>';
        str += '<td style="text-align:left;">';
        //        str += '<select name="regYear" id="regYear" onchange="setRegYear()" style="cursor:pointer;margin-top:4px;">' +
        //           '<option value="1" style="cursor:pointer;">1</option><option value="2" style="cursor:pointer;">2</option></select> 年 ';
        //        str += '</td>';
        //        str += '<td style="text-align:left;">';
        //        str += '</td>';
        //        str += '</tr>';

        var priceArr = productData[0].pprice.cprice.split(',');
        str += '<select name="regYear" id="regYear" onchange="setRegYear()" style="cursor:pointer;margin-top:4px;">';
        if (priceArr[3] != 0) {
            str += '<option value="1" style="cursor:pointer;">1</option>';
        }
        if (priceArr[4] != 0) {
            str += '<option value="2" style="cursor:pointer;">2</option>';
        }
        str += '</select> 年</td>';
        str += '<td style="text-align:left;">';
        str += '</td>';
        str += '</tr>';

        str += tr_td_SS + '<b>选择联系人信息：</b>';
        str += '</td>';
        str += '<td style="text-align:left;width:250px;">';
        str += '<select id=\"selcontact\" name=\"selcontact\" style=\"height:auto;cursor:pointer;\">';

        for (var i = 0; i < jsonArr.length; i++) {
            str += '<option value="' + i + '">' + jsonArr[i].lname + jsonArr[i].fname + "-" + (i + 1) + '</option>';
        }

        str += '</select>&nbsp;&nbsp;&nbsp;<input type="button" value="联系人模板管理" class="submit" id="btntemplates" style="cursor:pointer;"></td>';
        str += '<td style="text-align:left;">';
        str += '</td>';
        str += '</tr>';
        str += tr_td_SS + '<b>注册人中文名称 ：</b>';
        str += '</td>';
        str += '<td style="text-align:left;width:179px;">';
        str += '<input name="chinaname" id="chinaname" onfocus="xinwang_keyFocus(this)" onblur="xinwang_keyUpCheck(this)" ' + inputSS + '>';
        str += '</td>';
        str += '<td style="text-align:left;">';
        str += '</td>';
        str += '</tr>';
        str += tr_td_SS + '<b>国家：</b>';
        str += '</td>';
        str += '<td style="text-align:left;">';
        str += '<select name="country" id="country" style="cursor:pointer;margin-top:4px;">' +
        '<option value="AU">澳大利亚</option>' +
        '<option value="CA">加拿大</option>' +
        '<option value="CN" selected="selected">中国</option>' +
        '<option value="CX">圣诞岛</option>' +
        '<option value="DK">丹麦</option>' +
        '<option value="DJ">吉布提</option>' +
        '<option value="DM">多米尼加联邦</option>' +
        '<option value="DO">多米尼加共和国</option>' +
        '<option value="TP">东帝汶</option>' +
        '<option value="FR">法国</option>' +
        '<option value="IN">印度</option>' +
        '<option value="JP">日本</option>' +
        '<option value="MA">摩洛哥</option>' +
        '<option value="NZ">新西兰</option>' +
        '<option value="OM">阿曼</option>' +
        '<option value="RU">俄罗斯联邦</option>' +
        '<option value="SB">所罗门群岛</option>' +
        '<option value="SO">索马里</option>' +
        '<option value="ZA">南非</option>' +
        '<option value="ES">西班牙</option>' +
        '<option value="LK">斯里兰卡</option>' +
        '<option value="SD">苏丹</option>' +
        '<option value="TW">台湾</option>' +
        '<option value="US">美国</option>';
        str += '</select>';
        str += '<td style="text-align:left;">';
        str += '</td>';
        str += '</tr>';
        str += tr_td_SS + '<b>省份：</b>';
        str += '</td>';
        str += '<td style="text-align:left;width:179px;">';
        str += '<input name="province" id="province" onfocus="xinwang_keyFocus(this)" onblur="xinwang_keyUpCheck(this)" ' + inputSS + ' >';
        str += '</td>';
        str += '<td style="text-align:left;">';
        str += ' 省/市</td>';
        str += '</tr>';
        str += tr_td_SS + '<b>城市：</b>';
        str += '</td>';
        str += '<td style="text-align:left;width:179px;">';
        str += '<input name="city" id="city" onfocus="xinwang_keyFocus(this)" onblur="xinwang_keyUpCheck(this)" ' + inputSS + ' >';
        str += '</td>';
        str += '<td style="text-align:left;">';
        str += ' 市/区</td>';
        str += '</tr>';
        str += tr_td_SS + '<b>街道地址：</b>';
        str += '</td>';
        str += '<td style="text-align:left;width:179px;">';
        str += '<input name="street" id="street" onblur="xinwang_keyUpCheck(this)" ' + inputSS + ' >';
        str += '</td>';
        str += '<td style="text-align:left;">';
        str += '如：广东软件园A栋101号</td>';
        str += '</tr>';
        str += tr_td_SS + '<b>邮政编码：</b>';
        str += '</td>';
        str += '<td style="text-align:left;width:179px;">';
        str += '<input name="zipcode" id="zipcode" onblur="xinwang_keyUpCheck(this)" ' + inputSS + ' >';
        str += '</td>';
        str += '<td style="text-align:left;">';
        str += '</td>';
        str += '</tr>';
        str += tr_td_SS + '<b>联系电话：</b>';
        str += '</td>';
        str += '<td style="text-align:left;width:179px;">';
        str += '<input name="phone" id="phone" onfocus="xinwang_keyFocus(this)" onblur="xinwang_keyUpCheck(this)" ' + inputSS + '>';
        str += '</td>';
        str += '<td style="text-align:left;width:240px">';
        str += ' 手机/电话</td>';
        str += '</tr>';
        str += tr_td_SS + '<b>电话区号：</b>';
        str += '</td>';
        str += '<td style="text-align:left;width:179px;">';
        str += '<input name="phonecode" id="phonecode" ' + inputSS + '>';
        str += '</td>';
        str += '<td style="text-align:left;">';
        str += ' 如果为手机，此项为空</td>';
        str += '</tr>';
        str += tr_td_SS + '<b>传真号码：</b>';
        str += '</td>';
        str += '<td style="text-align:left;width:179px;">';
        str += '<input name="fax" id="fax" onfocus="xinwang_keyFocus(this)" onblur="xinwang_keyUpCheck(this)" ' + inputSS + '>';
        str += '</td>';
        str += '<td style="text-align:left;width:240px">';
        str += ' 手机/电话</td>';
        str += '</tr>';
        str += tr_td_SS + '<b>传真区号：</b>';
        str += '</td>';
        str += '<td style="text-align:left;width:179px;">';
        str += '<input name="faxcode" id="faxcode" ' + inputSS + '>';
        str += '</td>';
        str += '<td style="text-align:left;">';
        str += ' 如果为手机，此项为空</td>';
        str += '</tr>';
        str += tr_td_SS + '<b>电子邮箱：</b>';
        str += '</td>';
        str += '<td style="text-align:left;width:179px;">';
        str += '<input name="email" id="email" onblur="xinwang_keyUpCheck(this)" value=' + userData[0].umail + ' ' + inputSS + ' >';
        str += '</td>';
        str += '<td style="text-align:left;">';
        str += '</td>';
        str += '</tr>';

        str += tr_td_SS + '<b>注册人中文单位名称 ：</b>';
        str += '</td>';
        str += '<td style="text-align:left;width:179px;">';
        str += '<input name="org" id="org" onblur="xinwang_keyUpCheck(this)" ' + inputSS + ' >';
        str += '</td>';
        str += '<td style="text-align:left;">';
        str += '</td>';
        str += '</tr>';
        str += tr_td_SS + '<b>注册人单位所在地：</b>';
        str += '</td>';
        str += '<td style="text-align:left;width:179px;">';
        str += '<input name="location" id="location" onblur="xinwang_keyUpCheck(this)" ' + inputSS + ' >';
        str += '</td>';
        str += '<td style="text-align:left;width:150px;">如：广东广州';
        str += '</td>';
        str += '</tr>';

        var dnsArr = data.split('|');
        str += tr_td_SS + '<b>DNS1：</b>';
        str += '</td>';
        str += '<td style="text-align:left;width:190px;">';
        str += '<input name="dns1" id="dns1" value="' + dnsArr[0] + '" onblur="xinwang_keyUpCheck(this)" ' + inputSS + ' >';
        str += '</td>';
        str += '<td style="text-align:left;width:235px;">';
        str += '</td>';
        str += '</tr>';
        str += tr_td_SS + '<b>DNS2：</b>';
        str += '</td>';
        str += '<td style="text-align:left;width:190px;">';
        str += '<input name="dns2" id="dns2" value="' + dnsArr[1] + '" onblur="xinwang_keyUpCheck(this)" ' + inputSS + ' >';
        str += '</td>';
        str += '<td style="text-align:left;width:235px;">';
        str += '</td>';
        str += '</tr>';
        if (domainType == '.travel') {
            str += tr_td_SS + '<b>域名UIN编码：</b>';
            str += '</td>';
            str += '<td style="text-align:left;width:179px;">';
            str += '<input name="uincode" id="uincode" onblur="xinwang_keyUpCheck(this)" ' + inputSS + ' >';
            str += '</td>';
            str += '<td style="text-align:left;width:150px;">';
            str += '</td>';
            str += '</tr>';
        }

        if (domainType == '.asia') {
            str += tr_td_SS + '<b>域名证件号码：</b>';
            str += '</td>';
            str += '<td style="text-align:left;width:179px;">';
            str += '<input name="certcode" id="certcode" onblur="xinwang_keyUpCheck(this)" ' + inputSS + ' >';
            str += '</td>';
            str += '<td style="text-align:left;width:150px;">';
            str += '</td>';
            str += '</tr>';
            str += tr_td_SS + '<b>域名证件类型：</b>';
            str += '</td>';
            str += '<td style="text-align:left;width:360px;" colspan="2">';
            str += '<select  name="certtype" id="certtype" style="cursor:pointer;margin-top:4px;">';
            str += '<option value="passport" style="cursor:pointer;">护照或居民身份证</option>';
            str += '<option value="certificate" style="cursor:pointer;">营业执照</option>';
            str += '<option value="legislation" style="cursor:pointer;">特许成立的法定机构证明</option>';
            str += '<option value="societyRegistry" style="cursor:pointer;">非营利团体登记证明</option>';
            str += '<option value="politicalPartyRegistry" style="cursor:pointer;">政党注册证明</option>';
            str += '<option value="other" style="cursor:pointer;">其他</option>';
            str += '</select>';
            str += '</td>';
            str += '</tr>';
            str += tr_td_SS + '<b>域名实体类型：</b>';
            str += '</td>';
            str += '<td style="text-align:left;width:360px;" colspan="2">';
            str += '<select  name="entitytype" id="entitytype" style="cursor:pointer;margin-top:4px;">';
            str += '<option value="naturalPerson" style="cursor:pointer;">个人</option>';
            str += '<option value="corporation" style="cursor:pointer;">公司或社团法人</option>';
            str += '<option value="cooperative" style="cursor:pointer;">合作社</option>';
            str += '<option value="partnership" style="cursor:pointer;">合伙或集体公司</option>';
            str += '<option value="government" style="cursor:pointer;">政府机关</option>';
            str += '<option value="politicalParty" style="cursor:pointer;">政党或工会</option>';
            str += '<option value="society" style="cursor:pointer;">信托管理机构﹑资产管理机构﹑协会或社团</option>';
            str += '<option value="institution" style="cursor:pointer;">公共机构</option>';
            str += '<option value="other" style="cursor:pointer;">其他</option>';
            str += '</select>';
            str += '';
            str += '</td>';
            str += '</tr>';
        }

        str += '</table>';
        str += '</div>';
        $("#swin").html(str);
        $("#swin").append('<form id="OrderConfig"><div id="myStr"></div></form>');

        $("#selcontact").change(function () {
            var i = $(this).val();
            $("#chinaname").val(jsonArr[i].fname + jsonArr[i].lname);
            $("#country").val(jsonArr[i].countrycode);
            $("#province").val(jsonArr[i].province);
            $("#city").val(jsonArr[i].city);
            $("#street").val(jsonArr[i].street);
            $("#zipcode").val(jsonArr[i].zipcode);
            $("#phone").val(jsonArr[i].tel != '' ? jsonArr[i].tel : jsonArr[i].phone);
            $("#phonecode").val($("#phone").val().length == 11 ? "" : jsonArr[i].phonecode);
            $("#fax").val(jsonArr[i].tel != '' ? jsonArr[i].tel : jsonArr[i].fax);
            $("#faxcode").val($("#fax").val().length == 11 ? "" : jsonArr[i].faxcode);
            $("#email").val(jsonArr[i].email);
            $("#org").val(jsonArr[i].company);
            $("#location").val(jsonArr[i].companylocation);

            $("#swin input").focus();
           
        });

        $("#selcontact").val(templatesid).change();
        $("#swin #chinaname").focus();
        $("#btntemplates").click(function () {
            common_ListDomainContact(domainType, domainName, vprovider, '', "reg", templatesid);
        });

        var discount = parseFloat(productData[0].discount);
        var myPrice = getPriceByType(domainType, 'reg');
        var yearNum = 1;
        $("#divprice").remove();
        var pStr= '<div style="float:left;height:44px;line-height:44px;" id="divprice"><input type="hidden" value="' + yearNum + '" id="yearNum" />';
        if (discount > 0 && discount < 1) {
            pStr += '<strong>总价格：<span style="color:blue;" id="OrderNormalPrice"><strike>' + myPrice + '</strike></span> <b style="">RMB</b>';
            myPrice = parseFloat(getPriceByType(domainType, 'reg')) * discount;
            pStr += '<input type="hidden" value="' + myPrice + '" id="typePrice" />';
            pStr += '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
            pStr += '帐户优惠价(' + discount + '折)：<span style="color:blue;" id="OrderPrice">' + myPrice + '</span> <b style="">RMB</b></strong>';
        }
        else {

            myPrice = parseFloat(getPriceByType(domainType, 'reg')) * discount;

            pStr += '<input type="hidden" value="' + myPrice + '" id="typePrice" />';
            pStr += '<strong>总价格：<span style="color:blue;" id="OrderPrice">' + myPrice + '</span> <b style="color:blue;">RMB</b></strong>';
        }
        pStr += '</div>';
        $(".ui-dialog-buttonset").before(pStr);
    });
}
function xinwang_gotoRegDomain() {

    var chinaname = $("#chinaname"), country = $("#country"), province = $("#province"), city = $("#city"), street = $("#street"), phone = $("#phone"), fax = $("#fax"), email = $("#email");
    var zipcode = $("#zipcode"), org = $("#org"), phonecode = $("#phonecode"), faxcode = $("#faxcode"), location = $("#location");
    var uincode = -1, certcode = -1, certtype = -1, entitytype = -1;
    var dns1 = $("#dns1"), dns2 = $("#dns2");
    if (!(/^([\u4e00-\u9fa5])+$/.test(chinaname.val()))) { chinaname.parent().next("td").html("<b style='color:red;'>*请输入中文名称！</span>"); chinaname.focus(); return false; }
    if ($.trim(province.val()) == "") { province.parent().next("td").html("<b style='color:red;'>*省份不能为空！</span>"); province.focus(); return false; }
    if ($.trim(city.val()) == "") { city.parent().next("td").html("<b style='color:red;'>*城市不能为空！</span>"); city.focus(); return false; }
    if ($.trim(street.val()) == "") { street.parent().next("td").html("<b style='color:red;'>*街道地址不能为空！</span>"); street.focus(); return false; }
    if ($.trim(zipcode.val()) == "") { zipcode.parent().next("td").html("<b style='color:red;'>*邮政编码不能为空！</span>"); zipcode.focus(); return false; }

    if ($.trim(dns1.val()) == "") { dns1.parent().next("td").html("<b style='color:red;'>*DNS1不能为空！</span>"); dns1.focus(); return false; }
    if ($.trim(dns2.val()) == "") { dns2.parent().next("td").html("<b style='color:red;'>*DNS2不能为空！</span>"); dns2.focus(); return false; }

    if ($.trim(phone.val()) == "") {
        phone.parent().next("td").html("<b style='color:red;'>*联系电话不能为空！</span>");
        phone.focus();
        return false;
    }
    if ($.trim(phone.val()).length != 11 && $.trim(phonecode.val()).length <= 0) {
        phonecode.parent().next("td").html("<b style='color:red;'>*电话区号不能为空！</span>");
        phonecode.focus();
        return false;
    }

    if ($.trim(phone.val()).length + $.trim(phonecode.val()).length >= 12) {
        alert("联系电话或电话区号错误，区号+电话号码长度必须小于12");
        return false;
    }
    if ($.trim(fax.val()) == "") {
        fax.parent().next("td").html("<b style='color:red;'>*传真号不能为空！</span>");
        fax.focus();
        return false;
    }
    if ($.trim(fax.val()).length != 11 && $.trim(faxcode.val()).length <= 0) {
        faxcode.parent().next("td").html("<b style='color:red;'>*传真区号不能为空！</span>");
        faxcode.focus();
        return false;
    }
    if ($.trim(fax.val()).length + $.trim(faxcode.val()).length >= 12) {
        alert("传真号码或传真区号错误，区号+传真号码长度必须小于12");
        return false;
    }
    if ($.trim(email.val()) == "") {
        email.parent().next("td").html("<b style='color:red;'>*邮箱不能为空！</span>");
        email.focus();
        return false;
    }
    else {
        var reg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
        if (!reg.test($.trim(email.val()))) {
            email.parent().next("td").html("<b style='color:red;'>*邮箱格式不正确！</span>");
            email.focus();
            return false;
        }
        else {
            email.parent().next("td").html("<b style='font-size:1px;'>&nbsp;</b>");
        }
    }
    if (!(/^([\u4e00-\u9fa5])+$/.test(org.val()))) { org.parent().next("td").html("<b style='color:red;'>*请输入中文单位名称！</span>"); org.focus(); return false; }
    if ($.trim(location.val()) == "") { location.parent().next("td").html("<b style='color:red;'>*注册人单位所在地不能为空！</span>"); location.focus(); return false; }

    var theDomainName = $("#regDomainName").val();
    var theType = theDomainName.substr(theDomainName.indexOf("."));

    if (theType == '.travel') {
        uincode = uincode.val();
        if ($.trim(uincode).length <= 0) {
            uincode.parent().next("td").html("<b style='color:red;'>*域名UIN编码不能为空！</span>");
            uincode.focus();
            return false;
        }
    }
    if (theType == '.asia') {
        certcode = certcode.val();
        certtype = certtype.val();
        entitytype = entitytype.val();
        if ($.trim(certcode).length <= 0) {
            certcode.parent().next("td").html("<b style='color:red;'>*域名证件号码不能为空！</span>");
            certcode.focus();
            return false;
        }
    }

    var yNum = $("#regYear").val();
    normalPrice = parseFloat(getPriceByType(theType, 'reg')) * parseInt($("#yearNum").val());
    finalPrice = parseFloat($("#typePrice").val()) * parseInt($("#yearNum").val());
    billingCycle = parseInt($("#yearNum").val()) * 12;
    billingMothod = 1;
    var myInputs = '<input type="hidden" value="' + getPriceByType(theType, 'reg') + '" name="typePrice" />' +
          '<input type="hidden" value="' + getPriceByType(theType, 'renew') + '" name="renewPrice" />' +
          '<input type="hidden" value="' + getPriceByType(theType, 'transfer') + '" name="transferPrice" />' +
          '<input type="hidden" value="' + $("#regDomainName").val() + '" name="domainName" />' +
          '<input type="hidden" value="' + yNum + '" name="regYearNum" />' +

          '<input type="hidden" value="' + $.trim(chinaname.val()) + '" name="chinaname" />' +
          '<input type="hidden" value="' + $.trim(country.val()) + '" name="country" />' +
            '<input type="hidden" value="' + $.trim(province.val()) + '" name="province" />' +
          '<input type="hidden" value="' + $.trim(city.val()) + '" name="city" />' +
          '<input type="hidden" value="' + $.trim(street.val()) + '" name="street" />' +
          '<input type="hidden" value="' + $.trim(zipcode.val()) + '" name="zipcode" />' +
          '<input type="hidden" value="' + $.trim(phone.val()) + '" name="phone" />' +
          '<input type="hidden" value="' + $.trim(phonecode.val()) + '" name="phonecode" />' +
          '<input type="hidden" value="' + $.trim(fax.val()) + '" name="fax" />' +
          '<input type="hidden" value="' + $.trim(faxcode.val()) + '" name="faxcode" />' +
          '<input type="hidden" value="' + $.trim(email.val()) + '" name="email" />' +
          '<input type="hidden" value="' + $.trim(org.val()) + '" name="org" />' +
          '<input type="hidden" value="' + $.trim(location.val()) + '" name="location" />' +
          '<input type="hidden" value="' + $.trim(uincode) + '" name="uincode" />' +
          '<input type="hidden" value="' + $.trim(certcode) + '" name="certcode" />' +
          '<input type="hidden" value="' + $.trim(certtype) + '" name="certtype" />' +
          '<input type="hidden" value="' + $.trim(entitytype) + '" name="entitytype" />' +
          '<input type="hidden" value="' + $.trim(dns1.val()) + '" name="dns1" />' +
          '<input type="hidden" value="' + $.trim(dns2.val()) + '" name="dns2" />' +
          '<input type="hidden" value="xinwang" name="provider" />';
    $("#myStr").html(myInputs);
    suwin.next().find("#divprice").remove();
    suwin.dialog({ title: "购买确认", autoOpen: false, resizable: false, width: 399, height: 368, modal: true, buttons: { "确定购买": function () { checkout(1); }, "继续配置": function () { $(this).dialog("close"); }, "在线充值": function () { window.open('?c=finance', '_blank'); } } }).dialog("open");
    checkout(0);
}


function xinwang_keyUpCheck(obj) {
    var checkName = $(obj).attr("name");
    var checkValue = $.trim($(obj).val());
    switch (checkName) {
        case "chinaname":
        case "province":
        case "city":
        case "org":
        case "location":
            if (!ischinese(checkValue) || checkValue.length<2) {
                $(obj).parent().next("td").html("<span style='color:red;'>*请填写中文</span>");
            }
            else {
                $(obj).parent().next("td").html("");
            }
            break;
      
        case "email":
            var reg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
            if (!reg.test(checkValue)) {
                $(obj).parent().next("td").html("<span style='color:red;'>*邮箱格式错误！</span>");
            }
            else {
                $(obj).parent().next("td").html("");
            }
            break;

        case "zipcode":
            var reg = /^[0-9]{6}$/;
            if (!reg.test(checkValue)) {
                $(obj).parent().next("td").html("<span style='color:red;'>*邮政编码格式错误！</span>");
            }
            else {
                $(obj).parent().next("td").html("");
            }
            break;
        case "phone":
            if (checkValue.length == 0) {
                $(obj).parent().next("td").html("<span style='color:red;'>*不能为空</span>");
            } else if (checkValue.length != 7 && checkValue.length != 8 && checkValue.length != 11) {
                $(obj).parent().next("td").html("<span style='color:red;'>*联系电话格式错误！</span>");
            }
            break;
        case "fax":
            if (checkValue.length == 0) {
                $(obj).parent().next("td").html("<span style='color:red;'>*不能为空</span>");
            }
            break;
        case "province":
            if (checkValue.length == 0) {
                $(obj).parent().next("td").html("<span style='color:red;'>*不能为空</span>");
            }
            else {
                $(obj).parent().next("td").html(" 省/市");
            }
            break;
        case "city":
            if (checkValue.length == 0) {
                $(obj).parent().next("td").html("<span style='color:red;'>*不能为空</span>");
            }
            else {
                $(obj).parent().next("td").html(" 市/区");
            }
            break;
        default:
            if (checkValue.length == 0) {
                $(obj).parent().next("td").html("<span style='color:red;'>*不能为空</span>");
            }
            else {
                $(obj).parent().next("td").html("");
            }
            break;
    }
}
function xinwang_keyFocus(obj) {
    var checkName = $(obj).attr("name");
    var checkValue = $.trim($(obj).val());
    switch (checkName) {
        case "phone":
            $(obj).parent().next("td").html(" 如：15916245211或613781022");
            break;
        case "fax":
            $(obj).parent().next("td").html(" 如：15916245211或613781022");
            break;
        case "province":
            $(obj).parent().next("td").html(" 省/市");
            break;
        case "city":
            $(obj).parent().next("td").html(" 市/区");
            break;
    }
}
function ischinese(value) {
    var reg = /[\u4e00-\u9fa5]+/;
    return reg.test(value);
}