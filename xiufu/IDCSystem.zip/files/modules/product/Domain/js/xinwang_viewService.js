﻿/// <reference path="jquery-vsdoc.js" />
/// <reference path="jquery-ui.min.js" />
function xinwang_view() {
    var str = '<table width="100%" border="0" cellspacing="0" cellpadding="0" class="table grid"><thead><tr><th  style="text-align: right;">当前域名信息：</th><th class=\"full\">&nbsp;</th></tr></thead><tbody>';
    var title = '';
    if (serviceData[0].ssid == 0) {
        title = '域名服务还在申请中...';
    }
    else {
        title = '管理我的域名 ' + serviceData[0].sconfig.domainName + '';
    }
    str += '<tr><td class="title">域名：</td><td><span id=""></span><span title="">' + serviceData[0].sconfig.domainName + '</span></td></tr>';
    if (serviceData[0].ssid != 0) {
        str += '<tr><td class="title">注册时间：</td><td><span id="regTime" title="">' + serviceData[0].sconfig.regDate + '</span></td></tr>';
        str += "<tr>";
        str += "<td class=\"title\" style=\"text-align: right;\">";
        str += "域名管理：";
        str += "</td>";
        str += "<td>";
        str += "<form action=\"http://dcp.xinnet.com/Modules/agent/domain/domain_manage.jsp\" target=\"_blank\" method=\"POST\" name=\"form1\" id=\"form1\">";
        str += "<input type=\"submit\" name='btn_login' value=\"域名自助管理\" class=\"submit\" style=\"cursor:pointer;\">";
        str += "</form>";
        str += "</td></tr>";
    }
    if (serviceData[0].sconfig.transferType == "cn") { } else {
        str += '<tr><td class="title">联系人姓名：</td><td><span></span><span id="NameZH">' + serviceData[0].sconfig.chinaname + '</span></td></tr>';
        str += '<tr><td class="title">联系电话：</td><td><span></span><span id="phone">' + serviceData[0].sconfig.phone + '</span></td></tr>';
        str += '<tr><td class="title">传 真：</td><td><span></span><span id="fax">' + serviceData[0].sconfig.fax + '</span></td></tr>';
        str += '<tr><td class="title">联系邮箱：</td><td><span></span><span id="email">' + serviceData[0].sconfig.email + '</span></td></tr>';
        str += '<tr><td class="title">联系地址：</td><td><span></span><span id="OrganizationZH">' + serviceData[0].sconfig.province + serviceData[0].sconfig.city + serviceData[0].sconfig.street + '</span></td></tr>';
        str += '<tr><td class="title">邮 编：</td><td><span></span><span id="Postcode">' + serviceData[0].sconfig.zipcode + '</span></td></tr>';
        str += '<tr><td class="title">公司名称：</td><td><span></span><span id="OrganizationZH">' + serviceData[0].sconfig.org + '</span></td></tr>';

    }
    $("#pageTitle").html(title);
    document.title = title;
    var statusText = serviceStatus[parseInt(serviceData[0].sstatus) + 2];
    switch (serviceData[0].sstatus) {
        case "-1": statusText = '<strong style="color:#0000FF;">' + statusText + '</strong>'; break;
        case "0": statusText = '<strong style="color:#005B00;">' + statusText + '</strong>'; break;
        case "3": statusText = '<strong style="color:#CC3300;">' + statusText + '</strong>'; break;
        case "1":
        case "2":
        case "4": statusText = '<strong style="color:#FF0000;">' + statusText + '</strong>'; break;
    }
    str += '<tr><td class="title">续费价格：</td><td><b>' + serviceData[0].sprice + ' ' + userData[0].currency + '</b> / ' + serviceData[0].spcycle / 12 + ' 年&nbsp;&nbsp;&nbsp;<b>账户余额：</b>' + parseFloat(userData[0].balance).toFixed(2) + ' ' + userData[0].currency + ' &nbsp;&nbsp;<a href="javascript:_renew();">『马上续费』</a></td></tr>' +
            '<tr><td class="title">到期时间：</td><td><span id="endTime">' + getUnixTime(serviceData[0].etime) + '</span>&nbsp;&nbsp;<span style="color:#999;">请确保你的账户余额充足</span>&nbsp;&nbsp;&nbsp;<input id="autorenew" type="checkbox" ' + (serviceData[0].autorenew == '0' ? 'checked="checked"' : '') + '/><label for="autorenew">自动续费</label></td></tr>' +
            '<tr><td class="title">服务状态：</td><td id="statusFlag">' + statusText + ' &nbsp;&nbsp;';
    if (serviceData[0].sstatus == "-1") {
        str += '<input type=\"submit\" value=\"立即刷新状态\" class=\"submit\" onclick=\"xinwang_reloadpage()\" />';
    }
    str += '</td></tr>';

    str += '</tbody></table>';
    str += '<table width="100%" border="0" cellspacing="0" cellpadding="0" class="table grid"><thead><tr><th style="text-align: right;">当前服务其它信息：</th><th class=\"full\">&nbsp;</th></tr></thead>';

    if (serviceData[0].ssid != 0) {
        str += "<tr>";
        str += "<td class=\"title\" style=\"text-align: right;\">";
        str += "联系人模板管理：";
        str += "</td>";
        str += "<td>";
        str += "<input type=\"submit\" value=\"注册联系人模板信息管理\" onclick=\"common_ListDomainContact()\" class=\"submit\" style=\"cursor:pointer;\">&nbsp;&nbsp;";
        str += "</td></tr>";

        str += "<tr>";
        str += "<td class=\"title\" style=\"text-align: right;\">";
        str += "域名密码管理：";
        str += "</td>";
        str += "<td>";
        str += "<input type=\"submit\" id=\"xinwang_getBackPwd\" value=\"获取密码\" onclick=\"xinwang_getBackPwd()\" class=\"submit\" style=\"cursor:pointer;\">&nbsp;&nbsp;";
        str += "</td></tr>";
        str += "<tr>";
        str += "<td class=\"title\" style=\"text-align: right;\">";
        str += "域名DNS管理：";
        str += "</td>";
        str += "<td>";
        str += "<input type=\"submit\" id=\"xinwang_EditDomainDNS\" value=\"域名DNS修改\" onclick=\"xinwang_EditDomainDNS()\" class=\"submit\" style=\"cursor:pointer;\">&nbsp;&nbsp;";
        str += "&nbsp;&nbsp;";
        str += "</td></tr>";
        str += "<tr id='trrecord'>";
        str += "<td class=\"title\" style=\"text-align: right;\">";
        str += "解析记录管理：";
        str += "</td>";
        str += "<td>";
        str += "<input type=\"submit\" id=\"xinwang_nsrecord\" value=\"NS记录管理\" onclick=\"xinwang_record('ns')\" class=\"submit\" style=\"cursor:pointer;\">&nbsp;&nbsp;<input type=\"submit\" id=\"xinwang_Arecord\" value=\"A记录管理\" onclick=\"xinwang_record('a')\" class=\"submit\" style=\"cursor:pointer;\">&nbsp;&nbsp;<input type=\"submit\" id=\"xinwang_cnamerecord\" value=\"CNAME记录管理\" onclick=\"xinwang_record('cname')\" class=\"submit\" style=\"cursor:pointer;\">&nbsp;&nbsp;<input type=\"submit\" id=\"xinwang_mxrecord\" value=\"MX记录管理\" onclick=\"xinwang_record('mx')\" class=\"submit\" style=\"cursor:pointer;\">&nbsp;&nbsp;<input type=\"submit\" id=\"xinwang_txtrecord\" value=\"TXT记录管理\" onclick=\"xinwang_record('txt')\" class=\"submit\" style=\"cursor:pointer;\">&nbsp;&nbsp;";
        str += "</td></tr>";
    }

    str += "<td class=\"title\" style=\"text-align: right;\">";
    str += "</td>";
    str += "<td>"
    str += "<span id=\"ajaxFlag\"></span>";
    str += "</td></tr>";
    str += "</table>";
    $("#ViewService").html(str);
    $("#ViewService .title").css("text-align", "right");

    var whois = 'http://whois.chinaz.com/' + serviceData[0].sconfig.domainName;
    var mmStr = "";
    mmStr += "<tr>";
    mmStr += "<td class=\"title\" style=\"text-align: right;\">";
    mmStr += "Whois查询工具：";
    mmStr += "</td>";
    mmStr += "<td>";
    mmStr += "<span style='background-color:#444;font-weight:bold; color:White;padding:3px 5px;'><a style='font-weight:bold;text-decoration:none; color:White;' target='_blank' href='" + whois + "'>" + serviceData[0].sconfig.domainName + "</a></span>";
    mmStr += "</td></tr>";
    $("#ajaxFlag").parent().parent().parent().append(mmStr);
    $("#ViewService #autorenew").css("cursor", "pointer").click(function () {
        var autorenew = $(this).prop("checked") ? '0' : '1';
        setAutorenew(serviceData[0].sid, autorenew);
    });
    if (/([\u4e00-\u9fa5])/.test(serviceData[0].sconfig.domainName)) { $("#trrecord").remove(); }
}

function xinwang_reloadpage() {
    window.location.reload();
}

function xinwang_record(type) {
    var url = "?c=module&serviceid=" + serviceData[0].sid + "&show=text&todo=xinwang_listrecord&type=" + type + "&t=" + new Date();
    swin.html(ajaxLoading("正在加载信息，请稍等......"));
    swin.dialog({ title: "域名【" + serviceData[0].sconfig.domainName + "】" + type.toUpperCase() + '记录管理(最多20条记录)', autoOpen: false, resizable: false, width: 660, height: 400, modal: false, buttons: { '添加记录': function () {

        if ($("#trempty").html() != undefined) $("#trempty").remove();

        var nowId = 1;
        if ($("#main-content").find("tr").length > 1) {
            nowId = $("#main-content").find("tr:last").attr("id");
            nowId = parseInt(nowId.substr(2)) + 1;
        }
        var vtr = '<tr id="tr' + nowId + '"><td width="20%" align="center"><input class="text" style="width:120px;margin-top:5px;text-align:center;" name="recordname' + nowId + '" value="" /></td><td width="28%" align="center"><input class="text" style="width:150px;margin-top:5px;text-align:center;" name="recordcontent' + nowId + '" value="" /></td><td width="15%" align="center"><input class="text" style="width:60px;margin-top:5px;text-align:center;" name="recordttl' + nowId + '" value="3600" /></td>';
        vtr += '<td align="center"><input class="text" style="width:60px;margin-top:5px;text-align:center;" name="recordprio' + nowId + '" value="0" /></td>';
        vtr += '<td><input type="hidden" value="add" name="action' + nowId + '"/><input type="hidden" value="' + type + '" name="type' + nowId + '"/><input type="button" name="del' + nowId + '" class="button" value="删除" onclick="xinwang_delrecord(' + nowId + ');"/> <input type="button" class="button" name="save' + nowId + '" value="保存" onclick="xinwang_saverecord(' + nowId + ')"/> </td></tr>';
        $("#main-content").find("table").append(vtr);


        if ($("#main-content").find("table tr").length >= 21) $(".ui-dialog-buttonset button:first").hide();
        // swin.css({ "height": "auto" });

    }, '关 闭': function () { $(this).dialog("close"); }
    }
    }).dialog("open");


    $.post(url, function (rdata) {
        var str = '<div id="main-content"><table>' +
                          '<thead><tr><th width="20%">主机记录</th><th width="28%">记录值</th><th width="15%">生存时间</th><th width="15%">优先级</th></tr></thead>';

        var arr = rdata.split('|');
        var emptyrecord = "";
        var tr = "";
        if (arr[0] == "0") {
            var arrRecord = $.parseJSON(arr[1]);
            for (var i = 0, len = arrRecord.length; i < len; i++) {
                if (arrRecord[i].recordname != serviceData[0].sconfig.domainName) {
                    var recordname = arrRecord[i].recordname;
                    recordname = recordname.substr(0, recordname.lastIndexOf(serviceData[0].sconfig.domainName) - 1);
                    tr += '<tr id="tr' + i + '"><td width="20%" align="center"><input class="text"  style="width:120px;margin-top:5px;text-align:center;" name="recordname' + i + '" value="' + recordname + '" /></td><td width="28%" align="center"><input class="text" style="width:150px;margin-top:5px;text-align:center;" name="recordcontent' + i + '" value="' + arrRecord[i].content + '" /></td><td width="15%" align="center"><input class="text" style="width:60px;margin-top:5px;text-align:center;" name="recordttl' + i + '" value="' + arrRecord[i].ttl + '" /></td>';
                    tr += '<td align="center"><input class="text" style="width:60px;margin-top:5px;text-align:center;" name="recordprio' + i + '" value="' + arrRecord[i].prio + '" /></td>';
                    tr += '<td><input type="hidden" value="edit" name="action' + i + '"/><input type="hidden" value="' + type + '" name="type' + i + '"/><input type="button" name="del' + i + '" class="button" value="删除" onclick="xinwang_delrecord(' + i + ')"/></td></tr>';
                } else {
                    emptyrecord += '<tr id="tr' + i + '"><td width="20%" align="center"><input class="text"  style="width:120px;margin-top:5px;text-align:center;" name="recordname' + i + '" value="" /></td><td width="28%" align="center"><input class="text" style="width:150px;margin-top:5px;text-align:center;" name="recordcontent' + i + '" value="' + arrRecord[i].content + '" /></td><td width="15%" align="center"><input class="text" style="width:60px;margin-top:5px;text-align:center;" name="recordttl' + i + '" value="' + arrRecord[i].ttl + '" /></td>';
                    emptyrecord += '<td align="center"><input class="text" style="width:60px;margin-top:5px;text-align:center;" name="recordprio' + i + '" value="' + arrRecord[i].prio + '" /></td>';
                    emptyrecord += '<td><input type="hidden" value="edit" name="action' + i + '"/><input type="hidden" value="' + type + '" name="type' + i + '"/><input type="button" name="del' + i + '" class="button" value="删除" onclick="xinwang_delrecord(' + i + ')"/></td></tr>';
                }
            }

        }
        tr += '</table>';
        swin.html(str + emptyrecord+tr);
        if ($("#main-content").find("table tr").length >= 21) $(".ui-dialog-buttonset button:first").hide();

        $("#main-content").find("table tr").each(function () {
            $(this).find("input").not(":last").attr("disabled", "disabled");
        });
        xinwang_setTable();
    });

}
function xinwang_saverecord(id) {
    var content = $("input[name=recordcontent" + id + "]").val();
    var recordname = $("input[name=recordname" + id + "]").val();
    var ttl = $("input[name=recordttl" + id + "]").val();
    var prio = $("input[name=recordprio" + id + "]").val();
    var type = $("input[name=type" + id + "]").val();

    processing("正在处理，请稍候...");

    var isexist = false;
    $("input[name^=recordname]").each(function () {
        var vname = $(this).attr("name").replace('recordname', 'recordcontent');
        if ($(this).attr("name") != "recordname" + id && $(this).val() == recordname && $("input[name="+vname+"]").val()==content) {
            showResults("该记录已存在", 3000, "close");
            isexist = true;
        }
    });
    if(isexist)return;
    if (content.length <= 0) {
        showResults("记录值不能为空", 3000, "close");
        return;
    }
    if (ttl.length <= 0) {
        showResults("生存时间不能为空", 3000, "close");
        return;
    }
    if (prio.length <= 0) {
        showResults("优先级不能为空", 3000, "close");
        return;
    }

    var exurl = 'content=' + content + '&recordname=' + recordname + '&ttl=' + ttl + '&prio=' + prio + '&type=' + type;
    var delay = 5000;
    var url = "?c=module&serviceid=" + serviceData[0].sid + "&show=text&todo=xinwang_saverecord&" + exurl + "&t=" + new Date();
    $.post(url, function (rdata) {
        if (rdata == "0") {
            rdata = "操作成功";
            delay = 3000;
            $("input[name=save" + id + "]").remove();
            $("input[name=action" + id + "]").parent().parent().find("input").not(":last").attr("disabled", "disabled");

            $("input[name=action" + id + "]").val("edit");
        }
        showResults(rdata, delay, "close");
    });
}

function xinwang_delrecord(id) {
    var obj = $("input[name=action" + id + "]");
    if (obj.val() == 'add') {
        obj.parent().parent().remove();
        xinwang_setTable();
    } else {
        var recordname = $("input[name=recordname" + id + "]").val()
        var str = '<p style="font-weight:bold;padding-top:20px;text-align:center;"><input type="checkbox" id="confirm_box" value="1"/><label for="confirm_box" style="cursor:pointer;display:inline;">您确定要删除该记录吗？<br/>' + $("input[name=type" + id + "]").val().toUpperCase() + '记录：' + (recordname.length > 0 ? recordname + '.' : '') + serviceData[0].sconfig.domainName + '</label></p>';
        suwin.html(str);
        suwin.dialog({ title: '操作提示', autoOpen: false, resizable: false, width: 400, height: 220, modal: false, buttons: { '确定': function () {

            var confirm_box = $("#confirm_box").prop("checked");
            if (!confirm_box) {
                alert('请勾选复选框以确认操作！');
                return false;
            }
            var exurl = 'recordname=' + $("input[name=recordname" + id + "]").val() + "&content=" + $("input[name=recordcontent" + id + "]").val() + "&type=" + $("input[name=type" + id + "]").val();

            suwin.dialog('close');
            processing("正在处理，请稍候...");
            var cmd = '';
            var delay = 0;
            var url = "?c=module&serviceid=" + serviceData[0].sid + "&show=text&todo=xinwang_delrecord&" + exurl + "&t=" + new Date();
            $.post(url, function (rdata) {
                if (rdata == "0") {
                    rdata = "操作成功";
                    delay = 3000;
                    cmd = 'close';
                }
                showResults(rdata, delay, cmd);
                if (delay > 0) { obj.parent().parent().remove(); xinwang_setTable(); }
            });

        }, '取消': function () { $(this).dialog("close"); }
        }
        }).dialog("open");
    }

}

function xinwang_setTable() {
    if ($("#main-content").find("table tr").length == 1) {
        var str = '<tr id="trempty"><td width="20%" align="center"><input class="text" readonly="readonly" style="width:120px;margin-top:5px;text-align:center;border-color:#fff;"/></td><td width="28%" align="center"><input class="text" readonly="readonly" style="width:150px;margin-top:5px;text-align:center;border-color:#fff;" /></td><td width="15%" align="center"><input class="text" readonly="readonly" style="width:60px;margin-top:5px;text-align:center;border-color:#fff;" /></td>';
        str += '<td align="center"><input class="text" readonly="readonly" style="width:60px;margin-top:5px;text-align:center;border-color:#fff;"/></td>';
        str += '<td></td></tr>';
        $("#main-content").find("table").append(str);
    }
    if ($("#main-content").find("table tr").length < 21) $(".ui-dialog-buttonset button:first").show();
}

function xinwang_keyUpCheck(obj) {
    var checkName = $(obj).attr("name");
    var checkValue = $.trim($(obj).val());
    switch (checkName) {
        case "chinaname":
        case "province":
        case "city":
        case "org":
        case "location":
            if (!ischinese(checkValue) || checkValue.length < 2) {
                $(obj).parent().next("td").html("<span style='color:red;'>*请填写中文</span>");
            }
            else {
                $(obj).parent().next("td").html("");
            }
            break;

        case "email":
            var reg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
            if (!reg.test(checkValue)) {
                $(obj).parent().next("td").html("<span style='color:red;'>*邮箱格式错误！</span>");
            }
            else {
                $(obj).parent().next("td").html("");
            }
            break;

        case "zipcode":
            var reg = /^[0-9]{6}$/;
            if (!reg.test(checkValue)) {
                $(obj).parent().next("td").html("<span style='color:red;'>*邮政编码格式错误！</span>");
            }
            else {
                $(obj).parent().next("td").html("");
            }
            break;
        case "phone":
            if (checkValue.length == 0) {
                $(obj).parent().next("td").html("<span style='color:red;'>*不能为空</span>");
            }
            break;
        case "fax":
            if (checkValue.length == 0) {
                $(obj).parent().next("td").html("<span style='color:red;'>*不能为空</span>");
            }
            break;
        case "province":
            if (checkValue.length == 0) {
                $(obj).parent().next("td").html("<span style='color:red;'>*不能为空</span>");
            }
            else {
                $(obj).parent().next("td").html(" 省/市");
            }
            break;
        case "city":
            if (checkValue.length == 0) {
                $(obj).parent().next("td").html("<span style='color:red;'>*不能为空</span>");
            }
            else {
                $(obj).parent().next("td").html(" 市/区");
            }
            break;
        default:
            if (checkValue.length == 0) {
                $(obj).parent().next("td").html("<span style='color:red;'>*不能为空</span>");
            }
            else {
                $(obj).parent().next("td").html("");
            }
            break;
    }
}

function xinwang_keyFocus(obj) {
    var checkName = $(obj).attr("name");
    var checkValue = $.trim($(obj).val());
    switch (checkName) {
        case "province":
            $(obj).parent().next("td").html(" 省/市");
            break;
        case "city":
            $(obj).parent().next("td").html(" 市/区");
            break;
    }

}
function ischinese(value) {
    var reg = /[\u4e00-\u9fa5]+/;
    return reg.test(value);
}
function xinwang_editDomainContact() {
    $("#swin").html('<div class="loading" style="text-align:center;padding-top:40px;"><img src="images/loading.gif" /><br/>Loading...</div>');
    var str = '';
    var tr_td_SS = '<tr style="height:29px;line-height:29px;border-bottom:1px dashed #ddd;"><td style="width:180px;text-align:right;">';
    var inputSS = 'class="text" style="margin-top:4px;"';
    str += '<div style="padding-left:100px;"><form name="frmsave" id="frmsave" action="?c=module&serviceid=' + serviceData[0].sid + '&show=text&action=update_service_data&todo=xinwang_EditDomainContact" onsubmit="return xinwang_gotoSaveDomainContact();">';
    str += '<table style="width:600px;" id="tbContact">';
    str += tr_td_SS + '<b>联系人姓名(中文)：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="chinaname" id="chinaname" onfocus="xinwang_keyFocus(this)" onblur="xinwang_keyUpCheck(this)" ' + inputSS + ' value="' + serviceData[0].sconfig.chinaname + '">';
    str += '</td>';
    str += '<td style="text-align:left;" class="tip">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>国家：</b>';
    str += '</td>';
    str += '<td style="text-align:left;">';
    str += '<select name="country" id="country" style="cursor:pointer;margin-top:4px;">' +
        '<option value="AU">澳大利亚</option>' +
        '<option value="CA">加拿大</option>' +
        '<option value="CN">中国</option>' +
        '<option value="CX">圣诞岛</option>' +
        '<option value="DK">丹麦</option>' +
        '<option value="DJ">吉布提</option>' +
        '<option value="DM">多米尼加联邦</option>' +
        '<option value="DO">多米尼加共和国</option>' +
        '<option value="TP">东帝汶</option>' +
        '<option value="FR">法国</option>' +
        '<option value="IN">印度</option>' +
        '<option value="JP">日本</option>' +
        '<option value="MA">摩洛哥</option>' +
        '<option value="NZ">新西兰</option>' +
        '<option value="OM">阿曼</option>' +
        '<option value="RU">俄罗斯联邦</option>' +
        '<option value="SB">所罗门群岛</option>' +
        '<option value="SO">索马里</option>' +
        '<option value="ZA">南非</option>' +
        '<option value="ES">西班牙</option>' +
        '<option value="LK">斯里兰卡</option>' +
        '<option value="SD">苏丹</option>' +
        '<option value="TW">台湾</option>' +
        '<option value="US">美国</option>';
    str += '</select>';
    str += '<td style="text-align:left;">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>省份：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="province" id="province" onfocus="xinwang_keyFocus(this)" onblur="xinwang_keyUpCheck(this)" ' + inputSS + ' value="' + serviceData[0].sconfig.province + '">';
    str += '</td>';
    str += '<td style="text-align:left;" class="tip">';
    str += ' 省/市</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>城市：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="city" id="city" onfocus="xinwang_keyFocus(this)" onblur="xinwang_keyUpCheck(this)" ' + inputSS + ' value="' + serviceData[0].sconfig.city + '">';
    str += '</td>';
    str += '<td style="text-align:left;" class="tip">';
    str += ' 市/区</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>街道地址：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="street" id="street" onblur="xinwang_keyUpCheck(this)" ' + inputSS + ' value="' + serviceData[0].sconfig.street + '">';
    str += '</td>';
    str += '<td style="text-align:left;" class="tip">';
    str += '如：广东软件园A栋101号</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>邮政编码：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="zipcode" id="zipcode" onblur="xinwang_keyUpCheck(this)" ' + inputSS + '  value="' + serviceData[0].sconfig.zipcode + '">';
    str += '</td>';
    str += '<td style="text-align:left;" class="tip">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>联系电话：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="phone" id="phone" onfocus="xinwang_keyFocus(this)" onblur="xinwang_keyUpCheck(this)" ' + inputSS + ' value="' + serviceData[0].sconfig.phone + '">';
    str += '</td>';
    str += '<td style="text-align:left;width:240px" class="tip">';
    str += ' 手机/电话</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>电话区号：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="phonecode" id="phonecode" ' + inputSS + ' value="' + serviceData[0].sconfig.phonecode + '">';
    str += '</td>';
    str += '<td style="text-align:left;" class="tip">';
    str += ' 如果为手机，此项为空</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>传真号码：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="fax" id="fax" onfocus="xinwang_keyFocus(this)" onblur="xinwang_keyUpCheck(this)" ' + inputSS + '  value="' + serviceData[0].sconfig.fax + '">';
    str += '</td>';
    str += '<td style="text-align:left;width:240px" class="tip">';
    str += ' 手机/电话</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>传真区号：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="faxcode" id="faxcode" ' + inputSS + ' value="' + serviceData[0].sconfig.faxcode + '">';
    str += '</td>';
    str += '<td style="text-align:left;" class="tip">';
    str += ' 如果为手机，此项为空</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>电子邮箱：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="email" id="email" onblur="xinwang_keyUpCheck(this)" ' + inputSS + ' value="' + serviceData[0].sconfig.email + '">';
    str += '</td>';
    str += '<td style="text-align:left;" class="tip">';
    str += '</td>';
    str += '</tr>';

    str += tr_td_SS + '<b>联系人单位名称(中文) ：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="org" id="org" onblur="xinwang_keyUpCheck(this)" ' + inputSS + ' value="' + serviceData[0].sconfig.org + '">';
    str += '</td>';
    str += '<td style="text-align:left;" class="tip">';
    str += '</td>';
    str += '</tr>';
    str += tr_td_SS + '<b>联系人单位所在地：</b>';
    str += '</td>';
    str += '<td style="text-align:left;width:179px;">';
    str += '<input name="location" id="location" onblur="xinwang_keyUpCheck(this)" ' + inputSS + ' value="' + serviceData[0].sconfig.location + '" >';
    str += '</td>';
    str += '<td style="text-align:left;width:150px;" class="tip">如：广东广州';
    str += '</td>';
    str += '</tr>';

    str += '</table></form>';
    str += '</div>';
    $("#swin").html(str);

    $("#country").val(serviceData[0].sconfig.country);

    $("#swin").dialog({ title: "域名【" + serviceData[0].sconfig.domainName + "】联系人管理", autoOpen: false, resizable: false, width: 720, height: 560, modal: false, buttons: {
        "保存修改": function () {
            xinwang_gotoSaveDomainContact();
        },
        "关 闭": function () { $(this).dialog("close"); }
    }
    }).dialog("open");


}
function xinwang_gotoSaveDomainContact() {
    var isok = true;
    $("td.tip").each(function () {
        if ($(this).find("span").html() != undefined) {
            isok = false;
            return;
        }
    });
    if (!isok) return false;
    processing("正在执行操作，请稍等...");
    var cmd = '';
    var delay = 0;

    $.post($("#frmsave").attr("action"), $("#frmsave").serialize(), function (rdata) {
        if (rdata == '0') {
            rdata = '操作成功！';
            delay = 3000;
            $("#swin").dialog('close');
            cmd = 'reload';
        } else {
            rdata = rdata.split('|')[1];
        }
        showResults(rdata, delay, cmd);
    });
    return false;
}

function xinwang_EditDomainDNS() {
    var url = "?c=module&serviceid=" + serviceData[0].sid + "&show=text&action=update_service_data&todo=xinwang_EditDomainDNS";
    var txtStr = '<div style="height:10px;"></div>';
    txtStr += '<table style="margin-left:50px;">';
    txtStr += '<tr style="height:30px;line-height: 30px;">';
    txtStr += '<td style="width:90px;text-align:right;"><b>域 名：</b></td>';
    txtStr += '<td style="text-align:left;">' + serviceData[0].sconfig.domainName + '</td><td style="width:70px;">&nbsp;</td></tr>';
    txtStr += '<tr style="height:30px;line-height: 30px;"><td style="width:90px;text-align:right;">';
    txtStr += '<b>DNS1：</b>';
    txtStr += '</td><td style="text-align:left;">';
    txtStr += '<input id="dns1" name="dns1" class="text" style="width:150px;margin-top:5px;" value="' + serviceData[0].sconfig.dns1 + '" />';
    txtStr += '</td><td style="width:120px;">';
    txtStr += '</td></tr>';
    txtStr += '<tr style="height:30px;line-height: 30px;"><td style="width:90px;text-align:right;">';
    txtStr += '<b>DNS2：</b>';
    txtStr += '</td><td style="text-align:left;">';
    txtStr += '<input id="dns2" name="dns2" class="text" style="width:150px;margin-top:5px;" value="' + serviceData[0].sconfig.dns2 + '" />';
    txtStr += '</td><td style="width:120px;">';
    txtStr += '</td></tr>';
    txtStr += '</table><div style="padding-left:5px;"><strong style="color:red;">提示：</strong>DNS必须为新网的DNS，否则会导致无法管理/操作解析记录</div>';
    $("#suwin").html(txtStr);
    $("#suwin").dialog({ title: "修改域名【" + serviceData[0].sconfig.domainName + "】的DNS信息", autoOpen: false, resizable: false, width: 400, height: 300, modal: false, buttons: {
        "立即修改": function () {
            processing("正在处理，请稍候...");
            if ($.trim($("#dns1").val()) != "") {
                $("#dns1").parent().next("td").html("");
            } else {
                showResults('DNS1不能为空！', 3000, "close");
                $("#dns1").focus();
                return false;
            }
            if ($.trim($("#dns2").val()) != "") {
                $("#dns2").parent().next("td").html("");
            } else {
                showResults('DNS2不能为空！', 3000, "close");
                $("#dns2").focus();
                return false;
            }
            url += "&dns1=" + $.trim($("#dns1").val()) + "&dns2=" + $.trim($("#dns2").val());



            if ($.trim($("#dns1").val()) == serviceData[0].sconfig.dns1 && $.trim($("#dns2").val()) == serviceData[0].sconfig.dns2) {
                showResults('恭喜，DNS信息修改成功！', 3000, "close");
                suwin.dialog('close');
                return false;
            }
            $.post(url, function (data) {
                if (data == "0") {
                    suwin.dialog('close');
                    showResults('恭喜，DNS信息修改成功！', 3000, "reload");

                } else {
                    showResults(data, 0, "close");
                }
            });

        }, "取 消": function () {
            $(this).dialog("close");
        }
    }
    }).dialog("open");
}
function xinwang_getBackPwd() {
    var txtStr = '<div style="height:5px;"></div>';
    txtStr += '<table id="tbsendcode">';
    txtStr += '<tr style="height:30px;line-height: 30px;"><td style="width:100px;text-align:right;">';
    txtStr += '<b>域 名：</b>';
    txtStr += '</td><td style="text-align:left;">';
    txtStr += serviceData[0].sconfig.domainName;
    txtStr += '</td></tr>';
    var height = 180, width = 300;
    if (userData[0].isAdmin != "True" && (emailchk_Xinwang != "0" || smschk_Xinwang != "0")) {
        height = 250, width = 420;
        txtStr += '<tr style="height:30px;line-height: 30px;"><td style="width:100px;text-align:right;">';
        txtStr += '<b>发送验证码：</b>';
        txtStr += '</td><td style="text-align:left;">';
        if (emailchk_Xinwang != "0") {
            txtStr += '<input type="button" class="submit" value="发到邮箱" id="mailBtn" onclick="sendCodeToEmail(3)" /> &nbsp;';
        }
        if (smschk_Xinwang != "0") {
            txtStr += '<input type="button" class="submit" value="发到手机" id="phoneBtn" onclick="sendCodeToPhone(3)" />';
        }
        txtStr += '</td></tr>';
        txtStr += '<tr style="height:30px;line-height: 30px;"><td style="width:100px;text-align:right;">';
        txtStr += '<b><input type="hidden" id="codeFlag" value="-1">输入验证码：</b>';
        txtStr += '</td><td style="text-align:left;">';
        txtStr += '<input name="vcode" id="vcode" class="text" style="width:110px;margin-top:3px;" />';
        txtStr += '</td></tr>';

        $("#tbsendcode").css("paddingLeft", "40px");
    }
    txtStr += '</table>';
    txtStr += '<div class="loading" style="text-align:center;padding-top:2px;"></div>';
    $("#suwin").html(txtStr);

    $("#suwin").dialog({ title: "获取域名【" + serviceData[0].sconfig.domainName + "】的密码", autoOpen: false, resizable: false, width: width, height: height, modal: false, buttons: {
        "立即获取": function () {
            processing("正在获取中...");
            if (userData[0].isAdmin != "True" && (emailchk_Xinwang != "0" || smschk_Xinwang != "0") && $.trim($("#vcode").val()) == "") {

                showResults('验证码不能为空！', 3000, "close");
                return false;
            }

            var url = "?c=module&serviceid=" + serviceData[0].sid + "&show=text&todo=xinwang_GetDomainPwd&vcode=" + $("#vcode").val();
            $.get(url, function (data) {
                var vArr = data.split('|');
                if (vArr[0] == "0") {
                    $("#suwin").dialog("close");
                    $("#processing").dialog("close");
                    showPwdWin(vArr[1], serviceData[0].sconfig.domainName);
                } else {
                    showResults(vArr[1], 3000, "close");
                }
            });

        }, "取 消": function () {
            $(this).dialog("close");
        }
    }
    }).dialog("open");
}

//function showTipWin(pwd, domain) {
//    $("#suwin").dialog({ title: "操作提示", autoOpen: false, resizable: false, width: 300, height: 200, modal: false, buttons: { "关 闭": function () { $(this).dialog("close"); } } }).dialog("open");
//    var txtStr = '<p style="padding-left:70px;padding-top:20px;"><b>域 名：</b>' + domain + '</p><p style="padding-left:70px;"><b>密 码：</b>' + pwd + '</p>';
//    $("#suwin").html(txtStr);
//}

//function sendCodeToEmail(tum) {
//    $("#suwin .loading").html("<img style='' src='images/loading.gif' /><br/>正在发送验证码到邮箱中...");
//    var url = "?c=module&productid=" + productData[0].pid + "&show=text&action=send_email&todo=send_emailCode&domainName=" + serviceData[0].sconfig.domainName;
//    url += "&token=" + (new Date()).valueOf() + "&leftTime=" + tum;
//    var leftTime = parseInt(tum) * 60;
//    $("#mailBtn").attr("disabled", "disabled").attr("value", "还剩" + leftTime + "秒").css({ "color": "gray", "cursor": "default" });
//    $("#phoneBtn").attr("disabled", "disabled").attr("value", "还剩" + leftTime + "秒").css({ "color": "gray", "cursor": "default" });
//    var myTimer = setInterval(function () {
//        if (leftTime > 1) {
//            leftTime -= 1;
//            $("#mailBtn").attr("disabled", "disabled").attr("value", "还剩" + leftTime + "秒");
//            $("#phoneBtn").attr("disabled", "disabled").attr("value", "还剩" + leftTime + "秒");
//        }
//        else {
//            clearInterval(myTimer);
//            $("#mailBtn").removeAttr("disabled").attr("value", "发送到邮箱").css({ "color": "white", "cursor": "pointer" });
//            $("#phoneBtn").removeAttr("disabled").attr("value", "发送到手机").css({ "color": "white", "cursor": "pointer" });
//        }
//    }, 1000);
//    $.get(url, function (data) {
//        if (parseInt(data) == 0) {
//            $("#suwin .loading").html("<b style='color:green;'>验证码已发送到您的邮箱[" + userData[0].umail + "]，请查收！</b>");
//            $("#codeFlag").val("0");
//            $("#vcode").focus();
//        } else {
//            if (data.indexOf("Email is not verified") > -1) {
//                $("#suwin .loading").html("<b style='color:red;'>抱歉，邮箱不合法，请检查你的用户资料！</b>");
//            }
//            else {
//                $("#suwin .loading").html("<b style='color:red;'>" + data.substr(3) + "</b>");
//            }
//        }

//    });
//}
//function sendCodeToPhone(tum) {
//    $("#suwin .loading").html("<img style='' src='images/loading.gif' /><br/>正在发送验证码到手机中...");
//    var url = "?c=module&productid=" + productData[0].pid + "&show=text&action=send_sms&todo=send_phoneCode&domainName=" + serviceData[0].sconfig.domainName;
//    url += "&token=" + (new Date()).valueOf() + "&leftTime=" + tum;
//    var leftTime = parseInt(tum) * 60;
//    $("#mailBtn").attr("disabled", "disabled").attr("value", "还剩" + leftTime + "秒").css({ "color": "gray", "cursor": "default" });
//    $("#phoneBtn").attr("disabled", "disabled").attr("value", "还剩" + leftTime + "秒").css({ "color": "gray", "cursor": "default" });
//    var myTimer = setInterval(function () {
//        if (leftTime > 1) {
//            leftTime -= 1;
//            $("#mailBtn").attr("disabled", "disabled").attr("value", "还剩" + leftTime + "秒");
//            $("#phoneBtn").attr("disabled", "disabled").attr("value", "还剩" + leftTime + "秒");
//        }
//        else {
//            clearInterval(myTimer);
//            $("#mailBtn").removeAttr("disabled").attr("value", "发送到邮箱").css({ "color": "white", "cursor": "pointer" });
//            $("#phoneBtn").removeAttr("disabled").attr("value", "发送到手机").css({ "color": "white", "cursor": "pointer" });
//        }
//    }, 1000);
//    $.get(url, function (data) {
//        if (parseInt(data) == 0) {
//            $("#suwin .loading").html("<b style='color:green;'>验证码已发送到您的手机[" + userData[0].tel + "]，请查收！</b>");
//            $("#codeFlag").val("0");
//            $("#vcode").focus();
//        } else {
//            $("#suwin .loading").html("<b style='color:red;'>" + data.substr(3) + "</b>");
//        }

//    });
//}

