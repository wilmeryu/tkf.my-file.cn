﻿/// <reference path="jquery-vsdoc.js" />
/// <reference path="jquery-ui.min.js" />
function setService() {
    var s = $("#server_id").val() + '№' + $("#hidIP").val() + '№' + userData[0].uname + '№' + $("#os").val() + '№' + $("#vcpu").val() + '№' + $("#vassureram").val() + '№' + $("#vdisk").val() + '№' + $("#myvname").val() +
    '№' + (productData[0].pconfig.dns == null ? '' : productData[0].pconfig.dns) + '№' + (productData[0].pconfig.cpuunits == null ? '' : productData[0].pconfig.cpuunits) + '№' + (productData[0].pconfig.cpulimit == null ? '' : productData[0].pconfig.cpulimit) + '№' + $("#vram").val();
    $("#sdetail").val(s);
    configDetails = 'CPU数量：' + $("#vcpu").val() + ' CPUs<br/>突发内存大小：' + $("#vram").val() + ' MB<br/>保证内存大小：' + $("#vassureram").val() + ' MB<br/>硬盘容量：' + $("#vdisk").val() + ' GB<br/>操作系统：' + $("#os").val();
}
function orderConfig() {
    var discount = parseFloat(productData[0].discount);
    var ram = parseFloat(productData[0].pconfig.ram), assureram = parseFloat(productData[0].pconfig.assureram), disk = parseFloat(productData[0].pconfig.disk), cpu = parseFloat(productData[0].pconfig.cpu);
    var disk_max = parseFloat(productData[0].pupgrade.disk_max), disk_price = parseFloat(productData[0].pupgrade.disk_price), disk_step = parseFloat(productData[0].pupgrade.disk_step);
    var cpu_max = parseFloat(productData[0].pupgrade.cpu_max), cpu_price = parseFloat(productData[0].pupgrade.cpu_price), cpu_step = parseFloat(productData[0].pupgrade.cpu_step);
    var ram_max = parseFloat(productData[0].pupgrade.ram_max), ram_price = parseFloat(productData[0].pupgrade.ram_price), ram_step = parseFloat(productData[0].pupgrade.ram_step);
    var assureram_max = parseFloat(productData[0].pupgrade.assureram_max), assureram_price = parseFloat(productData[0].pupgrade.assureram_price), assureram_step = parseFloat(productData[0].pupgrade.assureram_step);
    $.post("?c=module&productid=" + productData[0].pid + "&show=text&caction=getserver&sid=" + productData[0].pconfig.server_id + "&t=" + new Date(), function (data) {
        if (data.split('|')[0] == '-1') {
            $("#OrderConfig").html('<div class="ui-state-highlight ui-corner-all" style="padding: 10px;margin-top:168px;text-align:center;"><strong>远程服务器返回错误:(500)内部服务器错误，可能是由于模块接口参数设置错误，请与客服联系！</strong></div>');
            $(".ui-dialog-buttonset button").eq(0).remove();
            return;
        }
        var jsonServers = $.parseJSON(data);
        var hsid = 0, hsip = 0;
        for (var i = 0, len = jsonServers.length; i < len; i++) {
            var objserver = jsonServers[i];
            if (objserver.ip == '0') {
                $("#OrderConfig").html('<div class="ui-state-highlight ui-corner-all" style="padding: 10px;margin-top:168px;text-align:center;"><strong>VPS主机没有可用的IP，请与客服联系！</strong></div>');
                $(".ui-dialog-buttonset button").eq(0).remove();
                return;
            }
            var serverRam = parseFloat(objserver.ram) * 1000;
            var serverDisk = parseFloat(objserver.disk);
            if (serverRam > assureram) {
                hsid = objserver.id;
                hsip = objserver.ip;
                if (ram_max > serverRam) ram_max = serverRam;
                if (assureram_max > serverRam) assureram_max = serverRam;
                if (disk_max > serverDisk) disk_max = serverDisk;
                break;
            }
        }
        if (hsid == 0) {
            $("#OrderConfig").html('<div class="ui-state-highlight ui-corner-all" style="padding: 10px;margin-top:168px;text-align:center;"><strong>此产品已销售完毕，请选择其它产品，如需帮助请与客服联系！</strong></div>');
            $(".ui-dialog-buttonset button").eq(0).remove();
            return;
        }

        var str = '<p><strong>帐户信息</strong>：帐户余额：<strong>' + userData[0].balance + '</strong> ' + userData[0].currency;
        if (discount < 1) str += '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong>帐户优惠</strong>：<strong style="color:#0000FF">' + (discount * 100 / 10) + '</strong>折';
        str += '<br />&nbsp;<br />产品名称：<strong>『' + productData[0].pname + '』</strong><br /><input type="hidden" name="server_id" id="server_id" value="' + hsid + '"/>' +
    '<input type="hidden" name="sdetail" id="sdetail" value="0"/><input type="hidden" name="os" id="os" value="0"/><input type="hidden" name="hidIP" id="hidIP" value="' + hsip + '"/>';
        str += '<div id="sc" style="width:628px;">' +
    '<p>CPU核心数：<input type="text" name="vcpu" id="vcpu"/><span></span></p><div id="sl_cpu"></div>' +
    '<p>突发内存大小(MB)：<input type="text" name="vram" id="vram"/><span></span></p><div id="sl_ram"></div>' +
    '<p>保证内存大小(MB)：<input type="text" name="vassureram" id="vassureram"/><span></span></p><div id="sl_assureram"></div>' +
    '<p>硬盘容量(GB)：<input type="text" name="vdisk" id="vdisk"/><span></span></p><div id="sl_disk"></div>' +
    ' <p>主机别名：<input type="text" name="myvname" id="myvname" value="MyServer" class="text"/>　VPS操作系统：<button  id="serveros" type="button"><span class="ui-button-text">选择操作系统</span></button></p></div><br/>';
        timeCycle = productData[0].psconfig.time_cycle == undefined ? '0' : productData[0].psconfig.time_cycle;
        var pcycles = productData[0].pprice.cycle.split(',');
        var pcprice = productData[0].pprice.cprice.split(',');
        var pp1 = 0, pp2 = 0;
        switch (productData[0].pprice.pmothod) {
            case "1":
                str += '付款周期：';
                for (i = 0; i < pcycles.length; i++) {
                    if (pcprice[i] != '0') {
                        if (pp1 == 0) pp1 = parseFloat(pcprice[i]) / parseInt(pcycles[i]);
                        else {
                            pp2 = (parseFloat(pcprice[i]) / parseInt(pcycles[i]) / pp1 * 10).toFixed(1);
                        }
                        str += '<input type="radio" name="baseprice" value="' + pcycles[i] + '_' + pcprice[i] + '_1" id="pcy' + pcycles[i] + '" /><label for="pcy' + pcycles[i] + '">' + getTimeCycleSuffix(pcycles[i], timeCycle, 0) + (pp2 != 0 ? '(' + pp2 + '折)' : '') + '</label>　';

                    }
                }
                break;
            case "2":
                str += '一次性付款：<input type="radio" name="baseprice" value="1_' + productData[0].pprice.onetime + '_2"/>起始价:' + productData[0].pprice.onetime + '元';
                break;
            case "3":
                str += '免费试用：<input type="radio" name="baseprice" value="0_' + productData[0].pprice.free + '_3"/>试用' + productData[0].pprice.free + '天';
                break;
        }

        $("#OrderConfig").html(str);
        // $('<div style="float:left;padding:15px 0px 0px 15px;"><strong>总价格：</strong><strong id="normalPrice" style="color:#0000FF;"></strong><span id="finalPrice"></span></div>').insertBefore(".ui-dialog-buttonset");
        if ($("#divprice").length > 0) { $("#divprice").remove(); }
        $("#swin").next().prepend('<div style="float:left;padding:15px 0px 0px 15px;" id="divprice"><strong>总价格：</strong><strong id="normalPrice" style="color:#0000FF;"></strong><span id="finalPrice"></span></div>');

        $("#sc p").css("padding-top", "15px");
        $("#sc input").attr("readonly", "readonly").css("border", "0px").css("width", "80px").css("font-weight", "bold");
        $("#sc button").css("color", "#000000").css("margin-right", "18px").button();
        $("#couponcode,#myvname").removeAttr("readonly").css("border", "1px solid #B8B8B8").css("background", "#FFFFFF");
        $("#myvname").css("width", "138px");

        var cpup = cpu_price / cpu_step;
        var ramp = ram_price / ram_step;
        var diskp = disk_price / disk_step;
        var assureramp = assureram_price / assureram_step;

        $("#sc span:eq(0)").html("　" + cpup.toFixed(2) + "元/核，最多" + cpu_max + "核");
        $("#sc span:eq(1)").html(ramp.toFixed(2) + "元/MB,最多" + ram_max + "MB");
        $("#sc span:eq(2)").html(assureramp.toFixed(2) + "元/MB,最多" + assureram_max + "MB");
        $("#sc span:eq(3)").html(diskp.toFixed(2) + "元/GB,最多" + disk_max + "GB");


        $("#OrderConfig p").css("line-height", "25px");
        $("#OrderConfig label").css({ "margin-right": "18px" });
        $("#OrderConfig input[name='baseprice']:first").prop("checked", "checked");

        billingMothod = productData[0].pprice.pmothod;
        sliderIt(cpu, cpu_max, cpu_price, cpu_step, ram, ram_max, ram_price, ram_step, disk, disk_max, disk_price, disk_step, assureram, assureram_max, assureram_price, assureram_step);
        updatePrice(cpu, cpu_price, cpu_step, ram, ram_price, ram_step, disk, disk_price, disk_step, assureram, assureram_price, assureram_step);

        $("#OrderConfig input[name='baseprice']").click(function () {
            updatePrice(cpu, cpu_price, cpu_step, ram, ram_price, ram_step, disk, disk_price, disk_step, assureram, assureram_price, assureram_step);
        });
        $(".ui-dialog-buttonset button:first").click(function () {
            if ($("#os").val() == "0") {
                $("#suwin").dialog("close");
                alert("请选择VPS要安装的操作系统！");
                return;
            } else if ($("#hidIP").val() == "0") {
                $("#suwin").dialog("close");
                alert("系统分配服务器IP出错，请刷新页面重试！");
                return;
            }
        });


        $(".ui-dialog-buttonset span").eq(0).click(function () {
            suwin.dialog({ title: "购买确认", autoOpen: false, resizable: false, width: 399, height: 368, modal: true, buttons: { "确定购买": function () { checkout(1); }, "继续配置": function () { $(this).dialog("close"); }, "在线充值": function () { window.open('?c=finance', '_blank'); } } }).dialog("open");
        });

        $("#myvname").change(function () { setService(); });
        $("#serveros").click(function () {
            $("#suwin").html(ajaxLoading("正在加载系统模板，请稍候......"));
            $("#suwin").dialog({ title: "系统模板", autoOpen: false, resizable: false, width: 380, height: 350, modal: true, buttons: { "关 闭": function () { $(this).dialog("close"); } } }).dialog("open");
            $.post("?c=module&productid=" + productData[0].pid + "&show=text&caction=listos&sid=" + hsid + "&t=" + new Date(), function (data) {
                var json = $.parseJSON(data);
                var vOS = "<div id='divos'>";
                var arrOs = json.data;
                for (var i = 0, len = arrOs.length; i < len; i++) {
                    vOS += '<p><input type="radio" name="rados" id="rados' + i + '" value="' + arrOs[i].name + '"/><label for="rados' + i + '">' + arrOs[i].name + '</label></p>';
                }
                vOS += "</div>";
                $("#suwin").html(vOS);
                $("input[name=rados][value='" + $("#os").val() + "']").attr("checked", "checked");

                $("input[name=rados]").click(function () {
                    $("#serveros span").html($(this).val());
                    $("#os").val($(this).val());
                    $("#suwin").dialog("close");
                    setService();
                });

            });
        });
    });
}

function updatePrice(mincpu, cpu_price, cpu_step, minram, ram_price, ram_step, mindisk, disk_price, disk_step, minassureram, assureram_price, assureram_step) {
    var pmothod = $("#OrderConfig input[name='baseprice']:checked").val().split('_');
    var basePrice = parseFloat(pmothod[1]);
    billingCycle = parseInt(pmothod[0]);
    if (billingCycle == 0) basePrice = 0;

    var vcpu = $("#vcpu"), vram = $("#vram"), vdisk = $("#vdisk"), vassureram = $("#vassureram");
    var vramsize = parseFloat(vram.val()), vassureramsize = parseFloat(vassureram.val());
    normalPrice = (parseFloat(vcpu.val()) - mincpu) * (cpu_price / cpu_step);

    normalPrice += (vassureramsize - minassureram) * (assureram_price / assureram_step);
    normalPrice += (parseFloat(vdisk.val()) - mindisk) * (disk_price / disk_step);
    if (vramsize > vassureramsize) {
        normalPrice += (vramsize - minram) * (ram_price / ram_step);
    }
    normalPrice = basePrice + normalPrice * billingCycle;
    if (normalPrice < basePrice) normalPrice = basePrice;
    var discount = parseFloat(productData[0].discount);
    finalPrice = normalPrice * discount;
    if (normalPrice > finalPrice) {
        $("#normalPrice").html('<strike>' + normalPrice.toFixed(2) + '</strike>');
        $("#finalPrice").html('<strong style="margin-left:18px">帐户优惠价(' + (discount * 100 / 10) + '折)：</strong><strong style="color:#0000FF;">' + finalPrice.toFixed(2) + '</strong> ' + userData[0].currency);
    }
    else $("#normalPrice").html(finalPrice.toFixed(2) + ' ' + userData[0].currency);
    setService();
}
function sliderIt(mincpu, maxcpu, cpu_price, cpu_step, minram, maxram, ram_price, ram_step, mindisk, maxdisk, disk_price, disk_step, minassureram, maxassureram, assureram_price, assureram_step) {
    var vcpu = $("#vcpu"), vram = $("#vram"), vdisk = $("#vdisk"), vassureram = $("#vassureram");
    $("#sl_cpu").slider({
        range: "min",
        value: mincpu,
        min: 0,
        max: maxcpu,
        step: cpu_step,
        slide: function (event, ui) {
            vcpu.val(ui.value);
        },
        stop: function (event, ui) {
            if (parseInt(ui.value) < mincpu) {
                $("#sl_cpu").slider("value", mincpu);
                vcpu.val(mincpu);
            }
            updatePrice(mincpu, cpu_price, cpu_step, minram, ram_price, ram_step, mindisk, disk_price, disk_step, minassureram, assureram_price, assureram_step);
        }
    });
    vcpu.val(mincpu);
    $("#sl_cpu").slider("value", mincpu);

    $("#sl_ram").slider({
        range: "min",
        value: minram,
        min: 0,
        max: maxram,
        step: ram_step,
        slide: function (event, ui) {
            vram.val(ui.value);
        },
        stop: function (event, ui) {
            if (parseInt(ui.value) < minram) {
                $("#sl_ram").slider("value", minram);
                vram.val(minram);
            }
            var ramT = parseFloat(vram.val()), assureramT = parseFloat(vassureram.val());
            if (assureramT > ramT) {
                if (maxram <= assureramT) {
                    vram.val(maxram);
                    $("#sl_ram").slider("value", maxram);
                } else {
                    vram.val(assureramT);
                    $("#sl_ram").slider("value", assureramT);
                }
            }
            updatePrice(mincpu, cpu_price, cpu_step, minram, ram_price, ram_step, mindisk, disk_price, disk_step, minassureram, assureram_price, assureram_step);
        }
    });
    vram.val(minram);
    $("#sl_ram").slider("value", minram);

    $("#sl_assureram").slider({
        range: "min",
        value: minassureram,
        min: 0,
        max: maxassureram,
        step: assureram_step,
        slide: function (event, ui) {
            vassureram.val(ui.value);
        },
        stop: function (event, ui) {
            if (parseInt(ui.value) < minassureram) {
                $("#sl_assureram").slider("value", minassureram);
                vassureram.val(minassureram);
            }
            var ramT = parseFloat(vram.val()), assureramT = parseFloat(vassureram.val());
            if (assureramT > ramT) {
                if (maxram <= assureramT) {
                    vram.val(maxram);
                    $("#sl_ram").slider("value", maxram);
                } else {
                    vram.val(assureramT);
                    $("#sl_ram").slider("value", assureramT);
                }
            }
            updatePrice(mincpu, cpu_price, cpu_step, minram, ram_price, ram_step, mindisk, disk_price, disk_step, minassureram, assureram_price, assureram_step);
        }
    });
    vassureram.val(minassureram);
    $("#sl_assureram").slider("value", minassureram);

    $("#sl_disk").slider({
        range: "min",
        value: mindisk,
        min: 0,
        max: maxdisk,
        step: disk_step,
        slide: function (event, ui) {
            vdisk.val(ui.value);
        },
        stop: function (event, ui) {
            if (parseInt(ui.value) < mindisk) {
                $("#sl_disk").slider("value", mindisk);
                vdisk.val(mindisk);
            }
            updatePrice(mincpu, cpu_price, cpu_step, minram, ram_price, ram_step, mindisk, disk_price, disk_step, minassureram, assureram_price, assureram_step);
        }
    });
    vdisk.val(mindisk);
    $("#sl_disk").slider("value", mindisk);
}
function getTimeCycleSuffix(billingCycle, timeCycle, tag) {
    var cycleSuffix = '';
    if (billingCycle == 0) {
        switch (timeCycle) {
            case '1': cycleSuffix = '天'; break;
            case '2': cycleSuffix = '小时'; break;
            default:
                cycleSuffix = '月';
                if (tag == 1) cycleSuffix = '个月';
                break;
        }
    }
    else {
        if (timeCycle == '0') {
            switch (billingCycle) {
                case '1': cycleSuffix = '月'; break;
                case '3': cycleSuffix = '季'; break;
                case '6': cycleSuffix = '半年'; break;
                case '12': cycleSuffix = '年'; break;
                case '24': cycleSuffix = '2年'; break;
                default: cycleSuffix = billingCycle + '个月'; break;
            }
        }
        else if (timeCycle == '1') {
            switch (billingCycle) {
                case '1': cycleSuffix = '天'; break;
                case '7': cycleSuffix = '周'; break;
                case '15': cycleSuffix = '半月'; break;
                case '30': cycleSuffix = '月'; break;
                case '90': cycleSuffix = '季'; break;
                case '365': cycleSuffix = '年'; break;
                default: cycleSuffix = billingCycle + '天'; break;
            }
        }
        else {
            switch (billingCycle) {
                case '1': cycleSuffix = '小时'; break;
                case '24': cycleSuffix = '天'; break;
                case '168': cycleSuffix = '周'; break;
                default: cycleSuffix = billingCycle + '小时'; break;
            }
        }
    }
    return cycleSuffix;
}
orderConfig();
