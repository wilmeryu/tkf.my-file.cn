﻿/// <reference path="jquery.min.js" />

function baseConfig() {
    
    var product_data = productData;
    var vpconfig = product_data[0].pconfig;
    var vpupgrade = product_data[0].pupgrade;
    var server_id = '', server_priority = '', dns = '', ram = '512', disk = '2', cpu = '2', assureram = '256', cpuunits = '1000', cpulimit='50';
    var disk_max = '100', disk_price = '1', disk_step = '1', cpu_max = '8', cpu_price = '5', cpu_step = '1', ram_max = '2000', ram_price = '2', ram_step = '1',assureram_max = '1500' ,assureram_price = '1' ,assureram_step = '1';
    if (vpconfig != null && vpconfig != "") {
      server_id=vpconfig.server_id.split(',');
      server_priority = vpconfig.server_priority.split(',');
      dns=vpconfig.dns;
      ram=vpconfig.ram;
      disk=vpconfig.disk;
      cpu = vpconfig.cpu;
      assureram = vpconfig.assureram;
      cpuunits = vpconfig.cpuunits;
      cpulimit = vpconfig.cpulimit;
     }
      if (vpupgrade != null && vpupgrade != "") {
         disk_max=vpupgrade.disk_max;
         disk_price=vpupgrade.disk_price;
         disk_step=vpupgrade.disk_step;
         cpu_max=vpupgrade.cpu_max;
         cpu_price=vpupgrade.cpu_price;
         cpu_step=vpupgrade.cpu_step;
         ram_max=vpupgrade.ram_max;
         ram_price=vpupgrade.ram_price;
         ram_step = vpupgrade.ram_step;
         assureram_max = vpupgrade.assureram_max;
         assureram_price = vpupgrade.assureram_price;
         assureram_step = vpupgrade.assureram_step;
      }
     var str = '<fieldset style="border:1px solid #ccc; padding:0px 10px;margin:8px 0px;width:80%"><legend><strong>服务器配置<span style="color:red">(注：优先级只对选中的项生效，其数值越小，优先级越高)</span></strong></legend>' +
    '<div id="divscroll"><table width="100%" style="margin-top:5px;"><tr style="background-color:#E7E7E7;height:22px;line-height:22px;" align="center" >' +
    '<th width="8%"> 选择 </th><th width="30%">服务器名称</th><th width="10%">优先级</th></tr><tbody id="tabbody">' +
    '<tr align="center"><td style="height:80px;" colspan="3"> Loading...... </td></tr>' +
    '</tbody></table></div></fieldset>' +
    '<p style="margin:15px 0px 10px 0px;" id="pvpsplan"><strong>VPS基本套餐配置</strong>：<input type="hidden" name="config_server_id" id="config_server_id" value="' + server_id + '"><input type="hidden" name="config_server_priority" id="config_server_priority" value="' + server_priority + '"><br/>CPU:<input style="width:80px;" class="text" name="config_cpu" value="' + cpu + '">核　保证内存:<input style="width:80px;" class="text" name="config_assureram" value="' + assureram + '">MB　' +
    '突发内存:<input style="width:80px;" name="config_ram" class="text" value="' + ram + '">MB　硬盘:<input style="width:80px;" class="text" name="config_disk" value="' + disk + '">GB</p>' +
    '<p style="margin-bottom:15px;">保证CPU单元：<input style="width:80px;" class="text" name="config_cpuunits" value="' + cpuunits + '">　最大限制CPU(%)：<input style="width:80px;" class="text" name="config_cpulimit" value="' + cpulimit + '">　DNS服务器:<input size="20" class="text" name="config_dns" value="' + dns + '"></p><p id="pvpsupgrade"><strong>升级配置说明</strong>：<br />' +
    '<strong>保证内存</strong>：每滑动<input style="width:80px;"class="text" name="upgrade_assureram_step" value="' + assureram_step + '">MB <input style="width:80px;" class="text" name="upgrade_assureram_price" value="' + assureram_price + '">元，最多<input style="width:80px;" class="text" name="upgrade_assureram_max" value="' + assureram_max + '">MB　' +
    '<br/><strong>突发内存</strong>：每滑动<input style="width:80px;" class="text" name="upgrade_ram_step" value="' + ram_step + '">MB <input style="width:80px;" class="text" name="upgrade_ram_price" value="' + ram_price + '">元，最多<input style="width:80px;" class="text" name="upgrade_ram_max" value="' + ram_max + '">MB' +
    '<br/><strong>CPU核数</strong>：每滑动<input style="width:80px;" class="text" name="upgrade_cpu_step" value="' + cpu_step + '">核 <input style="width:80px;" class="text" name="upgrade_cpu_price" value="' + cpu_price + '">元，最多<input style="width:80px;" class="text" name="upgrade_cpu_max" value="' + cpu_max + '">核　' +
    '<br/><strong style="margin-left:26px;">硬盘</strong>：每滑动<input style="width:80px;" class="text" name="upgrade_disk_step" value="' + disk_step + '">GB <input style="width:80px;" class="text" name="upgrade_disk_price" value="' + disk_price + '">元，最多<input style="width:80px;" class="text" name="upgrade_disk_max" value="' + disk_max + '">GB</p>';

   
     $.post("?c=module&productid=" + product_data[0].pid + "&show=text&caction=listserver&t=" + new Date(), function (data) {
         
         if (data == "-999") {
             $("#ProductConfig").html("<div style='color:red;font-size:14px; text-align:center;margin-top:50px;'>远程服务器返回错误: (401) 未经授权，请检查模块参数中OpenVZ登录名、登录密码是否正确！</div>");
             return;
         } else if (data == "-888") {
             $("#ProductConfig").html("<div style='color:red;font-size:14px; text-align:center;margin-top:50px;'>无法连接到远程服务器，请检查模块参数中OpenVZ面板IP是否正确！</div>");
             return;
         }
         $("#ProductConfig").html(str);
         var json = $.parseJSON(data);
         var Servers = json.data;
         var trs = '';
         for (var i = 0, len = Servers.length; i < len; i++) {
             var text = Servers[i].description;
             var pval = ' value="0"', chk = '';
             if (text == null || text.length <= 0) {
                 text = Servers[i].host;
             }
             if (server_id != '') {
                 for (var j = 0, vlen = server_id.length; j < vlen; j++) {
                     if (Servers[i].id == server_id[j]) {
                         chk = ' checked="checked"';
                         pval = ' value="' + server_priority[j] + '" id="priority' + server_id[j] + '"';
                     }
                 }
             }
             trs += '<tr align="center"><td style="width:300px"><input type="checkbox" name="server" id="server' + i + '" ' + chk + '/>' +
            '</td><td><label for="server' + i + '">' + text + '</label></td><td><input class="text" type="text" style="width:40px;" ' + pval + ' name="' + Servers[i].id + '"/></td></tr>';
         }
         $("#tabbody").html(trs);




         $("#divscroll input[type='text']").change(function () {

             var obj = $(this);
             var exp = /^[0-9]\d*$/;
             if (!exp.test(obj.val())) {
                 alert("请输入整数！");
                 obj.val(0);
                 obj.focus();
                 return;
             }
             var chk = obj.parent().parent().find("input[name=server]");
             if (chk.attr("checked") != "checked") {
                 if (confirm("您还没选择该服务器，确定选择该服务器？")) {
                     chk.attr("checked", "checked");
                     obj.attr("id", "priority" + chk.val());
                 } else {
                     obj.removeAttr("id");
                     obj.val(0);
                     return;
                 }
             }
             if (chk.attr("checked") == "checked") {
                 setservers();
             }

         });
         $("#divscroll input[name=server]").click(function () {
             var obj = $(this);
             var priority = obj.parent().parent().find("input[type=text]");
             if (obj.attr("checked") !== "checked") {
                 obj.attr("checked", "checked");
                 priority.attr("id", "priority" + obj.val());
             }
             else {
                 priority.removeAttr("id");
                 priority.val(0);
             }
             setservers();
         });

         function setservers() {
             var arrp = [], arrserver = [], temp = 0, ds = 0;
             $("#divscroll input[type=text][id^='priority']").each(function () {
                 arrp.push(parseInt($(this).val()));
                 arrserver.push(parseInt($(this).attr("name")));
             });
             for (var i = 0, n = arrp.length; i < n - 1; i++) {
                 for (var j = 0; j < n - i - 1; j++) {
                     if (arrp[j] > arrp[j + 1]) {
                         temp = arrp[j];
                         arrp[j] = arrp[j + 1];
                         arrp[j + 1] = temp;

                         ds = arrserver[j];
                         arrserver[j] = arrserver[j + 1];
                         arrserver[j + 1] = ds;
                     }
                 }
             }

             $("#config_server_id").val(arrserver.join(','));
             $("#config_server_priority").val(arrp.join(','));

         }


     });
   
//    $("#pvpsplan input,#pvpsupgrade input").focus(function () {
//        if ($("#config_server_id").val() == "0") {
//            alert("请配置好服务器后再配置该项！");
//            return;
//        }
//    });
    if ($("#divscroll").height() > 230)
        $("#divscroll").css("overflowY", "scroll").height("230px"); 
   
        //if (productData[0].pid == '0') product_data = $.parseJSON('[{"pconfig":{"cpu":"Intel® Xeon® E7-8870","ram":"16GB DDR3 ECC","disk":"4x1TB Sata3 Raid10","rack":"1U机架式","motherboard":"Intel® S5520URT","dc":"美国He机房","bandwidth":"10M不限流量","ip":"1","firewall":"10G硬防","buydown":"年付即送产权","other":""},"pupgrade":{"des":"增加内存：每1GB 50元/月<br />增加硬盘：500G 80元/月　1TB 100元/月<br />增加IP：每个 50元/月<br />增加带宽：每5M 100元/月<br />"}}]');
  

}
baseConfig();