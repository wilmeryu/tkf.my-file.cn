﻿/// <reference path="jquery.min.js" />
function serviceConfig() {
    //'<input type="hidden" name="serviceName" id="serviceName" value=' + service_data[0].sconfig.serviceName + '>
    var service_data = serviceData;
    var str = '<input type="hidden" name="startpwd" id="startpwd" value=' + service_data[0].sconfig.startpwd + '><input type="hidden" name="ssid" id="ssid" value=' + service_data[0].sconfig.ssid + '><input type="hidden" name="username" id="username" value=' + service_data[0].sconfig.username + '><input type="hidden" name="server_id" id="server_id" value=' + service_data[0].sconfig.server_id + '>' +
    '<strong>资源配置</strong>：';

    $.post("?c=module&serviceid=" + service_data[0].sid + "&show=text&caction=freeip&sid=" + service_data[0].sconfig.server_id + "&vid=" + service_data[0].ssid + "&t=" + new Date(), function (data) {
        if (data.substr(0, 1) != '{') {
            $("#ServiceConfig").html('<div class="ui-state-highlight ui-corner-all" style="padding: 10px;margin:10px;text-align:center;"><strong>远程服务器返回错误:(500)内部服务器错误，可能是由于模块接口参数设置错误，请与客服联系！</strong></div>');
            var a = $(".ui-dialog-buttonset").eq(1);
            a.find("button").eq(0).remove();
            return;
        }
        var arr = data.split('№');
        var jsonIP = $.parseJSON(arr[0]);
        var jsonVps = $.parseJSON(arr[1]);
        var jsonassureram = $.parseJSON(arr[2]);
        var vps = jsonVps.data;
        var arrIP = jsonIP.data;
        var strIP = '<option value="' + service_data[0].sconfig.selIP + '" selected="selected">' + service_data[0].sconfig.selIP + '</option>';
        for (var i = 0, len = arrIP.length; i < len; i++) {
            var ip = arrIP[i].address;
            strIP += '<option value="' + ip + '">' + ip + '</option>';
        }
        str += 'CPU核数：<input type="text" size="2" name="cpu" id="cpu" value="' + vps.cpus + '">核' +
             '　突发内存：<input size="6" name="ram" id="ram" value="' + vps.memory + '">MB' +
             '　保证内存：<input size="6" name="assureram" id="assureram" value="' + parseFloat(jsonassureram.soft_limit) / 256 + '">MB' +
             '　硬盘：<input size="6" name="disk" id="disk" value="' + parseFloat(vps.diskspace) / 1000 + '">GB' +
             '　<p style="margin:8px 0;padding-left:70px;">保证CPU单元：<input size="6" name="cpuunits" id="cpuunits" value="' + vps.cpu_units + '">' +
             '　最大限制CPU(%)：<input size="6" name="cpulimit" id="cpulimit" value="' + vps.cpu_limit + '"></p>' +
               '<p style="margin:15px 0"><strong>网络参数配置</strong>：' +
              'IP地址：<select name="selIP" id="selIP">' + strIP + '</select>' +
              '　主机名：<input size="2" name="hostname" id="hostname" value="' + vps.host_name + '" style="width:120px">' +
              '　DNS服务器：<input size="2" name="dns" id="dns" value="' + (vps.nameserver == null ? "" : vps.nameserver) + '" style="width:150px"></p>' +
        //  '　搜索域名：<input size="2" name="searchDomain" id="searchDomain" value="' + (vps.search_domain == null ? '' : vps.search_domain) + '" style="width:150px"></p>' +
              '<p style="margin:25px 0"><strong>实时信息</strong>：<span id="spanvps">Loading......</span></p>'
        $("#ServiceConfig").html('&nbsp;<br /><p style="line-height:30px">' + str + '</p>');
        $("#selIP").val(vps.ip_address);
    });

    $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&caction=statist&id=" + serviceData[0].ssid + "&t=" + new Date(), function (data) {
        var json = $.parseJSON(data);
        var arr = json.data;

        var vcpu = arr[0].value.text == undefined ? "0%" : arr[0].value.text;

        var txt = 'CPU负载：' + vcpu + '&nbsp;&nbsp;&nbsp;<p style="margin-top:15px;padding-left:54px;">内存使用情况：已使用';
        var vtxt = arr[2].value.text;
        var vindex = vtxt.indexOf(',');
        var vused = vtxt.substring(vindex + 1, vtxt.indexOf('B') + 1);
        var vfree = vtxt.substring(vtxt.indexOf('/') + 1, vtxt.lastIndexOf('B') + 1);

        txt += vused + ' ，剩余 ' + vfree + ' &nbsp;</p><p style="margin-top:15px;padding-left:54px;">磁盘使用情况：已使用';
        vtxt = arr[1].value.text;
        vindex = vtxt.indexOf(',');
        //  vpercent = vtxt.substring(0, vindex);
        vused = vtxt.substring(vindex + 1, vtxt.indexOf('B') + 1);
        vfree = vtxt.substring(vtxt.indexOf('/') + 1, vtxt.lastIndexOf('B') + 1);
        txt += vused + ' ，剩余 ' + vfree + '</p>';
        $("#spanvps").html(txt);
    });
             
      
   
   
}

serviceConfig();