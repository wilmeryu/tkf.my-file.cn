﻿/// <reference path="jquery-vsdoc.js" />
/// <reference path="jquery-ui.min.js" />
var timeCycle = productData[0].psconfig.time_cycle == undefined ? '0' : productData[0].psconfig.time_cycle;
function _view() {
    var vstatus = serviceData[0].sstatus;
    if (vstatus == '-2') {
        $("#ViewService").html("<span style='color:green;font-size:14px;'>您开通VPS主机的方式为人工手动开通，请联系管理员尽快为您开通VPS主机服务！</span>");
        return;
    }
    var vpsid = serviceData[0].ssid;
    var renewdata = getUnixTime(parseInt(serviceData[0].etime));
    renewdata = renewdata.substring(0, renewdata.indexOf(' '));
    var str = '<table width="100%" border="0" cellspacing="0" cellpadding="0" class="table grid"><thead><tr><th style="text-align:right">VPS主机信息统计：</th><th class="full"><a href="javascript:void(0);" id="afreshstatist" style="font-weight:normal">『刷新主机信息』</a></th></tr></thead><tbody>';
    var title = '管理我的VPS主机#' + serviceData[0].sid + '';
    $("#pageTitle").html(title);
    document.title = title;
    var statusText = serviceStatus[parseInt(vstatus) + 2];
    switch (vstatus) {
        case "3": statusText = '<strong style="color:#CC3300;">' + statusText + '</strong>'; break;
        case "4": statusText = '<strong style="color:#FF0000;">' + statusText + '</strong>'; break;
    }
    var myvpsinfo = '';
    if (vpsid == "0") {
        myvpsinfo = serviceData[0].sconfig.sdetail.split('№');
    }
    str += '<tr><td class="title">CPU负载：</td><td id="tdcpusload"><div style="height:18px;width: 218px;float:left" id="cpuload" class="ui-progressbar ui-widget ui-widget-content ui-corner-all" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><div class="ui-progressbar-value ui-widget-header ui-corner-left" style="display: none; width: 30%; "></div></div>&nbsp;&nbsp;&nbsp;0%</td></tr>' +
          '<tr><td class="title">内存使用情况：</td><td id="tdram"><div style="height:18px;width: 218px;float:left" id="cpuload" class="ui-progressbar ui-widget ui-widget-content ui-corner-all" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><div class="ui-progressbar-value ui-widget-header ui-corner-left" style="display: none; width: 30%; "></div></div>&nbsp;&nbsp;&nbsp;0%</td></tr>' +
      '<tr><td class="title">磁盘使用情况：</td><td id="tddisk"><div style="height:18px;width: 218px;float:left" id="cpuload" class="ui-progressbar ui-widget ui-widget-content ui-corner-all" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><div class="ui-progressbar-value ui-widget-header ui-corner-left" style="display: none; width: 30%; "></div></div>&nbsp;&nbsp;&nbsp;0%</td></tr></tbody></table>' +
     '<table id="tbhostinfo" width="100%" border="0" cellspacing="0" cellpadding="0" class="table grid"><thead><tr><th style="text-align:right">VPS主机基本信息：</th><th class="full">&nbsp;</th></tr></thead><tbody>' +
      '<tr><td class="title" style="text-align: right; ">主机编号：</td><td id="tdhostname">#0</td></tr>';
    if (userData[0].isAdmin == "True") {
        str += '<tr><td class="title" style="text-align: right; ">所属用户：</td><td><a href="?c=muser&uid=' + userData[0].uid + '" target="_blank">' + userData[0].uname + ' [#' + userData[0].uid + ']</a></td></tr>';
    }
     str+='<tr><td class="title" style="text-align: right; ">初始密码：</td><td><span style="margin-right:31px;">' + serviceData[0].sconfig.startpwd + '</span><input id="btnSendPwd" type="button" class="submit" value="修改密码"></td></tr>' +
      '<tr><td class="title" style="text-align: right; ">操作系统：</td><td><span id="spanos">' + (vpsid == '0' ? myvpsinfo[3] : '') + '</span>　　<input type="button" id="reinstal" class="submit" value="重装操作系统"></td></tr>' +
     '<tr><td class="title" style="text-align: right; ">IP地址：</td><td id="tdip">' + (vpsid == '0' ? myvpsinfo[1] : '') + '</td></tr>' +
     '<tr id="trdns" style="display:none;"><td class="title" style="text-align: right; ">DNS服务器：</td><td id="tddns">' + ((vpsid == '0' ? myvpsinfo[8] : '')) + '</td></tr>' +
     '<tr><td class="title" style="text-align: right; ">主机配置：</td><td><span id="spanhostinfo">CPU：' + serviceData[0].sconfig.cpu + ' 核　突发内存：' + serviceData[0].sconfig.ram + ' MB　保证内存：<span id="spanmaxram">' + serviceData[0].sconfig.assureram + '</span> MB　硬盘：<span id="spanmaxdisk">' + serviceData[0].sconfig.disk + '</span> GB</span>　　<input type="button" value="升级配置" id="btnUpgrade" class="submit"></td></tr>' +
     '<tr><td class="title" style="text-align: right; ">状态图表：</td><td><span id="spancharttip"></span><span id="spanchart"><a href="javascript:void(0);" id="acpuchart">『查看CPU状态图』</a>&nbsp;&nbsp;&nbsp;<a href="javascript:void(0);" id="adiskchart">『查看磁盘状态图』</a>&nbsp;&nbsp;&nbsp;<a href="javascript:void(0);" id="aramchart">『查看内存状态图』</a></span></td></tr>' +
     '<tr><td class="title" style="text-align: right; ">续费价格：</td><td><b>' + serviceData[0].sprice + ' ' + userData[0].currency + '</b> / ' + getTimeCycleSuffix(serviceData[0].spcycle, timeCycle, 1) + '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;帐户余额： ' + parseFloat(userData[0].balance).toFixed(2) + ' ' + userData[0].currency + '</td></tr>' +
     '<tr><td class="title" style="text-align: right; ">到期时间：</td><td>' + renewdata + '&nbsp;&nbsp;&nbsp;<input id="autorenew" type="checkbox" ' + (serviceData[0].autorenew == '0' ? 'checked="checked"' : '') + '/><label for="autorenew">自动续费</label>&nbsp;&nbsp;&nbsp;&nbsp;<a href="javascript:void(0);"  onclick="_renew()">『马上续费』</a></td></tr>' +
     '<tr><td class="title" style="text-align: right; ">服务状态：</td><td>' + statusText + '</td></tr>' +
      '<tr><td class="title" style="text-align: right; ">主机状态：</td><td><span id="spanstate">Loading...</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="javascript:void(0);" id="btnfresh" style="display:none;">『刷新状态』</a></td></tr>' +
     '<tr><td class="title" style="text-align: right; ">管理操作：</td><td id="tdVpsOperat"><input type="button" class="submit" value="开机"  onclick="ControlServer(' + vpsid + ',0,\'启动\')"/>　　<input name="shutdown" type="button" class="submit" value="关机" onclick="ControlServer(' + vpsid + ',1,\'关闭\')"/>　　<input type="button" class="submit" value="重启" name="reboot" onclick="ControlServer(' + vpsid + ',2,\'重启\')"/></td></tr>' +
      '</tbody></table>';
    if (vstatus == "-1") {
        $("#ViewService").html(str);
        $("#ViewService a,#ViewService input[type=button]").hide();
        $("#ViewService .title").css("text-align", "right");
        $("#spancharttip").html("服务暂未开通，无法读取状态图表信息！");
        $("#ViewService #autorenew").css("cursor", "pointer").click(function () {
            var autorenew = $(this).prop("checked") ? '0' : '1';
            setAutorenew(serviceData[0].sid, autorenew);
        });
        setTimeout('top.location.reload();', 10000);
    } else {
        var ram = 0, disk = 0, cpu = 0, assureram = 0, vpsos = '';

        $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&caction=getvps&t=" + new Date(), function (data) {
            var arrVps = data.split('|');
            if (arrVps[0] == "-1") {
                $("#ViewService").html('<div class="ui-state-highlight ui-corner-all" style="padding: 10px;margin:10px;text-align:center;"><strong>远程服务器返回错误:(500)内部服务器错误，请与客服联系！</strong></div>');
                return;
            }
            $("#ViewService").html(str);
            $("#spancharttip").html("Loading...");
            $("#spanchart").hide();

            var oneVps = $.parseJSON(arrVps[0]);
            var jsonassureram = $.parseJSON(arrVps[2]);
            cpu = parseFloat(oneVps.data.cpus);
            ram = parseFloat(oneVps.data.memory);
            disk = parseFloat(oneVps.data.diskspace) / 1000;
            assureram = parseFloat(jsonassureram.soft_limit) / 256; //保证内存
            vpsos = oneVps.data.orig_os_template;
            // $("#spanpwd").html(arrVps[3]);
            $("#spanos").html(oneVps.data.orig_os_template);
            $("#btnSendPwd").click(function () { showPwdWin(vpsid, arrVps[3], arrVps[4]); });
            $("#reinstal").click(function () { showInstalWin(vpsos, arrVps[3], arrVps[4]); });
            $("#btnUpgrade").click(function () { showUpgradeWin(renewdata, cpu, assureram, ram, disk); });
           
            $("#tdhostname").html('#<strong>' + vpsid + '</strong>　　别名：' + oneVps.data.host_name);
            $("#tdip").html(oneVps.data.ip_address);
            var vdns = oneVps.data.nameserver;
            if (vdns != null && vdns.length > 0) {
                $("#trdns").show();
                $("#tddns").html(vdns);
            } else {
                $("#trdns").hide();
            }
            $("#spanhostinfo").html('CPU：' + cpu + ' 核　突发内存：' + ram + ' MB　保证内存：<span id="spanmaxram">' + assureram + '</span> MB　硬盘：<span id="spanmaxdisk">' + disk + '</span> GB');
            _btnfresh(serviceData[0].ssid);
            $("#btnfresh").click(function () { _btnfresh(vpsid); });
            $("#ViewService #autorenew").css("cursor", "pointer").click(function () {
                var autorenew = $(this).prop("checked") ? '0' : '1';
                setAutorenew(serviceData[0].sid, autorenew);
            });
            //VPS状态图表信息
            var json = $.parseJSON(arrVps[1]);
            showStatist(json.data);
            $("#ViewService .title").css("text-align", "right");

            $("#afreshstatist").click(function () {
                $("#tdcpusload,#tddisk,#tdram").html("<p><img src='/images/loading.gif' alt='Loading...'/></p>");
                $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&caction=statist&t=" + new Date(), function (data) {
                    var json = $.parseJSON(data);
                    showStatist(json.data);
                });
            });
        });
    }
}


function showInstalWin(vpsos, emailchk, smschk) {
    if (serviceData[0].ssid == "0") {
        alert("当前状态不允许重装系统，请稍候重试！");
        return;
    }
    $("#suwin").html(ajaxLoading("正在加载系统模板，请稍等......"))
    $("#suwin").dialog({ title: "重装系统", autoOpen: false, resizable: false, width: 380, height: 350, modal: true, buttons: { "关 闭": function () { $(this).dialog("close"); } } }).dialog("open");

    $.post("?c=module&productid=" + productData[0].pid + "&show=text&caction=listos&sid=" + serviceData[0].sconfig.server_id + "&t=" + new Date(), function (data) {
        var json = $.parseJSON(data);
        var vOS = "<div id='divos'>";
        var arrOs = json.data;
        for (var i = 0, len = arrOs.length; i < len; i++) {
            vOS += '<p><input type="radio" name="rados" id="rados' + i + '" value="' + arrOs[i].name + '"/><label for="rados' + i + '">' + arrOs[i].name + '</label></p>';
        }
        vOS += '</div><p style="margin:15px 0px;border-top:1px solid #ccc;padding-top:5px;padding-left:3px;">新 密 码：<input type="password" id="txtinstalPwd"/>&nbsp;&nbsp;<span style="color:green;">(由字母、数字组成的6-16位字符)</span></p>' +
    '<p>确认密码：<input type="password" id="txtinstalRePwd"/></p>';

        if (userData[0].isAdmin != "True" && (emailchk != "0" || smschk != "0")) {
            vOS += '<p style="margin:10px 0px;">请选择验证方式：';
            if (smschk != "0") {
                vOS += '<input type="radio" name="radcheck" id="smscheck" value="1"/><label for="smscheck">短信验证</label>&nbsp;&nbsp;';
            }
            if (emailchk != "0") {
                vOS += '<input type="radio" name="radcheck" id="emailcheck" value="2" /><label for="emailcheck">邮箱验证</label>';
            }
            if (instalTime == 180) {
                vOS += '&nbsp;&nbsp;<input  type="button" class="submit" id="btnSendChkCode" value="发送验证码"/></p>';
            } else {
                vOS += '&nbsp;&nbsp;<input  type="button" disabled="disabled" class="submit" style="color:gray;cursor:default" id="btnSendChkCode" value="还剩' + instalTime + '秒"/></p>';
            }
            vOS += '<p style="margin:10px 0px;padding-left:4px;">验 证 码：<input type="text" id="txtchkCode"/></p>';
       }
      
        vOS += '<p style="margin-top:-10px;"><span id="chktip" style="color:green;">' + vcodeinstaltip + '</span></p>';


        $("#suwin").html(vOS);

        if (vcodeinstaltip.indexOf('@') > -1) {
            $("#emailcheck").attr("checked", "checked");
        } else {
            $("input[name=radcheck]:first").attr("checked", "checked");
        }
        var arrRad = $("input[name=rados]");
        var h = 460;
        if (emailchk != "0" || smschk != "0") {
            if (arrRad.length > 10) {
                $("#divos").css("overflowY", "scroll").height("220px");
                 h = 540;
            } else {
                h = 300 +30* parseFloat(arrRad.length);
            }
        } else {
            if (arrRad.length > 10) {
                $("#divos").css("overflowY", "scroll").height("220px");
                 h = 460;
            } else {
                h = 220 +30* parseFloat(arrRad.length);
            }
        }
        $("input[name=rados][value='" + vpsos + "']").attr("checked", "checked");

        $("#btnSendChkCode").click(function () {

            $("#btnSendChkCode").attr("disabled", "disabled").attr("value", "还剩" + instalTime + "秒").css({ "color": "gray", "cursor": "default" });
            var myTimer = setInterval(function () {
                if (instalTime > 1) {
                    instalTime -= 1;
                    $("#btnSendChkCode").attr("value", "还剩" + instalTime + "秒");
                }
                else {
                    clearInterval(myTimer);
                    instalTime = 180;
                    $("#btnSendChkCode").removeAttr("disabled").css({ "color": "white", "cursor": "pointer" }).val('发送验证码');
                }
            }, 1000);

            $("#chktip").html("<br/>正在发送验证码，请稍等......").css("color", "green");
            var chk = $("input[name=radcheck]:checked").val();
            if (chk == "1") {
                $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&action=send_sms&t=" + new Date(), function (data) {
                    if (data == "0") {
                        vcodeinstaltip = "<br/>验证码已发送到您的手机[<span style='color:red'>" + userData[0].tel + "</span>]，请查收！";
                        $("#chktip").html(vcodeinstaltip);
                        //setTimeout('$("#chktip").fadeOut("slow");', 5000);
                    } else {
                        $("#chktip").html('<br/>' + data);
                    }
                });
            } else {
                $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&action=send_email&t=" + new Date(), function (data) {
                    if (data == "0") {
                        vcodeinstaltip = "<br/>验证码已发送到您的邮箱[<span style='color:red'>" + userData[0].umail + "</span>]，请查收！";
                        $("#chktip").html(vcodeinstaltip);
                        //setTimeout('$("#chktip").fadeOut("slow");', 5000);
                    } else {
                        $("#chktip").html('<br/>' + data);
                    }
                });
            }
        });
        $("#suwin").dialog({ title: "重装系统", autoOpen: false, resizable: false, width: 500, height: h, modal: true, buttons: {
            "确认重装": function () {
                var nowOs = $("input[name=rados]:checked").val();
                var vpwd = $("#txtinstalPwd").val();
                var vrepwd = $("#txtinstalRePwd").val();
                var code = '';
                var exp = /^[A-Za-z0-9]{6,16}$/;
                if (vpwd.length <= 0 || (!exp.test(vpwd))) {
                    $("#chktip").html("<br/>请输入正确的密码！").css("color", "red");
                    $("#txtinstalPwd").val('').focus();
                    return;
                } else if (vrepwd != vpwd) {
                    $("#chktip").html("<br/>确认密码与新密码不一致！").css("color", "red");
                    $("#txtinstalRePwd").val('').focus();
                    return;
                } else if (userData[0].isAdmin != "True" && (emailchk != "0" || smschk != "0")) {
                    code = $("#txtchkCode").val();
                    if (code.length <= 0) {
                        $("#chktip").html("<br/>请输入验证码！").css("color", "red");
                        $("#txtchkCode").val('').focus();
                        return;
                    }
                }

                $("#chktip").html(ajaxLoading("正在执行操作，请稍等......")).css("color", "green");
                $("#suwin input").attr("disabled", "disabled");
                $(".ui-dialog-buttonset button:first").attr("disabled", "disabled");
                $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&caction=reinstal&os=" + nowOs + "&code=" + code + "&pwd=" + vpwd + "&repwd=" + vrepwd + "&t=" + new Date(), function (data) {
                    if (data == "0") {
                        showTipWin('重装成功！',1);
                    } else {
                        $("#chktip").html('<br/>' + data).css("color", "red");
                        $(".ui-dialog-buttonset button:first").removeAttr("disabled");
                        $("#suwin input").removeAttr("disabled");
                    }
                });

            }, "关 闭": function () { $(this).dialog("close"); }
        }
        }).dialog("open");
    });
}

function showStatist(arr) {
    if (arr[1].value.length < 4) {
        if (arr[0].value == '-') {
            $("#tdcpusload").html('<div style="height:18px;width: 218px;float:left" id="cpuload" class="ui-progressbar ui-widget ui-widget-content ui-corner-all" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><div class="ui-progressbar-value ui-widget-header ui-corner-left" style="display: none; width: 30%; "></div></div>&nbsp;&nbsp;&nbsp;0%');
            $("#cpuload").progressbar({
                value: parseFloat(0)
            });
        }
        if (arr[1].value == '-') {
            $("#tddisk").html('<div style="height:18px;width: 218px;float:left" id="cpuload" class="ui-progressbar ui-widget ui-widget-content ui-corner-all" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><div class="ui-progressbar-value ui-widget-header ui-corner-left" style="display: none; width: 30%; "></div></div>&nbsp;&nbsp;&nbsp;0%');
            $("#diskload").progressbar({
                value: parseFloat(0)
            });
        }
        if (arr[2].value == '-') {
            $("#tdram").html('<div style="height:18px;width: 218px;float:left" id="cpuload" class="ui-progressbar ui-widget ui-widget-content ui-corner-all" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><div class="ui-progressbar-value ui-widget-header ui-corner-left" style="display: none; width: 30%; "></div></div>&nbsp;&nbsp;&nbsp;0%');
            $("#ramload").progressbar({
                value: parseFloat(0)
            });
        }
    } else {
        var vcpu = 0;
        var vcputxt = "0%";
        if (arr[0].value != '-') {
            vcputxt = arr[0].value.text;
            vcpu = vcputxt.slice(0, -1);
        }
        $("#tdcpusload").html('<div style="height:18px;width: 218px;float:left" id="cpuload" class="ui-progressbar ui-widget ui-widget-content ui-corner-all" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><div class="ui-progressbar-value ui-widget-header ui-corner-left" style="display: none; width: 30%; "></div></div>&nbsp;&nbsp;&nbsp;' + vcputxt);

        $("#cpuload").progressbar({
            value: parseFloat(vcpu)
        });

        var vtxt = arr[2].value.text;
        var vindex = vtxt.indexOf(',');
        var vpercent = vtxt.substring(0, vindex);
        var vused = vtxt.substring(vindex + 1, vtxt.indexOf('B') + 1);
        var vfree = vtxt.substring(vtxt.indexOf('/') + 1, vtxt.lastIndexOf('B') + 1);
        $("#tdram").html('<div style="height:18px;width: 218px;float:left" id="ramload" class="ui-progressbar ui-widget ui-widget-content ui-corner-all" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><div class="ui-progressbar-value ui-widget-header ui-corner-left" style="display: none; width: 0%; "></div></div>&nbsp;&nbsp;&nbsp;' + vpercent + '，已使用' + vused + '，剩余' + vfree);
        $("#ramload").progressbar({
            value: parseFloat(vtxt.slice(0, -1))
        });

        vtxt = arr[1].value.text;
        vindex = vtxt.indexOf(',');
        vpercent = vtxt.substring(0, vindex);
        vused = vtxt.substring(vindex + 1, vtxt.indexOf('B') + 1);
        vfree = vtxt.substring(vtxt.indexOf('/') + 1, vtxt.lastIndexOf('B') + 1);
        $("#tddisk").html('<div style="height:18px;width: 218px;float:left" id="diskload" class="ui-progressbar ui-widget ui-widget-content ui-corner-all" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><div class="ui-progressbar-value ui-widget-header ui-corner-left" style="display: none; width: 0%; "></div></div>&nbsp;&nbsp;&nbsp;' + vpercent + '，已使用' + vused + '，剩余' + vfree);
        $("#diskload").progressbar({
            value: parseFloat(vtxt.slice(0, -1))
        });
    }
}
var chartData = 0;
function showChart(type, maxsize, tip) {
    if (serviceData[0].sstatus == "-1") {
        alert("当前状态不允许读取图表信息，请稍候重试！");
        return;
    }
    $("#suwin").html(ajaxLoading("正在加载图表信息，请稍等......"));
    $("#suwin").dialog({ title: tip, autoOpen: false, resizable: false, width: 600, height: 380, modal: true, buttons: { "关 闭": function () { $(this).dialog("close"); } } }).dialog("open");
    if (chartData != 0) {
        $("#suwin").html('<div id="divchart" style="width:550px;height:280px"></div>');
        maxsize = type == 1 ? parseFloat(maxsize) * 1000 : maxsize;
        var data = $.parseJSON(chartData.split('№')[type]);
        var vY = [], vX = [];
        for (var i = 0, len = data.length; i < len; i++) {
            if (i % 2 == 0) {
                //var vusage = type == 1 ? parseFloat(data[i].usage) * 100 : data[i].usage;
                var vusage = data[i].usage;
                if (type == 1) {
                    vusage = parseFloat(data[i].usage) * 100;
                } else if (type == 2) {
                    vusage = parseFloat(data[i].usage) * 100;
                }
                vY.push(parseFloat(vusage) / maxsize);
                vX.push(data[i].time);
            }
        }
        $('#divchart').gchart({
            type: 'line', //图表类型
            title: tip, //图表标题
            series: [
			$.gchart.series(vY, 'red')//图表数据
		],
            axes: [//图表坐标轴
			$.gchart.axis('left', 0, maxsize, 'blue'),
			$.gchart.axis('bottom', vX, '008000')
		],
            legend: 'top'
        });
    }
}
var pwdTime = 180, instalTime = 180, vcodepwdtip = "", vcodeinstaltip = "";
function showPwdWin(vpsid, emailchk, smschk) {
    if (serviceData[0].ssid == "0") {
        alert("当前状态不允许修改密码操作，请稍候重试！");
        return;
    }
    var height = 240;
    var str = "";
    if (userData[0].isAdmin != "True" && (emailchk != "0" || smschk != "0")) {
        height = 310;
        str = '<p style="margin:10px 0px;">请选择验证方式：';
        if (smschk != "0") {
            str += '<input type="radio" name="radpcheck" id="smspcheck" checked="checked" value="1"/><label for="smspcheck">短信验证</label>&nbsp;&nbsp;';
        }
        if (emailchk != "0") {
            str += '<input type="radio" name="radpcheck" id="emailpcheck" value="2"/><label for="emailpcheck">邮箱验证</label>';
        }
        if (pwdTime == 180) {
            str += '&nbsp;&nbsp;<input  type="button" class="submit" id="btnSendpChkCode" value="发送验证码"/></p>';
        } else {
            str += '&nbsp;&nbsp;<input  type="button" disabled="disabled" class="submit" style="color:gray;cursor:default" id="btnSendpChkCode" value="还剩' + pwdTime + '秒"/></p>';
        }
    }
    str += '<p style="margin:10px 0px;padding-left:3px;">新 密 码：<input type="password" id="txtpwd"/>&nbsp;&nbsp;<span style="color:green;">(由字母、数字组成的6-16位字符)</span></p>' +
    '<p>确认密码：<input type="password" id="txtrepwd"/></p>';
    if (emailchk != "0" || smschk != "0") {
        str += '<p style="margin-top:10px;padding-left:4px;">验 证 码：<input type="text" id="txtpchkCode"/></p>';
    }
    str += '<p><span id="chkptip" style="margin-top:10px;color:green;">' + vcodepwdtip + '</span></p>';

    $("#suwin").html(str);
    if (vcodepwdtip.indexOf('@') > -1) {
        $("#emailpcheck").attr("checked", "checked");
    } else {
        $("input[name=radpcheck]:first").attr("checked", "checked");
    }
    $("#btnSendpChkCode").click(function () {
        $("#btnSendpChkCode").attr("disabled", "disabled").attr("value", "还剩" + pwdTime + "秒").css({ "color": "gray", "cursor": "default" });
        var myTimer = setInterval(function () {
            if (pwdTime > 1) {
                pwdTime -= 1;
                $("#btnSendpChkCode").attr("value", "还剩" + pwdTime + "秒");
            }
            else {
                clearInterval(myTimer);
                pwdTime = 180;
                $("#btnSendpChkCode").removeAttr("disabled").css({ "color": "white", "cursor": "pointer" }).val('发送验证码');
            }
        }, 1000);

        $("#chkptip").html("<br/>正在发送验证码，请稍等......").css("color", "green");
        var chk = $("input[name=radpcheck]:checked").val();
        if (chk == "1") {
            $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&action=send_sms&t=" + new Date(), function (data) {
                if (data == "0") {
                    vcodepwdtip = "<br/>验证码已发送到您的手机[<span style='color:red'>" + userData[0].tel + "</span>]，请查收！";
                    $("#chkptip").html(vcodepwdtip).css("color", "green");
                } else {
                    $("#chkptip").html('<br/>' + data).css("color", "red");
                }
            });
        } else {
            $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&action=send_email&t=" + new Date(), function (data) {
                if (data == "0") {
                    vcodepwdtip = "<br/>验证码已发送到您的邮箱[<span style='color:red'>" + userData[0].umail + "</span>]，请查收！";
                    $("#chkptip").html(vcodepwdtip).css("color", "green");
                } else {
                    $("#chkptip").html('<br/>' + data).css("color", "red");
                }
            });
        }
    });
    $("#suwin").dialog({ title: "修改密码", autoOpen: false, resizable: false, width: 480, height: height, modal: true, buttons: {
        "修改密码": function () {
            var pwd = $("#txtpwd").val();
            var repwd = $("#txtrepwd").val();
            var pcode = '';
            var exp = /^[A-Za-z0-9]{6,16}$/;
            if (pwd.length <= 0 || (!exp.test(pwd))) {
                $("#chkptip").html("<br/>请输入正确的密码！").css("color", "red");
                $("#txtpwd").val('').focus();
                return;
            } else if (repwd != pwd) {
                $("#chkptip").html("<br/>确认密码与新密码不一致！").css("color", "red");
                $("#txtrepwd").val('').focus();
                return;
            }
            else if (userData[0].isAdmin != "True" && (emailchk != "0" || smschk != "0")) {
                pcode = $("#txtpchkCode").val();
                if (pcode.length <= 0) {
                    $("#chkptip").html("<br/>请输入验证码！").css("color", "red");
                    $("#txtpchkCode").val('').focus();
                    return;
                }
            }
            $("#chkptip").html(ajaxLoading("正在执行操作，请稍等......")).css("color", "green");
            $("#suwin input").attr("disabled", "disabled");
            $(".ui-dialog-buttonset button:first").attr("disabled", "disabled");
            $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&caction=sendpwd&pwd=" + pwd + "&repwd=" + repwd + "&code=" + pcode + "&t=" + new Date(), function (data) {
                if (data == "0") {
                    showTipWin('密码修改成功！',0);
                } else {
                    $("#chkptip").html('<br/>' + data).css("color", "red");
                    $(".ui-dialog-buttonset button:first").removeAttr("disabled");
                    $("#suwin input").removeAttr("disabled");
                }
            });

        },
        "关 闭": function () { $(this).dialog("close"); }
    }
    }).dialog("open");
}

function showTipWin(tip,flg) {
    $("#suwin").dialog({ title: "操作提示", autoOpen: false, resizable: false, width: 350, height: 200, modal: false, buttons: { "关 闭": function () { $(this).dialog("close"); } } }).dialog("open");
    $("#suwin").html('<div style="margin-top:30px;text-align:center;font-weight:bold">' + tip + '</div>');
    if (flg == 0)setTimeout('$("#suwin").dialog("close");', 3000);//修改密码
    else setTimeout('top.location.reload();', 3000);//重装系统
}
function showUpgradeWin(renewdata, cpu, assureram, ram, disk) {
    if (serviceData[0].spmothod != "1") {
        alert('您当前服务不支持升级操作！');
        return false;
    }
    var suwin = $("#suwin");
    suwin.html(ajaxLoading("正在加载升级配置信息，请稍等......"));
    suwin.dialog({ title: "升级配置", autoOpen: false, resizable: false, width: 600, height: 500, modal: true, buttons: { "关 闭": function () { $(this).dialog("close"); } } }).dialog("open");
    $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&caction=getsfreeInfo&sid=" + serviceData[0].sconfig.server_id + "&t=" + new Date(), function (data) {
        var sinfo = data.split('_');

        var tmpRam = parseFloat(sinfo[0]) * 1000;
        var tmpDisk = parseFloat(sinfo[1]);
        var disk_max = parseFloat(productData[0].pupgrade.disk_max), disk_price = parseFloat(productData[0].pupgrade.disk_price), disk_step = parseFloat(productData[0].pupgrade.disk_step);
        var cpu_max = parseFloat(productData[0].pupgrade.cpu_max), cpu_price = parseFloat(productData[0].pupgrade.cpu_price), cpu_step = parseFloat(productData[0].pupgrade.cpu_step);
        var ram_max = parseFloat(productData[0].pupgrade.ram_max), ram_price = parseFloat(productData[0].pupgrade.ram_price), ram_step = parseFloat(productData[0].pupgrade.ram_step);
        var assureram_max = parseFloat(productData[0].pupgrade.assureram_max), assureram_price = parseFloat(productData[0].pupgrade.assureram_price), assureram_step = parseFloat(productData[0].pupgrade.assureram_step);
        if (ram_max > tmpRam) ram_max = tmpRam;
        if (assureram_max > tmpRam) assureram_max = tmpRam;
        if (disk_max > tmpDisk) disk_max = tmpDisk;

        var arr = renewdata.split('-');
        var d = new Date();
        var y = parseInt(arr[0]) - parseInt(d.getFullYear());
        var m = parseInt(arr[1]) - (parseInt(d.getMonth()) + 1);
        var tmpd = parseInt(arr[2]) - parseInt(d.getDate());
        var mon = y * 12 + m;
        var day = tmpd;
        if (tmpd < 0) {
            mon -= 1;
            day += 30;
        }

        mon = (mon + (day / 30)).toFixed(3);
        var str = '<form id="uform"><div id="sc" style="line-height:25px;padding:0px 15px 0px 10px;">' +
        '<p>CPU核心数：<input type="text" class="vcvalue" name="vcpu" id="vcpu"/><span></span></p><div id="sl_cpu"></div>' +
        '<p>突发内存大小(MB)：<input type="text" class="vcvalue" name="vram" id="vram"/><span></span></p><div id="sl_ram"></div>' +
        '<p>保证内存大小(MB)：<input type="text" class="vcvalue" name="vassureram" id="vassureram"/><span></span></p><div id="sl_assureram"></div>' +
        '<p>硬盘容量(GB)：<input type="text" class="vcvalue" name="vdisk" id="vdisk"/><span></span></p><div id="sl_disk"></div>' +
        '<p>续费日期：<input class="text" type="text" value="' + renewdata + '"/>升级周期：<strong>' + mon + '</strong>个月(30天/月)&nbsp;&nbsp;&nbsp;余额：<strong>' + parseFloat(userData[0].balance).toFixed(2) + ' ' + userData[0].currency + '</strong></p>' +
        '<p>升级费用：<input class="text" type="text" name="muprice" id="muprice" value="0.00 RMB /月"/>本次费用：<span style="font-weight:bold;padding-right:8px;" title="到下个计费周期所剩时间的升级费用，也是您本次需要支付的费用！" class="finalPrice"><strong>0.00 RMB</strong></span><span class="normalPrice"></span></p>' +
        '<p>&nbsp;<br /><span>优 惠 码：<input type="text" id="couponcode" size="10"/> <input type="button" class="submit" value="使用" onclick="applyCode(\'upgrade\')"/> <input type="button" class="submit" value="不使用" onclick="clearCouponCode(1)"/></span> ' +
        '<span id="ccdes" class="pptext"></span></p></div></form>';
        suwin.html(str);

        suwin.find("p").css("padding-top", "15px");
        suwin.find(".vcvalue").attr("readonly", "readonly").css({ "border": "0px", "width": "80px", "font-weight": "bold" });
        suwin.find(".text").attr("readonly", "readonly").css("border", "0px").css("width", "130px").css("font-weight", "bold");

        var cpup = cpu_price / cpu_step;
        var ramp = ram_price / ram_step;
        var diskp = disk_price / disk_step;
        var assureramp = assureram_price / assureram_step;

        $("#sc span:eq(0)").html("　" + cpup.toFixed(2) + "元/核，最多" + cpu_max + "核");
        $("#sc span:eq(1)").html(ramp.toFixed(2) + "元/MB,最多" + ram_max + "MB");
        $("#sc span:eq(2)").html(assureramp.toFixed(2) + "元/MB,最多" + assureram_max + "MB");
        $("#sc span:eq(3)").html(diskp.toFixed(2) + "元/GB,最多" + disk_max + "GB");

        sliderIt(cpu, cpu_max, cpu_price, cpu_step, ram, ram_max, ram_price, ram_step, disk, disk_max, disk_price, disk_step, assureram, assureram_max, assureram_price, assureram_step, mon);

        suwin.dialog({ title: "升级配置", autoOpen: false, resizable: false, width: 680, height: 500, modal: false, buttons: { "马上升级": function () {
            if (parseFloat($("#muprice").val()) <= 0) {
                alert("您的VPS主机配置与原来的一样，无需升级！");
                return;
            }
            RunUpgrade($("#vcpu").val(), $("#vram").val(), $("#vassureram").val(), $("#vdisk").val(), $("#couponcode").val());
        }, "关 闭": function () { $(this).dialog("close"); }
        }
        }).dialog("open");

    });
}
function RunUpgrade(cpu, ram, assureram, disk, couponcode) {

    $("#suwin").html(ajaxLoading("正在升级配置，请稍等......"));
    $("#suwin").dialog({ title: "升级提示", autoOpen: false, resizable: false, width: 300, height: 200, modal: false, buttons: { "关 闭": function () { $(this).dialog("close"); } } }).dialog("open");
    var delay = 0;
    $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&action=upgrade_service&couponcode=" + couponcode + "&cpu=" + cpu + "&ram=" + ram + "&assureram=" + assureram + "&disk=" + disk + "&os=" + $("#spanos").html() + "&ip=" + $("#tdip").html() + "&t=" + new Date(), function (data) {
        if (data == "0") {
            data = '升级配置成功！';
            delay = 3000;
        } else {
            data = data.split('|')[1];
        }
        $("#suwin").html("<br/><br/><div style='text-align:center;'>" + data + "</div>");
        if (delay > 0) setTimeout('top.location.reload();', delay);
        // if (delay > 0) setTimeout('$("#suwin").dialog("close");', delay);
    });
}
function updatePrice(mincpu, cpu_price, cpu_step, minram, ram_price, ram_step, mindisk, disk_price, disk_step, minassureram, assureram_price, assureram_step, mon) {
    $("#couponcode").val('');
    $("#ccdes").html('');
    var vcpu = $("#vcpu"), vram = $("#vram"), vdisk = $("#vdisk"), vassureram = $("#vassureram");
    var vramsize = parseFloat(vram.val()), vassureramsize = parseFloat(vassureram.val());
    var discount = parseFloat(productData[0].discount);
    normalPrice = (parseFloat(vcpu.val()) - mincpu) * cpu_price / cpu_step;
    normalPrice += (vassureramsize - minassureram) * assureram_price / assureram_step;
    normalPrice += (parseFloat(vdisk.val()) - mindisk) * disk_price / disk_step;
    if (vramsize > vassureramsize) {
        normalPrice += (vramsize - minram) * (ram_price / ram_step);
    }

    if (normalPrice < 0) normalPrice = 0;
    finalPrice = normalPrice * discount;
    var suwin = $("#suwin");
    suwin.find('input[name="muprice"]').val(finalPrice.toFixed(2) + ' ' + userData[0].currency + ' /月');

    normalPrice = normalPrice * mon;
    finalPrice = normalPrice * discount;
    if (normalPrice > finalPrice) {
        suwin.find('.finalPrice').html('<strike>' + normalPrice.toFixed(2) + '</strike>&nbsp;&nbsp;&nbsp;' + finalPrice.toFixed(2) + ' ' + userData[0].currency + ' 帐户优惠(' + (discount * 100 / 10) + '折)');
        suwin.find('.normalPrice').html('');
    }
    else suwin.find('.finalPrice').html('<strong>' + finalPrice.toFixed(2) + ' ' + userData[0].currency + '</strong>');
}
function sliderIt(mincpu, maxcpu, cpu_price, cpu_step, minram, maxram, ram_price, ram_step, mindisk, maxdisk, disk_price, disk_step, minassureram, maxassureram, assureram_price, assureram_step, mon) {
    var vcpu = $("#vcpu"), vram = $("#vram"), vdisk = $("#vdisk"), vassureram = $("#vassureram");
    $("#sl_cpu").slider({
        range: "min",
        value: mincpu,
        min: 0,
        max: maxcpu,
        step: cpu_step,
        slide: function (event, ui) {
            vcpu.val(ui.value);
            updatePrice(mincpu, cpu_price, cpu_step, minram, ram_price, ram_step, mindisk, disk_price, disk_step, minassureram, assureram_price, assureram_step, mon);

        },
        stop: function (event, ui) {
            if (parseInt(ui.value) < mincpu) {
                $("#sl_cpu").slider("value", mincpu);
                vcpu.val(mincpu);
            }
            updatePrice(mincpu, cpu_price, cpu_step, minram, ram_price, ram_step, mindisk, disk_price, disk_step, minassureram, assureram_price, assureram_step, mon);
        }
    });
    vcpu.val(mincpu);
    $("#sl_cpu").slider("value", mincpu);

    $("#sl_ram").slider({
        range: "min",
        value: minram,
        min: 0,
        max: maxram,
        step: ram_step,
        slide: function (event, ui) {
            vram.val(ui.value);
            updatePrice(mincpu, cpu_price, cpu_step, minram, ram_price, ram_step, mindisk, disk_price, disk_step, minassureram, assureram_price, assureram_step, mon);

        },
        stop: function (event, ui) {
            if (parseInt(ui.value) < minram) {
                $("#sl_ram").slider("value", minram);
                vram.val(minram);
            }
            var ramT = parseFloat(vram.val()), assureramT = parseFloat(vassureram.val());
            if (assureramT > ramT) {
                if (maxram <= assureramT) {
                    vram.val(maxram);
                    $("#sl_ram").slider("value", maxram);
                } else {
                    vram.val(assureramT);
                    $("#sl_ram").slider("value", assureramT);
                }
            }
            updatePrice(mincpu, cpu_price, cpu_step, minram, ram_price, ram_step, mindisk, disk_price, disk_step, minassureram, assureram_price, assureram_step, mon);
        }
    });
    vram.val(minram);
    $("#sl_ram").slider("value", minram);

    $("#sl_assureram").slider({
        range: "min",
        value: minassureram,
        min: 0,
        max: maxassureram,
        step: assureram_step,
        slide: function (event, ui) {
            vassureram.val(ui.value);
            updatePrice(mincpu, cpu_price, cpu_step, minram, ram_price, ram_step, mindisk, disk_price, disk_step, minassureram, assureram_price, assureram_step, mon);

        },
        stop: function (event, ui) {
            if (parseInt(ui.value) < minassureram) {
                $("#sl_assureram").slider("value", minassureram);
                vassureram.val(minassureram);
            }
            var ramT = parseFloat(vram.val()), assureramT = parseFloat(vassureram.val());
            if (assureramT > ramT) {
                if (maxram <= assureramT) {
                    vram.val(maxram);
                    $("#sl_ram").slider("value", maxram);
                } else {
                    vram.val(assureramT);
                    $("#sl_ram").slider("value", assureramT);
                }
            }
            updatePrice(mincpu, cpu_price, cpu_step, minram, ram_price, ram_step, mindisk, disk_price, disk_step, minassureram, assureram_price, assureram_step, mon);
        }
    });
    vassureram.val(minassureram);
    $("#sl_assureram").slider("value", minassureram);

    $("#sl_disk").slider({
        range: "min",
        value: mindisk,
        min: 0,
        max: maxdisk,
        step: disk_step,
        slide: function (event, ui) {
            vdisk.val(ui.value);
            updatePrice(mincpu, cpu_price, cpu_step, minram, ram_price, ram_step, mindisk, disk_price, disk_step, minassureram, assureram_price, assureram_step, mon);

        },
        stop: function (event, ui) {
            if (parseInt(ui.value) < mindisk) {
                $("#sl_disk").slider("value", mindisk);
                vdisk.val(mindisk);
            }
            updatePrice(mincpu, cpu_price, cpu_step, minram, ram_price, ram_step, mindisk, disk_price, disk_step, minassureram, assureram_price, assureram_step, mon);
        }
    });
    vdisk.val(mindisk);
    $("#sl_disk").slider("value", mindisk);
}
function ControlServer(vpsid, action, tip) {
    if (serviceData[0].ssid == "0") {
        alert("当前状态不允许该操作，请稍候重试！");
        return;
    }
    var msg = "您确定要" + tip + "VPS主机[" + vpsid + "]吗？";
    $("#suwin").html('<p style="font-weight:bold;padding-top:20px;text-align:center;"><input type="checkbox" id="confirm_box" value="1"/><label for="confirm_box" style="cursor:pointer">' + msg + '<label></p>');
    $("#suwin").dialog({ title: "操作确认", autoOpen: false, resizable: false, width: 340, height: 200, modal: true, buttons: { "确认": function () {
        if (!$("#confirm_box").prop("checked")) {
            alert('请勾选复选框以确认操作！');
            return false;
        }
        runService(action, tip);
    }, "关 闭": function () { $(this).dialog("close"); }
    }
    }).dialog("open");
}

function runService(action, tip) {
    var msg = "正在" + tip + "VPS主机，请稍候......";
    $("#suwin").html(ajaxLoading(msg));
    $("#suwin").dialog({ title: "操作提示", autoOpen: false, resizable: false, width: 300, height: 200, modal: true, buttons: { "关 闭": function () { $(this).dialog("close"); } } }).dialog("open");
    var delay = 0;
    $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&caction=controlvps&act=" + action + "&t=" + new Date(), function (data) {
        if (data == "1") {
            data = tip + 'VPS主机成功！';
            delay = 3000;
        }
        $("#suwin").html("<br/><br/><div style='text-align:center;'>" + data + "</div>");
        if (delay > 0) setTimeout('top.location.reload();', delay);
        // if (delay > 0) setTimeout('$("#suwin").dialog("close");', delay);
    })
}
_view();

function _btnfresh(vpsid) {
    if (vpsid != "0") {
        $("#spanstate").html("检测中......");
        $("#btnfresh").hide();
        $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&caction=freshstate&t=" + new Date(), function (data) {
            var varr = data.split('|');
            if (varr[0] == "running") {
                // $("#spanstate").html("<img src=" + varr[1] + "/js/run.png"/>正在运行");
                $("#spanstate").html("<img src='" + varr[1] + "/js/run.png'/>正在运行");
                chartData = varr[2];
                $("#spancharttip").hide();
                $("#spanchart").show();
                $("#acpuchart").click(function () { showChart(0, 100, "CPU状态图"); });
                $("#adiskchart").click(function () { showChart(1, $("#spanmaxdisk").html(), "磁盘状态图"); });
                $("#aramchart").click(function () { showChart(2, $("#spanmaxram").html(), "内存状态图"); });
            } else {
                $("#spanstate").html("<img src='" + varr[1] + "/js/stop.png'/>已停止运行");
                $("#spancharttip").show().html("VPS主机处于关机状态，无法获取状态图表信息！");
                $("#spanchart").hide();
            }

            $("#btnfresh").show();
            setTimeout("_btnfresh('" + vpsid + "')", 120000);
        });
    }
}
var finalPrice = 0;
var normalPrice = 0;
var productID = productData[0].pid;
var billingMothod = 1;
var billingCycle = 1;
function _renew() {
    if (serviceData[0].spmothod != "1") {
        alert("您当前服务无需续费！");
        return false;
    }
    if (serviceData[0].sstatus == "-1") {
        alert("当前状态不允许续费操作，请稍候重试！");
        return;
    }
    var discount = parseFloat(productData[0].discount);


    var addprice = (parseFloat(serviceData[0].sconfig.assureram) - parseFloat(productData[0].pconfig.assureram)) * parseFloat(productData[0].pupgrade.assureram_price) / parseFloat(productData[0].pupgrade.assureram_step);
    addprice += (parseFloat(serviceData[0].sconfig.disk) - parseFloat(productData[0].pconfig.disk)) * parseFloat(productData[0].pupgrade.disk_price) / parseFloat(productData[0].pupgrade.disk_step);
    addprice += (parseFloat(serviceData[0].sconfig.cpu) - parseFloat(productData[0].pconfig.cpu)) * parseFloat(productData[0].pupgrade.cpu_price) / parseFloat(productData[0].pupgrade.cpu_step);
    if (parseFloat(serviceData[0].sconfig.ram) > parseFloat(serviceData[0].sconfig.assureram)) {
        addprice += (parseFloat(serviceData[0].sconfig.ram) - parseFloat(productData[0].pconfig.ram)) * parseFloat(productData[0].pupgrade.ram_price) / parseFloat(productData[0].pupgrade.ram_step);
    }

    if (addprice < 0) addprice = 0;

    var str = '<div style="line-height:25px"><strong>帐户余额</strong>：<strong>' + parseFloat(userData[0].balance).toFixed(2) + '</strong> ' + userData[0].currency;
    if (discount < 1) str += '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong>帐户优惠</strong>：<strong style="color:#0000FF">' + (discount * 100 / 10) + '</strong>折';
    str += '&nbsp;<br /><strong>请选择续费周期</strong>：<br />';
    var cycles = productData[0].pprice.cycle.split(',');
    var cprices = productData[0].pprice.cprice.split(',');
    var cprice = 0, yprice = 0, pp1 = 0, pp2 = 0;
    for (i = 0; i < cycles.length; i++) {
        if (cprices[i] != '0') {
            cprice = parseFloat(addprice * parseFloat(cycles[i]) + parseFloat(cprices[i]));
            yprice = cprice;
            if (cycles[i] == serviceData[0].spcycle) cprice = serviceData[0].sprice;

            if (pp1 == 0) pp1 = parseFloat(yprice) / parseInt(cycles[i]);
            else {
                pp2 = (parseFloat(yprice) / parseInt(cycles[i]) / pp1 * 10).toFixed(1);
            }
            str += '<input type="radio" name="cycle" value="' + cycles[i] + '_' + cprice + '_' + yprice + '" id="cycle' + cycles[i] + '" /><label for="cycle' + cycles[i] + '">';
//            switch (cycles[i]) {
//                case "1": str += '月　付'; break;
//                case "3": str += '季　付'; break;
//                case "6": str += '半年付'; break;
//                case "12": str += '年　付'; break;
//                case "24": str += '二年付'; break;
//                default: str += cycles[i] + '个月付'; break;
//            }

//            if (cycles[i] == serviceData[0].spcycle) str += '：' + parseFloat(cprice).toFixed(2) + (pp2 != 0 ? ' (' + pp2 + '折)' : '') + '</label><br />';
//            else
            //                str += '：' + (discount > 1 ? (parseFloat(cprice) * discount).toFixed(2) : cprice) + (pp2 != 0 ? ' (' + pp2 + '折)' : '') + '</label><br />';
            str += parseFloat(cprice).toFixed(2) + ' / ' + getTimeCycleSuffix(cycles[i], timeCycle, 1) + ((pp2 > 0 && pp2 < 10) ? ' (' + pp2 + '折)' : '') + '</label><br />';
        }
    }
    str += '&nbsp;<br /><strong>续费价格</strong>：<strong class="finalPrice"></strong> ' + userData[0].currency + '&nbsp;&nbsp;&nbsp;<span class="normalPrice"></span><br />&nbsp;<br />' +
           '<span>优 惠 码：<input type="text" id="couponcode" size="10"/> <input type="button" class="submit" value="使用" onclick="applyCode(\'renew\')"/> <input type="button" class="submit" value="不使用" onclick="clearCouponCode(1)"/></span><br />' +
           '<span id="ccdes" class="pptext"></span></div>';
    $("#suwin").html(str);
    $("#suwin input:radio").click(function () {
        clearCouponCode(1);
        var ps = $(this).val().split('_');
        billingCycle = parseInt(ps[0]);
        finalPrice = parseFloat(ps[1]);
        normalPrice = parseFloat(ps[2]);
        if (billingCycle != parseInt(serviceData[0].spcycle)) finalPrice = finalPrice * discount;
        $("#suwin .finalPrice").html(finalPrice.toFixed(2));

    });
    $("#suwin #cycle" + serviceData[0].spcycle).click();
    $("#suwin").dialog({ title: "续费确认", autoOpen: false, resizable: false, width: 500, height: 398, modal: true, buttons: { "确认续费": function () { renew(serviceData[0].sid, billingCycle, $("#couponcode").val()); }, "关 闭": function () { $(this).dialog("close"); } } }).dialog("open");
}
function getTimeCycleSuffix(billingCycle, timeCycle, tag) {
    var cycleSuffix = '';
    if (billingCycle == 0) {
        switch (timeCycle) {
            case '1': cycleSuffix = '天'; break;
            case '2': cycleSuffix = '小时'; break;
            default:
                cycleSuffix = '月';
                if (tag == 1) cycleSuffix = '个月';
                break;
        }
    }
    else {
        if (timeCycle == '0') {
            switch (billingCycle) {
                case '1': cycleSuffix = '月'; break;
                case '3': cycleSuffix = '季'; break;
                case '6': cycleSuffix = '半年'; break;
                case '12': cycleSuffix = '年'; break;
                case '24': cycleSuffix = '2年'; break;
                default: cycleSuffix = billingCycle + '个月'; break;
            }
        }
        else if (timeCycle == '1') {
            switch (billingCycle) {
                case '1': cycleSuffix = '天'; break;
                case '7': cycleSuffix = '周'; break;
                case '15': cycleSuffix = '半月'; break;
                case '30': cycleSuffix = '月'; break;
                case '90': cycleSuffix = '季'; break;
                case '365': cycleSuffix = '年'; break;
                default: cycleSuffix = billingCycle + '天'; break;
            }
        }
        else {
            switch (billingCycle) {
                case '1': cycleSuffix = '小时'; break;
                case '24': cycleSuffix = '天'; break;
                case '168': cycleSuffix = '周'; break;
                default: cycleSuffix = billingCycle + '小时'; break;
            }
        }
    }
    return cycleSuffix;
}
