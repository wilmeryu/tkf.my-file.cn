﻿/// <reference path="/modules/js/jquery-vsdoc.js" />
/// <reference path="/modules/js/jquery-ui.min.js" />
function _pm_init() {
    var swin = $("#swin");
    swin.find("#moduleDescription").html('&nbsp;');
    swin.find("#btn_add").remove();
    var ID = moduleData[0].cconfig.ID == undefined ? '' : moduleData[0].cconfig.ID;
    var Key = moduleData[0].cconfig.Key == undefined ? '' : moduleData[0].cconfig.Key;
    var IP = moduleData[0].cconfig.IP == undefined ? '' : moduleData[0].cconfig.IP;
    var ovznodeids = moduleData[0].cconfig.ovznodeids == undefined ? '' : moduleData[0].cconfig.ovznodeids;
    var ovzmaxvps = moduleData[0].cconfig.ovzmaxvps == undefined ? '' : moduleData[0].cconfig.ovzmaxvps;
    var xennodeids = moduleData[0].cconfig.xennodeids == undefined ? '' : moduleData[0].cconfig.xennodeids;
    var xenmaxvps = moduleData[0].cconfig.xenmaxvps == undefined ? '' : moduleData[0].cconfig.xenmaxvps;

    var kvmnodeids = moduleData[0].cconfig.kvmnodeids == undefined ? '' : moduleData[0].cconfig.kvmnodeids;
    var kvmmaxvps = moduleData[0].cconfig.kvmmaxvps == undefined ? '' : moduleData[0].cconfig.kvmmaxvps;
    var emailchk = moduleData[0].cconfig.emailchk == undefined ? '1' : moduleData[0].cconfig.emailchk;
    var smschk = moduleData[0].cconfig.smschk == undefined ? '1' : moduleData[0].cconfig.smschk;
    var enID = moduleData[0].cconfig.enid == undefined ? '0' : moduleData[0].cconfig.enid;
    var enKey = moduleData[0].cconfig.enkey == undefined ? '0' : moduleData[0].cconfig.enkey;
    var vbtnId = '修改', vbtnKey = '修改';
    var ableId = 'readonly="readonly"', ableKey = 'readonly="readonly"';
    if (enID == '0') {
        vbtnId = '加密';
        ableId = '';
    }
    if (enKey == '0') {
        vbtnKey = '加密';
        ableKey = '';
    }
    var str = '<li><label class="a">API ID：</label><input type="hidden" name="cname_001" value="ID"/><input class="text" type="text" name="cvalue_001" value="' + ID + '" ' + ableId + ' />&nbsp;&nbsp;&nbsp;<input class="submit" value="' + vbtnId + '" name="btnEncryp" id="btnId" type="button"/><input type="hidden" name="cname_004" value="enid"/><input type="hidden" name="cvalue_004" value="' + enID + '"/>&nbsp;<span class="pptext"></span></li>' +
     '<li><label class="a">API Key：</label><input type="hidden" name="cname_002" value="Key"/><input class="text" type="text" name="cvalue_002" value="' + Key + '" ' + ableKey + '/>&nbsp;&nbsp;&nbsp;<input class="submit" value="' + vbtnKey + '" name="btnEncryp" id="btnKey"  type="button"/><input type="hidden" name="cname_005" value="enkey"/><input type="hidden" name="cvalue_005" value="' + enKey + '"/>&nbsp;<span class="pptext"></span></li>' +
      '<li><label class="a">Solusvm面板IP：</label><input type="hidden" name="cname_003" value="IP"/><input class="text" type="text" name="cvalue_003" value="' + IP + '"/></li>' +
     '<li><label class="a">邮件验证：</label><input type="hidden" name="cname_006" value="emailchk"/>&nbsp<input type="radio" name="cvalue_006" value="1" id="email1"><label for="email1">启用</label>&nbsp;&nbsp;&nbsp;<input type="radio" name="cvalue_006" value="0" id="email0"><label for="email0">禁用</label>' +
     '<li><label class="a">短信验证：</label><input type="hidden" name="cname_007" value="smschk"/>&nbsp;<input type="radio" name="cvalue_007" value="1" id="sms1"><label for="sms1">启用</label>&nbsp;&nbsp;&nbsp;<input type="radio" name="cvalue_007" value="0" id="sms0"><label for="sms0">禁用</label>' +
      '<li><label class="a">服务器设置：</label><input type="hidden" name="cname_008" value="ovznodeids"/><input type="hidden" name="cvalue_008" value="' + ovznodeids + '"/><input type="hidden" name="cname_009" value="ovzmaxvps"/><input type="hidden" name="cvalue_009" value="' + ovzmaxvps + '"/>' +
      '<input type="hidden" name="cname_010" value="xennodeids"/><input type="hidden" name="cvalue_010" value="' + xennodeids + '"/><input type="hidden" name="cname_011" value="xenmaxvps"/><input type="hidden" name="cvalue_011" value="' + xenmaxvps + '"/>' +
      '<input type="hidden" name="cname_012" value="kvmnodeids"/><input type="hidden" name="cvalue_012" value="' + kvmnodeids + '"/><input type="hidden" name="cname_013" value="kvmmaxvps"/><input type="hidden" name="cvalue_013" value="' + kvmmaxvps + '"/>' +
      '<input class="submit" value="设置服务器" id="btnSetServer" type="button"/></li>';
    '<li><label class="a">OpenVZ模块版本号：</label>Ver 1.1 build(201204091520)</li>';
    var paramList = swin.find("#paramList");
    paramList.html(str);
    $("input[name=cvalue_006][value=" + emailchk + "]").attr("checked", "checked");
    $("input[name=cvalue_007][value=" + smschk + "]").attr("checked", "checked");
//    paramList.find("li").css({ "height": "30px" });
//    paramList.find("label.a").css({ "font-weight": "bold", "float": "left", "text-align": "right", "width": "156px" });
//    paramList.find(".text").css({ "width": "328px" });
    paramList.find("li").css({ "height": "30px", "line-height": "30px" });
    paramList.find("label.a").css({ "font-weight": "bold", "float": "left", "text-align": "right", "width": "180px", "height": "30px", "line-height": "30px", "cursor": "default" });
    paramList.find(".text").css({ "width": "260px" }); paramList.find(".path").css({ "width": "330px" });

    $("#moduleDescription").hide();

    $("#btnSetServer").click(function () {
        $("#suwin").dialog({ title: "操作提示", autoOpen: false, resizable: false, width: 500, height: 450, modal: true, buttons: { "确 定": function () { $(this).dialog("close"); } } }).dialog("open");

        var str = '<p style="margin:15px 0px;" id="pvpstype"><strong>VPS类型配置</strong>：<input type="radio" name="config_vpstype" value="openvz" id="OpenVZ"/><label for="OpenVZ">OpenVZ</label>&nbsp;<input type="radio" name="config_vpstype" value="xen" id="Xen"/><label for="Xen">Xen</label>&nbsp;' +
     '<input type="radio" name="config_vpstype" value="kvm" id="KVM"/><label for="KVM">KVM</label></p>' +

     '<strong>服务器配置</strong>：<fieldset style="border:1px solid #ccc; padding:0px 5px;margin:8px 0px;width:80%;"><table width="100%" style="margin-top:5px;"><thead><tr style="background-color:#E7E7E7;height:22px;line-height:22px;">' +
        '<th width="50%">服务器名称</th><th width="50%">最大VPS数量</th></tr></thead><tbody id="tbbody"></tbody></table></fieldset>';
        $("#suwin").html(str);

        $("#pvpstype input[name=config_vpstype]").click(function () {
            var vtype = $(this).val();

            var id = $("input[name=cvalue_001]").val();
            id = id.replace(/\+/ig, "№");
            var key = $("input[name=cvalue_002]").val();
            key = key.replace(/\+/ig, "№");
            var ip = $("input[name=cvalue_003]").val();
            $("#tbbody").html("<tr><td colspan='2' style='padding-bottom:10px;'>" + ajaxLoading("正在加载服务器数据，请稍候......") + "</td></tr>");
            $.getScript("http://" + currentDomain + "/files/modules/product/Solusvm/index.ashx?type=" + vtype + "&id=" + id + "&key=" + key + "&ip=" + ip + "&t=" + new Date(), function () {
                var data = strnodes, maxvpscount;
                if (vtype == "openvz") {
                    maxvpscount = ovzmaxvps;
                } else if (vtype == "xen") {
                    maxvpscount = xenmaxvps;
                } else {
                    maxvpscount = kvmmaxvps;
                }
                maxvpscount = maxvpscount.split(',');
                var strNodeid = '', strNode = '';
                if (data == "offline") {
                    strNode += "<tr><td colspan='2' style='padding:5px;text-align:center;'><span style='color:red;font-size:14px;'>无法连接到远程服务器，调用API接口出现异常！</span></td></tr>";
                } else if (data == "errornode") {
                    strNode += "<tr><td colspan='2' style='padding:5px;text-align:center;'><span style='color:red;font-size:14px;'>您还未在solusvm面板配置 <strong style='color:red;'>" + vtype.toUpperCase() + "</strong> 服务器！</span></td></tr>";
                } else if (data.indexOf('error') > -1) {
                    strNode += "<tr><td colspan='2' style='padding:5px;text-align:center;'><span style='color:red;font-size:14px;'>" + data + "</span></td></tr>";
                } else {
                    var varr = data.split('|');
                    var arrNodeName = varr[0].split(',');
                    strNodeid = varr[1];
                    for (var i = 0, len = arrNodeName.length; i < len; i++) {
                        strNode += '<tr style="height:25px;line-height:25px;"><td style="padding:5px;text-align:center;">' + arrNodeName[i] + '</td><td style="padding:5px;text-align:center;"><input type="text" class="text" name="maxvpscount" style="width:50px;" value="' + (maxvpscount[i] == undefined ? '' : maxvpscount[i]) + '"/>(0-999)</td></tr>';

                    }
                }

                $("#tbbody").html(strNode);
                if (data != "offline" && data != "errornode") {
                    var vcountinfo = '';
                    $("input[name=maxvpscount]").each(function () {
                        vcountinfo += $(this).val() + ',';
                    });

                    if (vcountinfo.length > 0) vcountinfo = vcountinfo.substr(0, vcountinfo.length - 1);
                    if (vtype == "openvz") {
                        $("input[name=cvalue_009]").val(vcountinfo);
                        $("input[name=cvalue_008]").val(strNodeid);

                    } else if (vtype == "xen") {
                        $("input[name=cvalue_011]").val(vcountinfo);
                        $("input[name=cvalue_010]").val(strNodeid);
                    } else {
                        $("input[name=cvalue_013]").val(vcountinfo);
                        $("input[name=cvalue_012]").val(strNodeid);
                    }
                }
                $("input[name=maxvpscount]").each(function (i) {
                    var obj = $(this);
                    obj.change(function () {
                        var txt = obj.val(), vmaxvpscount = '';
                        if (isNaN(txt) || txt.length <= 0) {//不是数字
                            alert("请输入数字！");
                            obj.val('').focus();
                            return;
                        } else if (parseInt(txt) < 0 || parseInt(txt) > 999) {
                            alert("请输入正确的整数！");
                            obj.val('').focus();
                            return;
                        } else {
                            if (vtype == "openvz") {
                                vmaxvpscount = $("input[name=cvalue_009]").val().split(',');
                                vmaxvpscount[i] = txt;
                                $("input[name=cvalue_009]").val(vmaxvpscount.join(","));

                            } else if (vtype == "xen") {
                                vmaxvpscount = $("input[name=cvalue_011]").val().split(',');
                                vmaxvpscount[i] = txt;
                                $("input[name=cvalue_011]").val(vmaxvpscount.join(","));
                            } else {
                                vmaxvpscount = $("input[name=cvalue_013]").val().split(',');
                                vmaxvpscount[i] = txt;
                                $("input[name=cvalue_013]").val(vmaxvpscount.join(","));
                            }
                        }
                    });
                });
            });

        });
        $("#pvpstype input[name=config_vpstype]").eq(0).click();

    });


    $("input[name=btnEncryp]").click(function () {
        var btn = $(this);
        var txt = btn.parent().find("input[type='text']");
        var hid = btn.parent().find("input:last");
        var vSpan = btn.parent().find("span");
        if (txt.val().length <= 0) {
            vSpan.html("请输入参数值！");
            txt.focus();
            return;
        }

        if ($(this).attr('id') == 'btnId') {
            if (enID == '1') {//修改操作
                if (confirm('修改API ID需要重新输入API ID，确认修改？')) {
                    txt.val('');
                    hid.val('0');
                    txt.removeAttr('readonly');
                    btn.attr('value', '加密');
                    enID = '0';
                    vSpan.html("");
                    txt.focus();
                }
                return;
            }
        } else {
            if (enKey == '1') {
                if (confirm('修改API Key需要重新输入API Key，确认修改？')) {
                    txt.val('');
                    hid.val('0');
                    txt.removeAttr('readonly');
                    btn.attr('value', '加密');
                    enKey = '0';
                    vSpan.html("");
                    txt.focus();
                }
                return;
            }
        }


        vSpan.html("正在加密，请稍等...");
        $.getScript("http://" + currentDomain + "/files/modules/product/Solusvm/index.ashx?type=encryp&txt=" + txt.val() + "&t=" + new Date(), function () {
            txt.val(a);
            vSpan.html("加密完成！");
            if (btn.attr('id') == 'btnId') {
                enID = '1';
            } else {
                enKey = '1';
            }
            hid.val('1');
            btn.val('修改')
            txt.attr("readonly", "readonly");
        });
    });
}

_pm_init();