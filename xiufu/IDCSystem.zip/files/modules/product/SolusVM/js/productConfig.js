﻿/// <reference path="jquery.min.js" />

function baseConfig() {
    var product_data = productData;
    var vpstype = 'openvz', vpsplan = '', cpu = '', guaranteedram='',ram = '', disk = '', bandwidth = '', port = '', ips = '';
    if (product_data[0].pconfig != null && product_data[0].pconfig != "") {
        vpstype = product_data[0].pconfig.vpstype;
        vpsplan = product_data[0].pconfig.vpsplan;
        cpu = product_data[0].pconfig.cpu;
        guaranteedram = product_data[0].pconfig.guaranteedram;
        ram = product_data[0].pconfig.ram;
       
        disk = product_data[0].pconfig.disk;
        bandwidth = product_data[0].pconfig.bandwidth;
        port = product_data[0].pconfig.port;
        ips = product_data[0].pconfig.ips;

    }
    var str = '<p id="pvpstype"><strong>VPS类型配置</strong>：<input type="radio" name="config_vpstype" value="openvz" id="OpenVZ"/><label for="OpenVZ">OpenVZ</label>&nbsp;<input type="radio" name="config_vpstype" value="xen" id="Xen"/><label for="Xen">Xen</label>&nbsp;' +
     '<input type="radio" name="config_vpstype" value="kvm" id="KVM"/><label for="KVM">KVM</label></p>' +
     '<strong>VPS基本套餐配置</strong>：';
    str += '<p style="margin:5px 0px 0px 0px;padding-buttom:0px;" id="pvpsplan"></p><p style="margin:5px 0px 10px 0px;" id="pvpsinfo"></p>';

   
    
    $("#ProductConfig").html(str);

    $("#pvpstype input[name=config_vpstype]").click(function () {
        var vtype = $(this).val();
        $("#pvpsinfo").hide();
        $("#pvpsplan").html(ajaxLoading("正在加载套餐数据，请稍候......"));
        $.post("?c=module&productid=" + product_data[0].pid + "&show=text&caction=listplans&vtype=" + vtype + "&t=" + new Date(), function (data) {
            $("#pvpsinfo").show();
            var strPlan = '', vpsinfo = '';
            if (data == "offline") {
                strPlan += "<span style='color:red;font-size:14px; text-align:center;margin-top:30px;'>无法连接到远程服务器，调用API接口出现异常！</span>";

            } else if (data == "errorplan") {
                strPlan += "<span style='color:red;font-size:14px; text-align:center;margin-top:30px;'>您还未在solusvm面板配置 <strong style='color:red;'>" + vtype.toUpperCase() + "</strong> VPS套餐！</span>";
            } else {
                var arrPlans = data.split(',');
                for (var i = 0, len = arrPlans.length; i < len; i++) {
                    var vchecked = '';
                    if (vpsplan == arrPlans[i]) vchecked = 'checked=checked'
                    strPlan += '<input type="radio" name="config_vpsplan" value="' + arrPlans[i] + '" id="plan' + i + '" ' + vchecked + '/><label for="plan' + i + '">' + arrPlans[i] + '</label><br/>';
                }
                vpsinfo = '<strong>VPS基本套餐资源配置</strong>：<br/><strong>CPU</strong>：<input class="text" style="width:80px" size="6" name="config_cpu">核　<strong>保证内存</strong>：<input class="text" style="width:80px" size="6" name="config_guaranteedram">MB　　<strong>突发内存</strong>：<input class="text" style="width:80px" size="6" name="config_ram">MB　' +
        '<strong>硬盘</strong>：<input class="text" style="width:80px" size="6" name="config_disk">GB　<br/><strong>流量</strong>：<input class="text" style="width:80px" size="6" name="config_bandwidth">G　' +
        '<strong>端口</strong>：<input class="text" style="width:80px" size="6" name="config_port">Mbps(0为不限)　<strong>IP地址数</strong>：<input class="text" style="width:80px" size="6" name="config_ips">个';

            }
            $("#pvpsplan").html(strPlan);
            $("#pvpsinfo").html(vpsinfo);
            $("#pvpsplan input[name=config_vpsplan]").click(function () {
                if ($(this).val() == vpsplan) {
                    setVpsInfo(cpu,guaranteedram, ram, disk, bandwidth, port, ips);
                } else {
                    setVpsInfo("", "","", "", "", "", "");
                }
            });
            $("#pvpsplan :radio[value='" + vpsplan + "']").click();

        });
    });

    $("#pvpstype :radio[value='" + vpstype + "']").click();
}

baseConfig();

function setVpsInfo(cpu, guaranteedram,ram, disk, bandwidth, port, ips) {
    $("input[name=config_cpu]").val(cpu);
    $("input[name=config_guaranteedram]").val(guaranteedram);
    $("input[name=config_ram]").val(ram);
    $("input[name=config_disk]").val(disk);
    $("input[name=config_bandwidth]").val(bandwidth);
    $("input[name=config_port]").val(port);
    $("input[name=config_ips]").val(ips);
}