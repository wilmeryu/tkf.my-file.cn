﻿/// <reference path="jquery.min.js" />
function serviceConfig() {
    var service_data = serviceData;
    var str = '<input type="hidden" name="vpspwd" id="vpspwd" value=' + service_data[0].sconfig.vpspwd + '><input type="hidden" name="vpstype" id="vpstype" value=' + service_data[0].sconfig.vpstype + '><input type="hidden" name="vpsplan" id="vpsplan" value=' + service_data[0].sconfig.vpsplan + '><input type="hidden" name="clientpwd" id="clientpwd" value=' + service_data[0].sconfig.clientpwd + '>' +
    '<strong>资源配置</strong>：';

    $.post("?c=module&serviceid=" + service_data[0].sid + "&show=text&caction=getvps&t=" + new Date(), function (data) {
        var arrVps = data.split('|');
        if (arrVps[0] == "-1") {
            $("#ServiceConfig").html('<div class="ui-state-highlight ui-corner-all" style="padding: 10px;margin:10px;text-align:center;"><strong>' + arrVps[1] + '</strong></div>');
            var a = $(".ui-dialog-buttonset").eq(1);
            a.find("button").eq(0).remove();
            return;
        }
        var vps = $.parseJSON(arrVps[1]);
        var bw = vps.bandwidth.split(',');
        var usedbw = 0, freebw = 0;
        if (bw[1]!= "")
            usedbw = (parseFloat(bw[1]) / 1024 / 1024 / 1024).toFixed(2);
        if (bw[2] != "")
            freebw = (parseFloat(bw[2]) / 1024 / 1024 / 1024).toFixed(2);

        var ram = vps.ram.split(',');
        var usedram = 0, freeram = 0;
        if (ram[1] != "")
            usedram = (parseFloat(ram[1]) / 1024 / 1024).toFixed(2);
        if (ram[2] != "")
            freeram = (parseFloat(ram[2]) / 1024 / 1024).toFixed(2);
        var disk = vps.disk.split(',');
        var useddisk = 0, freedisk = 0;
        if (disk[1] != "")
            useddisk = (parseFloat(disk[1]) / 1024 / 1024 / 1024).toFixed(2);
        if (disk[2] != "")
            freedisk = (parseFloat(disk[2]) / 1024 / 1024 / 1024).toFixed(2);


        var arrIP = vps.ip.split(',');
        var strIP = '<option value="' + arrIP[0] + '" selected="selected">' + arrIP[0] + '</option>';
                for (var i = 1, len = arrIP.length; i < len; i++) {
                    strIP += '<option value="' + arrIP[i] + '">' + arrIP[i] + '</option>';
                }
        var port = service_data[0].sconfig.port;
        var pindex = port.indexOf('M');
        if (pindex > -1) port = port.substring(0, pindex);
        str += '内存：' + (parseFloat(ram[0]) / 1024 / 1024) + 'MB　硬盘：' + (parseFloat(disk[0]) / 1024 / 1024 / 1024) + 'GB　流量：' + (parseFloat(bw[0]) / 1024 / 1024 / 1024) + 'GB' +
             '　<p style="margin:8px 0;padding-left:60px;">' +
              'CPU核数：<input type="text" class="text" size="2" style="width:80px;" name="cpu" id="cpu" value="' + service_data[0].sconfig.cpu + '">核' +
             '　端口：<input size="6" class="text" name="port" id="port" style="width:80px;" value="' + port + '">Mbps(0为不限)</p>' +
               '<p style="margin:15px 0"><strong>网络参数配置</strong>：' +
              '主IP地址：<select name="selIP" id="selIP">' + strIP + '</select>　服务器节点：' + vps.node + '</p><p style="margin:8px 0;padding-left:90px;">主机名：' + vps.hostname + '　VPS主机类别：' + vps.type + '　主机套餐：' + service_data[0].sconfig.vpsplan + '</p>' +
              '<div style="margin:25px 0"><strong>实时信息</strong>：' +
              '流量使用情况：已使用' + usedbw + 'G,剩余' + freebw + 'G<p style="margin-top:15px;padding-left:64px;">内存使用情况：已使用' + usedram + 'M，剩余' + freeram + 'M</p>' +
              '<p style="margin-top:15px;padding-left:64px;">磁盘使用情况：已使用' + useddisk + 'G，剩余' + freedisk + 'G</p></div>';
        $("#ServiceConfig").html('&nbsp;<br /><p style="line-height:30px">' + str + '</p>');
    });
}
function getData(data) {
    if (data != "") data = (parseFloat(data) / 1024 / 1024 / 1024).toFixed(2);
    else data = 0;
    return data;
}
serviceConfig();