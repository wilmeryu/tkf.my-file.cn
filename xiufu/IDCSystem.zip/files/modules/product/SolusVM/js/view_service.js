﻿/// <reference path="jquery-vsdoc.js" />
/// <reference path="jquery-ui.min.js" />
var timeCycle = productData[0].psconfig.time_cycle == undefined ? '0' : productData[0].psconfig.time_cycle
function _view() {
    var vstatus = serviceData[0].sstatus;
    if (vstatus == '-2') {
        $("#ViewService").html("<span style='color:green;font-size:14px;'>您开通VPS主机的方式为人工手动开通，请联系管理员尽快为您开通VPS主机服务！</span>");
        return;
    }
    var vpsid = serviceData[0].ssid;
    var renewdata = getUnixTime(parseInt(serviceData[0].etime));
    renewdata = renewdata.substring(0, renewdata.indexOf(' '));
    var str = '<table width="100%" border="0" cellspacing="0" cellpadding="0" class="table grid"><thead><tr><th style="text-align:right">VPS主机信息统计：</th><th class="full"><a href="javascript:void(0);" id="afreshstatist" style="font-weight:normal">『刷新主机信息』</a></th></tr></thead><tbody>';
    var title = '管理我的VPS主机#' + serviceData[0].sid + '';
    $("#pageTitle").html(title);
    document.title = title;
    var statusText = serviceStatus[parseInt(vstatus) + 2];

    switch (vstatus) {
        case "-1": statusText = '<strong style="color:#0000FF;">' + statusText + '</strong>'; break;
        case "0": statusText = '<strong style="color:#005B00;">' + statusText + '</strong>'; break;
        case "3": statusText = '<strong style="color:#CC3300;">' + statusText + '</strong>'; break;
        case "1":
        case "2":
        case "4": statusText = '<strong style="color:#FF0000;">' + statusText + '</strong>'; break;
    }


    var myvpsinfo = '';

    str += '<tr><td class="title">流量使用情况：</td><td id="tdbandwidthload"><div style="height:18px;width: 218px;float:left" id="bandwidthload" class="ui-progressbar ui-widget ui-widget-content ui-corner-all" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><div class="ui-progressbar-value ui-widget-header ui-corner-left" style="display: none; width: 30%; "></div></div>&nbsp;&nbsp;&nbsp;0%</td></tr>' +
          '<tr><td class="title">内存使用情况：</td><td id="tdram"><div style="height:18px;width: 218px;float:left" id="cpuload" class="ui-progressbar ui-widget ui-widget-content ui-corner-all" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><div class="ui-progressbar-value ui-widget-header ui-corner-left" style="display: none; width: 30%; "></div></div>&nbsp;&nbsp;&nbsp;0%</td></tr>' +
      '<tr><td class="title">磁盘使用情况：</td><td id="tddisk"><div style="height:18px;width: 218px;float:left" id="cpuload" class="ui-progressbar ui-widget ui-widget-content ui-corner-all" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><div class="ui-progressbar-value ui-widget-header ui-corner-left" style="display: none; width: 30%; "></div></div>&nbsp;&nbsp;&nbsp;0%</td></tr></tbody></table>' +
     '<table id="tbhostinfo" width="100%" border="0" cellspacing="0" cellpadding="0" class="table grid"><thead><tr><th style="text-align:right">VPS主机基本信息：</th><th class="full">&nbsp;</th></tr></thead><tbody>' +
      '<tr><td class="title" style="text-align: right; ">VPS主机信息：</td><td id="tdhostname">编号：#0</td></tr>' +
      '<tr><td class="title" style="text-align: right; ">VPS类型：</td><td>' + serviceData[0].sconfig.vpstype + '</td></tr>' +
      '<tr><td class="title" style="text-align: right; ">主机套餐：</td><td>' + serviceData[0].sconfig.vpsplan + '</td></tr>';
    str += '<tr id="trlogin"><td class="title" style="text-align: right; ">VPS初始密码：</td><td><span style="margin-right:31px;">' + (serviceData[0].sconfig.vpspwd == undefined ? "" : serviceData[0].sconfig.vpspwd) + '</span><input id="btnSendPwd" type="button" class="submit" value="重置VPS密码"></td></tr>' +
      '<tr id="tros"><td class="title" style="text-align: right; ">操作系统：</td><td><span id="spanos">' + (vpsid == '0' ? serviceData[0].sconfig.os : '') + '</span>　　<input type="button" id="reinstal" class="submit" value="重装操作系统"></td></tr>' +
     '<tr><td class="title" style="text-align: right; ">主IP地址：</td><td id="tdip"></td></tr>' +
     '<tr><td class="title" style="text-align: right; ">主机配置：</td><td><span id="spanhostinfo">CPU：' + serviceData[0].sconfig.cpu + ' 核　内存：<span id="spanmaxram">' + (vpsid == '0' ? serviceData[0].sconfig.ram + "M" : '') + '</span> 　硬盘：<span id="spanmaxdisk">' + (vpsid == '0' ? serviceData[0].sconfig.disk + "G" : '') + '</span> 　流量：<span id="spanbandwidth">' + (vpsid == '0' ? serviceData[0].sconfig.bandwidth + "G" : '') + '</span> 　端口：<span id="spanport">' + (serviceData[0].sconfig.port == "0" ? "不限" : serviceData[0].sconfig.port + "M") + '</span></span>　　</td></tr>' +
     '<tr><td class="title" style="text-align: right; ">状态图表：</td><td><span id="spancharttip"></span><span id="spanchart"><a href="javascript:void(0);" id="abandwidthchart">『查看流量状态图』</a>&nbsp;&nbsp;&nbsp;<a href="javascript:void(0);" id="aloadchart">『查看负载状态图』</a>&nbsp;&nbsp;&nbsp;<a href="javascript:void(0);" id="aramchart">『查看内存状态图』</a></span></td></tr>' +
     '<tr><td class="title" style="text-align: right; ">续费价格：</td><td><b>' + serviceData[0].sprice + ' ' + userData[0].currency + '</b> / ' + getTimeCycleSuffix(serviceData[0].spcycle, timeCycle, 1) + '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;帐户余额： ' + parseFloat(userData[0].balance).toFixed(2) + ' ' + userData[0].currency + '</td></tr>' +
     '<tr><td class="title" style="text-align: right; ">到期时间：</td><td>' + renewdata + '&nbsp;&nbsp;&nbsp;<input id="autorenew" type="checkbox" ' + (serviceData[0].autorenew == '0' ? 'checked="checked"' : '') + '/><label for="autorenew">自动续费</label>&nbsp;&nbsp;&nbsp;&nbsp;<a href="javascript:void(0);"  onclick="_renew()">『马上续费』</a></td></tr>' +
     '<tr><td class="title" style="text-align: right; ">服务状态：</td><td>' + statusText + '</td></tr>' +
      '<tr><td class="title" style="text-align: right; ">主机状态：</td><td><span id="spanstate">Loading...</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="javascript:void(0);" id="btnfresh" style="display:none;">『刷新状态』</a></td></tr>' +
     '<tr><td class="title" style="text-align: right; ">管理操作：</td><td id="tdVpsOperat"><input type="button" class="submit" value="开机"  onclick="ControlServer(' + vpsid + ',0,\'启动\')"/>　　<input name="shutdown" type="button" class="submit" value="关机" onclick="ControlServer(' + vpsid + ',1,\'关闭\')"/>　　<input type="button" class="submit" value="重启" name="reboot" onclick="ControlServer(' + vpsid + ',2,\'重启\')"/></td></tr>' +
       '<tr><td class="title" style="text-align: right; ">提示：</td><td style="color:green">如果用户已开通多台主机服务，用户在SolusVM管理面板的登录密码是用户最近一次修改后的登录密码</td></tr>' +
      '</tbody></table>';
    if (vstatus == "-1") {
        $("#ViewService").html(str);
        $("#ViewService a,#ViewService input[type=button]").hide();
        $("#ViewService .title").css("text-align", "right");
        $("#spancharttip").html("服务暂未开通，无法读取状态图表信息！");
        $("#ViewService #autorenew").css("cursor", "pointer").click(function () {
            var autorenew = $(this).prop("checked") ? '0' : '1';
            setAutorenew(serviceData[0].sid, autorenew);
        });
        setTimeout('top.location.reload();', 12000);
    } else {

        $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&caction=getvps&t=" + new Date(), function (data) {

            var arrVps = data.split('|');
            if (arrVps[0] == "-1") {
                $("#ViewService").html('<div class="ui-state-highlight ui-corner-all" style="padding: 10px;margin:10px;text-align:center;"><strong>' + arrVps[1] + '</strong></div>');
                return;
            } else {
                var ram = 0, disk = 0, bandwidth = 0, vpsos = '', arrIp = '';
                $("#ViewService").html(str);
                var oneVps = $.parseJSON(arrVps[1]);
                showStatist(arrVps[1]);
                ram = oneVps.ram.split(',')[0];

                disk = oneVps.disk.split(',')[0];
                bandwidth = oneVps.bandwidth.split(',')[0];
                arrIp = oneVps.ip.split(',');
                if (ram == '0') ram = serviceData[0].sconfig.ram;
                else
                    ram = parseFloat(ram) / 1024 / 1024;
                disk = parseFloat(disk) / 1024 / 1024 / 1024;
                bandwidth = parseFloat(bandwidth) / 1024 / 1024 / 1024;
                vpsos = oneVps.os;
                $("#spanos").html(vpsos);
                $("#btnSendPwd").click(function () { showPwdWin(1, oneVps.emailchk, oneVps.smschk); });
                $("#reinstal").click(function () { showInstalWin($("#spanos").html(), oneVps.emailchk, oneVps.smschk); });



                var vfrm = '<tr><td class="title" style="text-align: right; ">快捷登录：</td><td>' +
        '<form action="' + arrVps[3] + '/login.php" target="_blank" method="post" id="form1">' +
        '<input type="hidden" value="' + userData[0].uname + '" name="username" id="username">' +
         '<input type="hidden" value="' + serviceData[0].sconfig.clientpwd + '" name="password" id="password">' +
        '<input name="Submit" type="submit" class="submit" value="登录SolusVM管理面板"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input id="btnResLoginPwd" type="button" class="submit" value="重置用户登录密码"></form> </td></tr>';

                $(vfrm).insertBefore("#trlogin");
                $("#btnResLoginPwd").click(function () { showPwdWin(2, oneVps.emailchk, oneVps.smschk); });


                $("#tdhostname").html('编号：#<strong>' + vpsid + '</strong>　　别名：' + oneVps.hostname);
                if (userData[0].isAdmin == "True") {
                    $("#tdhostname").append('　　所属用户：<a href="?c=muser&uid=' + userData[0].uid + '" target="_blank">' + userData[0].uname + ' [#' + userData[0].uid + ']</a>');
                }
                $('<tr><td class="title" style="text-align: right; ">服务器节点：</td><td>' + oneVps.node + '</td></tr>').insertBefore("#tros");
                $("#tdip").html(arrIp[0] + '<span style="margin-left: 10px; "><a href="javascript:void(0)" id="aip">『查看全部IP地址』</a></span>');
                $("#aip").click(function () { mIPs(oneVps.ip); });

                $("#spanhostinfo").html('CPU：' + serviceData[0].sconfig.cpu + ' 核　内存：' + ram + 'M　硬盘：<span id="spanmaxdisk">' + disk + 'G</span>　流量：<span id="spanbandwidth">' + bandwidth + 'G</span>　端口：<span id="spanport">' + (serviceData[0].sconfig.port == "0" ? "不限" : serviceData[0].sconfig.port + "M") + '</span>');

                $("#btnfresh").click(function () { _btnfresh(vpsid); });
                $("#ViewService #autorenew").css("cursor", "pointer").click(function () {
                    var autorenew = $(this).prop("checked") ? '0' : '1';
                    setAutorenew(serviceData[0].sid, autorenew);
                });
                //VPS状态图表信息
                $("#ViewService .title").css("text-align", "right");
                if (oneVps.state == "online") {
                    $("#spanstate").html("<img src='" + arrVps[2] + "/js/run.png'/>正在运行");
                } else {
                    $("#spanstate").html("<img src='" + arrVps[2] + "/js/stop.png'/>已停止运行");
                }
                $("#btnfresh").show();
                $("#afreshstatist").click(function () {
                    $("#tdbandwidthload,#tddisk,#tdram").html("<p><img src='/images/loading.gif' alt='Loading...'/></p>");
                    $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&caction=statist&t=" + new Date(), function (data) {
                        showStatist(data);
                    });
                });
                $("#abandwidthchart").click(function () { showChart(0, "流量状态图"); });
                $("#aloadchart").click(function () { showChart(1, "负载状态图"); });
                $("#aramchart").click(function () { showChart(2, "内存状态图"); });
            }
        });
    }
}

function mIPs(ips) {
    var arrIp = ips.split(',');
    $("#suwin").dialog({ title: "查看全部IP地址", autoOpen: false, resizable: false, width: 380, height: 350, modal: true, buttons: { "关 闭": function () { $(this).dialog("close"); } } }).dialog("open");
    var str = "<strong>IP地址列表：</strong><br/>";
    for (var i = 0, len = arrIp.length; i < len; i++) {
        str += '<p style="margin:8px 0px;">' + arrIp[i] + "</p>";
    }
    $("#suwin").html(str);

}
function showInstalWin(vpsos, emailchk, smschk) {
    if (serviceData[0].ssid == "0") {
        alert("当前状态不允许重装系统，请稍候重试！");
        return;
    }
    $("#suwin").html(ajaxLoading("正在加载系统模板，请稍等......"))
    $("#suwin").dialog({ title: "重装系统", autoOpen: false, resizable: false, width: 380, height: 350, modal: true, buttons: { "关 闭": function () { $(this).dialog("close"); } } }).dialog("open");

    $.post("?c=module&productid=" + productData[0].pid + "&show=text&caction=listos&vtype=" + serviceData[0].sconfig.vpstype + "&t=" + new Date(), function (data) {
        var arrOs = data.split('|');
        if (arrOs[0] == '-1') {
            $("#suwin").html("<div style='text-align:center;'>" + arrOs[1] + "</div>");
            return;
        }
        var vOS = "<div id='divos' style='border-bottom:1px solid #ccc;'>";
        for (var i = 0, len = arrOs.length; i < len; i++) {
            vOS += '<p><input type="radio" name="rados" id="rados' + i + '" value="' + arrOs[i] + '"/><label for="rados' + i + '">' + arrOs[i] + '</label></p>';
        }
        vOS += '</div>';

        if (userData[0].isAdmin != "True" && (emailchk != "0" || smschk != "0")) {
            vOS += '<p style="margin:10px 0px;">请选择验证方式：';
            if (smschk != "0") {
                vOS += '<input type="radio" name="radcheck" id="smscheck" value="1"/><label for="smscheck">短信验证</label>&nbsp;&nbsp;';
            }
            if (emailchk != "0") {
                vOS += '<input type="radio" name="radcheck" id="emailcheck" value="2" /><label for="emailcheck">邮箱验证</label>';
            }
            if (instalTime == 180) {
                vOS += '&nbsp;&nbsp;<input  type="button" class="submit" id="btnSendChkCode" value="发送验证码"/></p>';
            } else {
                vOS += '&nbsp;&nbsp;<input  type="button" disabled="disabled" class="submit" style="color:gray;cursor:default" id="btnSendChkCode" value="还剩' + instalTime + '秒"/></p>';
            }
            vOS += '<p style="margin:10px 0px;padding-left:4px;">验 证 码：<input type="text" class="text" id="txtchkCode"/></p>';
        }

        //vOS += '<p style="margin-top:-10px;"><span id="chktip" style="color:green;">' + vcodeinstaltip + '</span></p>';


        $("#suwin").html(vOS);

        if (vcodeinstaltip == "email") {
            $("#emailcheck").attr("checked", "checked");
        } else {
            $("input[name=radcheck]:first").attr("checked", "checked");
        }
        var arrRad = $("input[name=rados]");
        var h = 360;
        if (userData[0].isAdmin != "True" && (emailchk != "0" || smschk != "0")) {
            if (arrRad.length > 10) {
                $("#divos").css("overflowY", "scroll").height("220px");
                h = 450;
            } else {
                h = 220 + 30 * parseFloat(arrRad.length);
            }
        } else {
            if (arrRad.length > 10) {
                $("#divos").css("overflowY", "scroll").height("220px");
                h = 360;
            } else {
                h = 150 + 30 * parseFloat(arrRad.length);
            }
        }
        $("input[name=rados][value='" + vpsos + "']").attr("checked", "checked");

        $("#btnSendChkCode").click(function () {
            $("#btnSendChkCode").attr("disabled", "disabled").attr("value", "还剩" + instalTime + "秒").css({ "color": "gray", "cursor": "default" });
            var myTimer = setInterval(function () {
                if (instalTime > 1) {
                    instalTime -= 1;
                    $("#btnSendChkCode").attr("value", "还剩" + instalTime + "秒");
                }
                else {
                    clearInterval(myTimer);
                    instalTime = 180;
                    $("#btnSendChkCode").removeAttr("disabled").css({ "color": "white", "cursor": "pointer" }).val('发送验证码');
                }
            }, 1000);
            processing("正在发送验证码，请稍等......");
            var chk = $("input[name=radcheck]:checked").val();
            if (chk == "1") {
                if (userData[0].tel == "0") {
                    showResults("您在本平台还没设置手机号！", 5000, "");
                    return;
                }
                $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&action=send_sms&tel=" + userData[0].tel + "&t=" + new Date(), function (data) {
                    vcodeinstaltip = "tel";
                    if (data == "0") {
                        data = "验证码已发送到您的手机[<span style='color:red'>" + userData[0].tel + "</span>]，请查收！";
                    }
                    showResults(data, 5000, "close");
                });
            } else {
                $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&action=send_email&t=" + new Date(), function (data) {
                    vcodeinstaltip = "email";
                    if (data == "0") {
                        data = "验证码已发送到您的邮箱[<span style='color:red'>" + userData[0].umail + "</span>]，请查收！";
                    }
                    showResults(data, 5000, "close");
                });
            }
        });
        $("#suwin").dialog({ title: "重装系统", autoOpen: false, resizable: false, width: 500, height: h, modal: true, buttons: {
            "确认重装": function () {
                var nowOs = $("input[name=rados]:checked").val();
                var code = '';
                if (userData[0].isAdmin != "True" && (emailchk != "0" || smschk != "0")) {
                    code = $("#txtchkCode").val();
                    if (code.length <= 0) {
                        processing("正在处理...");
                        showResults("请输入验证码！", 1000, "close");
                        $("#txtchkCode").val('').focus();
                        return;
                    }
                }

                //  $("#chktip").html(ajaxLoading("正在执行操作，请稍等......")).css("color", "green");
                // $("#suwin input").attr("disabled", "disabled");
                // $(".ui-dialog-buttonset button:first").attr("disabled", "disabled");
                processing("正在执行操作，请稍等......");
                $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&caction=reinstal&os=" + nowOs + "&code=" + code + "&t=" + new Date(), function (data) {
                    //                    if (data == "0") {
                    //                        showTipWin('重装成功！',nowOs);
                    //                    } else {
                    //                        $("#chktip").html('<br/>' + data).css("color", "red");
                    //                        $(".ui-dialog-buttonset button:first").removeAttr("disabled");
                    //                        $("#suwin input").removeAttr("disabled");
                    //                    }
                    if (data == "0") {
                        showResults("重装成功", 2000, "close");
                        $("#suwin").dialog("close");
                        $("#spanos").html(nowOs);
                    } else {
                        showResults(data, 5000, "close");
                    }
                });

            }, "关 闭": function () { $(this).dialog("close"); }
        }
        }).dialog("open");
    });
}
function getData(data) {

    if (data != "") data = (parseFloat(data) / 1024 / 1024 / 1024).toFixed(2);
    else data = 0;
    return data;
}
function showStatist(data) {
    var arr = data.split('|');
    if (arr[0] == '-1') {
        $("#tdbandwidthload").html(arr[1]);
        $("#tddisk").html(arr[1]);
        $("#tdram").html(arr[1]);
    } else {
        var json = $.parseJSON(data);
        var bw = json.bandwidth.split(',');
        var usedbw = getData(bw[1]), freebw = getData(bw[2]);
        var ram = json.ram.split(',');
        var usedram = 0, freeram = 0;
        if (ram[1] != "")
            usedram = (parseFloat(ram[1]) / 1024 / 1024).toFixed(2);
        if (ram[2] != "")
            freeram = (parseFloat(ram[2]) / 1024 / 1024).toFixed(2);

        if (freeram == '0.00') freeram = parseFloat(serviceData[0].sconfig.ram).toFixed(2);

        var disk = json.disk.split(',');
        var useddisk = getData(disk[1]), freedisk = getData(disk[2]);

        $("#tdbandwidthload").html('<div style="height:18px;width: 218px;float:left" id="bandwidthload" class="ui-progressbar ui-widget ui-widget-content ui-corner-all" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><div class="ui-progressbar-value ui-widget-header ui-corner-left" style="display: none; width: 0%; "></div></div>&nbsp;&nbsp;&nbsp;' + bw[3] + '%，已使用' + usedbw + 'G，剩余' + freebw + 'G');
        $("#bandwidthload").progressbar({
            value: parseFloat(usedbw)
        });

        $("#tdram").html('<div style="height:18px;width: 218px;float:left" id="ramload" class="ui-progressbar ui-widget ui-widget-content ui-corner-all" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><div class="ui-progressbar-value ui-widget-header ui-corner-left" style="display: none; width: 0%; "></div></div>&nbsp;&nbsp;&nbsp;' + ram[3] + '%，已使用' + usedram + 'M，剩余' + freeram + 'M');
        $("#ramload").progressbar({
            value: parseFloat(usedram)
        });
        $("#tddisk").html('<div style="height:18px;width: 218px;float:left" id="diskload" class="ui-progressbar ui-widget ui-widget-content ui-corner-all" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><div class="ui-progressbar-value ui-widget-header ui-corner-left" style="display: none; width: 0%; "></div></div>&nbsp;&nbsp;&nbsp;' + disk[3] + '%，已使用' + useddisk + 'G，剩余' + freedisk + 'G');
        $("#diskload").progressbar({
            value: parseFloat(useddisk)
        });
    }
}

function showChart(type, tip) {
    if (serviceData[0].sstatus == "-1") {
        alert("当前状态不允许读取图表信息，请稍候重试！");
        return;
    }
    $("#suwin").html(ajaxLoading("正在加载图表信息，请稍等......"));
    $("#suwin").dialog({ title: tip, autoOpen: false, resizable: false, width: 600, height: 400, modal: true, buttons: { "关 闭": function () { $(this).dialog("close"); } } }).dialog("open");
    $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&caction=getstatechart&t=" + new Date(), function (data) {

        var vjson = $.parseJSON(data);
        if (vjson.error == "0") {
            var imgSrc = "";
            if (type == 1) imgSrc = vjson.loadgraph;
            else if (type == 2) imgSrc = vjson.memorygraph;
            else imgSrc = vjson.trafficgraph;
            if (imgSrc == undefined || imgSrc == "") {
                $("#suwin").html('<div style="margin-top:30px;text-align:center;font-weight:bold">生成' + tip + '失败，请稍后重试！</div>');
            } else {
                $("#suwin").html("<img src='" + imgSrc + "' width='570' height='270'/>");
            }
        } else {
            $("#suwin").html('<div style="margin-top:30px;text-align:center;font-weight:bold">' + vjson.error + '</div>');
        }

    });

}
var pwdTime = 180, instalTime = 180, vcodepwdtip = "", vcodeinstaltip = "";
function showPwdWin(type, emailchk, smschk) {
    if (serviceData[0].ssid == "0") {
        alert("当前状态不允许重置密码操作，请稍候重试！");
        return;
    }
    var height = 200;
    var str = "";
    if (userData[0].isAdmin != "True" && (emailchk != "0" || smschk != "0")) {
        height = 300;
        str = '<p style="margin:10px 0px;">请选择验证方式：';
        if (smschk != "0") {
            str += '<input type="radio" name="radpcheck" id="smspcheck" checked="checked" value="1"/><label for="smspcheck">短信验证</label>&nbsp;&nbsp;';
        }
        if (emailchk != "0") {
            str += '<input type="radio" name="radpcheck" id="emailpcheck" value="2"/><label for="emailpcheck">邮箱验证</label>';
        }
        if (pwdTime == 180) {
            str += '&nbsp;&nbsp;<input  type="button" class="submit" id="btnSendpChkCode" value="发送验证码"/></p>';
        } else {
            str += '&nbsp;&nbsp;<input  type="button" disabled="disabled" class="submit" style="color:gray;cursor:default" id="btnSendpChkCode" value="还剩' + pwdTime + '秒"/></p>';
        }
        str += '<p style="margin-top:10px;padding-left:4px;">验 证 码：<input type="text" class="text"  id="txtpchkCode"/></p>';

        //str += '<p><span id="chkptip" style="margin-top:10px;color:green;">' + vcodepwdtip + '</span></p>';
    } //else
    // str += '<p style="font-weight:bold;padding-top:20px;text-align:center;"><input type="checkbox" id="confirm_box" value="1"/><label for="confirm_box" style="cursor:pointer">您确定要重置主机密码吗？<label></p>';
    str += '<p style="margin:10px 0px;padding-left:3px;">新 密 码：<input type="password" class="text" id="txtpwd"/>&nbsp;&nbsp;<span style="color:green;">(至少6位字符)</span></p>' +
    '<p>确认密码：<input type="password" class="text" id="txtrepwd"/></p>';

    $("#suwin").html(str);
    if (vcodepwdtip.indexOf('@') > -1) {
        $("#emailpcheck").attr("checked", "checked");
    } else {
        $("input[name=radpcheck]:first").attr("checked", "checked");
    }
    $("#btnSendpChkCode").click(function () {
        $("#btnSendpChkCode").attr("disabled", "disabled").attr("value", "还剩" + pwdTime + "秒").css({ "color": "gray", "cursor": "default" });
        var myTimer = setInterval(function () {
            if (pwdTime > 1) {
                pwdTime -= 1;
                $("#btnSendpChkCode").attr("value", "还剩" + pwdTime + "秒");
            }
            else {
                clearInterval(myTimer);
                pwdTime = 180;
                $("#btnSendpChkCode").removeAttr("disabled").css({ "color": "white", "cursor": "pointer" }).val('发送验证码');
            }
        }, 1000);
        processing("正在发送验证码，请稍等......");

        var chk = $("input[name=radpcheck]:checked").val();
        if (chk == "1") {
            $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&action=send_sms&t=" + new Date(), function (data) {
                if (data == "0") {

                    data = "验证码已发送到您的手机[<span style='color:red'>" + userData[0].tel + "</span>]，请查收！";
                } else {

                }
                showResults(data, 5000, "close");
            });
        } else {
            $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&action=send_email&t=" + new Date(), function (data) {
                if (data == "0") {
                    data = "验证码已发送到您的邮箱[<span style='color:red'>" + userData[0].umail + "</span>]，请查收！";
                } else {

                }
                showResults(data, 5000, "close");
            });
        }
    });
    var vtitle = "重置VPS密码";
    if (type == 2) vtitle = "重置用户登录密码";
    $("#suwin").dialog({ title: vtitle, autoOpen: false, resizable: false, width: 480, height: height, modal: true, buttons: {
        "确认重置": function () {

            var pwd = $("#txtpwd").val();
            var repwd = $("#txtrepwd").val();
            var pcode = '';
            //var exp = /^[A-Za-z0-9]{6,16}$/;
            if (pwd.length < 5) {
                processing("正在处理...");
                showResults("请输入正确的密码！", 1000, "close");
                $("#txtpwd").val('').focus();
                return;
            } else if (repwd != pwd) {
                processing("正在处理...");
                showResults("确认密码与新密码不一致！", 1000, "close");
                $("#txtrepwd").val('').focus();
                return;
            } else if (userData[0].isAdmin != "True" && (emailchk != "0" || smschk != "0")) {
                pcode = $("#txtpchkCode").val();
                if (pcode.length <= 0) {
                    processing("正在处理...");
                    showResults("请输入验证码！", 1000, "close");
                    $("#txtpchkCode").val('').focus();
                    return;
                }
            }
            //else if (!$("#confirm_box").prop("checked")) {
            //                processing("正在处理...");
            //                showResults("请勾选复选框以确认操作！", 2000, "close");

            //                return false;
            //            }
            processing("正在执行操作，请稍等......");

            $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&caction=changepwd&type=" + type + "&code=" + pcode + "&pwd=" + pwd + "&repwd=" + repwd + "&t=" + new Date(), function (data) {

                if (data.split('|')[0] == "0") {
                    showResults(data.substr(2), 5000, "");
                    $("#suwin").dialog("close");

                    if (type == 2) $("#password").val(pwd);

                } else {
                    showResults(data, 5000, "");
                }

            });

        },
        "关 闭": function () { $(this).dialog("close"); }
    }
    }).dialog("open");
}

function showTipWin(tip, txt) {
    $("#suwin").dialog({ title: "操作提示", autoOpen: false, resizable: false, width: 350, height: 200, modal: false, buttons: { "关 闭": function () { $(this).dialog("close"); } } }).dialog("open");
    $("#suwin").html('<div style="margin-top:30px;text-align:center;font-weight:bold">' + tip + '</div>');
    // setTimeout('top.location.reload();', 3000);
    setTimeout('$("#suwin").dialog("close");$("#spanos").html("' + txt + '");', 3000);
}


function ControlServer(vpsid, action, tip) {
    if (serviceData[0].ssid == "0") {
        alert("当前状态不允许该操作，请稍候重试！");
        return;
    }
    var msg = "您确定要" + tip + "VPS主机[" + vpsid + "]吗？";
    $("#suwin").html('<p style="font-weight:bold;padding-top:20px;text-align:center;"><input type="checkbox" id="confirm_box" value="1"/><label for="confirm_box" style="cursor:pointer">' + msg + '<label></p>');
    $("#suwin").dialog({ title: "操作确认", autoOpen: false, resizable: false, width: 340, height: 200, modal: true, buttons: { "确认": function () {
        if (!$("#confirm_box").prop("checked")) {
            alert('请勾选复选框以确认操作！');
            return false;
        }
        runService(vpsid, action, tip);
    }, "关 闭": function () { $(this).dialog("close"); }
    }
    }).dialog("open");
}

function runService(vpsid, action, tip) {
    var msg = "正在" + tip + "VPS主机，请稍候......";
    $("#suwin").html(ajaxLoading(msg));
    $("#suwin").dialog({ title: "操作提示", autoOpen: false, resizable: false, width: 300, height: 200, modal: true, buttons: { "关 闭": function () { $(this).dialog("close"); } } }).dialog("open");
    var delay = 0;
    $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&caction=handlevps&act=" + action + "&t=" + new Date(), function (data) {
        if (data == "1") {
            data = tip + 'VPS主机成功！';
            delay = 3000;
        }
        $("#suwin").html("<br/><br/><div style='text-align:center;'>" + data + "</div>");
        //if (delay > 0) setTimeout('top.location.reload();', delay);
        if (delay > 0) {
            setTimeout('$("#suwin").dialog("close");$("#spanstate").html("检测中......");$("#btnfresh").hide();', delay);

            setTimeout('_btnfresh(' + vpsid + ');_autofreshstate();', 10000);
        }
    })
}
_view();


function _autofreshstate() {
    $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&caction=statist&t=" + new Date(), function (data) {
        showStatist(data);
    });
}


function _btnfresh(vpsid) {
    if (vpsid != "0") {
        $("#spanstate").html("检测中......");
        $("#btnfresh").hide();
        $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&caction=freshstate&t=" + new Date(), function (data) {

            var varr = data.split('|');
            if (varr[1] == "online") {
                $("#spanstate").html("<img src='" + varr[2] + "/js/run.png'/>正在运行");
            } else if (varr[1] == "offline") {
                $("#spanstate").html("<img src='" + varr[2] + "/js/stop.png'/>已停止运行");

            } else {
                $("#spanstate").html("<img src='" + varr[2] + "/js/stop.png'/>" + varr[1]);
            }

            $("#btnfresh").show();
            setTimeout("_btnfresh('" + vpsid + "')", 120000);
        });
    }
}
var finalPrice = 0;
var normalPrice = 0;
var productID = productData[0].pid;
var billingMothod = 1;
var billingCycle = 1;
function _renew() {
    if (serviceData[0].spmothod != "1") {
        alert("您当前服务无需续费！");
        return false;
    }
    if (serviceData[0].sstatus == "-1") {
        alert("当前状态不允许续费操作，请稍候重试！");
        return;
    }
    var discount = parseFloat(productData[0].discount);

    var str = '<div style="line-height:25px"><strong>帐户余额</strong>：<strong>' + parseFloat(userData[0].balance).toFixed(2) + '</strong> ' + userData[0].currency;
    if (discount < 1) str += '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong>帐户优惠</strong>：<strong style="color:#0000FF">' + (discount * 100 / 10) + '</strong>折';
    str += '&nbsp;<br /><strong>请选择续费周期</strong>：<br />';
    var cycles = productData[0].pprice.cycle.split(',');
    var cprices = productData[0].pprice.cprice.split(',');
    var cprice = 0, yprice = 0, pp1 = 0, pp2 = 0;
    for (i = 0; i < cycles.length; i++) {
        if (cprices[i] != '0') {
            cprice = parseFloat(cprices[i]);
            yprice = cprice;
            if (cycles[i] == serviceData[0].spcycle) cprice = serviceData[0].sprice;

            if (pp1 == 0) pp1 = parseFloat(yprice) / parseInt(cycles[i]);
            else {
                pp2 = (parseFloat(yprice) / parseInt(cycles[i]) / pp1 * 10).toFixed(1);
            }
            str += '<input type="radio" name="cycle" value="' + cycles[i] + '_' + cprice + '_' + yprice + '" id="cycle' + cycles[i] + '" /><label for="cycle' + cycles[i] + '">';
            //            switch (cycles[i]) {
            //                case "1": str += '月　付'; break;
            //                case "3": str += '季　付'; break;
            //                case "6": str += '半年付'; break;
            //                case "12": str += '年　付'; break;
            //                case "24": str += '二年付'; break;
            //                default: str += cycles[i] + '个月付'; break;
            //            }
            //            if (cycles[i] == serviceData[0].spcycle) str += '：' + parseFloat(cprice).toFixed(2) + (pp2 != 0 ? ' (' + pp2 + '折)' : '') + '</label><br />';
            //            else
            //                str += '：' + (discount > 1 ? (parseFloat(cprice) * discount).toFixed(2) : cprice) + (pp2 != 0 ? ' (' + pp2 + '折)' : '') + '</label><br />';
            str += parseFloat(cprice).toFixed(2) + ' / ' + getTimeCycleSuffix(cycles[i], timeCycle, 1) + ((pp2 > 0 && pp2 < 10) ? ' (' + pp2 + '折)' : '') + '</label><br />';

        }
    }
    str += '&nbsp;<br /><strong>续费价格</strong>：<strong class="finalPrice"></strong> ' + userData[0].currency + '&nbsp;&nbsp;&nbsp;<span class="normalPrice"></span><br />&nbsp;<br />' +
           '<span>优 惠 码：<input type="text" id="couponcode" class="text"  size="10"/> <input type="button" class="submit" value="使用" onclick="applyCode(\'renew\')"/> <input type="button" class="submit" value="不使用" onclick="clearCouponCode(1)"/></span><br />' +
           '<span id="ccdes" class="pptext"></span></div>';
    $("#suwin").html(str);
    $("#suwin input:radio").click(function () {
        clearCouponCode(1);
        var ps = $(this).val().split('_');
        billingCycle = parseInt(ps[0]);
        finalPrice = parseFloat(ps[1]);
        normalPrice = parseFloat(ps[2]);
        if (billingCycle != parseInt(serviceData[0].spcycle)) finalPrice = finalPrice * discount;
        $("#suwin .finalPrice").html(finalPrice.toFixed(2));

    });
    $("#suwin #cycle" + serviceData[0].spcycle).click();
    $("#suwin").dialog({ title: "续费确认", autoOpen: false, resizable: false, width: 500, height: 430, modal: false, buttons: { "确认续费": function () { renew(serviceData[0].sid, billingCycle, $("#couponcode").val()); }, "关 闭": function () { $(this).dialog("close"); } } }).dialog("open");
}
function getTimeCycleSuffix(billingCycle, timeCycle, tag) {
    var cycleSuffix = '';
    if (billingCycle == 0) {
        switch (timeCycle) {
            case '1': cycleSuffix = '天'; break;
            case '2': cycleSuffix = '小时'; break;
            default:
                cycleSuffix = '月';
                if (tag == 1) cycleSuffix = '个月';
                break;
        }
    }
    else {
        if (timeCycle == '0') {
            switch (billingCycle) {
                case '1': cycleSuffix = '月'; break;
                case '3': cycleSuffix = '季'; break;
                case '6': cycleSuffix = '半年'; break;
                case '12': cycleSuffix = '年'; break;
                case '24': cycleSuffix = '2年'; break;
                default: cycleSuffix = billingCycle + '个月'; break;
            }
        }
        else if (timeCycle == '1') {
            switch (billingCycle) {
                case '1': cycleSuffix = '天'; break;
                case '7': cycleSuffix = '周'; break;
                case '15': cycleSuffix = '半月'; break;
                case '30': cycleSuffix = '月'; break;
                case '90': cycleSuffix = '季'; break;
                case '365': cycleSuffix = '年'; break;
                default: cycleSuffix = billingCycle + '天'; break;
            }
        }
        else {
            switch (billingCycle) {
                case '1': cycleSuffix = '小时'; break;
                case '24': cycleSuffix = '天'; break;
                case '168': cycleSuffix = '周'; break;
                default: cycleSuffix = billingCycle + '小时'; break;
            }
        }
    }
    return cycleSuffix;
}

