﻿/*
{"name":"VestaCP虚拟主机","tag":"VestaCP","version":"1.05","build":"build(201508311407)"}
*/