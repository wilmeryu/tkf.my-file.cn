﻿/// <reference path="jquery.min.js" />

function baseConfig() {
    var product_data = productData;
    $.post("?c=module&productid=" + product_data[0].pid + "&show=text&caction=listplans&t=" + new Date(), function (data) {
      
        if (data == "[]") {
            $("#ProductConfig").html("<div style='color:red;font-size:14px; text-align:center;margin-top:50px;'>您还没有在Vestacp面板配置任何套餐，请先在Vestacp面板配置好套餐！</div>");
            return;
        }
        //        else if (vArr[0] == "-1") {
        //            $("#ProductConfig").html("<div style='color:red;font-size:14px; text-align:center;margin-top:50px;'>" + vArr[1] + "</div>");
        //            return;
        //        }
        var vdataArr = $.parseJSON(data);
        var vdetail = "<p style='margin:15px 0px 10px 0px;' id='wspplan'><strong>产品基本套餐配置</strong>：<select id=\"config_plan\" name=\"config_plan\" style=\"height:auto;cursor:pointer;\">";
        for (var i = 0, len = vdataArr.length; i < len; i++) {
            vdetail += "<option value='" + vdataArr[i].planname + "'>" + vdataArr[i].planname + "</option>";
        }
        vdetail += "</select></p>";
        var plan = vdataArr[0].planname;
        if (product_data[0].pconfig != null && product_data[0].pconfig != "") {
            plan = product_data[0].pconfig.plan;
        }
        changeDetail(plan, vdetail, vdataArr);
    });
}
function changeDetail(plan, vdetail, vdataArr) {
     var i=0;
    for (i = 0, len = vdataArr.length; i < len; i++) {
        if (plan == vdataArr[i].planname) {
            $("#ProductConfig").html(vdetail + getDetail(vdataArr[i]));
            // $('#config_plan').find("[value=" + planid + "]option").attr("selected", "selected");
            $('#config_plan').val(plan);
            $("#config_plan").change(function () {changeDetail($("#config_plan").val(), vdetail, vdataArr) });
            break;
        }
    }
    if (i == vdataArr.length) {
        $("#ProductConfig").html(vdetail + getDetail(vdataArr[0]));
        $("#config_plan").change(function () { changeDetail($("#config_plan").val(), vdetail, vdataArr) });
    }
}
function getDetail(obj) {
   var str = "<fieldset style=\"border:1px solid #ccc; padding:0px 10px;margin:8px 0px;\">";
    str += "<legend style=\"padding:0px 6px;\">";
    str += '套餐详细信息';
    str += "</legend>";
    str += "<table>";
    str += "<tr>";
    str += "<td style='width:100px;'>&nbsp;</td>";
    str += "<td style='width:100px;text-align:right;'>";
    str += "流量：";
    str += "</td>";
    str += "<td style='width:100px;text-align:left;'>";
    str += "<input type=\"hidden\" value='" + obj.bandwidth + "' name=\"config_bandwidth\" id=\"config_bandwidth\" />";
    str += "<span style=\"\" id=\"bandwidth\">" + obj.bandwidth + "</span>";
    str += "</td>";
    str += "<td style='width:120px;text-align:right;'>";
    str += "磁盘大小：";
    str += "</td>";
    str += "<td style='text-align:left;'>";
    str += "<input type=\"hidden\" value='" + obj.disk + "' name=\"config_disk\" id=\"config_disk\" />";
    str += "<span style=\"\" id=\"disk\">" + obj.disk + "</span>";
    str += "</td>";
    str += "</tr>";
    str += "<tr>";
    str += "<td style='width:100px;'>&nbsp;</td>";
    str += "<td style='width:100px;text-align:right;'>";
    str += "网站域名配额：";
    str += "</td>";
    str += "<td style='width:120px;text-align:left;'>";
    str += "<input type=\"hidden\" value='" + obj.webDomains + "' name=\"config_webDomains\" id=\"config_webDomains\" />";
    str += "<span style=\"width:100px\" id=\"webDomains\">" + obj.webDomains + "</span> （个）";
    str += "</td>";
    str += "<td style='width:100px;text-align:right;'>";
    str += "网站别名：";
    str += "</td>";
    str += "<td style='text-align:left;'>";
    str += "<input type=\"hidden\" value='" + obj.webAliases + "' name=\"config_webAliases\" id=\"config_webAliases\"/>";
    str += "<span style=\"\" id=\"webAliases\">" + obj.webAliases + "</span> （个）";
    str += "</td>";
    str += "</tr>";


    str += "<tr>";
    str += "<td style='width:100px;'>&nbsp;</td>";
    str += "<td style='width:100px;text-align:right;'>";
    str += "DNS域名配额：";
    str += "</td>";
    str += "<td style='width:120px;text-align:left;'>";
    str += "<input type=\"hidden\" value='" + obj.dnsDomains + "' name=\"config_dnsDomains\" id=\"config_dnsDomains\" />";
    str += "<span style=\"width:100px\" id=\"dnsDomains\">" + obj.dnsDomains + "</span> （个）";
    str += "</td>";
    str += "<td style='width:100px;text-align:right;'>";
    str += "DNS记录：";
    str += "</td>";
    str += "<td style='text-align:left;'>";
    str += "<input type=\"hidden\" value='" + obj.dnsRecords + "' name=\"config_dnsRecords\" id=\"config_dnsRecords\"/>";
    str += "<span style=\"\" id=\"dnsRecords\">" + obj.dnsRecords + "</span> （个）";
    str += "</td>";
    str += "</tr>";

    str += "<tr>";
    str += "<td style='width:100px;'>&nbsp;</td>";
    str += "<td style='width:100px;text-align:right;'>";
    str += "邮局域名配额：";
    str += "</td>";
    str += "<td style='width:120px;text-align:left;'>";
    str += "<input type=\"hidden\" value='" + obj.mailDomains + "' name=\"config_mailDomains\" id=\"config_mailDomains\" />";
    str += "<span style=\"width:100px\" id=\"mailDomains\">" + obj.mailDomains + "</span> （个）";
    str += "</td>";
    str += "<td style='width:100px;text-align:right;'>";
    str += "邮箱账户：";
    str += "</td>";
    str += "<td style='text-align:left;'>";
    str += "<input type=\"hidden\" value='" + obj.mailAccounts + "' name=\"config_mailAccounts\" id=\"config_mailAccounts\"/>";
    str += "<span style=\"\" id=\"mailAccounts\">" + obj.mailAccounts + "</span> （个）";
    str += "</td>";
    str += "</tr>";
   
    str += "<tr>";
    str += "<td style='width:100px;'>&nbsp;</td>";
    str += "<td style='width:100px;text-align:right;'>";
    str += "数据库：";
    str += "</td>";
    str += "<td style='width:120px;text-align:left;'>";
    str += "<input type=\"hidden\" value='" + obj.databases + "' name=\"config_databases\" id=\"config_databases\"/>";
    str += "<span style=\"width:100px\" id=\"databases\">" + obj.databases + "</span> （个）";
    str += "</td>";
    str += "<td style='width:100px;text-align:right;'>";
    str += "定时任务：";
    str += "</td>";
    str += "<td style='text-align:left;'>";
    str += "<input type=\"hidden\" value='" + obj.cronJobs + "' name=\"config_cronJobs\" id=\"config_cronJobs\"/>";
    str += "<span style=\"\" id=\"cronJobs\">" + obj.cronJobs + "</span> （个）";
    str += "</td>";
    str += "</tr>";

    str += "<tr>";
    str += "<td style='width:100px;'>&nbsp;</td>";
    str += "<td style='width:100px;text-align:right;'>";
    str += "SSH权限：";
    str += "</td>";
    str += "<td style='text-align:left;'>";
    str += "<input type=\"hidden\" value='" + (obj.sshAccess == "nologin" ? "无" : obj.sshAccess) + "' name=\"config_sshAccess\" id=\"config_sshAccess\"/>";
    str += "<span style=\"\" id=\"sshAccess\">" + (obj.sshAccess == "nologin" ? "无" : obj.sshAccess) + "</span>";
    str += "</td>";
    str += "<td style='width:100px;text-align:right;'>";
    str += "备份数：";
    str += "</td>";
    str += "<td style='width:120px;text-align:left;'>";
    str += "<input type=\"hidden\" value='" + obj.backups + "' name=\"config_backups\" id=\"config_backups\"/>";
    str += "<span style=\"width:100px\" id=\"backups\">" + obj.backups + "</span>  （个）";
    str += "</td>";
    str += "</tr>";
    str += "</table>";
    str += "<br/>";
    str += "</fieldset>";
    return str;
}
baseConfig();