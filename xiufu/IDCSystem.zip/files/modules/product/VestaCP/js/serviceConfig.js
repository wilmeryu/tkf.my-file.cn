﻿/// <reference path="jquery.min.js" />
function serviceConfig() {

    var str = "<input type='hidden' name='startpwd' id='startpwd' value=" + serviceData[0].sconfig.startpwd + "><br/><strong>登录用户名</strong>：idcvesta" + serviceData[0].ssid + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong>初始密码</strong>：	" + serviceData[0].sconfig.startpwd + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='hidden' name='plan' id='plan' value=" + serviceData[0].sconfig.plan + "><strong>用户套餐名称</strong>：" + serviceData[0].sconfig.plan;
    str+= "<fieldset style=\"border:1px solid #ccc; padding:0px 10px;margin:8px 0px;\">";
    str += "<legend style=\"padding:0px 6px;\">";
    str += '套餐详细信息';
    str += "</legend>";
    str += "<table>";
    str += "<tr>";
    str += "<td style='width:100px;height:25px;'>&nbsp;</td>";
    str += "<td style='width:100px;text-align:right;'>";
    str += "磁盘大小：";
    str += "</td>";
    str += "<td style='width:100px;text-align:left;'>";
    str += "<input type='hidden' name='disk' id='disk' value=" + serviceData[0].sconfig.disk + "><span style=\"\">" + serviceData[0].sconfig.disk + "</span>";
    str += "</td>";
    str += "<td style='width:120px;text-align:right;'>";
    str += "流量：";
    str += "</td>";
    str += "<td style='text-align:left;'>";
    str += "<input type='hidden' name='bandwidth' id='bandwidth' value=" + serviceData[0].sconfig.bandwidth + "><span style=\"\">" + serviceData[0].sconfig.bandwidth + "</span>";
    str += "</td>";
    str += "</tr>";
    str += "<tr>";
    str += "<td style='width:100px;height:25px;'>&nbsp;</td>";
    str += "<td style='width:100px;text-align:right;'>";
    str += "域名配额：";
    str += "</td>";
    str += "<td style='width:120px;text-align:left;'>";
    str += "<input type='hidden' name='webDomains' id='webDomains' value=" + serviceData[0].sconfig.webDomains + "><span style=\"width:100px\">" + serviceData[0].sconfig.webDomains + "</span> （个）";
    str += "</td>";
    str += "<td style='width:100px;text-align:right;'>";
    str += "网站别名：";
    str += "</td>";
    str += "<td style='text-align:left;'>";
    str += "<input type='hidden' name='webAliases' id='webAliases' value=" + serviceData[0].sconfig.webAliases + "><span style=\"\">" + serviceData[0].sconfig.webAliases + "</span> （个）";
    str += "</td>";
    str += "</tr>";


    str += "<tr>";
    str += "<td style='width:100px;height:25px;'>&nbsp;</td>";
    str += "<td style='width:100px;text-align:right;'>";
    str += "DNS域名配额：";
    str += "</td>";
    str += "<td style='width:120px;text-align:left;'>";
    str += "<input type='hidden' name='dnsDomains' id='dnsDomains' value=" + serviceData[0].sconfig.dnsDomains + "><span style=\"width:100px\">" + serviceData[0].sconfig.dnsDomains + "</span> （个）";
    str += "</td>";
    str += "<td style='width:100px;text-align:right;'>";
    str += "DNS记录：";
    str += "</td>";
    str += "<td style='text-align:left;'>";
    str += "<input type='hidden' name='dnsRecords' id='dnsRecords' value=" + serviceData[0].sconfig.dnsRecords + "><span style=\"\">" + serviceData[0].sconfig.dnsRecords + "</span> （个）";
    str += "</td>";
    str += "</tr>";

    str += "<tr>";
    str += "<td style='width:100px;height:25px;'>&nbsp;</td>";
    str += "<td style='width:100px;text-align:right;'>";
    str += "邮局域名配额：";
    str += "</td>";
    str += "<td style='width:120px;text-align:left;'>";
    str += "<input type='hidden' name='mailDomains' id='mailDomains' value=" + serviceData[0].sconfig.mailDomains + "><span style=\"width:100px\">" + serviceData[0].sconfig.mailDomains + "</span> （个）";
    str += "</td>";
    str += "<td style='width:100px;text-align:right;'>";
    str += "邮箱账户：";
    str += "</td>";
    str += "<td style='text-align:left;'>";
    str += "<input type='hidden' name='mailAccounts' id='mailAccounts' value=" + serviceData[0].sconfig.mailAccounts + "><span style=\"\">" + serviceData[0].sconfig.mailAccounts + "</span> （个）";
    str += "</td>";
    str += "</tr>";

    str += "<tr>";
    str += "<td style='width:100px;height:25px;'>&nbsp;</td>";
    str += "<td style='width:100px;text-align:right;'>";
    str += "数据库：";
    str += "</td>";
    str += "<td style='width:120px;text-align:left;'>";
    str += "<input type='hidden' name='databases' id='databases' value=" + serviceData[0].sconfig.databases + "><span style=\"width:100px\">" + serviceData[0].sconfig.databases + "</span> （个）";
    str += "</td>";
    str += "<td style='width:100px;text-align:right;'>";
    str += "定时任务数：";
    str += "</td>";
    str += "<td style='text-align:left;'>";
    str += "<input type='hidden' name='cronJobs' id='cronJobs' value=" + serviceData[0].sconfig.cronJobs + "><span style=\"\">" + serviceData[0].sconfig.cronJobs + "</span> （个）";
    str += "</td>";
    str += "</tr>";

    str += "<tr>";
    str += "<td style='width:100px;height:25px;'>&nbsp;</td>";
    str += "<td style='width:100px;text-align:right;'>";
    str += "备份数：";
    str += "</td>";
    str += "<td style='width:120px;text-align:left;'>";
    str += "<input type='hidden' name='backups' id='backups' value=" + serviceData[0].sconfig.backups + "><span style=\"width:100px\">" + serviceData[0].sconfig.backups + "</span> （个）";
    str += "</td>";
    str += "<td style='width:100px;text-align:right;'>";
    str += "SSH权限：";
    str += "</td>";
    str += "<td style='text-align:left;'>";
    str += "<input type='hidden' name='sshAccess' id='sshAccess' value=" + serviceData[0].sconfig.sshAccess + "><span style=\"\">" + serviceData[0].sconfig.sshAccess + "</span>";
    str += "</td>";
    str += "</tr>";
    str += "</table>";
    str += "<br/>";
    str += "</fieldset>";
    $("#ServiceConfig").html(str);
}
function changeDetail(vpackname,planid, vdetail, vdataArr) {
        for (var i = 0, len = vdataArr.length; i < len; i++) {
            if (planid == vdataArr[i].planid) {
                $("#ServiceConfig").html(vdetail + getDetail(vdataArr[i]));
                $("#packagename").val(vpackname);
                $('#plan').find("[value=" + planid + "]option").attr("selected", "selected");
                $("#plan").change(function () { changeDetail($("#packagename").val(),$("#plan").val(), vdetail, vdataArr) });
                break;
            }
        }
    }
    function getDetail(obj) {
        var bw = obj.bandwidth == '-1' ? '无限' : obj.bandwidth;
        var disk = obj.disk == '-1' ? '无限' : obj.disk;
        var domains = obj.domains == '-1' ? '无限' : obj.domains;
        var subdomains = obj.subdomains == '-1' ? '无限' : obj.subdomains;
       // var domainbinds = obj.domainpointers == '-1' ? '无限' : obj.domainpointers;
        var ftp = obj.ftps == '-1' ? '无限' : obj.ftps;
        var websites = obj.websites == '-1' ? '无限' : obj.websites;
        var email = obj.emails == '-1' ? '无限' : obj.emails;
        var php5 = obj.php5 == '1' ? '支持' : '不支持';
        var php4 = obj.php4 == '1' ? '支持' : '不支持';
        var aspnet2 = obj.aspnet2 == '1' ? '支持' : '不支持';
        var aspnet4 = obj.aspnet4 == '1' ? '支持' : '不支持';
        var ssl = obj.ssl == '1' ? '支持' : '不支持';
        var cgi = obj.cgi == '1' ? '支持' : '不支持';
        var asp = obj.asp == '1' ? '支持' : '不支持';
        var errors = obj.errors == '1' ? '支持' : '不支持';
        var defaultpage = obj.defaultpage == '1' ? '支持' : '不支持';
        var mssqlsize = obj.mssqlsize == '-1' ? '无限' : obj.mssqlsize;
        var mysqlsize = obj.mysqlsize == '-1' ? '无限' : obj.mysqlsize;
        var mssqlcount = obj.mssql == '-1' ? '无限' : obj.mssql;
        var mysqlcount = obj.mysql == '-1' ? '无限' : obj.mysql;
        var str = "<fieldset style=\"border:1px solid #ccc; padding:0px 10px;margin:8px 0px;\">";
        str += "<legend style=\"padding:0px 6px;\">";
        str += '套餐详细信息';
        str += "</legend>";
        str += "<table>";
        str += "<tr>";
        str += "<td style='width:100px;height:25px;'>&nbsp;</td>";
        str += "<td style='width:100px;text-align:right;'>";
        str += "流量：";
        str += "</td>";
        str += "<td style='width:100px;text-align:left;'>";

        str += "<span style=\"\" id=\"bandwidth\">" + bw + "</span> （M）";
        str += "</td>";
        str += "<td style='width:120px;text-align:right;'>";
        str += "磁盘大小：";
        str += "</td>";
        str += "<td style='text-align:left;'>";
        str += "<span style=\"\" id=\"disk\">" + disk + "</span> （M）";
        str += "</td>";
        str += "</tr>";
        str += "<tr>";
        str += "<td style='width:100px;height:25px;'>&nbsp;</td>";
        str += "<td style='width:100px;text-align:right;'>";
        str += "域名配额：";
        str += "</td>";
        str += "<td style='width:120px;text-align:left;'>";
        str += "<span style=\"width:100px\" id=\"domains\">" + domains + "</span> （个）";
        str += "</td>";
        str += "<td style='width:100px;text-align:right;'>";
        str += "子域名配额：";
        str += "</td>";
        str += "<td style='text-align:left;'>";
        str += "<span style=\"\" id=\"subdomains\">" + subdomains + "</span> （个）";
        str += "</td>";
        str += "</tr>";
       
        str += "<tr>";
        str += "<td style='width:100px;height:25px;'>&nbsp;</td>";
        str += "<td style='width:100px;text-align:right;'>";
        str += "Ftp帐户：";
        str += "</td>";
        str += "<td style='width:120px;text-align:left;'>";
        str += "<span style=\"width:100px\" id=\"ftp\">" + ftp + "</span> （个）";
        str += "</td>";
        str += "<td style='width:100px;text-align:right;'>";
        str += "Email帐户：";
        str += "</td>";
        str += "<td style='text-align:left;'>";
        str += "<span style=\"\" id=\"email\">" + email + "</span> （个）";
        str += "</td>";
        str += "</tr>";


        if (mysqlcount != "0") {
            var mysqlversion = obj.mysqlversion;
            str += "<tr>";
            str += "<td style='width:100px;height:25px;'>&nbsp;</td>";
            str += "<td style='width:100px;text-align:right;'>";
            str += "MySQL" + mysqlversion + "：";
            str += "</td>";
            str += "<td style='width:120px;text-align:left;'>";
            str += "<span style=\"width:100px\" id=\"mysql\">" + mysqlcount + "</span> （个）";
            str += "</td>";
            str += "<td style='width:150px;text-align:right;'>";
            str += "MySQL" + mysqlversion + "数据库大小：";
            str += "</td>";
            str += "<td style='text-align:left;'>";
            str += "<span style=\"\" id=\"mysqlsize\">" +mysqlsize + "</span> （M）";
            str += "</td>";
            str += "</tr>";
        } 
        if (mssqlcount!= "0") {
            var mssqlversion = obj.mssqlversion;
            str += "<tr>";
            str += "<td style='width:100px;height:25px;'>&nbsp;</td>";
            str += "<td style='width:100px;text-align:right;'>";
            str += "MsSQL" + mssqlversion + "：";
            str += "</td>";
            str += "<td style='width:120px;text-align:left;'>";

            str += "<span style=\"width:100px\" id=\"mssql\">" + mssqlcount + "</span> （个）";
            str += "</td>";
            str += "<td style='width:150px;text-align:right;'>";
            str += "MsSQL" + mssqlversion + "数据库大小：";
            str += "</td>";
            str += "<td style='text-align:left;'>";
            str += "<span style=\"\" id=\"mssqlsize\">" + mssqlsize + "</span> （M）";
            str += "</td>";
            str += "</tr>";
        }

        str += "<tr>";
        str += "<td style='width:100px;height:25px;'>&nbsp;</td>";
        str += "<td style='width:100px;text-align:right;'>";
        str += "可建网站数：";
        str += "</td>";
        str += "<td style='text-align:left;'>";
        str += "<span style=\"\" id=\"websites\">" + websites + "</span> （个）";
        str += "</td>";
        str += "<td style='width:100px;text-align:right;'>";
        str += "自定义默认文档：";
        str += "</td>";
        str += "<td style='width:120px;text-align:left;'>";
        str += "<span style=\"width:100px\" id=\"defaultpage\">" + defaultpage + "</span> ";
        str += "</td>";
       
        str += "</tr>";

        str += "<tr>";
        str += "<td style='width:100px;height:25px;'>&nbsp;</td>";
        str += "<td style='width:100px;text-align:right;'>";
        str += "PHP4：";
        str += "</td>";
        str += "<td style='width:120px;text-align:left;'>";
        str += "<span style=\"width:100px\" id=\"php4\">" + php4 + "</span>";
        str += "</td>";
        str += "<td style='width:100px;text-align:right;'>";
        str += "PHP5：";
        str += "</td>";
        str += "<td style='text-align:left;'>";
        str += "<span style=\"\" id=\"php5\">" + php5 + "</span>";
        str += "</td>";
        str += "</tr>";
        str += "<tr>";
        str += "<td style='width:100px;height:25px;'>&nbsp;</td>";
        str += "<td style='width:100px;text-align:right;'>";
        str += "Asp.net2.0：";
        str += "</td>";
        str += "<td style='width:120px;text-align:left;'>";
        str += "<span style=\"width:100px\" id=\"aspnet2\">" + aspnet2 + "</span>";
        str += "</td>";
        str += "<td style='width:100px;text-align:right;'>";
        str += "Asp.net4.0：";
        str += "</td>";
        str += "<td style='text-align:left;'>";
        str += "<span style=\"\" id=\"aspnet4\">" + aspnet4 + "</span>";
        str += "</td>";
        str += "</tr>";

        str += "<tr>";
        str += "<td style='width:100px;height:25px;'>&nbsp;</td>";
        str += "<td style='width:100px;text-align:right;'>";
        str += "Asp：";
        str += "</td>";
        str += "<td style='width:120px;text-align:left;'>";
        str += "<span style=\"width:100px\" id=\"asp\">" + asp + "</span>";
        str += "</td>";
        str += "<td style='width:100px;text-align:right;'>";
        str += "自定义错误：";
        str += "</td>";
        str += "<td style='text-align:left;'>";
        str += "<span style=\"\" id=\"errors\">" + errors + "</span>";
        str += "</td>";
        str += "</tr>";
        str += "<tr>";
        str += "<td style='width:100px;height:25px;'>&nbsp;</td>";
        str += "<td style='width:100px;text-align:right;'>";
        str += "SSL 访问：";
        str += "</td>";
        str += "<td style='width:120px;text-align:left;'>";
        str += "<span style=\"width:100px\" id=\"ssl\">" + ssl + "</span>";
        str += "</td>";
        str += "<td style='width:100px;text-align:right;'>";
        str += "CGI 访问：";
        str += "</td>";
        str += "<td style='text-align:left;'>";
        str += "<span style=\"\" id=\"cgi\">" + cgi + "</span>";
        str += "</td>";
        str += "</tr>";
        str += "</table>";
        str += "<br/>";
        str += "</fieldset>";
        return str;
    }

serviceConfig();