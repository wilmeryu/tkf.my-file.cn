﻿/// <reference path="/modules/js/jquery-vsdoc.js" />
/// <reference path="/modules/js/jquery-ui.min.js" />

function _pm_init() {
    var swin = $("#swin");
    swin.find("#moduleDescription").html('&nbsp;');
    swin.find("#btn_add").remove();

    var apiKey = moduleData[0].cconfig.apiKey == undefined ? '' : moduleData[0].cconfig.apiKey;
    var secretKey = moduleData[0].cconfig.secretKey == undefined ? '' : moduleData[0].cconfig.secretKey;
    var clientID = moduleData[0].cconfig.clientID == undefined ? '' : moduleData[0].cconfig.clientID;
    var hostKey = moduleData[0].cconfig.hostKey == undefined ? '' : moduleData[0].cconfig.hostKey;
    var emailName = moduleData[0].cconfig.emailName == undefined ? '' : moduleData[0].cconfig.emailName;
    var emailPwd = moduleData[0].cconfig.emailPwd == undefined ? '' : moduleData[0].cconfig.emailPwd;

    var str = '<li><label>API key：</label><input type="hidden" name="cname_001" value="apiKey"/><input class="text" type="text" name="cvalue_001" value="' + apiKey + '"/></li>' +
              '<li><label>Secret key：</label><input type="hidden" name="cname_002" value="secretKey"/><input class="text" type="text" name="cvalue_002" value="' + secretKey + '"/></li>' +
    '<li><label>主机商客户编号：</label><input type="hidden" name="cname_003" value="clientID"/><input class="text" type="text" name="cvalue_003" value="' + clientID + '"/></li>' +
    '<li><label>加密key：</label><input type="hidden" name="cname_004" value="hostKey"/><input class="text" type="text" name="cvalue_004" value="' + hostKey + '"/></li>' +
    '<li><label>邮箱登录名：</label><input type="hidden" name="cname_005" value="emailName"/><input class="text" type="text" name="cvalue_005" value="' + emailName + '"/></li>' +
    '<li><label>邮箱登录密码：</label><input type="hidden" name="cname_006" value="emailPwd"/><input class="text" type="text" name="cvalue_006" value="' + emailPwd + '"/></li>';
     var paramList = swin.find("#paramList");
    paramList.html(str);
    //paramList.find("li").css({ "height": "30px" });
   // paramList.find("label").css({ "font-weight": "bold", "float": "left", "text-align": "right", "width": "126px" });
    // paramList.find(".text").css({ "width": "328px" });
    paramList.find("li").css({ "height": "30px", "line-height": "30px" });
    paramList.find("label").css({ "font-weight": "bold", "float": "left", "text-align": "right", "width": "116px", "height": "30px", "line-height": "30px", "cursor": "default" });
    paramList.find(".text").css({ "width": "260px" }); paramList.find(".path").css({ "width": "330px" });
}

_pm_init();