﻿/// <reference path="jquery.min.js" />
function serviceConfig() {
    $("#ServiceConfig").html("<strong>没有相关配置信息</strong>");
}


serviceConfig();