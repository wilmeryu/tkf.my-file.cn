﻿/// <reference path="/modules/js/jquery-vsdoc.js" />
/// <reference path="/modules/js/jquery-ui.min.js" />
//加载域名管理界面
function loadInit() {
    $("#ViewService").html(ajaxLoading()).parents("table");
    $("#pageTitle").replaceWith('<p id="pageTitle" class="subtitle">管理我的网站监控 #' + serviceData[0].sid + '</p>');
    $("#ViewService").parents("table[class='boss']").attr('id', 'tbhostinfo');
    var btnStr = '<td class="catList"><a href="javascript:listMonitors(\'http\');">HTTP监控管理</a>  <a href="javascript:pingList();">Ping监控管理</a>  <a href="javascript:listMonitors(\'https\');">HTTPS监控管理</a>  <a href="javascript:listMonitors(\'ssh\');">SSH监控管理</a>  <a href="javascript:listMonitors(\'ftp\');">FTP监控管理</a>  <a href="javascript:listMonitors(\'mysql\');">MYSQL监控管理</a></td>';
    $("#ViewService").replaceWith(btnStr);
    $(".catList a").button();
}
loadInit();

function listMonitors(type) {
    processing("正在加载中请稍候...");
    var url = "?c=module&serviceid=" + serviceData[0].sid + "&show=text&caction=listMonitors&type=" + type + "&t=" + new Date();
    $.post(url, function (json) {
        var rdata = $.parseJSON(json);
        var str = '<div id="main-content" style="margin:0px;padding:0px;"><table  class="grid" style="width:580px;">' +
                          '<thead><tr><th width="30%">URL</th><th width="14%">端口</th><th width="14%">类型</th><th width="14%">状态</th><th>&nbsp;</th></tr></thead>';
        $(rdata).each(function (i) {
            var url = rdata[i].url;
            var port = getPortByType(type);
            if (url.indexOf(':') > -1) {
                port = url.substr(url.indexOf(":") + 1);
                url = url.substr(0, url.indexOf(":"));
            }
            str += '<tr id="tr' + rdata[i].id + '" name="' + i + '"><td title="' + url + '" width="30%" align="center">' + url + '</td><td width="14%" align="center">' + port + '</td><td width="14%" align="center">' + type + '</td><td width="14%" align="center">' + (rdata[i].isSuspended == 0 ? "<span style='color:green;font-weight:bolder;'>正常</span>" : "<span style='color:red;font-weight:bolder;'>暂停</span>") + '</td><td><input type="button" class="button" name="setstatus" value="' + (rdata[i].isSuspended == 0 ? "暂停" : "启用") + '"/> <input type="button" name="editmonitor" class="button" value="修改"/> <input type="button" name="delmonitor" class="button" value="删除"/> </td></tr>';
        });
        str += "</table></div>";
        swin.html(str);
        swin.find(".button").click(function () {
            var baction = $(this).attr("name");
            var ctr = $(this).parent().parent();

            var exurl = 'id=' + ctr.attr("id").substring(2);
            str = '<form><div style="font-weight:bold;padding-top:10px;line-height:30px;">';
            if (baction == "delmonitor") {
                exurl += '&caction=delmonitor';
                str += '<p style="font-weight:bold;padding-top:20px;text-align:center;"><input type="checkbox" id="confirm_box" value="1"/><label for="confirm_box" style="cursor:pointer;display:inline;">您确定要删除此网站' + type.toUpperCase() + '监控吗？<br/>网站URL：' + ctr.find('td:first').text() + '</label></p>';
                suwin.html(str);
                suwin.dialog({ title: '操作提示', autoOpen: false, resizable: false, width: 400, height: 220, modal: false, buttons: { '确定': function () { delControl(type, '正在处理，请稍候...', '操作成功！', exurl); }, '取消': function () { $(this).dialog("close"); } } }).dialog("open");
            }
            else if (baction == 'setstatus') {
                if ($(this).val() == "暂停") {
                    exurl += '&caction=suspendmonitor';
                } else {
                    exurl += '&caction=startmonitor';
                }
                processing("正在处理，请稍候...");
                var cmd = 'close';
                var delay = 0;
                var url = "?c=module&serviceid=" + serviceData[0].sid + "&show=text&" + exurl + "&t=" + new Date();
                var vstatus = $(this);
                $.post(url, function (rdata) {
                    var vjson = $.parseJSON(rdata);
                    if (vjson.status == "ok") {
                        rdata = "操作成功";
                        delay = 3000;
                        cmd = 'close';
                        if (vstatus.val() == "暂停") {
                            vstatus.val("启用");
                            ctr.find('td:eq(3)').html("<span style='color:red;font-weight:bolder;'>暂停</span>");
                        } else {
                            vstatus.val("暂停");
                            ctr.find('td:eq(3)').html("<span style='color:green;font-weight:bolder;'>正常</span>");
                        }

                    } else {
                        rdata =getErrorTip(vjson.error);
                    }
                    showResults(rdata, delay, cmd);
                });
            } else if (baction == "editmonitor") {
                addMonitors(ctr.attr("id").substring(2), rdata[ctr.attr("name")].name, type);
            }

        });

        if (type == "http")
            swin.dialog({ title: 'HTTP监控管理', autoOpen: false, resizable: false, width: 600, height: 500, modal: false, buttons: { '添加HTTP监控': function () { addMonitors(0, 0, type); }, '关 闭': function () { $(this).dialog("close"); } } }).dialog("open");
        else if (type == "https")
            swin.dialog({ title: 'HTTPS监控管理', autoOpen: false, resizable: false, width: 600, height: 500, modal: false, buttons: { '添加HTTPS监控': function () { addMonitors(0, 0, type); }, '关 闭': function () { $(this).dialog("close"); } } }).dialog("open");
        else if (type == "ssh")
            swin.dialog({ title: 'SSH监控管理', autoOpen: false, resizable: false, width: 600, height: 500, modal: false, buttons: { '添加SSH监控': function () { addMonitors(0, 0, type); }, '关 闭': function () { $(this).dialog("close"); } } }).dialog("open");
        else if (type == "mysql")
            swin.dialog({ title: 'MYSQL监控管理', autoOpen: false, resizable: false, width: 600, height: 500, modal: false, buttons: { '添加MYSQL监控': function () { addMonitors(0, 0, type); }, '关 闭': function () { $(this).dialog("close"); } } }).dialog("open");
        else
            swin.dialog({ title: 'FTP监控管理', autoOpen: false, resizable: false, width: 600, height: 500, modal: false, buttons: { '添加FTP监控': function () { addMonitors(0, 0, type); }, '关 闭': function () { $(this).dialog("close"); } } }).dialog("open");

        $("#processing").dialog("close");

    });
}
function getPortByType(type) {
    var port = 80;
    switch (type) {
        case 'https':
            port = 443;
            break;
        case 'ssh':
            port = 22;
            break;
        case 'ftp':
            port = 21;
            break;
        case 'mysql':
            port = 3306;
            break;
        default:
            port = 80;
            break;
    }
    return port;
}
function addMonitors(id, oldname, type) {
    suwin.html(ajaxLoading("正在加载中请稍候..."));
    var str = '<form action="?c=module&serviceid=' + serviceData[0].sid + '&show=text&caction=addMonitors" onsubmit="return false;"><div style="line-height:35px;"><input type="hidden" name="hidid" id="hidid" value="' + id + '"/><input type="hidden" name="oldname" value="' + oldname + '"/><input type="hidden" name="type" value="' + type + '"/> ' +
                '<li><label class="lbl">URL/IP：</label><input type="text" name="url" id="url" class="text" value=""/> (如：idcsystem.com)</li>' +
                '<li><label class="lbl">端口：</label><input type="text" name="port" id="port" class="text" value="' + getPortByType(type) + '"/> </li>';
    if (type=='http'||type=='https') {
        str += '<li><label class="lbl">请求方法：</label><input type="radio" checked="checked" name="method" value="1" id="bt_0"><label for="bt_0" style="display:inline;">GET</label>&nbsp;&nbsp;&nbsp;<input type="radio" name="method" value="2" id="bt_1"><label for="bt_1" style="display:inline;">POST</label></li>';
    } else if (type == 'ftp') {
        str += '<li><label class="lbl">SSL访问设置：</label><input type="radio" checked="checked" name="ssl" value="1" id="ssl_1"><label for="ssl_1" style="display:inline;">启用SSL</label>&nbsp;&nbsp;&nbsp;<input type="radio" name="ssl" value="0" id="ssl_2"><label for="ssl_2" style="display:inline;">禁用SSL</label> </li>';
    } else if (type == 'mysql') {
        str += '<li><label class="lbl">登录用户名：</label><input type="text" name="mysqlusername" id="mysqlusername" class="text"/> </li>';
        str += '<li><label class="lbl">登录密码：</label><input type="text" name="mysqlpassword" id="mysqlpassword" class="text"/> </li>';
       // str += '<p class="pmethod"><strong>数据库名称：</strong><input type="text" name="mysqldbname" id="mysqldbname" class="text"/> (可不填)<br /></p>';
    }

    str += '<li><label class="lbl">超时设置(秒)：</label><input type="text" name="timeout" id="timeout" class="text" value="10"/> (1-10之间的整数)</li></div></form>';

    if (id != 0) {
        var url = "?c=module&serviceid=" + serviceData[0].sid + "&show=text&caction=getmonitors&id=" + id + "&t=" + new Date();
        $.post(url, function (rdata) {
            suwin.html(str);
            suwin.find("li").css({ "height": "34px", "line-height": "34px" });
            suwin.find("label.lbl").css({ "font-weight": "bold", "float": "left", "text-align": "right", "width": "116px", "height": "30px", "line-height": "30px", "cursor": "default" });
            suwin.find(".text").css({ "width": "260px" });
            $("#port,#timeout").css({ "width": "50px" });
            suwin.find("form:first").attr("action", '?c=module&serviceid=' + serviceData[0].sid + '&show=text&caction=saveMonitors');
            var vjson = $.parseJSON(rdata);
            var url = vjson.url;
            var port = getPortByType(type);
            if (url.indexOf(':') > -1) {
                port = url.substr(url.indexOf(":") + 1);
                url = url.substr(0, url.indexOf(":"));
            }
            $("#url").val(url);
            $("#timeout").val(vjson.timeout);
            $("p.pmethod").remove();
            $("#port").val(port);
        });
    } else {
        suwin.html(str);
        suwin.find("li").css({ "height": "38px", "line-height": "34px" });
        suwin.find("label.lbl").css({ "font-weight": "bold", "float": "left", "text-align": "right", "width": "116px", "height": "30px", "line-height": "30px", "cursor": "default" });
        suwin.find(".text").css({ "width": "260px" });
        $("#port,#timeout").css({ "width": "50px" });
    }

    suwin.dialog({ title: '添加/修改' + type.toUpperCase() + '监控', autoOpen: false, resizable: false, width: 600, height: 500, modal: true, buttons: { '保 存': function () {
        processing('正在处理，请稍候...');
        if ($.trim($("#url").val()).length <= 0) {
            showResults("URL不能为空", 0, "close");
            return;
        }
        if ($.trim($("#port").val()).length <= 0) {
            showResults("端口不能为空", 0, "close");
            return;
        }
        var cform = suwin.find("form:first");
        var delay = 0;
        var cmd = '';
        $.post(cform.attr("action"), cform.serialize(), function (rdata) {
            var vjson = $.parseJSON(rdata);
            if (vjson.status == "ok") {
                rdata = "操作成功";
                delay = 3000;
                cmd = 'close';
                listMonitors(type);
                suwin.dialog("close");

            } else {
                rdata =getErrorTip(vjson.error);
            }
            showResults(rdata, delay, cmd);
        });

    }, '关 闭': function () { $(this).dialog("close"); }
    }
    }).dialog("open");
}

function getErrorTip(strError) {
    var str = "";
    switch (strError) {
        case "The URL is not allowed":
            str = "该URL不允许被添加";
            break;
        case "monitorUrlExists":
            str = "该域名已被添加";
            break;
        case "Invalid timeout value. It should be between 1 and 10.":
            str = "请输入1-10的整数";
            break;
        case "JSON error":
            str = "JSON错误，请检查数值是否过大";
            break;
        case "Invalid parameter 'timeout'.":
            str = "超时设置请输入整数";
            break;
        case "error editing test":
            str = "JSON错误，请检查数值是否过大";
            break;
        case "Invalid timeout value. It should be between 1 and 1000.":
            str = "请输入1-1000的整数";
            break;
           

        default:
            str = strError;
    }
    return str;
}

function pingList() {
    processing("正在加载中请稍候...");
    var url = "?c=module&serviceid=" + serviceData[0].sid + "&show=text&caction=pinglist&t=" + new Date();
    $.post(url, function (json) {
        var rdata = $.parseJSON(json);
        var str = '<div id="main-content" style="margin:0px;padding:0px;"><table class="grid"  style="width:480px;">' +
                          '<thead><tr><th width="30%">URL</th><th width="18%">类型</th><th width="18%">状态</th><th>&nbsp;</th></tr></thead>';
        $(rdata).each(function (i) {
            str += '<tr id="tr' + rdata[i].id + '" name="' + i + '"><td title="' + rdata[i].url + '" width="30%" align="center">' + rdata[i].url + '</td><td width="18%" align="center">Ping</td><td width="18%" align="center">' + (rdata[i].isSuspended == 0 ? "<span style='color:green;font-weight:bolder;'>正常</span>" : "<span style='color:red;font-weight:bolder;'>暂停</span>") + '</td><td><input type="button" class="button" name="setstatus" value="' + (rdata[i].isSuspended == 0 ? "暂停" : "启用") + '"/> <input type="button" name="editmonitor" class="button" value="修改"/> <input type="button" name="delmonitor" class="button" value="删除"/> </td></tr>';
        });
        str += "</table></div>";
        swin.html(str);
        swin.find(".button").click(function () {
            var baction = $(this).attr("name");
            var ctr = $(this).parent().parent();

            var exurl = 'id=' + ctr.attr("id").substring(2);
            str = '<form><div style="font-weight:bold;padding-top:10px;line-height:30px;">';
            if (baction == "delmonitor") {
                exurl += '&caction=delmonitor';
                str += '<p style="font-weight:bold;padding-top:20px;text-align:center;"><input type="checkbox" id="confirm_box" value="1"/><label for="confirm_box" style="cursor:pointer;display:inline;">您确定要删除此网站Ping监控吗？<br/>网站URL：' + ctr.find('td:first').text() + '</label></p>';
                suwin.html(str);
                suwin.dialog({ title: '操作提示', autoOpen: false, resizable: false, width: 400, height: 220, modal: false, buttons: { '确定': function () { delControl('ping', '正在处理，请稍候...', '操作成功！', exurl); }, '取消': function () { $(this).dialog("close"); } } }).dialog("open");
            }
            else if (baction == 'setstatus') {
                if ($(this).val() == "暂停") {
                    exurl += '&caction=suspendmonitor';
                } else {
                    exurl += '&caction=startmonitor';
                }
                processing("正在处理，请稍候...");
                var cmd = 'close';
                var delay = 0;
                var url = "?c=module&serviceid=" + serviceData[0].sid + "&show=text&" + exurl + "&t=" + new Date();
                var vstatus = $(this);
                $.post(url, function (rdata) {
                    var vjson = $.parseJSON(rdata);
                    if (vjson.status == "ok") {
                        rdata = "操作成功";
                        delay = 3000;
                        cmd = 'close';
                        if (vstatus.val() == "暂停") {
                            vstatus.val("启用");
                            ctr.find('td:eq(2)').html("<span style='color:red;font-weight:bolder;'>暂停</span>");
                        } else {
                            vstatus.val("暂停");
                            ctr.find('td:eq(2)').html("<span style='color:green;font-weight:bolder;'>正常</span>");
                        }

                    } else {
                        rdata = getErrorTip(vjson.error);
                    }
                    showResults(rdata, delay, cmd);
                });
            } else if (baction == "editmonitor") {
                addPing(ctr.attr("id").substring(2), rdata[ctr.attr("name")].name);
            }

        });
        swin.dialog({ title: 'Ping监控管理', autoOpen: false, resizable: false, width: 500, height: 500, modal: false, buttons: { '添加Ping监控': function () { addPing(0, 0); }, '关 闭': function () { $(this).dialog("close"); } } }).dialog("open");
        $("#processing").dialog("close");

    });
}
function addPing(id, oldname) {
    suwin.html(ajaxLoading("正在加载中请稍候..."));
    var str = '<form action="?c=module&serviceid=' + serviceData[0].sid + '&show=text&caction=addping" onsubmit="return false;"><div style="line-height:35px;"><input type="hidden" name="hidid" id="hidid" value="' + id + '"/><input type="hidden" name="oldname" id="oldname" value="' + oldname + '"/> ' +
                '<strong>URL/IP：</strong><input type="text" name="url" id="url" class="text" value=""/> (如：idcsystem.com)<br />' +
               '<strong>超时设置(毫秒)：</strong><input type="text" name="timeout" id="timeout" class="text" value="1000" style="width:50px;"/> (1-1000之间的整数)<br /></div></form>';
    if (id != 0) {
        var url = "?c=module&serviceid=" + serviceData[0].sid + "&show=text&caction=getmonitors&id=" + id + "&t=" + new Date();
        $.post(url, function (rdata) {
            suwin.html(str);
            suwin.find("strong").css({ "font-weight": "bold", "float": "left", "text-align": "right", "width": "116", "height": "30px", "line-height": "30px", "cursor": "default" });
            suwin.find("form:first").attr("action", '?c=module&serviceid=' + serviceData[0].sid + '&show=text&caction=saveping');
            var vjson = $.parseJSON(rdata);
            $("#url").val(vjson.url);
            $("#timeout").val(vjson.timeout);
        });
    } else {
        suwin.html(str);
        suwin.find("strong").css({ "font-weight": "bold", "float": "left", "text-align": "right", "width": "116px", "height": "30px", "line-height": "30px", "cursor": "default" });
    }

    suwin.dialog({ title: '添加/修改Ping监控', autoOpen: false, resizable: false, width: 500, height: 500, modal: true, buttons: { '保 存': function () {
        processing('正在处理，请稍候...');
        if ($.trim($("#url").val()).length <= 0) {
            showResults("URL不能为空", 0, "close");
            return;
        }
        if (parseInt($("#timeout").val()) > 1000) {
            showResults("超时设置为1-1000之间的整数", 0, "close");
            return;
        }
        var cform = suwin.find("form:first");
        var delay = 0;
        var cmd = '';
        $.post(cform.attr("action"), cform.serialize(), function (rdata) {
            var vjson = $.parseJSON(rdata);
            if (vjson.status == "ok") {
                rdata = "操作成功";
                delay = 3000;
                cmd = 'close';
                pingList();
                suwin.dialog("close");

            } else {
                rdata = getErrorTip(vjson.error);
            }
            showResults(rdata, delay, cmd);
        });

    }, '关 闭': function () { $(this).dialog("close"); }
    }
    }).dialog("open");
}

function delControl(type, wtext, otext, exurl) {
    var confirm_box = $("#confirm_box").prop("checked");
    if (!confirm_box) {
        alert('请勾选复选框以确认操作！');
        return false;
    }
    suwin.dialog('close');
    processing(wtext);
    var cmd = 'close';
    var delay = 0;
    var url = "?c=module&serviceid=" + serviceData[0].sid + "&show=text&" + exurl + "&t=" + new Date();
    $.post(url, function (rdata) {
        var json = $.parseJSON(rdata);
        if (json.status == "ok") {
            rdata = otext;
            delay = 3000;
            cmd = 'close';
            if (type == "ping") {
                pingList();
            } else {
                listMonitors(type);
            }
        } else {
            rdata = getErrorTip(json.error);
        }
        showResults(rdata, delay, cmd);
    });
}

