﻿/// <reference path="/modules/js/jquery-vsdoc.js" />
/// <reference path="/modules/js/jquery-ui.min.js" />
function _pm_init() {
    var swin = $("#swin");
    swin.find("#moduleDescription").html('&nbsp;');
    swin.find("#btn_add").remove();
    var LoginName = moduleData[0].cconfig.LoginName == undefined ? '' : moduleData[0].cconfig.LoginName;
    var LoginPwd = moduleData[0].cconfig.LoginPwd == undefined ? '' : moduleData[0].cconfig.LoginPwd;
    var IP = moduleData[0].cconfig.IP == undefined ? '' : moduleData[0].cconfig.IP;
    var ClientIP = moduleData[0].cconfig.ClientIP == undefined ? '' : moduleData[0].cconfig.ClientIP;
    var domainip = moduleData[0].cconfig.domainip == undefined ? '' : moduleData[0].cconfig.domainip;
    var emailchk = moduleData[0].cconfig.emailchk == undefined ? '1' : moduleData[0].cconfig.emailchk;
    var smschk = moduleData[0].cconfig.smschk == undefined ? '1' : moduleData[0].cconfig.smschk;
    var enUname = moduleData[0].cconfig.enusername == undefined ? '0' : moduleData[0].cconfig.enusername;
    var enPwd = moduleData[0].cconfig.enpwd == undefined ? '0' : moduleData[0].cconfig.enpwd;
    var vbtnUname = '修改', vbtnPwd = '修改';
    var ableName = 'readonly="readonly"', ablePwd = 'readonly="readonly"';
    if (enUname == '0') {
        vbtnUname = '加密';
        ableName = '';
    }
    if (enPwd == '0') {
        vbtnPwd = '加密';
        ablePwd = '';
    }
    var str = '<li><label class="a">代理用户名：</label><input type="hidden" name="cname_001" value="LoginName"/><input class="text" type="text" name="cvalue_001" value="' + LoginName + '" ' + ableName + ' />&nbsp;&nbsp;&nbsp;<input class="submit" value="' + vbtnUname + '" name="btnEncryp" id="btnName" type="button"/><input type="hidden" name="cname_004" value="enusername"/><input type="hidden" name="cvalue_004" value="' + enUname + '"/>&nbsp;<span class="pptext"></span></li>' +
     '<li><label class="a">代理用户密码：</label><input type="hidden" name="cname_002" value="LoginPwd"/><input class="text" type="text" name="cvalue_002" value="' + LoginPwd + '" ' + ablePwd + '/>&nbsp;&nbsp;&nbsp;<input class="submit" value="' + vbtnPwd + '" name="btnEncryp" id="btnPwd"  type="button"/><input type="hidden" name="cname_005" value="enpwd"/><input type="hidden" name="cvalue_005" value="' + enPwd + '"/>&nbsp;<span class="pptext"></span></li>' +
    '<li><label class="a">WebsitePanel服务器IP：</label><input type="hidden" name="cname_003" value="IP"/><input class="text" type="text" name="cvalue_003" value="' + IP + '"/></li>' +
    '<li><label class="a">WebsitePanel客户端IP：</label><input type="hidden" name="cname_006" value="ClientIP"/><input class="text" type="text" name="cvalue_006" value="' + ClientIP + '"/></li>' +
    '<li><label class="a">域名指向IP：</label><input type="hidden" name="cname_009" value="domainip"/><input class="text" type="text" name="cvalue_009" value="' + domainip + '"/></li>' +
    '<li><label class="a">邮件验证：</label><input type="hidden" name="cname_007" value="emailchk"/>&nbsp<input type="radio" name="cvalue_007" value="1" id="email1"><label for="email1">启用</label>&nbsp;&nbsp;&nbsp;<input type="radio" name="cvalue_007" value="0" id="email0"><label for="email0">禁用</label>' +
    '<li><label class="a">短信验证：</label><input type="hidden" name="cname_008" value="smschk"/>&nbsp;<input type="radio" name="cvalue_008" value="1" id="sms1"><label for="sms1">启用</label>&nbsp;&nbsp;&nbsp;<input type="radio" name="cvalue_008" value="0" id="sms0"><label for="sms0">禁用</label>' +
    '<li><label class="a">WebsitePanel模块版本号：</label>Ver 1.1 build(201204091520)</li>';
    var paramList = swin.find("#paramList");
    paramList.html(str);
    $("input[name=cvalue_007][value=" + emailchk + "]").attr("checked", "checked");
    $("input[name=cvalue_008][value=" + smschk + "]").attr("checked", "checked");
   // paramList.find("li").css({ "height": "30px" });
   // paramList.find("label.a").css({ "font-weight": "bold", "float": "left", "text-align": "right", "width": "200px" });
   // paramList.find(".text").css({ "width": "328px" });
    paramList.find("li").css({ "height": "30px", "line-height": "30px" });
    paramList.find("label.a").css({ "font-weight": "bold", "float": "left", "text-align": "right", "width": "200px", "height": "30px", "line-height": "30px", "cursor": "default" });
    paramList.find(".text").css({ "width": "260px" }); paramList.find(".path").css({ "width": "330px" });
   
    $("#moduleDescription").hide();
    $("input[name=btnEncryp]").click(function () {
        var btn = $(this);
        var txt = btn.parent().find("input[type='text']");
        var hid = btn.parent().find("input:last");
        var vSpan = btn.parent().find("span");
        if (txt.val().length <= 0) {
            vSpan.html("请输入参数值！");
            txt.focus();
            return;
        }

        if ($(this).attr('id') == 'btnName') {
            if (enUname == '1') {//修改操作
                if (confirm('修改登录名需要重新输入登录名，确认修改？')) {
                    txt.val('');
                    hid.val('0');
                    txt.removeAttr('readonly');
                    btn.attr('value', '加密');
                    enUname = '0';
                    vSpan.html("");
                    txt.focus();
                }
                return;
            }
        } else {
            if (enPwd == '1') {
                if (confirm('修改登录密码需要重新输入登录密码，确认修改？')) {
                    txt.val('');
                    hid.val('0');
                    txt.removeAttr('readonly');
                    btn.attr('value', '加密');
                    enPwd = '0';
                    vSpan.html("");
                    txt.focus();
                }
                return;
            }
        }


        vSpan.html("正在加密，请稍等...");
        $.getScript("http://" + currentDomain + "/files/modules/product/WebsitePanel/index.ashx?type=encryp&txt=" + txt.val() + "&t=" + new Date(), function () {
            txt.val(a);
            vSpan.html("加密完成！");
            if (btn.attr('id') == 'btnName') {
                enUname = '1';
            } else {
                enPwd = '1';
            }
            hid.val('1');
            btn.val('修改')
            txt.attr("readonly", "readonly");
        });
    });
}

_pm_init();