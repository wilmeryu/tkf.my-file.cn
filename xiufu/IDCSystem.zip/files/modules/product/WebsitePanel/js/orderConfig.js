﻿/// <reference path="jquery-vsdoc.js" />
/// <reference path="jquery-ui.min.js" />
function orderConfig() {

    var discount = parseFloat(productData[0].discount);
    var pconfig = productData[0].pconfig;
    var str = '<strong>帐户信息</strong>：帐户余额：<strong>' + userData[0].balance + '</strong> ' + userData[0].currency;
    if (discount < 1) str += '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong>帐户优惠</strong>：<strong style="color:#0000FF">' + (discount * 100 / 10) + '</strong>折';
    str += '<br />&nbsp;<strong>产品名称</strong>：<strong>『' + productData[0].pname + '』</strong><br /><strong>产品描述</strong>：' + HTMLDecode(productData[0].pdes) + '<br/>';
    str += "<fieldset style=\"border:1px solid #ccc; padding:0px 10px;margin:15px 0px;\">";
    str += "<legend style=\"padding:0px 2px;\">";
    str += '<strong>产品详细信息</strong>';
    str += "</legend>";
    str += "<table>";
    str += "<tr style='height:25px;'>";
    str += "<td style='width:100px;'>&nbsp;</td>";
    str += "<td style='width:100px;text-align:right;'>";
    str += "流量：";
    str += "</td>";
    str += "<td style='width:100px;text-align:left;'>";
    str += "<span style=\"\" id=\"bandwidth\">" + pconfig.bandwidth + "</span> （M）";
    str += "</td>";
    str += "<td style='width:120px;text-align:right;'>";
    str += "磁盘大小：";
    str += "</td>";
    str += "<td style='text-align:left;'>";
    str += "<span style=\"\" id=\"disk\">" + pconfig.disk + "</span> （M）";
    str += "</td>";
    str += "</tr>";
    str += "<tr style='height:25px;'>";
    str += "<td style='width:100px;'>&nbsp;</td>";
    str += "<td style='width:100px;text-align:right;'>";
    str += "域名配额：";
    str += "</td>";
    str += "<td style='width:120px;text-align:left;'>";
    str += "<span style=\"width:100px\" id=\"domains\">" + pconfig.domains + "</span> （个）";
    str += "</td>";
    str += "<td style='width:100px;text-align:right;'>";
    str += "子域名配额：";
    str += "</td>";
    str += "<td style='text-align:left;'>";
    str += "<span style=\"\" id=\"subdomains\">" + pconfig.subdomains + "</span> （个）";
    str += "</td>";
    str += "</tr>";

    str += "<tr style='height:25px;'>";
    str += "<td style='width:100px;'>&nbsp;</td>";
    str += "<td style='width:100px;text-align:right;'>";
    str += "Ftp帐户：";
    str += "</td>";
    str += "<td style='width:120px;text-align:left;'>";
    str += "<span style=\"width:100px\" id=\"ftps\">" + pconfig.ftps + "</span> （个）";
    str += "</td>";
    str += "<td style='width:100px;text-align:right;'>";
    str += "Email帐户：";
    str += "</td>";
    str += "<td style='text-align:left;'>";
    str += "<span style=\"\" id=\"emails\">" + pconfig.emails + "</span> （个）";
    str += "</td>";
    str += "</tr>";


    if (pconfig.mysql != "0") {
        str += "<tr style='height:25px;'>";
        str += "<td style='width:100px;'>&nbsp;</td>";
        str += "<td style='width:100px;text-align:right;'>";
        str += "MySQL" + pconfig.mysqlversion + "：";
        str += "</td>";
        str += "<td style='width:100px;text-align:left;'>";
        str += "<span style=\"width:100px\" id=\"mysql\">" + pconfig.mysql + "</span> （个）";
        str += "</td>";
        str += "<td style='width:150px;text-align:right;'>";
        str += "MySQL" + pconfig.mysqlversion + "数据库大小：";
        str += "</td>";
        str += "<td style='text-align:left;'>";
        str += "<span style=\"\" id=\"mysqlsize\">" + pconfig.mysqlsize + "</span> （M）";
        str += "</td>";
        str += "</tr>";
    }

    if (pconfig.mssql != "0") {
        str += "<tr style='height:25px;'>";
        str += "<td style='width:100px;'>&nbsp;</td>";
        str += "<td style='width:100px;text-align:right;'>";
        str += "MsSQL" + pconfig.mssqlversion + "：";
        str += "</td>";
        str += "<td style='width:100px;text-align:left;'>";
        str += "<span style=\"width:100px\" id=\"mssql\">" + pconfig.mssql + "</span> （个）";
        str += "</td>";
        str += "<td style='width:150px;text-align:right;'>";
        str += "MsSQL" + pconfig.mssqlversion + "数据库大小：";
        str += "</td>";
        str += "<td style='text-align:left;'>";
        str += "<span style=\"\" id=\"mssqlsize\">" + pconfig.mssqlsize + "</span> （M）";
        str += "</td>";
        str += "</tr>";
    }
    str += "<tr style='height:25px;'>";
    str += "<td style='width:100px;'>&nbsp;</td>";
    str += "<td style='width:100px;text-align:right;'>";
    str += "可建网站数：";
    str += "</td>";
    str += "<td style='text-align:left;'>";
    str += "<span style=\"\" id=\"websites\">" + pconfig.websites + "</span> （个）";
    str += "</td>";
    str += "<td style='width:100px;text-align:right;'>";
    str += "自定义默认文档：";
    str += "</td>";
    str += "<td style='width:120px;text-align:left;'>";
    str += "<span style=\"width:100px\" id=\"domainbinds\">" + pconfig.defaultpage + "</span> ";
    str += "</td>";
    str += "</tr>";
    str += "<tr style='height:25px;'>";
    str += "<td style='width:100px;'>&nbsp;</td>";
    str += "<td style='width:100px;text-align:right;'>";
    str += "PHP4：";
    str += "</td>";
    str += "<td style='width:120px;text-align:left;'>";
    str += "<span style=\"width:100px\" id=\"php4\">" + pconfig.php4 + "</span>";
    str += "</td>";
    str += "<td style='width:100px;text-align:right;'>";
    str += "PHP5：";
    str += "</td>";
    str += "<td style='text-align:left;'>";
    str += "<span style=\"\" id=\"php5\">" + pconfig.php5 + "</span>";
    str += "</td>";
    str += "</tr>";
    str += "<tr style='height:25px;'>";
    str += "<td style='width:100px;'>&nbsp;</td>";
    str += "<td style='width:100px;text-align:right;'>";
    str += "Asp.net2.0：";
    str += "</td>";
    str += "<td style='width:120px;text-align:left;'>";
    str += "<span style=\"width:100px\" id=\"aspnet2\">" + pconfig.aspnet2 + "</span>";
    str += "</td>";
    str += "<td style='width:100px;text-align:right;'>";
    str += "Asp.net4.0：";
    str += "</td>";
    str += "<td style='text-align:left;'>";
    str += "<span style=\"\" id=\"aspnet4\">" + pconfig.aspnet4 + "</span>";
    str += "</td>";
    str += "</tr>";

    str += "<tr style='height:25px;'>";
    str += "<td style='width:100px;'>&nbsp;</td>";
    str += "<td style='width:100px;text-align:right;'>";
    str += "Asp：";
    str += "</td>";
    str += "<td style='width:120px;text-align:left;'>";
    str += "<span style=\"width:100px\" id=\"asp\">" + pconfig.asp + "</span>";
    str += "</td>";
    str += "<td style='width:100px;text-align:right;'>";
    str += "自定义错误：";
    str += "</td>";
    str += "<td style='text-align:left;'>";
    str += "<span style=\"\" id=\"errors\">" + pconfig.errors + "</span>";
    str += "</td>";
    str += "</tr>";


    str += "<tr style='height:25px;'>";
    str += "<td style='width:100px;'>&nbsp;</td>";
    str += "<td style='width:100px;text-align:right;'>";
    str += "SSL 访问：";
    str += "</td>";
    str += "<td style='width:120px;text-align:left;'>";
    str += "<span style=\"width:100px\" id=\"ssl\">" + pconfig.ssl + "</span>";
    str += "</td>";
    str += "<td style='width:100px;text-align:right;'>";
    str += "CGI 访问：";
    str += "</td>";
    str += "<td style='text-align:left;'>";
    str += "<span style=\"\" id=\"cgi\">" + pconfig.cgi + "</span>";
    str += "</td>";
    str += "</tr>";
    str += "</table>";
    str += "<br/>";
    str += "</fieldset><br/>";
    str += "<strong>主机空间别名</strong>：<input type='hidden' name='wspuname' id='wspuname' value=" + userData[0].uname + "><input type='text' name='packagename' id='packagename' class='text'><span style='color:red;'>*</span><br/><br/>";
    timeCycle = productData[0].psconfig.time_cycle == undefined ? '0' : productData[0].psconfig.time_cycle;
    var pcycles = productData[0].pprice.cycle.split(',');
    var pcprice = productData[0].pprice.cprice.split(',');
    var pp1 = 0, pp2 = 0;
    switch (productData[0].pprice.pmothod) {
        case "1":
            str += '<strong>付款周期</strong>：';
            for (i = 0; i < pcycles.length; i++) {
                if (pcprice[i] != '0') {
                    if (pp1 == 0) pp1 = parseFloat(pcprice[i]) / parseInt(pcycles[i]);
                    else {
                        pp2 = (parseFloat(pcprice[i]) / parseInt(pcycles[i]) / pp1 * 10).toFixed(1);
                    }
                    str += '<input type="radio" name="baseprice" value="' + pcycles[i] + '_' + pcprice[i] + '_1" id="pcy' + pcycles[i] + '" /><label for="pcy' + pcycles[i] + '">' + getTimeCycleSuffix(pcycles[i], timeCycle, 0)+ (pp2 != 0 ? '(' + pp2 + '折)' : '') + '</label>　';
                }
            }
            break;
        case "2":
            str += '一次性付款：<input type="radio" name="baseprice" value="1_' + productData[0].pprice.onetime + '_2"/>起始价:' + productData[0].pprice.onetime + '元';
            break;
        case "3":
            str += '免费试用：<input type="radio" name="baseprice" value="0_0_3"/>试用' + productData[0].pprice.free + '天';
            break;
    }

    $("#OrderConfig").html(str);
    if ($("#divprice").length > 0) { $("#divprice").remove(); }
    $("#swin").next().prepend('<div style="float:left;padding:15px 0px 0px 15px;" id="divprice"><strong>总价格：</strong><strong id="normalPrice" style="color:#0000FF;"></strong><span id="finalPrice"></span></div>');
    $("#OrderConfig p").css("line-height", "25px");
    $("#OrderConfig label").css({ "margin-right": "18px" });

    $("#OrderConfig input[name='baseprice']").click(function () {
        var pps = $(this).val().split('_');
        billingCycle = parseInt(pps[0]);
        normalPrice = parseFloat(pps[1]);
        finalPrice = normalPrice * discount;
        if (normalPrice > finalPrice) {
            $("#normalPrice").html('<strike>' + normalPrice.toFixed(2) + '</strike>');
            $("#finalPrice").html('<strong style="margin-left:18px">帐户优惠价(' + (discount * 100 / 10) + '折)：</strong><strong style="color:#0000FF;">' + finalPrice.toFixed(2) + '</strong> ' + userData[0].currency);
        }
        else $("#normalPrice").html(finalPrice.toFixed(2) + ' ' + userData[0].currency);

    });
    $("#OrderConfig input[name='baseprice']:first").click();
    billingMothod = productData[0].pprice.pmothod;

    $(".ui-dialog-buttonset span").eq(0).click(function () {
        suwin.dialog({ title: "购买确认", autoOpen: false, resizable: false, width: 399, height: 368, modal: true, buttons: { "确定购买": function () { checkout(1); }, "继续配置": function () { $(this).dialog("close"); }, "在线充值": function () { window.open('?c=finance', '_blank'); } } }).dialog("open");
    });
}
function HTMLDecode(text) {
    var temp = document.createElement("div");
    temp.innerHTML = text;
    var output = temp.innerText || temp.textContent;
    temp = null;
    return output;
}
function getTimeCycleSuffix(billingCycle, timeCycle, tag) {
    var cycleSuffix = '';
    if (billingCycle == 0) {
        switch (timeCycle) {
            case '1': cycleSuffix = '天'; break;
            case '2': cycleSuffix = '小时'; break;
            default:
                cycleSuffix = '月';
                if (tag == 1) cycleSuffix = '个月';
                break;
        }
    }
    else {
        if (timeCycle == '0') {
            switch (billingCycle) {
                case '1': cycleSuffix = '月'; break;
                case '3': cycleSuffix = '季'; break;
                case '6': cycleSuffix = '半年'; break;
                case '12': cycleSuffix = '年'; break;
                case '24': cycleSuffix = '2年'; break;
                default: cycleSuffix = billingCycle + '个月'; break;
            }
        }
        else if (timeCycle == '1') {
            switch (billingCycle) {
                case '1': cycleSuffix = '天'; break;
                case '7': cycleSuffix = '周'; break;
                case '15': cycleSuffix = '半月'; break;
                case '30': cycleSuffix = '月'; break;
                case '90': cycleSuffix = '季'; break;
                case '365': cycleSuffix = '年'; break;
                default: cycleSuffix = billingCycle + '天'; break;
            }
        }
        else {
            switch (billingCycle) {
                case '1': cycleSuffix = '小时'; break;
                case '24': cycleSuffix = '天'; break;
                case '168': cycleSuffix = '周'; break;
                default: cycleSuffix = billingCycle + '小时'; break;
            }
        }
    }
    return cycleSuffix;
}
orderConfig();
