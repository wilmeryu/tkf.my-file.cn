﻿/// <reference path="jquery.min.js" />

function baseConfig() {
    var product_data = productData;
    $.post("?c=module&productid=" + product_data[0].pid + "&show=text&caction=listplans&t=" + new Date(), function (data) {
       
        var vArr = data.split('№');
        if (vArr[0] == "]") {
            $("#ProductConfig").html("<div style='color:red;font-size:14px; text-align:center;margin-top:50px;'>您还没有在WebsitePanel面板配置任何套餐，请先在WebsitePanel面板配置好套餐！</div>");
            return;
        } else if (vArr[0] == "-1") {
            $("#ProductConfig").html("<div style='color:red;font-size:14px; text-align:center;margin-top:50px;'>" + vArr[1] + "</div>");
            return;
        }
        var vdataArr = $.parseJSON(vArr[0]);
        var vdetail = "<input type='hidden' value='" + vArr[1] + "' name='config_resellerid' id='config_resellerid'/><p style='margin:15px 0px 10px 0px;' id='wspplan'><strong>产品基本套餐配置</strong>：<select id=\"config_plan\" name=\"config_plan\" style=\"height:auto;cursor:pointer;\">";
        for (var i = 0, len = vdataArr.length; i < len; i++) {
            vdetail += "<option value='" + vdataArr[i].planid + "'>" + vdataArr[i].planname + "</option>";
        }
        vdetail += "</select></p>";
        var vplanid = vdataArr[0].planid;
        if (product_data[0].pconfig != null && product_data[0].pconfig != "") {
            vplanid = product_data[0].pconfig.plan;
        }
        changeDetail(vplanid, vdetail, vdataArr);
    });
}
function changeDetail(planid, vdetail, vdataArr) {
     var i=0;
    for (i = 0, len = vdataArr.length; i < len; i++) {
        if (planid == vdataArr[i].planid) {
            $("#ProductConfig").html(vdetail + getDetail(vdataArr[i]));
            // $('#config_plan').find("[value=" + planid + "]option").attr("selected", "selected");
            $('#config_plan').val(planid);
            $("#config_plan").change(function () {changeDetail($("#config_plan").val(), vdetail, vdataArr) });
            break;
        }
    }
    if (i == vdataArr.length) {
        $("#ProductConfig").html(vdetail + getDetail(vdataArr[0]));
        $("#config_plan").change(function () { changeDetail($("#config_plan").val(), vdetail, vdataArr) });
    }
}
function getDetail(obj) {
    var bw = obj.bandwidth == '-1' ? '无限' : obj.bandwidth;
    var disk = obj.disk == '-1' ? '无限' : obj.disk;
    var domains = obj.domains == '-1' ? '无限' : obj.domains;
    var subdomains = obj.subdomains == '-1' ? '无限' : obj.subdomains;
    var ftp = obj.ftps == '-1' ? '无限' : obj.ftps;
    var websites = obj.websites == '-1' ? '无限' : obj.websites;
    var email = obj.emails == '-1' ? '无限' : obj.emails;
    var php5 = obj.php5 == '1' ? '支持' : '不支持';
    var php4 = obj.php4 == '1' ? '支持' : '不支持';
    var aspnet2 = obj.aspnet2 == '1' ? '支持' : '不支持';
    var aspnet4 = obj.aspnet4 == '1' ? '支持' : '不支持';
    var ssl = obj.ssl == '1' ? '支持' : '不支持';
    var cgi = obj.cgi == '1' ? '支持' : '不支持';
    var asp = obj.asp == '1' ? '支持' : '不支持';
    var errors = obj.errors == '1' ? '支持' : '不支持';
    var defaultpage = obj.defaultpage == '1' ? '支持' : '不支持';
    var mssqlsize = obj.mssqlsize == '-1' ? '无限' : obj.mssqlsize;
    var mysqlsize = obj.mysqlsize == '-1' ? '无限' : obj.mysqlsize;
    var mssqlcount = obj.mssql == '-1' ? '无限' : obj.mssql;
    var mysqlcount = obj.mysql == '-1' ? '无限' : obj.mysql;
   var str = "<fieldset style=\"border:1px solid #ccc; padding:0px 10px;margin:8px 0px;\">";
    str += "<legend style=\"padding:0px 6px;\">";
    str += '套餐详细信息';
    str += "</legend>";
    str += "<table>";
    str += "<tr>";
    str += "<td style='width:100px;'>&nbsp;</td>";
    str += "<td style='width:100px;text-align:right;'>";
    str += "流量：";
    str += "</td>";
    str += "<td style='width:100px;text-align:left;'>";
    str += "<input type=\"hidden\" value='"+bw+"' name=\"config_bandwidth\" id=\"config_bandwidth\" />";
    str += "<span style=\"\" id=\"bandwidth\">" + bw + "</span> （M）";
    str += "</td>";
    str += "<td style='width:120px;text-align:right;'>";
    str += "磁盘大小：";
    str += "</td>";
    str += "<td style='text-align:left;'>";
    str += "<input type=\"hidden\" value='" + disk + "' name=\"config_disk\" id=\"config_disk\" />";
    str += "<span style=\"\" id=\"disk\">" +disk + "</span> （M）";
    str += "</td>";
    str += "</tr>";
    str += "<tr>";
    str += "<td style='width:100px;'>&nbsp;</td>";
    str += "<td style='width:100px;text-align:right;'>";
    str += "域名配额：";
    str += "</td>";
    str += "<td style='width:120px;text-align:left;'>";
    str += "<input type=\"hidden\" value='" + domains + "' name=\"config_domains\" id=\"config_domains\" />";
    str += "<span style=\"width:100px\" id=\"domains\">" + domains + "</span> （个）";
    str += "</td>";
    str += "<td style='width:100px;text-align:right;'>";
    str += "子域名配额：";
    str += "</td>";
    str += "<td style='text-align:left;'>";
    str += "<input type=\"hidden\" value='" + subdomains + "' name=\"config_subdomains\" id=\"config_subdomains\"/>";
    str += "<span style=\"\" id=\"subdomains\">" + subdomains + "</span> （个）";
    str += "</td>";
    str += "</tr>";
   
    str += "<tr>";
    str += "<td style='width:100px;'>&nbsp;</td>";
    str += "<td style='width:100px;text-align:right;'>";
    str += "Ftp帐户：";
    str += "</td>";
    str += "<td style='width:120px;text-align:left;'>";
    str += "<input type=\"hidden\" value='"+ftp+"' name=\"config_ftps\" id=\"config_ftp\"/>";
    str += "<span style=\"width:100px\" id=\"ftp\">" +ftp + "</span> （个）";
    str += "</td>";
    str += "<td style='width:100px;text-align:right;'>";
    str += "Email帐户：";
    str += "</td>";
    str += "<td style='text-align:left;'>";
    str += "<input type=\"hidden\" value='"+email+"' name=\"config_emails\" id=\"config_email\"/>";
    str += "<span style=\"\" id=\"email\">" + email + "</span> （个）";
    str += "</td>";
    str += "</tr>";

    if (mysqlcount != "0") {
        var mysqlversion = obj.mysqlversion;
        str += "<tr>";
        str += "<td style='width:100px;'>&nbsp;</td>";
        str += "<td style='width:100px;text-align:right;'>";
        str += "MySQL" + mysqlversion + "：";
        str += "</td>";
        str += "<td style='width:120px;text-align:left;'>";
        str += "<input type=\"hidden\" value='" + mysqlcount + "' name=\"config_mysql\" id=\"config_mysql\"/>";
        str += "<span style=\"width:100px\" id=\"mysql\">" + mysqlcount + "</span> （个）";
        str += "</td>";
        str += "<td style='width:150px;text-align:right;'>";
        str += "MySQL"+mysqlversion+"数据库大小：";
        str += "</td>";
        str += "<td style='text-align:left;'>";
        str += "<input type=\"hidden\" value='" + mysqlsize + "' name=\"config_mysqlsize\" id=\"config_mysqlsize\"/>";
        str += "<input type=\"hidden\" value='" + obj.mysqlversion + "' name=\"config_mysqlversion\" id=\"config_mysqlversion\"/>";
        str += "<span style=\"\" id=\"mysqlsize\">" + mysqlsize + "</span> （M）";
        str += "</td>";
        str += "</tr>";
    } else{
        str += "<input type=\"hidden\" value='0' name=\"config_mysql\" id=\"config_mysql\"/>";
    }
    if (mssqlcount != "0") {
        var mssqlversion = obj.mssqlversion;
        str += "<tr>";
        str += "<td style='width:100px;'>&nbsp;</td>";
        str += "<td style='width:100px;text-align:right;'>";
        str += "MsSQL"+mssqlversion+"：";
        str += "</td>";
        str += "<td style='width:120px;text-align:left;'>";
        str += "<input type=\"hidden\" value='" + mssqlcount + "' name=\"config_mssql\" id=\"config_mssql\"/>";
        str += "<span style=\"width:100px\" id=\"mssql\">" + mssqlcount + "</span> （个）";
        str += "</td>";
        str += "<td style='width:150px;text-align:right;'>";
        str += "MsSQL" + mssqlversion + "数据库大小：";
        str += "</td>";
        str += "<td style='text-align:left;'>";
        str += "<input type=\"hidden\" value='" + mssqlsize + "' name=\"config_mssqlsize\" id=\"config_mssqlsize\"/>";
        str += "<input type=\"hidden\" value='" + obj.mssqlversion + "' name=\"config_mssqlversion\" id=\"config_mssqlversion\"/>";
        str += "<span style=\"\" id=\"mssqlsize\">" + mssqlsize + "</span> （M）";
        str += "</td>";
        str += "</tr>";
    } else {
        str += "<input type=\"hidden\" value='0' name=\"config_mssql\" id=\"config_mssql\"/>";
    }

    str += "<tr>";
    str += "<td style='width:100px;'>&nbsp;</td>";
    str += "<td style='width:100px;text-align:right;'>";
    str += "可建网站数：";
    str += "</td>";
    str += "<td style='text-align:left;'>";
    str += "<input type=\"hidden\" value='" + websites + "' name=\"config_websites\" id=\"config_websites\"/>";
    str += "<span style=\"\" id=\"websites\">" + websites + "</span> （个）";
    str += "</td>";
    str += "<td style='width:100px;text-align:right;'>";
    str += "自定义默认文档：";
    str += "</td>";
    str += "<td style='width:120px;text-align:left;'>";
    str += "<input type=\"hidden\" value='" + defaultpage + "' name=\"config_defaultpage\" id=\"config_defaultpage\"/>";
    str += "<span style=\"width:100px\" id=\"defaultpage\">" + defaultpage + "</span> ";
    str += "</td>";
   
    str += "</tr>";

    str += "<tr>";
    str += "<td style='width:100px;'>&nbsp;</td>";
    str += "<td style='width:100px;text-align:right;'>";
    str += "PHP4：";
    str += "</td>";
    str += "<td style='width:120px;text-align:left;'>";
    str += "<input type=\"hidden\" value='" + php4 + "' name=\"config_php4\" id=\"config_php4\"/>";
    str += "<span style=\"width:100px\" id=\"php4\">" + php4 + "</span>";
    str += "</td>";
    str += "<td style='width:100px;text-align:right;'>";
    str += "PHP5：";
    str += "</td>";
    str += "<td style='text-align:left;'>";
    str += "<input type=\"hidden\" value='" + php5 + "' name=\"config_php5\" id=\"config_php5\"/>";
    str += "<span style=\"\" id=\"php5\">" + php5 + "</span>";
    str += "</td>";
    str += "</tr>";
    str += "<tr>";
    str += "<td style='width:100px;'>&nbsp;</td>";
    str += "<td style='width:100px;text-align:right;'>";
    str += "Asp.net2.0：";
    str += "</td>";
    str += "<td style='width:120px;text-align:left;'>";
    str += "<input type=\"hidden\" value='" + aspnet2 + "' name=\"config_aspnet2\" id=\"config_aspnet2\"/>";
    str += "<span style=\"width:100px\" id=\"aspnet2\">" + aspnet2 + "</span>";
    str += "</td>";
    str += "<td style='width:100px;text-align:right;'>";
    str += "Asp.net4.0：";
    str += "</td>";
    str += "<td style='text-align:left;'>";
    str += "<input type=\"hidden\" value='" + aspnet4 + "' name=\"config_aspnet4\" id=\"config_aspnet4\"/>";
    str += "<span style=\"\" id=\"aspnet4\">" + aspnet4 + "</span>";
    str += "</td>";
    str += "</tr>";

    str += "<tr>";
    str += "<td style='width:100px;'>&nbsp;</td>";
    str += "<td style='width:100px;text-align:right;'>";
    str += "Asp：";
    str += "</td>";
    str += "<td style='width:120px;text-align:left;'>";
    str += "<input type=\"hidden\" value='" + asp + "' name=\"config_asp\" id=\"config_asp\"/>";
    str += "<span style=\"width:100px\" id=\"asp\">" + asp + "</span>";
    str += "</td>";
    str += "<td style='width:100px;text-align:right;'>";
    str += "自定义错误：";
    str += "</td>";
    str += "<td style='text-align:left;'>";
    str += "<input type=\"hidden\" value='" + errors + "' name=\"config_errors\" id=\"config_errors\"/>";
    str += "<span style=\"\" id=\"errors\">" + errors + "</span>";
    str += "</td>";
    str += "</tr>";

    str += "<tr>";
    str += "<td style='width:100px;'>&nbsp;</td>";
    str += "<td style='width:100px;text-align:right;'>";
    str += "SSL 访问：";
    str += "</td>";
    str += "<td style='width:120px;text-align:left;'>";
    str += "<input type=\"hidden\" value='" + ssl + "'  name=\"config_ssl\" id=\"config_ssl\" />";
    str += "<span style=\"width:100px\" id=\"ssl\">" + ssl + "</span>";
    str += "</td>";
    str += "<td style='width:100px;text-align:right;'>";
    str += "CGI 访问：";
    str += "</td>";
    str += "<td style='text-align:left;'>";
    str += "<input type=\"hidden\" value='" + cgi + "'  name=\"config_cgi\" id=\"config_cgi\" />";
    str += "<span style=\"\" id=\"cgi\">" + cgi + "</span>";
    str += "</td>";
    str += "</tr>";
  
    //        str += "<tr>";
    //        str += "<td style='width:100px;text-align:right;'>";
    //        str += "是否发送邮件：";
    //        str += "</td>";
    //        str += "<td style='text-align:left;'>";
    //        if (product_data[0].pconfig.notify == null || product_data[0].pconfig.notify == undefined || product_data[0].pconfig.notify == "yes") {
    //            product_data[0].pconfig.notify = "yes";
    //            str += "<input type=\"radio\" title=\"An email will be sent to email\" style='cursor:pointer;' checked=\"checked\" value='yes' name=\"config_notify\" id=\"config_notify\" />是&nbsp;&nbsp;&nbsp;";
    //            str += "<input type=\"radio\" value='no' name=\"config_notify\" style='cursor:pointer;' />否";
    //        }
    //        else {
    //            str += "<input type=\"radio\" title=\"An email will be sent to email\" style='cursor:pointer;' value='yes' name=\"config_notify\" id=\"config_notify\"  />是&nbsp;&nbsp;&nbsp;";
    //            str += "<input type=\"radio\" style='cursor:pointer;' checked=\"checked\"  value='no' name=\"config_notify\" />否";
    //        }
    //        str += "</td>";
//    str += "<td style=''>";
//    str += "";
//    str += "</td>";
//    str += "<td style=''>";
//    str += "";
//    str += "</td>";
//    str += "</tr>";
    str += "</table>";
    str += "<br/>";
    str += "</fieldset>";
    return str;
}
baseConfig();