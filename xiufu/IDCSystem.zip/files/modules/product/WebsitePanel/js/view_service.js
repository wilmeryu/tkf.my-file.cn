﻿/// <reference path="jquery-vsdoc.js" />
/// <reference path="jquery-ui.min.js" />
var timeCycle = productData[0].psconfig.time_cycle == undefined ? '0' : productData[0].psconfig.time_cycle;
function _view() {
    var vstatus = serviceData[0].sstatus;
    if (serviceData[0].ssid == "-999") {
        $("#ViewService").html("<span style='color:green;font-size:14px;'>服务器不能通讯，请检查WebsitePanel面板中服务器配置是否正确！</span>");
        return;
    }
    if (vstatus == '-2') {
        $("#ViewService").html("<span style='color:green;font-size:14px;'>您开通虚拟主机的方式为人工手动开通，请联系管理员尽快为您开通虚拟主机服务！</span>");
        return;
    }
    var packid = serviceData[0].ssid;
    var renewdata = getUnixTime(parseInt(serviceData[0].etime));
    renewdata = renewdata.substring(0, renewdata.indexOf(' '));
    var title = '管理我的虚拟主机#' + serviceData[0].sid + '';
    document.title = title;
    $("#pageTitle").html(title);
    var statusText = serviceStatus[parseInt(vstatus) + 2];

    switch (vstatus) {
        case "-1": statusText = '<strong style="color:#0000FF;">' + statusText + '</strong>'; break;
        case "0": statusText = '<strong style="color:#005B00;">' + statusText + '</strong>'; break;
        case "3": statusText = '<strong style="color:#CC3300;">' + statusText + '</strong>'; break;
        case "1":
        case "2":
        case "4": statusText = '<strong style="color:#FF0000;">' + statusText + '</strong>'; break;
    }

    var str = '<table id="tbhostinfo" width="100%" border="0" cellspacing="0" cellpadding="0" class="table grid"><thead><tr><th style="text-align: right;width:150px;">虚拟主机基本信息：</th><th class="full">&nbsp;</th></tr></thead><tbody>' +
      '<tr><td class="title" style="text-align: right; ">主机编号：</td><td id="tdhostnum">#' + packid + '</td></tr>' +
       '<tr><td class="title" style="text-align: right; ">主机别名：</td><td id="tdhostname">' + serviceData[0].sconfig.packagename + '</td></tr>';
    if (userData[0].isAdmin == "True") {
        str+='<tr><td class="title" style="text-align: right; ">所属用户：</td><td><a href="?c=muser&uid=' + userData[0].uid + '" target="_blank">' + userData[0].uname + ' [#' + userData[0].uid + ']</a></td></tr>';
     }
     str+='<tr><td class="title" style="text-align: right; ">用户名：</td><td id="tdusername">' + userData[0].uname + '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' +
      '<tr><td class="title" style="text-align: right; ">初始密码：</td><td id="tdpwd"><span id="spanpwd" style="margin-right:31px;">' + serviceData[0].sconfig.startpwd + '</span></td></tr>';
    if (serviceData[0].sconfig.bandwidth != "无限") {
        str += '<tr id="trlogin"><td class="title" style="text-align: right;">流量：</td><td id="tdbw"><div style="height:18px;width: 218px;float:left" id="bwload" class="ui-progressbar ui-widget ui-widget-content ui-corner-all" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><div class="ui-progressbar-value ui-widget-header ui-corner-left" style="display: none; width: 30%; "></div></div>&nbsp;&nbsp;&nbsp已使用0 M，剩余' + serviceData[0].sconfig.bandwidth + ' M</td></tr>';
    } else {
        str += '<tr id="trlogin"><td class="title" style="text-align: right;">流量：</td><td id="tdbw">已使用0 M，无限流量</td></tr>';
    }
    if (serviceData[0].sconfig.disk != "无限") {
        str += '<tr ><td class="title" style="text-align: right;">磁盘大小：</td><td id="tddisk"><div style="height:18px;width: 218px;float:left" id="diskload" class="ui-progressbar ui-widget ui-widget-content ui-corner-all" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><div class="ui-progressbar-value ui-widget-header ui-corner-left" style="display: none; width: 30%; "></div></div>&nbsp;&nbsp;&nbsp已使用0 M，剩余' + serviceData[0].sconfig.disk + ' M</td></tr>';
    } else {
        str += '<tr ><td class="title" style="text-align: right;">磁盘大小：</td><td id="tddisk">已使用0 M，无限磁盘空间</td></tr>';
    }
    str += '<tr><td class="title" style="text-align: right; ">域名配额：</td><td id="tddomains">0/' + serviceData[0].sconfig.domains + '（个）</td></tr>' +
     '<tr><td class="title" style="text-align: right; ">子域名配额：</td><td id="tdsubdomains">0/' + serviceData[0].sconfig.subdomains + '（个）</td></tr>' +
    // '<tr><td class="title" style="text-align: right; ">可绑定域名数：</td><td id="tddomainbinds">0/' + serviceData[0].sconfig.domainbinds + '（个）</td></tr>' +
     '<tr><td class="title" style="text-align: right; ">可建网站数：</td><td id="tdwebsites">0/' + serviceData[0].sconfig.websites + '（个）</td></tr>' +
    '<tr><td class="title" style="text-align: right; ">Ftp帐户：</td><td id="tdftp">0/' + serviceData[0].sconfig.ftps + '（个）</td></tr>' +
    '<tr><td class="title" style="text-align: right; ">Email帐户：</td><td id="tdemail">0/' + serviceData[0].sconfig.emails + '（个）</td></tr>';
    // if (serviceData[0].sconfig.mysql != "0") {
        str += '<tr id="trmysql"><td class="title" style="text-align: right;" id="td1mysqlversion">MySQL' + serviceData[0].sconfig.mysqlversion + '：</td><td id="tdmysql">' + serviceData[0].sconfig.mysql + '（个）</td></tr>';
        str += '<tr id="trmysqlsize"><td class="title" style="text-align: right;" id="td2mysqlversion">MySQL' + serviceData[0].sconfig.mysqlversion + '数据库大小：</td><td id="tdmysqlsize">' + serviceData[0].sconfig.mysqlsize + '(M)</td></tr>';

    //}
   // if (serviceData[0].sconfig.mssql != "0") {
        str += '<tr id="trmssql"><td class="title" style="text-align: right; " id="td1mssqlversion">MsSQL' + serviceData[0].sconfig.mssqlversion + '：</td><td id="tdmssql">' + serviceData[0].sconfig.mssql + '（个)</td></tr>';
        str += '<tr id="trmssqlsize"><td class="title" style="text-align: right; " id="td2mssqlversion">MsSQL' + serviceData[0].sconfig.mssqlversion + '数据库大小：</td><td id="tdmssqlsize">' + serviceData[0].sconfig.mssqlsize + '(M)</td></tr>';

   // }


        str += '<tr><td class="title" style="text-align: right; ">PHP4：</td><td id="tdphp4">' + serviceData[0].sconfig.php4 + '</td></tr>' +
    '<tr><td class="title" style="text-align: right; ">PHP5：</td><td id="tdphp5">' + serviceData[0].sconfig.php5 + '</td></tr>' +
    '<tr><td class="title" style="text-align: right; ">Asp.net2.0：</td><td id="tdaspnet2">' + serviceData[0].sconfig.aspnet2 + '</td></tr>' +
    '<tr><td class="title" style="text-align: right; ">Asp.net4.0：</td><td id="tdaspnet4">' + serviceData[0].sconfig.aspnet4 + '</td></tr>' +

      '<tr><td class="title" style="text-align: right; ">Asp：</td><td id="tdasp">' + serviceData[0].sconfig.asp + '</td></tr>' +
        '<tr><td class="title" style="text-align: right; ">自定义默认文档：</td><td id="tddefaultpage">' + serviceData[0].sconfig.defaultpage + '</td></tr>' +
        '<tr><td class="title" style="text-align: right; ">自定义错误：</td><td id="tderrors">' + serviceData[0].sconfig.errors + '</td></tr>' +
    '<tr><td class="title" style="text-align: right; ">SSL 访问：</td><td id="tdssl">' + serviceData[0].sconfig.ssl + '</td></tr>' +
    '<tr><td class="title" style="text-align: right; ">CGI 访问：</td><td id="tdcgi">' + serviceData[0].sconfig.cgi + '</td></tr>' +
     '<tr><td class="title" style="text-align: right; ">续费价格：</td><td><b>' + serviceData[0].sprice + ' ' + userData[0].currency + '</b> / ' + getTimeCycleSuffix(serviceData[0].spcycle, timeCycle, 1) + '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;帐户余额： ' + parseFloat(userData[0].balance).toFixed(2) + ' ' + userData[0].currency + '</td></tr>' +
     '<tr><td class="title" style="text-align: right; ">到期时间：</td><td>' + renewdata + '&nbsp;&nbsp;&nbsp;<input id="autorenew" type="checkbox" ' + (serviceData[0].autorenew == '0' ? 'checked="checked"' : '') + '/><label for="autorenew">自动续费</label>&nbsp;&nbsp;&nbsp;&nbsp;<a href="javascript:void(0);"  onclick="_renew()">『马上续费』</a></td></tr>' +
     '<tr><td class="title" style="text-align: right; ">服务状态：</td><td>' + statusText + '</td></tr>' +

      '<tr><td class="title" style="text-align: right; ">提示：</td><td style="color:green">如果用户已开通多台主机服务，用户在WebsitePanel管理面板的登录密码是用户最近一次修改后的登录密码</td></tr>' +
        //  '<tr><td class="title" style="text-align: right; ">管理操作：</td><td id="tdVpsOperat"><input type="button" class="submit" value="启动"  onclick="ControlPackage(' + packid + ',1,\'启动\')"/>　　<input name="shutdown" type="button" class="submit" value="停止" onclick="ControlPackage(' + packid + ',3,\'停止\')"/></td></tr>' +
      '</tbody></table>';
    // '<table><thead><tr><th style="text-align: right;">虚拟主机其它信息：</th><th class="full">&nbsp;</th></tr></thead><tbody>' +
     // '<tr><td class="title" style="text-align: right; ">提示：</td><td style="color:green">如果用户已开通多台主机服务，用户在WebsitePanel管理面板的登录密码是用户最近一次修改后的登录密码</td></tr></tbody></table>';
    if (vstatus == "-1") {
        $("#ViewService").html(str);
        if (serviceData[0].sconfig.mysql == "0") {
            $("#trmysql").hide();
            $("#trmysqlsize").hide();      
        }
          if (serviceData[0].sconfig.mssql == "0") {
              $("#trmssql").hide();
              $("#trmssqlsize").hide();
        }
        $("#ViewService input[type=button]").hide();
        setTimeout('top.location.reload();', 10000);
    } else {
    $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&caction=getpack&pwd=" + serviceData[0].sconfig.startpwd + "&id=" + packid + "&t=" + new Date(), function (data) {
        if (data.split('|')[0] == "-1") {
            $("#ViewService").html('<div class="ui-state-highlight ui-corner-all" style="padding: 10px;margin:10px;text-align:center;"><strong>远程服务器返回错误:(500)内部服务器错误，可能是由于模块接口参数设置错误，请与客服联系！</strong></div>');
            return;
        }

        $("#ViewService").html(str);

        var vpackArr = data.split('№');

        var vfrm = '<tr><td class="title" style="text-align: right; ">快捷登录：</td><td>' +
        '<form action="' + vpackArr[3] + '/Default.aspx?pid=Login&amp;ReturnUrl=%2fDefault.aspx%3fpid%3dHome" target="_blank" method="post" id="form1">' +
        '<input type="hidden" value="' + vpackArr[1] + '" name="ctl02$ctl01$ctl00$txtUsername" id="ctl02_ctl01_ctl00_txtUsername">' +
         '<input type="hidden" value="' + serviceData[0].sconfig.startpwd + '" name="ctl02$ctl01$ctl00$txtPassword" id="ctl02_ctl01_ctl00_txtPassword">' +
        '<input name="ctl02$ctl01$ctl00$btnLogin" id="ctl02_ctl01_ctl00_btnLogin" type="submit" class="submit" value="登录WebsitePanel管理面板"/></form></td></tr>';
        if (vpackArr[6].length>0)
         vfrm+='<tr><td class="title" style="text-align: right; ">服务器IP：</td><td id="tdserverip">' + vpackArr[6] + '</td></tr>';

        $(vfrm).insertBefore("#trlogin");
        if (vpackArr[2] == "1") {
            $("#tdpwd").append('<input id="btnSendPwd" type="button" class="submit" value="修改密码">');
            $("#btnSendPwd").click(function () {
                showPwdWin(vpackArr[4], vpackArr[5]);
            });
        } else {
            $('<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="' + vpackArr[4] + '"/><input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="' + vpackArr[5] + '"/>').insertBefore("#ctl02_ctl01_ctl00_txtUsername");
        }

        var vpack = $.parseJSON(vpackArr[0]);
        $("#tdhostname").html(vpack.packagename);
        $("#tddomains").html(vpack.domainsUsed + '/' + (vpack.domains == '-1' ? '无限' : vpack.domains) + '（个）');
        $("#tdsubdomains").html(vpack.subdomainsUsed + '/' + (vpack.subdomains == '-1' ? '无限' : vpack.subdomains) + '（个）');
        $("#tddefaultpage").html(vpack.defaultpage == '1' ? '支持' : '不支持');
        $("#tdwebsites").html(vpack.websitesUsed + '/' + (vpack.websites == '-1' ? '无限' : vpack.websites) + '（个）');
        $("#tdftp").html(vpack.ftpsUsed + '/' + (vpack.ftps == '-1' ? '无限' : vpack.ftps) + '（个）');
        $("#tdemail").html(vpack.emailsUsed + '/' + (vpack.emails == '-1' ? '无限' : vpack.emails) + '（个）');
        $("#tdphp4").html(vpack.php4 == '1' ? '支持' : '不支持');
        $("#tdphp5").html(vpack.php5 == '1' ? '支持' : '不支持');
        $("#tdaspnet2").html(vpack.aspnet2 == '1' ? '支持' : '不支持');
        $("#tdaspnet4").html(vpack.aspnet4 == '1' ? '支持' : '不支持');
        $("#tdasp").html(vpack.asp == '1' ? '支持' : '不支持');
        $("#tderrors").html(vpack.errors == '1' ? '支持' : '不支持');
        $("#tdssl").html(vpack.ssl == '1' ? '支持' : '不支持');
        $("#tdcgi").html(vpack.cgi == '1' ? '支持' : '不支持');
        if (vpack.mysql != "0") {
            $("#td1mysqlversion").html('MySQL' + vpack.mysqlversion + '：');
            $("#td2mysqlversion").html('MySQL' + vpack.mysqlversion + '数据库大小：');
            $("#tdmysql").html(vpack.mysql == '-1' ? '无限' : vpack.mysql + " (个)");
            $("#tdmysqlsize").html(vpack.mysqlsize == '-1' ? '无限' : vpack.mysqlsize + " (M)");
        } else {
            $("#trmysql").hide();
            $("#trmysqlsize").hide();
        }
        if (vpack.mssql != "0") {

            $("#td1mssqlversion").html('MsSQL' + vpack.mssqlversion + '：');
            $("#td2mssqlversion").html('MsSQL' + vpack.mssqlversion + '数据库大小：');
            $("#tdmssql").html(vpack.mssql == '-1' ? '无限' : vpack.mssql + " (个)");
            $("#tdmssqlsize").html(vpack.mssqlsize == '-1' ? '无限' : vpack.mssqlsize + " (M)");
        } else {
            $("#trmssql").hide();
            $("#trmssqlsize").hide();
        }

        var bwUsed = parseFloat(vpack.bandwidthUsed), bwAll = parseFloat(vpack.bandwidth);
        var diskUsed = parseFloat(vpack.diskUsed), diskAll = parseFloat(vpack.disk);
        if (bwAll != -1) {
            $("#tdbw").html('<div style="height:18px;width: 218px;float:left" id="bwload" class="ui-progressbar ui-widget ui-widget-content ui-corner-all" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><div class="ui-progressbar-value ui-widget-header ui-corner-left" style="display: none; width: 30%; "></div></div>&nbsp;&nbsp;&nbsp已使用' + bwUsed.toFixed(2) + ' M，剩余' + (bwAll - bwUsed).toFixed(2) + ' M');
            bwUsed = 100 * bwUsed / bwAll;
            $("#bwload").progressbar({
                value: bwUsed
            });
        } else {
            $("#tdbw").html('已使用' + bwUsed + ' M，无限流量');
        }
        if (diskAll != -1) {
            $("#tddisk").html('<div style="height:18px;width: 218px;float:left" id="diskload" class="ui-progressbar ui-widget ui-widget-content ui-corner-all" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><div class="ui-progressbar-value ui-widget-header ui-corner-left" style="display: none; width: 30%; "></div></div>&nbsp;&nbsp;&nbsp已使用' + diskUsed.toFixed(2) + ' M，剩余' + (diskAll - diskUsed).toFixed(2) + ' M');
            diskUsed = 100 * diskUsed / diskAll;
            $("#diskload").progressbar({
                value: diskUsed
            });
        } else {
            $("#tddisk").html('已使用' + diskUsed + ' M，无限磁盘空间');
        }
        $("#ViewService #autorenew").css("cursor", "pointer").click(function () {
            var autorenew = $(this).prop("checked") ? '0' : '1';
            setAutorenew(serviceData[0].sid, autorenew);
        });
    });
    }
}

var pwdTime = 180;
var vcodetip = "";
function showPwdWin(emailchk, smschk) {
    if (serviceData[0].ssid == "0") {
        alert("当前状态不允许修改密码操作，请稍候重试！");
        return;
    }
    var height = 240;
    var str = "";
    if (userData[0].isAdmin != "True" && (emailchk != "0" || smschk != "0")) {
        height = 400;
        str = '<p style="margin:10px 0px;">请选择验证方式：';
        if (smschk != "0") {
            str += '<input type="radio" name="radpcheck" id="smspcheck" checked="checked" value="1"/><label for="smspcheck">短信验证</label>&nbsp;&nbsp;';
        }
        if (emailchk != "0") {
            str += '<input type="radio" name="radpcheck" id="emailpcheck" value="2"/><label for="emailpcheck">邮箱验证</label>';
        }
        if (pwdTime == 180) {
            str += '&nbsp;&nbsp;<input  type="button" class="submit" id="btnSendpChkCode" value="发送验证码"/></p>';
        } else {
            str += '&nbsp;&nbsp;<input  type="button" disabled="disabled" class="submit" style="color:gray;cursor:default" id="btnSendpChkCode" value="还剩' + pwdTime + '秒"/></p>';
        }
    }
    str += '<p style="margin:10px 0px;padding-left:3px;">新 密 码：<input type="password" id="txtpwd" class="text"/>&nbsp;&nbsp;<span style="color:green;">(由字母、数字组成的6-16位字符)</span></p>' +
    '<p>确认密码：<input type="password" id="txtrepwd" class="text"/></p>';
    if (userData[0].isAdmin != "True" && (emailchk != "0" || smschk != "0")) {
        str += '<p style="margin-top:10px;padding-left:4px;">验 证 码：<input type="text" id="txtpchkCode" class="text"/></p>';
    }
    str += '<p><span id="chkptip" style="margin-top:10px;color:green;">' + vcodetip + '</span></p>';
    $("#suwin").html(str);
    if (vcodetip.indexOf('@') > -1) {
        $("#emailpcheck").attr("checked", "checked");
    } else {
        $("input[name=radpcheck]:first").attr("checked", "checked");
    }

    $("#btnSendpChkCode").click(function () {
        $("#btnSendpChkCode").attr("disabled", "disabled").attr("value", "还剩" + pwdTime + "秒").css({ "color": "gray", "cursor": "default" });
        var myTimer = setInterval(function () {
            if (pwdTime > 1) {
                pwdTime -= 1;
                $("#btnSendpChkCode").attr("value", "还剩" + pwdTime + "秒");
            }
            else {
                clearInterval(myTimer);
                pwdTime = 180;
                $("#btnSendpChkCode").removeAttr("disabled").css({ "color": "white", "cursor": "pointer" }).val('发送验证码');
            }
        }, 1000);

        $("#chkptip").html("<br/>正在发送验证码，请稍等......").css("color", "green");
        var chk = $("input[name=radpcheck]:checked").val();
        if (chk == "1") {
            $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&action=send_sms&t=" + new Date(), function (data) {
                if (data == "0") {
                    vcodetip = "<br/>验证码已发送到您的手机[<span style='color:red'>" + userData[0].tel + "</span>]，请查收！";
                    $("#chkptip").html(vcodetip).css("color", "green");
                } else {
                    $("#chkptip").html('<br/>' + data).css("color", "red");
                }
            });
        } else {
            $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&action=send_email&t=" + new Date(), function (data) {
                if (data == "0") {
                    vcodetip = "<br/>验证码已发送到您的邮箱[<span style='color:red'>" + userData[0].umail + "</span>]，请查收！";
                    $("#chkptip").html(vcodetip).css("color", "green");
                } else {
                    $("#chkptip").html('<br/>' + data).css("color", "red");
                }
            });
        }
    });
    $("#suwin").dialog({ title: "修改密码", autoOpen: false, resizable: false, width: 488, height: height, modal: false, buttons: {
        "修改密码": function () {
            var pwd = $("#txtpwd").val();
            var repwd = $("#txtrepwd").val();
            var pcode = '';
            var exp = /^(([a-z]+[0-9]+)|([0-9]+[a-z]+))[a-z0-9]*$/i;
            if (pwd.length < 6 || pwd.length > 16 || (!exp.test(pwd))) {
                $("#chkptip").html("<br/>密码由字母、数字组成的6-16位字符，且必须包含至少1位数字！").css("color", "red");
                $("#txtpwd").val('').focus();
                return;
            } else if (repwd != pwd) {
                $("#chkptip").html("<br/>确认密码与新密码不一致！").css("color", "red");
                $("#txtrepwd").val('').focus();
                return;
            } else if (userData[0].isAdmin != "True" && (emailchk != "0" || smschk != "0")) {
                pcode = $("#txtpchkCode").val();
                if (pcode.length <= 0) {
                    $("#chkptip").html("<br/>请输入验证码！").css("color", "red");
                    $("#txtpchkCode").val('').focus();
                    return;
                }
            }

            $("#chkptip").html(ajaxLoading("正在执行操作，请稍等......")).css("color", "green");
            $("#suwin input").attr("disabled", "disabled");
            $(".ui-dialog-buttonset button:first").attr("disabled", "disabled");
            $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&caction=changepwd&pwd=" + pwd + "&repwd=" + repwd + "&code=" + pcode + "&t=" + new Date(), function (data) {
                if (data == "0") {
                    showTipWin('密码修改成功！');
                } else {
                    $("#chkptip").html('<br/>' + data).css("color", "red");
                    $(".ui-dialog-buttonset button:first").removeAttr("disabled");
                    $("#suwin input").removeAttr("disabled");
                }
            });

        },
        "关 闭": function () { $(this).dialog("close"); }
    }
    }).dialog("open");
}

function showTipWin(tip) {
    $("#suwin").dialog({ title: "操作提示", autoOpen: false, resizable: false, width: 350, height: 200, modal: false, buttons: { "关 闭": function () { $(this).dialog("close"); } } }).dialog("open");
    $("#suwin").html('<div style="margin-top:30px;text-align:center;font-weight:bold">' + tip + '</div>');
    setTimeout('top.location.reload();', 3000);
}

_view();

var finalPrice = 0;
var normalPrice = 0;
var productID = productData[0].pid;
var billingMothod = 1;
var billingCycle = 1;
function _renew() {
    if (serviceData[0].spmothod != "1") {
        alert("您当前服务无需续费！");
        return false;
    }
    if (serviceData[0].sstatus == "-1") {
        alert("当前状态不允许续费操作，请稍候重试！");
        return;
    }
    var discount = parseFloat(productData[0].discount);

    var str = '<div style="line-height:25px"><strong>帐户余额</strong>：<strong>' + parseFloat(userData[0].balance).toFixed(2) + '</strong> ' + userData[0].currency;
    if (discount < 1) str += '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong>帐户优惠</strong>：<strong style="color:#0000FF">' + (discount * 100 / 10) + '</strong>折';
    str += '&nbsp;<br /><strong>请选择续费周期</strong>：<br />';
    var cycles = productData[0].pprice.cycle.split(',');
    var cprices = productData[0].pprice.cprice.split(',');
    var cprice = 0, yprice = 0, pp1 = 0, pp2 = 0;
    for (i = 0; i < cycles.length; i++) {
        if (cprices[i] != '0') {
            cprice = parseFloat(cprices[i]);
            yprice = cprice;
            if (cycles[i] == serviceData[0].spcycle) cprice = serviceData[0].sprice;

            if (pp1 == 0) pp1 = parseFloat(yprice) / parseInt(cycles[i]);
            else {
                pp2 = (parseFloat(yprice) / parseInt(cycles[i]) / pp1 * 10).toFixed(1);
            }
            str += '<input type="radio" name="cycle" value="' + cycles[i] + '_' + cprice + '_' + yprice + '" id="cycle' + cycles[i] + '" /><label for="cycle' + cycles[i] + '">';
//            switch (cycles[i]) {
//                case "1": str += '月　付'; break;
//                case "3": str += '季　付'; break;
//                case "6": str += '半年付'; break;
//                case "12": str += '年　付'; break;
//                case "24": str += '二年付'; break;
//                default: str += cycles[i] + '个月付'; break;
//            }
          
//            if (cycles[i] == serviceData[0].spcycle) str += '：' + parseFloat(cprice).toFixed(2) + (pp2 != 0 ? ' (' + pp2 + '折)' : '') + '</label><br />';
//            else
            //                str += '：' + (discount > 1 ? (parseFloat(cprice) * discount).toFixed(2) : cprice) + (pp2 != 0 ? ' (' + pp2 + '折)' : '') + '</label><br />';
            str += parseFloat(cprice).toFixed(2) + ' / ' + getTimeCycleSuffix(cycles[i], timeCycle, 1) + ((pp2 > 0 && pp2 < 10) ? ' (' + pp2 + '折)' : '') + '</label><br />';

        }
    }
    str += '&nbsp;<br /><strong>续费价格</strong>：<strong class="finalPrice"></strong> ' + userData[0].currency + '&nbsp;&nbsp;&nbsp;<span class="normalPrice"></span><br />&nbsp;<br />' +
           '<span>优 惠 码：<input type="text" id="couponcode" size="10" class="text"/> <input type="button" class="submit" value="使用" onclick="applyCode(\'renew\')"/> <input type="button" class="submit" value="不使用" onclick="clearCouponCode(1)"/></span><br />' +
           '<span id="ccdes" class="pptext"></span></div>';
    $("#suwin").html(str);
    $("#suwin input:radio").click(function () {
        clearCouponCode(1);
        var ps = $(this).val().split('_');
        billingCycle = parseInt(ps[0]);
        finalPrice = parseFloat(ps[1]);
        normalPrice = parseFloat(ps[2]);
        if (billingCycle != parseInt(serviceData[0].spcycle)) finalPrice = finalPrice * discount;
        $("#suwin .finalPrice").html(finalPrice.toFixed(2));

    });
    $("#suwin #cycle" + serviceData[0].spcycle).click();
    $("#suwin").dialog({ title: "续费确认", autoOpen: false, resizable: false, width: 500, height: 398, modal: false, buttons: { "确认续费": function () { renew(serviceData[0].sid, billingCycle, $("#couponcode").val()); }, "关 闭": function () { $(this).dialog("close"); } } }).dialog("open");
}

function getTimeCycleSuffix(billingCycle, timeCycle, tag) {
    var cycleSuffix = '';
    if (billingCycle == 0) {
        switch (timeCycle) {
            case '1': cycleSuffix = '天'; break;
            case '2': cycleSuffix = '小时'; break;
            default:
                cycleSuffix = '月';
                if (tag == 1) cycleSuffix = '个月';
                break;
        }
    }
    else {
        if (timeCycle == '0') {
            switch (billingCycle) {
                case '1': cycleSuffix = '月'; break;
                case '3': cycleSuffix = '季'; break;
                case '6': cycleSuffix = '半年'; break;
                case '12': cycleSuffix = '年'; break;
                case '24': cycleSuffix = '2年'; break;
                default: cycleSuffix = billingCycle + '个月'; break;
            }
        }
        else if (timeCycle == '1') {
            switch (billingCycle) {
                case '1': cycleSuffix = '天'; break;
                case '7': cycleSuffix = '周'; break;
                case '15': cycleSuffix = '半月'; break;
                case '30': cycleSuffix = '月'; break;
                case '90': cycleSuffix = '季'; break;
                case '365': cycleSuffix = '年'; break;
                default: cycleSuffix = billingCycle + '天'; break;
            }
        }
        else {
            switch (billingCycle) {
                case '1': cycleSuffix = '小时'; break;
                case '24': cycleSuffix = '天'; break;
                case '168': cycleSuffix = '周'; break;
                default: cycleSuffix = billingCycle + '小时'; break;
            }
        }
    }
    return cycleSuffix;
}