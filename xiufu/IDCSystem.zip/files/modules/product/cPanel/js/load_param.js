﻿/// <reference path="/modules/js/jquery-vsdoc.js" />
/// <reference path="/modules/js/jquery-ui.min.js" />
$(function () {
    var swin = $("#swin");
    swin.find("#moduleDescription").html('');
    $("#moduleDescription").next().append('&nbsp;&nbsp;&nbsp;<input class="submit" value="添加服务器" name="btnAddServer" id="btnAddServer" type="button"/>&nbsp;&nbsp;&nbsp;&nbsp;<input class="submit" value="保存服务器" name="btnSaveServer" id="btnSaveServer" type="button"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="hidden" name="cname_009" value="emailchk"/><input type="checkbox" name="cvalue_009" value="1" id="email" class="chk"><label for="email">启用邮件验证</label>&nbsp;&nbsp;&nbsp;&nbsp;<input type="hidden" name="cname_010" value="smschk"/><input type="checkbox" name="cvalue_010" value="1" id="sms" class="chk"><label for="sms">启用短信验证</label><input type="hidden" id="paraminfo" value=""/>');
    swin.find("#btn_add").remove();

    var serverids = moduleData[0].cconfig.serverids == undefined ? [] : moduleData[0].cconfig.serverids.split('№');
    var LoginName = moduleData[0].cconfig.LoginName == undefined ? [] : moduleData[0].cconfig.LoginName.split('№');
    var LoginPwd = moduleData[0].cconfig.LoginPwd == undefined ? [] : moduleData[0].cconfig.LoginPwd.split('№');
    var Accesskey = moduleData[0].cconfig.Accesskey == undefined ? [] : moduleData[0].cconfig.Accesskey.split('№');
    var IP = moduleData[0].cconfig.IP == undefined ? [] : moduleData[0].cconfig.IP.split('№');
    var ClientIP = moduleData[0].cconfig.ClientIP == undefined ? [] : moduleData[0].cconfig.ClientIP.split('№');
    var enUname = moduleData[0].cconfig.enUname == undefined ? [] : moduleData[0].cconfig.enUname.split('№');
    var enPwd = moduleData[0].cconfig.enPwd == undefined ? [] : moduleData[0].cconfig.enPwd.split('№');


    var emailchk = moduleData[0].cconfig.emailchk == undefined ? '1' : moduleData[0].cconfig.emailchk;
    var smschk = moduleData[0].cconfig.smschk == undefined ? '1' : moduleData[0].cconfig.smschk;

    var vbtnUname = '修改', vbtnPwd = '修改';
    var ableName = 'readonly="readonly"', ablePwd = 'readonly="readonly"';

    var str = '<input type="hidden" name="cname_001" value="LoginName"/><input type="hidden" name="cvalue_001" value="' + moduleData[0].cconfig.LoginName + '"/>' +
    '<input type="hidden" name="cname_002" value="LoginPwd"/><input type="hidden" name="cvalue_002" value="' + moduleData[0].cconfig.LoginPwd + '"/>' +
    '<input type="hidden" name="cname_003" value="Accesskey"/><input type="hidden" name="cvalue_003" value="' + moduleData[0].cconfig.Accesskey + '"/>' +
    '<input type="hidden" name="cname_004" value="IP"/><input type="hidden" name="cvalue_004" value="' + moduleData[0].cconfig.IP + '"/>' +
    '<input type="hidden" name="cname_005" value="ClientIP"/><input type="hidden" name="cvalue_005" value="' + moduleData[0].cconfig.ClientIP + '"/>' +
    '<input type="hidden" name="cname_006" value="enUname"/><input type="hidden" name="cvalue_006" value="' + moduleData[0].cconfig.enUname + '"/>' +
    '<input type="hidden" name="cname_007" value="enPwd"/><input type="hidden" name="cvalue_007" value="' + moduleData[0].cconfig.enPwd + '"/>' +
     '<input type="hidden" name="cname_008" value="serverids"/><input type="hidden" name="cvalue_008" value="' + moduleData[0].cconfig.serverids + '"/>';
    for (var i = 0; i < serverids.length; i++) {
        if (enUname[i] == '0') {
            vbtnUname = '加密';
            ableName = '';
        } else {
            vbtnUname = '修改';
            ableName = 'readonly="readonly"';
        }
        if (enPwd[i] == '0') {
            vbtnPwd = '加密';
            ablePwd = '';
        } else {
            vbtnPwd = '修改';
            ablePwd = 'readonly="readonly"';
        }
        var vserverid = serverids[i];
        str += '<div id="params' + vserverid + '" class="ui-accordion ui-widget ui-helper-reset ui-accordion-icons" role="tablist">' +
        '<h3 class="ui-accordion-header ui-helper-reset ui-state-default ui-corner-top" role="tab" aria-expanded="false" aria-selected="false" tabindex="0" id="tab' + vserverid + '"><span></span><a href="#"><strong>服务器-' + vserverid + '</strong></a></h3>' +
        '<div class="ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom" role="tabpanel" id="tabpanel' + vserverid + '">' +
      '<li><label class="a">管理员登录名：</label><input class="text" type="text" id="loginname' + vserverid + '" value="' + LoginName[i] + '" ' + ableName + ' />&nbsp;&nbsp;&nbsp;<input class="submit" value="' + vbtnUname + '" name="btnEncrypname' + vserverid + '" id="btnName' + vserverid + '" type="button" onclick="Encry(this);"/><input type="hidden" id="enuname' + vserverid + '" value="' + enUname[i] + '"/>&nbsp;<span class="pptext"></span></li>' +
     '<li><label class="a">管理员密码：</label><input class="text" type="text" id="loginpwd' + vserverid + '" value="' + LoginPwd[i] + '" ' + ablePwd + '/>&nbsp;&nbsp;&nbsp;<input class="submit" value="' + vbtnPwd + '" name="btnEncryppwd' + vserverid + '" id="btnPwd' + vserverid + '"  type="button" onclick="Encry(this);"/><input type="hidden" id="enpwd' + vserverid + '" value="' + enPwd[i] + '"/>&nbsp;<span class="pptext"></span></li>' +
    '<li><label class="a">Access key：</label><input class="text" type="text" id="accesskey' + vserverid + '" value="' + Accesskey[i] + '"/></li>' +
    '<li><label class="a">WHM面板IP(包括端口)：</label><input class="text" type="text" id="ip' + vserverid + '" value="' + IP[i] + '"/></li>' +
    '<li><label class="a">cPanel客户端IP(包括端口)：</label><input class="text" type="text" id="clientip' + vserverid + '" value="' + ClientIP[i] + '"/>&nbsp;&nbsp;&nbsp;<input class="submit delserver" value="删除服务器" name="' + vserverid + '" id="btndelserver' + vserverid + '" type="button"/></li>' +
       '</div></div>';
    }

    var paramList = swin.find("#paramList");
    paramList.html(str);
    $("input[name=cvalue_009][value=" + emailchk + "]").attr("checked", "checked");
    $("input[name=cvalue_010][value=" + smschk + "]").attr("checked", "checked");
    $(".chk").click(function () {
        var value = $(this).prop("checked") ? '1' : '0';
        $(this).val(value);
    });

    paramList.find("li").css({ "height": "30px", "line-height": "30px" });
    paramList.find("label.a").css({ "font-weight": "bold", "float": "left", "text-align": "right", "width": "200px", "height": "30px", "line-height": "30px" });
    paramList.find(".text").css({ "width": "280px" });

    $("div[role = tablist]").accordion({ autoHeight: false, collapsible: true, active: 0 });
    $("div[role=tablist]").accordion("option", "active", false);

    $("h3[role=tab]").click(function () {
        $("div[role=tablist]").not($(this).parent()).accordion("option", "active", false);
    });
    $("input[id^=btndelserver]").click(function () {
        var vid = parseInt($(this).attr("name"));
        $("#params" + vid).remove();

    });

    $("#btnSaveServer").click(function () {
        processing("正在保存，请稍等...");

        var vLoginName = [], vLoginPwd = [], vAccesskey = [], vIP = [], vClientIP = [], vEnUname = [], vEnPwd = [], vServerids = [];
        $("input[id^=loginname]").each(function () {
            vLoginName.push($(this).val());
        });
        $("input[id^=loginpwd]").each(function () {
            vLoginPwd.push($(this).val());
        });
        $("input[id^=accesskey]").each(function () {
            vAccesskey.push($(this).val());
        });
        $("input[id^=ip]").each(function () {
            vIP.push($(this).val());
        });
        $("input[id^=clientip]").each(function () {
            vClientIP.push($(this).val());
        });
        $("input[id^=enuname]").each(function () {
            vEnUname.push($(this).val());
        });
        $("input[id^=enpwd]").each(function () {
            vEnPwd.push($(this).val());
        });
        $("div[role=tablist]").each(function () {
            vServerids.push($(this).attr("id").replace('params', ''));
        });
        $("input[name=cvalue_001]").val(vLoginName.join('№'));
        $("input[name=cvalue_002]").val(vLoginPwd.join('№'));
        $("input[name=cvalue_003]").val(vAccesskey.join('№'));
        $("input[name=cvalue_004]").val(vIP.join('№'));
        $("input[name=cvalue_005]").val(vClientIP.join('№'));
        $("input[name=cvalue_006]").val(vEnUname.join('№'));
        $("input[name=cvalue_007]").val(vEnPwd.join('№'));
        $("input[name=cvalue_008]").val(vServerids.join('№'));
        showResults("保存成功", 1000, 'close');
    });


    $("#btnAddServer").click(function () {
        var count = parseInt($("div[role=tablist]").length) + 1;
        var vserverid = 0;
        if (count > 1) {
            $("div[role=tablist]").each(function () {
                var vid = parseInt($(this).attr("id").replace('params', ''));
                if (vid > vserverid) vserverid = vid;
            });
        }
        vserverid++;

        $("div[role=tablist]").not("#params" + vserverid).accordion("option", "active", false);
        var str = '<div id="params' + vserverid + '" class="ui-accordion ui-widget ui-helper-reset ui-accordion-icons" role="tablist">';
        str += '<h3 class="ui-accordion-header ui-helper-reset ui-state-default ui-corner-top" role="tab" aria-expanded="false" aria-selected="false" tabindex="0" id="tab' + vserverid + '"><span></span><a href="#"><strong>服务器-' + vserverid + '</strong></a></h3>' +
                '<div class="ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom" role="tabpanel" id="tabpanel' + vserverid + '">' +
              '<li><label class="a">管理员登录名：</label><input class="text" type="text" id="loginname' + vserverid + '" value="' + vserverid + '"  />&nbsp;&nbsp;&nbsp;<input class="submit" value="加密" name="btnEncrypname' + vserverid + '" id="btnName' + vserverid + '" type="button" onclick="Encry(this);"/><input type="hidden" id="enuname' + vserverid + '" value="0"/>&nbsp;<span class="pptext"></span></li>' +
             '<li><label class="a">管理员密码：</label><input class="text" type="text" id="loginpwd' + vserverid + '" value="' + vserverid + '"/>&nbsp;&nbsp;&nbsp;<input class="submit" value="加密" name="btnEncryppwd' + vserverid + '" id="btnPwd' + vserverid + '"  type="button" onclick="Encry(this);"/><input type="hidden" id="enpwd' + vserverid + '" value="0"/>&nbsp;<span class="pptext"></span></li>' +
            '<li><label class="a">Access key：</label><input class="text" type="text" id="accesskey' + vserverid + '" value="' + vserverid + '"/></li>' +
            '<li><label class="a">WHM面板IP(包括端口)：</label><input class="text" type="text" id="ip' + vserverid + '" value="' + vserverid + '"/></li>' +
            '<li><label class="a">cPanel客户端IP(包括端口)：</label><input class="text" type="text" id="clientip' + vserverid + '" value="' + vserverid + '"/>&nbsp;&nbsp;&nbsp;<input class="submit delserver" value="删除服务器" name="' + vserverid + '" id="btndelserver' + vserverid + '" type="button"/></li>' +
               '</div>';
        str += '</div>';
        var paramList = swin.find("#paramList");
        paramList.prepend(str);
        paramList.find("li").css({ "height": "30px", "line-height": "30px" });
        paramList.find("label.a").css({ "font-weight": "bold", "float": "left", "text-align": "right", "width": "200px", "height": "30px", "line-height": "30px" });
        paramList.find(".text").css({ "width": "280px" });

        $("#params" + vserverid).accordion({ autoHeight: false, collapsible: true, active: 0 });


        $("h3[role=tab]").click(function () {
            $("div[role=tablist]").not($(this).parent()).accordion("option", "active", false);
        });

        $("input[id^=btndelserver]").click(function () {
            var vid = parseInt($(this).attr("name"));
            $("#params" + vid).remove();

        });


    });
});

function Encry(obj) {
    var sid = 0;
    var btn = $(obj);
    var txt = btn.parent().find("input[type='text']");
    var hid = btn.parent().find("input:last");
    var vSpan = btn.parent().find("span");  
    if (txt.val().length <= 0) {
        vSpan.html("请输入参数值！");
        txt.focus();
        return;
    }

    if ($(obj).attr('id').indexOf('btnName') > -1) {
       sid=$(obj).attr("id").replace('btnName', '');
        if ($("#enuname" + sid).val() == '1') {//修改操作
            if (confirm('修改登录名需要重新输入登录名，确认修改？')) {
                txt.val('');
                hid.val('0');
                txt.removeAttr('readonly');
                btn.attr('value', '加密');
                $("#enuname" + sid).val('0');
                vSpan.html("");
                txt.focus();
            }
            return;
        }
    } else {
        sid = $(obj).attr("id").replace('btnPwd', '');
        if ($("#enpwd" + sid).val() == '1') {
            if (confirm('修改登录密码需要重新输入登录密码，确认修改？')) {
                txt.val('');
                hid.val('0');
                txt.removeAttr('readonly');
                btn.attr('value', '加密');
                $("#enpwd" + sid).val('0');
                vSpan.html("");
                txt.focus();
            }
            return;
        }
    }


    vSpan.html("正在加密，请稍等...");
    $.getScript("http://" + currentDomain + "/files/modules/product/cPanel/index.ashx?type=encryp&txt=" + txt.val() + "&t=" + new Date(), function () {
        txt.val(a);
        vSpan.html("加密完成！");
        if (btn.attr('id').indexOf('btnName') > -1) {
            $("#enuname" + sid).val('1');
        } else {
            $("#enpwd" + sid).val('1');
        }
        hid.val('1');
        btn.val('修改')
        txt.attr("readonly", "readonly");
    });
}
