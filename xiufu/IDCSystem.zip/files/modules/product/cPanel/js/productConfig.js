﻿/// <reference path="jquery.min.js" />
function baseConfig(packname, sid, isshow) {
    var product_data = productData;
    if (sid == undefined) sid = 0;
    if (sid != 0 && isshow == 1) processing("正在加载数据，请稍等...");
    $.post("?c=module&productid=" + product_data[0].pid + "&show=text&caction=listserver&sid=" + sid + "&t=" + new Date(), function (data) {
        if (sid != 0 && isshow == 1) $("#processing").dialog("close");
        var varr = data.split('|');
        var ipArr = varr[0].split('№');
        var serveridArr = varr[1].split('№');
        var vdetail = "<p style='margin:3px 0px 10px 0px;' id='cpanelplan'><strong>服务器配置</strong>：<select id=\"config_serverid\" name=\"config_serverid\" style=\"height:auto;cursor:pointer;\">";
        for (var i = 0, len = serveridArr.length; i < len; i++) {
            vdetail += "<option value='" + serveridArr[i] + "'>服务器" + ipArr[i].substr(0, ipArr[i].indexOf(':')) + "</option>";
        }
        vdetail += "</select>";

        if (varr[2].indexOf('无法解析此远程名称') > -1 || varr[2].indexOf('远程服务器返回错误') > -1 || varr[2].indexOf('无法连接到远程服务器') > -1) {
            $("#ProductConfig").html(vdetail + "<div style='color:red;font-size:14px; text-align:center;margin-top:50px;'>无法连接到远程服务器，请检查模块参数中该服务器配置是否正确！</div>");
            $("#config_serverid").val(sid);
            $("#config_serverid").change(function () {
                baseConfig(0, $(this).val(), 1);
            });
            return;
        }

        var vdataArr = $.parseJSON(varr[2]);

        vdetail += "&nbsp;&nbsp;&nbsp;<br/><strong>产品基本套餐配置</strong>：<select id=\"config_packname\" name=\"config_packname\" style=\"height:auto;cursor:pointer;\">";
        for (var i = 0, len = vdataArr.length; i < len; i++) {
            vdetail += "<option value='" + vdataArr[i].name + "'>" + vdataArr[i].name + "</option>";
        }
        vdetail += "</select>&nbsp;&nbsp;&nbsp;&nbsp;<input  type='button' class='submit' id='btnAddPack' value='添加套餐' onclick='addPack()'/>&nbsp;&nbsp;&nbsp;&nbsp;<input  type='button' class='submit' id='btnEditPack' value='修改套餐' onclick='editPack()'/>&nbsp;&nbsp;&nbsp;&nbsp;<input  type='button' class='submit' id='btnDelPack' value='删除套餐' onclick='delPack()'/>&nbsp;&nbsp;&nbsp;&nbsp;<input  type='button' class='submit' id='btnClearPack' value='清空' onclick='ClearPack()'/></p>";
        if (vdataArr.length > 0) {
            var vpackname = vdataArr[0].name;
            if (packname != 0) vpackname = packname;
            else if (product_data[0].pconfig != null && product_data[0].pconfig != "") {
                vpackname = product_data[0].pconfig.packname;
            }
            changeDetail(vpackname, vdetail, vdataArr, sid);
        } else {
            $("#ProductConfig").html(vdetail + getDetail(vdataArr));
            ClearPack();
            $("#config_packname").change(function () { changeDetail($("#config_packname").val(), vdetail, vdataArr, sid) });
        }
        $("#config_serverid").val(sid);
        $("#config_serverid").change(function () {

            baseConfig(0, $(this).val(), 1);
        });

    });
}
function changeDetail(packname, vdetail, vdataArr, sid) {
    var i = 0;
    for (i = 0, len = vdataArr.length; i < len; i++) {
        if (packname == vdataArr[i].name) {
            $("#ProductConfig").html(vdetail + getDetail(vdataArr[i]));
            $('#config_packname').val(packname);
            $("#config_packname").change(function () { changeDetail($("#config_packname").val(), vdetail, vdataArr, sid) });
            break;
        }
    }
    if (i == vdataArr.length) {
        $("#ProductConfig").html(vdetail + getDetail(vdataArr[0]));
        $("#config_packname").change(function () { changeDetail($("#config_packname").val(), vdetail, vdataArr, sid) });
    }
    $("#config_serverid").val(sid);
    $("#suwin").height("470px");

    $("#ProductConfig input[type=checkbox]").click(function () {
        var value = $(this).prop("checked") ? '1' : '0';
        $(this).val(value);
    });

}
function getDetail(obj) {
    if ($("#divtip").length > 0) $("#divtip").remove();
    var str = "<div id=\"divtip\" style=\"display:none;\"></div><fieldset id='plancontent' style=\"border:1px solid #ccc; padding:0px 10px;margin:8px 0px;\">";
    str += "<legend style=\"padding:0px 6px;\">";
    str += '套餐详细信息 (<span style="color:red;">提示：数字类型的值如果填写-1则代表不限</span>)';
    str += "</legend>";
    str += "<table id='tbcontent'>";
    str += "<tr>";
    str += "<td style='text-align:right;'>";
    str += "套餐名称：";
    str += "</td>";
    str += "<td style='text-align:left;height:40px;'>";
    var name = obj.name == undefined ? '' : obj.name;
    var disable = name.length > 0 ? 'readonly=readonly' : "";
    str += "<input type=\"text\" value='" + name + "' name=\"planname\" id=\"planname\" class=\"text\" " + disable + "/>";
    str += "</td>";
    str += "<td style='text-align:right;'>";
    str += "cPanel的主题：";
    str += "</td>";
    str += "<td style='text-align:left;height:40px;'>";
    var CPMOD = obj.CPMOD == undefined ? '' : obj.CPMOD;
    str += "<input type=\"text\" value='" + CPMOD + "' name=\"config_theme\" id=\"config_theme\" class=\"text\"/>(不填则使用默认主题)";
    str += "</td>";
    str += "</tr>";

    str += "<tr>";
    str += "<td style='text-align:right;'>";
    str += "磁盘大小（M）：";
    str += "</td>";
    str += "<td style='text-align:left;height:40px;'>";
    str += "<input type=\"text\" value='" + ((obj.QUOTA == undefined || obj.QUOTA == 'unlimited') ? '-1' : obj.QUOTA) + "' name=\"config_disk\" id=\"config_disk\" class=\"text\"/>";
    str += "</td>";
    str += "<td style='text-align:right;'>";
    str += "流量大小（M）：";
    str += "</td>";
    str += "<td style='text-align:left;height:40px;'>";
    str += "<input type=\"text\" value='" + ((obj.BWLIMIT == undefined || obj.BWLIMIT == 'unlimited') ? '-1' : obj.BWLIMIT) + "' name=\"config_bandwidth\" id=\"config_bandwidth\" class=\"text\"/>";
    str += "</td>";
    str += "</tr>";

    str += "<tr>";
    str += "<td style='text-align:right;'>";
    str += "Email帐户数量：";
    str += "</td>";
    str += "<td style='text-align:left;height:40px;'>";
    str += "<input type=\"text\" value='" + ((obj.MAXPOP == undefined || obj.MAXPOP == 'unlimited') ? '-1' : obj.MAXPOP) + "' name=\"config_emails\" id=\"config_emails\" class=\"text\"/>";
    str += "</td>";
    str += "<td style='text-align:right;'>";
    str += "邮件列表数量：";
    str += "</td>";
    str += "<td style='text-align:left;height:40px;'>";
    str += "<input type=\"text\" value='" + ((obj.MAXLST == undefined || obj.MAXLST == 'unlimited') ? '-1' : obj.MAXLST) + "' name=\"config_emaillist\" id=\"config_emaillist\" class=\"text\"/>";
    str += "</td>";
    str += "</tr>";

    str += "<tr>";
    str += "<td style='text-align:right;'>";
    str += "数据库数量：";
    str += "</td>";
    str += "<td style='text-align:left;height:40px;'>";
    str += "<input type=\"text\" value='" + ((obj.MAXSQL == undefined || obj.MAXSQL == 'unlimited') ? '-1' : obj.MAXSQL) + "' name=\"config_database\" id=\"config_database\" class=\"text\"/>";
    str += "</td>";
    str += "<td style='text-align:right;'>";
    str += "FTP帐户数量：";
    str += "</td>";
    str += "<td style='text-align:left;height:40px;'>";
    str += "<input type=\"text\" value='" + ((obj.MAXFTP == undefined || obj.MAXFTP == 'unlimited') ? '-1' : obj.MAXFTP) + "' name=\"config_ftps\" id=\"config_ftps\" class=\"text\"/>";
    str += "</td>";
    str += "</tr>";
    str += "<tr>";
    str += "<td style='text-align:right;'>";
    str += "子域名数量：";
    str += "</td>";
    str += "<td style='text-align:left;height:40px;'>";
    str += "<input type=\"text\" value='" + ((obj.MAXSUB == undefined || obj.MAXSUB == 'unlimited') ? '-1' : obj.MAXSUB) + "' name=\"config_subdomains\" id=\"config_subdomains\" class=\"text\"/>";
    str += "</td>";
    str += "<td style='text-align:right;'>";
    str += "域名停放数量：";
    str += "</td>";
    str += "<td style='text-align:left;height:40px;'>";
    str += "<input type=\"text\" value='" + ((obj.MAXPARK == undefined || obj.MAXPARK == 'unlimited') ? '-1' : obj.MAXPARK) + "' name=\"config_parkeddomains\" id=\"config_parkeddomains\" class=\"text\"/>";
    str += "</td>";
    str += "</tr>";

    str += "<tr>";
    str += "<td style='text-align:right;'>";
    str += "插件域数量：";
    str += "</td>";
    str += "<td style='text-align:left;height:20px;'>";
    str += "<input type=\"text\" value='" + ((obj.MAXADDON == undefined || obj.MAXADDON == 'unlimited') ? '-1' : obj.MAXADDON) + "' name=\"config_addondomains\" id=\"config_addondomains\" class=\"text\"/>";
    str += "</td>";
    str += "<td style='text-align:right;'>";
    str += "专用IP：";
    str += "</td>";
    str += "<td style='text-align:left;height:20px;'>";
    str += "<input type=\"checkbox\" name=\"config_dedicatedIP\" id=\"config_dedicatedIP\" " + ((obj.IP == undefined || obj.IP == 'n') ? 'value=0' : 'checked=checked value=1') + ">";
    str += "</td>";
    str += "</tr>";

    str += "<tr>";
    str += "<td style='text-align:right;'>";
    str += "Shell Access：";
    str += "</td>";
    str += "<td style='text-align:left;height:20px;'>";
    str += "<input type=\"checkbox\" name=\"config_shell\" id=\"config_shell\" " + ((obj.HASSHELL == undefined || obj.HASSHELL == 'n') ? 'value=0' : 'checked=checked value=1') + ">";
    str += "</td>";
    str += "<td style='text-align:right;'>";
    str += "CGI Access：";
    str += "</td>";
    str += "<td style='text-align:left;height:20px;'>";
    str += "<input type=\"checkbox\" name=\"config_cgi\" id=\"config_cgi\" " + ((obj.CGI == undefined || obj.CGI == 'n') ? 'value=0' : 'checked=checked value=1') + ">";
    str += "</td>";
    str += "</tr>";
    str += "<tr>";
    str += "<td style='width:220px;text-align:right;'>";
    str += "Frontpage Extensions：";
    str += "</td>";
    str += "<td style='text-align:left;height:20px;'>";
    str += "<input type=\"checkbox\" " + ((obj.FRONTPAGE == undefined || obj.FRONTPAGE == 'n') ? 'value=0' : 'checked=checked value=1') + " name=\"config_frontpage\" id=\"config_frontpage\">";
    str += "</td>";
    str += "<td style='width:240px;text-align:right;'>";
    str += "";
    str += "</td>";
    str += "<td style='text-align:left;'>";
//    str += "<select name=\"language\" id=\"language\">";

//    if (obj.LANG == "en")
//        str += "<option value=\"zh\">Chinese (中文)</option><option value=\"en\" selected=\"selected\">English(英文)</option>";
//    else
//        str += "<option value=\"zh\" selected=\"selected\">Chinese (中文)</option><option value=\"en\">English(英文)</option>";

//    str += "</select>";
    str += "</td></tr>";

    str += "</table>";
    str += "<br/>";
    str += "</fieldset>";
    return str;
}

baseConfig(0, productData[0].pconfig.serverid, 0);
function ClearPack() {
    $("#ProductConfig .text").val(-1);
    $("#ProductConfig #planname").val('').removeAttr('readonly');
    $("#ProductConfig #config_theme").val('');
    $("#ProductConfig #config_parkeddomains").val(0);
    $("#ProductConfig #config_addondomains").val(0);
    $("#ProductConfig input[type=checkbox]").not("#config_cgi").removeAttr('checked').val(0);
    $("#ProductConfig #config_cgi").attr("checked", "checked").val(1);

}
function addPack() {
    var packname = $("#ProductConfig #planname").val();
    processing("正在执行操作，请稍等......");
    if (packname.length <= 0) {
        showResults("套餐名称不能为空", 5000, '');
        return;
    }
    $.post("?c=module&productid=" + productData[0].pid + "&show=text&caction=addpack&t=" + new Date(), $("#mform").serialize(), function (rdata) {
        if (rdata == "0") {
            showResults("添加套餐成功", 3000, 'close');
            baseConfig($("#ProductConfig #planname").val(), $("#config_serverid").val(), 0);
        } else {
            if (rdata.indexOf('already exists') > -1 && rdata.indexOf('edit the package') > -1) {
                rdata = '套餐名称已存在，请修改套餐名称后再进行操作！';
            }
            showResults(rdata, 5000, '');
        }
    });
}
function delPack() {
    $("#divtip").html('<div style="margin-top:30px;text-align:center;font-weight:bold">确认删除该套餐吗？</div>');
    $("#divtip").dialog({ title: "操作提示", autoOpen: false, resizable: false, width: 350, height: 200, modal: false, buttons: { "确认": function () {
        $("#divtip").dialog("close");
        processing("正在执行操作，请稍等......");
        $.post("?c=module&productid=" + productData[0].pid + "&show=text&caction=delpack&pack=" + $("#ProductConfig #config_packname").val() + "&t=" + new Date(), function (rdata) {
            var vjson = $.parseJSON(rdata);
            if (vjson.status == "1") {
                showResults("删除套餐成功", 3000, 'close');
                baseConfig(0, $("#config_serverid").val(), 0);
            } else {
                showResults(vjson.statusmsg, 5000, '');
            }
        });

    }, "关 闭": function () { $(this).dialog("close"); }
    }
    }).dialog("open");
}

function editPack() {
    var packname = $("#planname").val();
    processing("正在执行操作，请稍等......");
    if (packname.length <= 0) {
        showResults("套餐名称不能为空", 5000, '');
        return;
    }

    $.post("?c=module&productid=" + productData[0].pid + "&show=text&caction=editpack&t=" + new Date(), $("#mform").serialize(), function (rdata) {
        if (rdata != "0") {
            showResults(rdata, 5000, '');
        } else {
            showResults("修改套餐成功", 3000, 'close');
            baseConfig($("#ProductConfig #config_packname").val(), $("#config_serverid").val(), 0);

        }
    });
}
