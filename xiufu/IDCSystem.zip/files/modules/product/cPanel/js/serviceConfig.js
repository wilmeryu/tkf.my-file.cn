﻿/// <reference path="jquery.min.js" />
function serviceConfig() {
    $.post("?c=module&serviceid=" + serviceData[0].sid + "&show=text&caction=listplans&t=" + new Date(), function (data) {
        var vArr = data.split('|');
        var vdataArr = $.parseJSON(vArr[1]);

        var vdetail = "<strong>用户名：</strong>p" + serviceData[0].ssid + "&nbsp;&nbsp;&nbsp;&nbsp;<strong>初始密码：</strong>" + serviceData[0].sconfig.pwd + "<input type='hidden' value=" + serviceData[0].sconfig.pwd + " name='pwd' /><input type='hidden' value=" + serviceData[0].sconfig.serverid + " name='serverid' />" +
        "<br/><strong>服务器IP：</strong>" + vArr[0].substr(0, vArr[0].indexOf(':')) + "<input type='hidden' value=" + vArr[0].substr(0, vArr[0].indexOf(':')) + " name='ip' />&nbsp;&nbsp;&nbsp;&nbsp;<strong>域名：</strong>" + serviceData[0].sconfig.domain + "<input type='hidden' value=" + serviceData[0].sconfig.domain + " name='domain' />" +
        "<p style='margin:15px 0px 10px 0px;' id='cpanelplan'><strong>产品基本套餐配置</strong>：<select id=\"packname\" name=\"packname\" style=\"height:auto;cursor:pointer;\">";
        for (var i = 0, len = vdataArr.length; i < len; i++) {
            vdetail += "<option value='" + vdataArr[i].name + "'>" + vdataArr[i].name + "</option>";
        }
        vdetail += "</select></p>";
        if (vdataArr.length > 0) {
            var vpackname = vdataArr[0].name;
            if (serviceData[0].sconfig != null && serviceData[0].sconfig != "") {
                vpackname = serviceData[0].sconfig.packname;
            }
            changeDetail(vpackname, vdetail, vdataArr);
        } else {
            $("#ServiceConfig").html(vdetail + getDetail(vdataArr));
            $("#packname").change(function () { changeDetail($("#packname").val(), vdetail, vdataArr) });
        }

    });
}

function changeDetail(packname, vdetail, vdataArr) {
    var i = 0;
    for (i = 0, len = vdataArr.length; i < len; i++) {
        if (packname == vdataArr[i].name) {
            $("#ServiceConfig").html(vdetail + getDetail(vdataArr[i]));
            $('#packname').val(packname);
            $("#packname").change(function () { changeDetail($("#packname").val(), vdetail, vdataArr) });
            break;
        }
    }
    if (i == vdataArr.length) {
        $("#ServiceConfig").html(vdetail + getDetail(vdataArr[0]));
        $("#packname").change(function () { changeDetail($("#packname").val(), vdetail, vdataArr) });
    }
}
function getDetail(obj) {
    var str = "<fieldset style=\"border:1px solid #ccc; padding:0px 10px;margin:8px 0px;\">";
    str += "<legend style=\"padding:0px 6px;\">";
    str += '套餐详细信息';
    str += "</legend>";
    str += "<table>";
    str += "<tr>";
    str += "<td style='text-align:right;'>";
    str += "套餐名称：";
    str += "</td>";
    str += "<td style='text-align:left;height:20px;'>";
    var name = obj.name == undefined ? '' : obj.name;
    str +=name;
    str += "</td>";
    str += "<td style='text-align:right;'>";
    str += "cPanel的主题：";
    str += "</td>";
    str += "<td style='text-align:left;height:20px;'>";
    var CPMOD = obj.CPMOD == undefined ? '' : obj.CPMOD;
    str += CPMOD;
    str += "</td>";
    str += "</tr>";

    str += "<tr>";
    str += "<td style='text-align:right;'>";
    str += "磁盘大小（M）：";
    str += "</td>";
    str += "<td style='text-align:left;height:20px;'>";
    str += ((obj.QUOTA == undefined || obj.QUOTA == 'unlimited') ? '不限' : obj.QUOTA);
    str += "</td>";
    str += "<td style='text-align:right;'>";
    str += "流量大小（M）：";
    str += "</td>";
    str += "<td style='text-align:left;height:20px;'>";
    str += ((obj.BWLIMIT == undefined || obj.BWLIMIT == 'unlimited') ? '不限' : obj.BWLIMIT);
    str += "<input type='hidden' value=" + ((obj.BWLIMIT == undefined || obj.BWLIMIT == 'unlimited') ? '-1' : obj.BWLIMIT) + " name='bandwidth' /></td>";
    str += "</tr>";

    str += "<tr>";
    str += "<td style='text-align:right;'>";
    str += "Email帐户数量：";
    str += "</td>";
    str += "<td style='text-align:left;height:20px;'>";
    str += ((obj.MAXPOP == undefined || obj.MAXPOP == 'unlimited') ? '不限' : obj.MAXPOP);
    str += "</td>";
    str += "<td style='text-align:right;'>";
    str += "邮件列表数量：";
    str += "</td>";
    str += "<td style='text-align:left;height:20px;'>";
    str += ((obj.MAXLST == undefined || obj.MAXLST == 'unlimited') ? '不限' : obj.MAXLST);
    str += "</td>";
    str += "</tr>";

    str += "<tr>";
    str += "<td style='text-align:right;'>";
    str += "数据库数量：";
    str += "</td>";
    str += "<td style='text-align:left;height:20px;'>";
    str += ((obj.MAXSQL == undefined || obj.MAXSQL == 'unlimited') ? '不限' : obj.MAXSQL);
    str += "</td>";
    str += "<td style='text-align:right;'>";
    str += "FTP帐户数量：";
    str += "</td>";
    str += "<td style='text-align:left;height:20px;'>";
    str += ((obj.MAXFTP == undefined || obj.MAXFTP == 'unlimited') ? '不限' : obj.MAXFTP);
    str += "</td>";
    str += "</tr>";
    str += "<tr>";
    str += "<td style='text-align:right;'>";
    str += "子域名数量：";
    str += "</td>";
    str += "<td style='text-align:left;height:20px;'>";
    str += ((obj.MAXSUB == undefined || obj.MAXSUB == 'unlimited') ? '不限' : obj.MAXSUB);
    str += "</td>";
    str += "<td style='text-align:right;'>";
    str += "域名停放数量：";
    str += "</td>";
    str += "<td style='text-align:left;height:20px;'>";
    str += ((obj.MAXPARK == undefined || obj.MAXPARK == 'unlimited') ? '不限' : obj.MAXPARK);
    str += "</td>";
    str += "</tr>";

    str += "<tr>";
    str += "<td style='text-align:right;'>";
    str += "插件域数量：";
    str += "</td>";
    str += "<td style='text-align:left;height:20px;'>";
    str += ((obj.MAXADDON == undefined || obj.MAXADDON == 'unlimited') ? '不限' : obj.MAXADDON);
    str += "</td>";
    str += "<td style='text-align:right;'>";
    str += "专用IP：";
    str += "</td>";
    str += "<td style='text-align:left;height:20px;'>";
    str += (obj.IP == undefined || obj.IP == 'n')?'否':'是' ;
    str += "<input type='hidden' name=\"dedicatedIP\" id=\"dedicatedIP\" value=" + ((obj.IP == undefined || obj.IP == 'n') ? '0' : '1') + "></td>";
    str += "</tr>";

    str += "<tr>";
    str += "<td style='text-align:right;'>";
    str += "Shell Access：";
    str += "</td>";
    str += "<td style='text-align:left;height:20px;'>";
    str += (obj.HASSHELL == undefined || obj.HASSHELL == 'n')?"不支持":"支持";
    str += "<input type='hidden' name=\"shell\" id=\"shell\" value=" + ((obj.HASSHELL == undefined || obj.HASSHELL == 'n')?'0':'1') + "></td>";
    str += "<td style='text-align:right;'>";
    str += "CGI Access：";
    str += "</td>";
    str += "<td style='text-align:left;height:20px;'>";
    str += (obj.CGI == undefined || obj.CGI == 'n') ? "不支持" : "支持";
    str += "<input type='hidden' name=\"cgi\" id=\"cgi\" value=" + ((obj.CGI == undefined || obj.CGI == 'n') ? '0' : '1') + "></td>";
    str += "</tr>";
    str += "<tr>";
    str += "<td style='width:220px;text-align:right;'>";
    str += "Frontpage Extensions：";
    str += "</td>";
    str += "<td style='text-align:left;height:20px;'>";
    str += (obj.FRONTPAGE == undefined || obj.FRONTPAGE == 'n')? "不支持" : "支持";
    str += "<input type='hidden' name=\"frontpage\" id=\"frontpage\" value=" + ((obj.FRONTPAGE == undefined || obj.FRONTPAGE == 'n') ? '0' : '1') + "></td>";
    str += "<td style='width:240px;text-align:right;'>";
    str += "";
    str += "</td>";
    str += "<td style='text-align:left;'>";
    str += "";
    str += "</td>";
    str += "</tr>";

    str += "</table>";
    str += "<br/>";
    str += "</fieldset>";
    return str;
}

serviceConfig();