﻿/// <reference path="/files/modules/js/jquery-vsdoc.js" />
/// <reference path="/files/modules/js/jquery-ui.min.js" />
function _pm_init() {
    var currentInputValue = currentInput.val();
    if (currentInputValue.indexOf('{') < 0 || currentInputValue.indexOf('}') < 0) currentInputValue = '{}';
    var currentValue = $.parseJSON(currentInputValue);
    var paramType = currentValue.paramType == undefined ? '0' : currentValue.paramType;
    var displayMode = currentValue.displayMode == undefined ? '0' : currentValue.displayMode;
    var displayText = currentValue.displayText == undefined ? '显示的选项名称' : currentValue.displayText;
    var params = currentValue.params == undefined ? ''.split('|') : currentValue.params.split('|');;

    var paramTypes = '$paramTypes'.split('|');
    var displayModes = '$displayModes'.split('|');

    var str = '<strong>参数选项名称</strong>：<input class="text" style="width:388px" name="displayText" value="' + displayText + '"/><br />'+
              '<strong>参数选项属性</strong>：';
    for (i = 0; i < paramTypes.length; i++) str += '<input type="radio" ' + (paramType == i.toString() ? 'checked="checked"' : '') + ' name="paramType" value="' + i + '" id="pt' + i + '"/><label for="pt' + i + '">' + paramTypes[i] + '</label>';
    str += '<br /><strong>参数显示模式</strong>：';
    for (i = 0; i < displayModes.length; i++) str += '<input type="radio" ' + (displayMode == i.toString() ? 'checked="checked"' : '') + ' name="displayMode" value="' + i + '" id="dm' + i + '"/><label for="dm' + i + '">' + displayModes[i] + '</label>';

    str = '<form id="mpConfig" style="line-height:28px">' + str + '<p id="mpValues"></p></form>';
    suwin.html(str).find("#mpConfig label").css({ "padding-right": "18px" });

    suwin.find("#mpConfig input[name='displayMode']").click(function () { showValues($(this).val(), params); });
    showValues(displayMode, params);

    suwin.dialog("close").dialog({ title: "产品模块参数项设置 $Version", autoOpen: false, resizable: false, width: 630, height: 520, modal: true, buttons: { "保存参数": function () { _pm_save(); }, "关 闭": function () { $(this).dialog("close"); } } }).dialog("open");
}

function showValues(displayMode, params) {
    var str = '';
    switch (displayMode) {
        case '0':
        case '1':
            str += '<strong>本选项默认值</strong>：<input class="text" name="params" style="width:388px" value="' + params[0] + '"/>';
            break;
        case '2':
        case '3':
        case '4':
            str += '&nbsp;<br /><strong>参数选项列表</strong>：&nbsp;<input type="button" class="submit" name="btn_add" onclick="_pm_paramAdd()" value="添加选项"/><br />';
            for (i = 0; i < params.length; i++) str += '<p>选项.' + (i + 1) + '：<input class="text" name="params" style="width:388px" value="' + params[i] + '"/> <a href="javascript:;" onclick="_pm_paramDel(this);">『删除』</a> <a href="javascript:;" onclick="_paramUp(this);">『↑』</a> <a href="javascript:;" onclick="_paramDown(this);">『↓』</a></p>';
            break;
    }
    suwin.find("#mpValues").html(str);
}

function _pm_paramAdd() {
    suwin.find("#mpValues").append('<p>新选项：<input class="text" name="params" style="width:388px"/> <a href="javascript:;" onclick="_pm_paramDel(this);">『删除』</a> <a href="javascript:;" onclick="_paramUp(this);">『↑』</a> <a href="javascript:;" onclick="_paramDown(this);">『↓』</a></p>');   
}

function _pm_paramDel(ca) {
    $(ca).parent().remove();
}

function _pm_save() {
    var mpConfig = suwin.find("#mpConfig");
    var jsonValue = '{"paramType":"' + mpConfig.find("input[name='paramType']:checked").val() + '","displayText":"' + mpConfig.find("input[name='displayText']").val() + '","displayMode":"' + mpConfig.find("input[name='displayMode']:checked").val() + '","params":"';
    var mpValues = mpConfig.find("input[name='params']");
    var str = '';
    $(mpValues).each(function (i) { str += '|' + ($(mpValues[i]).val()).replaceAll('\\|', '!'); });
    if (str != '') str = str.substring(1);
    jsonValue += str + '"}';
    currentInput.val(jsonValue);
    suwin.dialog("close");
}

_pm_init();
