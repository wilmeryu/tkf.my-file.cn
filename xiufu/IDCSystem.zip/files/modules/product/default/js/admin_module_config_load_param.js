﻿/// <reference path="/files/modules/js/jquery-vsdoc.js" />
/// <reference path="/files/modules/js/jquery-ui.min.js" />
function _pm_init() {
    var submodule = moduleData[0].cconfig.moduleConfig_submodule == undefined ? '' : moduleData[0].cconfig.moduleConfig_submodule;
    swin.find("#moduleDescription").html('<strong>专用管理模块路径</strong>：<input type="hidden" name="cname_submodule" value="moduleConfig_submodule"/><input class="text" name="cvalue_submodule" value="' + submodule + '" style="width:383px"/> 例如：rDataCenter模块地址等');

    $('<input type="button" id="btn_import" class="button" value="导入" style="margin-left:6px"/> <input type="button" id="btn_export" class="button" value="导出" /> <input type="button" id="btn_download" class="button" value="下载示例模型" />').insertAfter(swin.find("#btn_add"));
    swin.find("#paramList li:first").before('<li>指定“参数名(字母/数字)”后，通过“<strong>自定义</strong>”参数功能设置“参数值”的属性格式和展现形式！更多方法请见：<a href="https://my.cloudgoing.com/go.aspx?id=10018" target="_blank">『模块设置教程』</a></li>');

    swin.find(".button").click(function () {
        var bid = $(this).attr("id");
        switch (bid) {
            case "btn_import":
                _pm_import(0);
                break;
            case "btn_export":
                window.open('?c=module&moduleid=' + moduleData[0].cid + '&action=custom_action&show=text&subaction=export_module_config&' + new Date(), '_export');
                break;
            case "btn_download":
                window.open('https://my.cloudgoing.com/go.aspx?id=10019', '_blank');
                break;
        }

    });
}


function _pm_import(action) {
    if (action == 0) {
        var str = '<form action="$currentUrl?getaction=upload_module_config" method="post" enctype ="multipart/form-data" target="_import" style="padding-top:15px;line-height:39px">' +
                  '<strong>模型文件：</strong><input name="mfile" type="file" style="width:200px"/> ' +
                  '<input type="submit" value="立即上传" class="button"/><br />温馨提示：导入成功后将覆盖当前设置的参数'+
                  '<input type="hidden" value="$userID" name="userid"><input type="hidden" value="$key" name="key"></form>';
        suwin.html(str);
        suwin.dialog({ title: "导入模块设置模型", autoOpen: false, resizable: false, width: 500, height: 230, modal: true, buttons: { "确定导入": function () { _pm_import(1); }, "关 闭": function () { $(this).dialog("close"); } } }).dialog("open");
    }
    else {
        processing("正在导入，请稍候......");
        var delay = 0;
        var cmd = '';
        $.get('?c=module&moduleid=' + moduleData[0].cid + '&action=custom_action&show=text&subaction=import_module_config&' + new Date(), function (rdata) {
            var rmsg = rdata.split('|');
            if (rmsg[0] == "0") {
                rdata = rdata.substring(2);
                if (rdata.indexOf('}') > 0) {
                    swin.find("#paramList li:gt(0)").remove();
                    var i = 0;
                    var importModuleConfigs = $.parseJSON(rdata);
                    $.each(importModuleConfigs, function (key, value) {
                        addParam(key, value, i);
                        i++;
                    });
                }
                rdata = '导入成功！';
                delay = 1000;
                cmd = 'close';
                suwin.dialog("close");
            } else if (rmsg[0] == "-1") {
                switch (rmsg[1]) {
                    case "Please select a file to upload": rdata = "请先上传模型文件！"; break;
                    default: rdata = rmsg[1]; break;
                }
            }
            showResults(rdata, delay, cmd);
        });


    }
}

_pm_init();
