﻿/// <reference path="/files/modules/js/jquery-vsdoc.js" />
/// <reference path="/files/modules/js/jquery-ui.min.js" />
var productConfig;
function _pm_init() {
    var moduleConfig = $.parseJSON('$moduleConfig');
    var displayModes = '$displayModes'.split('|');
    var serviceName = productData[0].pconfig["serviceName"] == undefined ? "" : productData[0].pconfig["serviceName"];
    var params;
    var str = '<div id="params">' +
              '<h3><a href="#"><strong>基本属性配置</strong></a></h3>' +
              '<div style="line-height:28px"><strong>用户服务名称格式</strong>：<input class="text" style="width:388px" name="config_serviceName" value="' + serviceName + '"/>&nbsp;&nbsp;&nbsp;<a href="https://my.cloudgoing.com/go.aspx?id=10020" target="_blank">『格式设置说明教程』</a><br />' +
              '<strong>此产品支持的变量</strong>：<br /><span class="nameTag"></span>' +
              '</div>';
    var nameTags = '';
    var ppTitle = '', ppValue = '', ppPrice = '0';
    var paramValues;
    $.each(moduleConfig, function (key, value) {
        params = $.parseJSON(value.replaceAll('&quot;', '"'));
        ppTitle = productData[0].pconfig[key + '_title'] == undefined ? params.displayText : productData[0].pconfig[key + '_title'];
        nameTags += '<input type="button" value="[' + key + '] ' + ppTitle + '" class="button"/> ';
        paramValues = params.params.split('|');
        ppValue = productData[0].pconfig[key + '_value'] == undefined ? paramValues[0] : productData[0].pconfig[key + '_value'];
        str += '<h3><a href="#"><strong>' + ppTitle + '</strong></a></h3>' +
               '<div style="line-height:28px"><strong>自定义属性名称</strong>：<input class="text ptitle" style="width:397px" name="config_' + key + '_title" value="' + ppTitle + '"/><br />' +
               '<strong>自定义属性设置</strong>：<label><input type="checkbox" ' + (productData[0].pconfig[key + '_hidden'] == '1' ? 'checked="checked"' : '') + ' name="config_' + key + '_hidden" value="1" />隐藏此属性</label>&nbsp;&nbsp;&nbsp;' +
               '<label><input type="checkbox" ' + (productData[0].pconfig[key + '_readonly'] == '1' ? 'checked="checked"' : '') + ' name="config_' + key + '_readonly" value="1" />只读属性</label>&nbsp;&nbsp;&nbsp;' +
               '<label><input type="checkbox" ' + (productData[0].pconfig[key + '_showonly'] == '1' ? 'checked="checked"' : '') + ' name="config_' + key + '_showonly" value="1" />仅作显示用途</label><br />';
        switch (params.displayMode) {
            case '0':
                str += '<strong>当前属性默认值</strong>：<input style="width:397px" class="text" name="config_' + key + '_value" value="' + ppValue + '"/>';
                if (params.paramType == '0') {
                    ppPrice = productData[0].pconfig[key + '_price_0'] == undefined ? '1' : productData[0].pconfig[key + '_price_0'];
                    str += '&nbsp;&nbsp;&nbsp;单价：<input style="width:35px" class="text center" name="config_' + key + '_price_0" value="' + ppPrice + '"/>';
                }
                break;
            case '1':
                str += '<strong>当前属性默认值</strong>：<br /><textarea style="width:500px;height:65px" class="text" name="config_' + key + '_value">' + ppValue.replaceAll('rn', '\r\n') + '</textarea>';
                break;
            case '2':
            case '3':
            case '4':
                //if (isNaN(ppValue)) ppValue = '0';
                str += '<strong>列表项属性设置</strong>：[' + displayModes[parseInt(params.displayMode)] + ']<br />';
                for (i = 0; i < paramValues.length; i++) {
                    str += '<input type="' + (params.displayMode == '4' ? 'checkbox' : 'radio') + '" ' + ((',' + ppValue + ',').indexOf(',' + i + ',') > -1 ? 'checked="checked"' : '') + ' name="config_' + key + '_value" value="' + i + '" id="' + key + '_value_' + i + '"/><label for="' + key + '_value_' + i + '">默认</label>&nbsp;&nbsp;&nbsp;' +
                           '<input type="checkbox" ' + (productData[0].pconfig[key + '_hidden_' + i] == '1' ? 'checked="checked"' : '') + ' name="config_' + key + '_hidden_' + i + '" value="1" id="' + key + '_hidden_' + i + '"/><label for="' + key + '_hidden_' + i + '">隐藏</label>';
                    if (params.paramType == '0') {
                        ppPrice = productData[0].pconfig[key + '_price_' + i] == undefined ? '0' : productData[0].pconfig[key + '_price_' + i];
                        str += '&nbsp;&nbsp;&nbsp;价格：<input style="width:35px" class="text center" name="config_' + key + '_price_' + i + '" value="' + ppPrice + '"/>';
                    }
                    str += '&nbsp;&nbsp;&nbsp;<strong>选项[' + (i + 1) + ']：' + paramValues[i] + '</strong><br />';
                }
                break;
        }
        str += '</div>';
    });
    str += '</div>';
    productConfig = $("#ProductConfig");
    productConfig.html(str);
    productConfig.find(".nameTag").html(nameTags).find(".button").click(function () {
        var cTag = $(this).val();
        var snInput = $(this).parent().parent().find("input[name='config_serviceName']");
        cTag = cTag.substring(0, cTag.indexOf(' '));
        snInput.val(snInput.val() + ' ' + cTag);
    });
    productConfig.find(".ptitle").change(function () { $(this).parent().prev().find("strong").text($(this).val()); });
    productConfig.find("#params").accordion({
        heightStyle: "content",
        collapsible: true,
        active: 0
    });
}

_pm_init();
