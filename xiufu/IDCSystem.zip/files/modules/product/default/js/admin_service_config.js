﻿/// <reference path="/files/modules/js/jquery-vsdoc.js" />
/// <reference path="/files/modules/js/jquery-ui.min.js" />
var serviceConfig;
function _pm_init() {
    var moduleConfig = $.parseJSON('$moduleConfig');
    var str = '<div id="params"><h3><a href="#"><strong>产品服务配置管理</strong></a></h3>' +
              '<div><table style="width:100%;line-height:25px;"><tr><td style="text-align:right"><strong>服务名称：</strong></td><td>' + serviceData[0].sname + '</td></tr><tr><td style="height:10px;"></td><td></td></tr>';
    var params;
    var ppTitle = '', ppValue = '', ppPrice = '0';
    var paramValues;
    $.each(moduleConfig, function (key, value) {
        if (productData[0].pconfig[key + '_hidden'] == '1' || productData[0].pconfig[key + '_showonly'] == '1') return true;
        params = $.parseJSON(value.replaceAll('&quot;', '"'));
        ppTitle = productData[0].pconfig[key + '_title'] == undefined ? params.displayText : productData[0].pconfig[key + '_title'];
        paramValues = params.params.split('|');
        ppValue = serviceData[0].sconfig[key] == undefined ? paramValues[0] : serviceData[0].sconfig[key];

        str += '<tr><td style="text-align:right"><strong>' + ppTitle + '：</strong></td><td>';
        switch (params.displayMode) {
            case '0':
                if (params.paramType == '0') {
                    str += '<input style="width:35px;" class="text center" name="' + key + '" value="' + ppValue + '"/> X ' + productData[0].pconfig[key + '_price_0'];
                } else str += '<input style="width:500px" class="text" name="' + key + '" value="' + ppValue + '"/>';
                break;
            case '1':
                str += '<textarea style="width:500px;height:65px" class="text" name="' + key + '">' + ppValue.replaceAll('rn','\r\n') + '</textarea>';
                break;
            case '2':
                if (isNaN(ppValue)) ppValue = '0';
                str += '<select name="' + key + '">';
                for (i = 0; i < paramValues.length; i++) {
                    if (productData[0].pconfig[key + '_hidden_' + i] == '1') continue;
                    str += '<option value="' + i + '" ' + (ppValue == i.toString() ? 'selected="selected"' : '') + '>' + paramValues[i];
                    ppPrice = productData[0].pconfig[key + '_price_' + i] == undefined ? '0' : productData[0].pconfig[key + '_price_' + i];
                    if (params.paramType == '0' && ppPrice != '0') {
                        if (ppPrice.substring(0, 1) != '-') ppPrice = '+' + ppPrice;
                        str += ' (' + ppPrice + ')';
                    }
                    str += '</option>'
                }
                str += '</select>';
                break;
            case '3':
            case '4':
                for (i = 0; i < paramValues.length; i++) {
                    if (productData[0].pconfig[key + '_hidden_' + i] == '1') continue;
                    str += '<input type="' + (params.displayMode == '4' ? 'checkbox' : 'radio') + '" ' + ((',' + ppValue + ',').indexOf(',' + i + ',') > -1 ? 'checked="checked"' : '') + ' name="' + key + '" value="' + i + '" id="' + key + '_value_' + i + '"/>' +
                           '<label for="' + key + '_value_' + i + '">' + paramValues[i];
                    ppPrice = productData[0].pconfig[key + '_price_' + i] == undefined ? '0' : productData[0].pconfig[key + '_price_' + i];
                    if (params.paramType == '0' && ppPrice != '0') {
                        if (ppPrice.substring(0, 1) != '-') ppPrice = '+' + ppPrice;
                        str += ' (' + ppPrice + ')';
                    }
                    str += '</label><br />'
                }
                break;
        }
        str += '</td></tr><tr><td style="height:10px;"></td><td></td></tr>';
    });
    str += '</table></div>' +
          '<h3><a href="#"><strong>附加服务资料管理</strong></a></h3><div>' +
           '<p><input type="button" onclick="_pm_configAdd(0,\'\',\'\')" class="submit" value="添加"/></p><ul id="addConfigs" style="line-height:31px;"></ul></div></div>';
    serviceConfig = $("#ServiceConfig");
    serviceConfig.html(str);
    var suffix;
    var c = 0;
    $.each(serviceData[0].sconfig, function (key, value) {
        if (key.indexOf('as_name_') == 0) {
            suffix = key.substring(8);
            _pm_configAdd(c, value, serviceData[0].sconfig['as_value_' + suffix]);
            c++;
        }
    });
    serviceConfig.find("#params").accordion({
        heightStyle: "content",
        collapsible: true,
        active: 0
    });
}

function _pm_configAdd(c,cname,cvalue) {
    var suffix = new Date().getTime().toString() + c;
            serviceConfig.find("#addConfigs").append('<li>属性名：<input style="width:118px;margin-right:10px" class="text" name="as_name_' + suffix + '" value="' + cname + '"/>属性值：<input style="width:278px;margin-right:6px" class="text" name="as_value_' + suffix + '" value="' + cvalue + '"/><a href="javascript:;" onclick="_pm_htmlEdit(this);">[编辑器]</a> &nbsp;<a href="javascript:;" onclick="_pm_configDel(this);">[删除]</a> &nbsp;<a href="javascript:;" onclick="_pm_configUp(this);">[上移]</a> &nbsp;<a href="javascript:;" onclick="_pm_configDown(this);">[下移]</a></li>');
}

function _pm_configDel(ca) {
    $(ca).parent().remove();
}

function _pm_configUp(ca) {
    $($(ca).parent().prev()).before($(ca).parent());
}

function _pm_configDown(ca) {
    $($(ca).parent().next()).after($(ca).parent());
}

function _pm_htmlEdit(ca) {
    htmlEdit($(ca).parent().find("input:last"), 0);
}

_pm_init();


