﻿/// <reference path="/files/modules/js/jquery-vsdoc.js" />
/// <reference path="/files/modules/js/jquery-ui.min.js" />
function _pm_init() {
    var moduleConfig = $.parseJSON('$moduleConfig');
    var discount = parseFloat(productData[0].discount);
    var str = '<div id="orderForm" style="line-height:25px;"><strong>产品名称：' + productData[0].pname + '</strong>' + (ia ? '&nbsp;&nbsp;&nbsp;<a href="?c=mproducts&pgtype=' + ptype + '&pid=' + productData[0].pid + '" target="_blank">『编辑此产品参数』</a>' : '') + '<br />' +
              '<strong>产品描述：</strong>' + htmlDecode(productData[0].pdes).replaceAll('<br />', ' / ') + '<br />';
    str += '<table style="width:100%;"><tr><td style="width:138px;text-align:right"><strong style="color:#0054ff;">◇产品及价格配置：</strong></td><td></td></tr>' +
           '<tr><td style="text-align:right"><strong>标配价格：</strong></td><td><select name="billingCycle">';
    var addPriceCycle = ' /月';
    if (productData[0].pprice.pmothod == '3') {
        //str += '<option value="0_0">免费试用' + productData[0].pprice.free + '天</option>';
        //addPriceCycle = '';
    }
    else if (productData[0].pprice.pmothod == '2') {
        str += '<option value="1_' + productData[0].pprice.onetime + '">' + productData[0].pprice.onetime + ' (一次性)</option>';
        addPriceCycle = '';
    }
    else {
        var pcycles = productData[0].pprice.cycle.split(',');
        var pcprice = productData[0].pprice.cprice.split(',');
        var pp1 = 0, pp2 = 0;
        var k = 0;
        for (i = 0; i < pcycles.length; i++) {
            if (pcprice[i] == '0') continue;
            if (pp1 == 0) pp1 = parseFloat(pcprice[i]) / parseInt(pcycles[i]);
            else {
                pp2 = (parseFloat(pcprice[i]) / parseInt(pcycles[i]) / pp1 * 10).toFixed(1);
            }
            str += '<option value="' + pcycles[i] + '_' + pcprice[i] + '">';
            switch (pcycles[i]) {
                case "1": str += '月　付'; break;
                case "3": str += '季　付'; break;
                case "6": str += '半年付'; break;
                case "12": str += '年　付'; break;
                case "24": str += '二年付'; break;
                default: str += pcycles[i] + '个月'; break;
            }
            str += '：' + (discount > 1 ? (parseFloat(pcprice[i]) * discount).toFixed(2) : pcprice[i]) + (pp2 != 0 ? ' (' + pp2 + '折)' : '') + '</option>';
        }
    }
    str += '</select></td></tr><tr><td style="height:10px;"></td><td></td></tr>';
    var params;
    var readOnly = '', ppTitle = '', ppValue = '', ppPrice = '0';
    var paramValues;
    var currency = userData[0].currency;
    $.each(moduleConfig, function (key, value) {
        if (productData[0].pconfig[key + '_hidden'] == '1') return true;
        readOnly = productData[0].pconfig[key + '_readonly'] == '1' ? 'readonly="readonly"' : '';
        params = $.parseJSON(value.replaceAll('&quot;', '"'));
        ppTitle = productData[0].pconfig[key + '_title'] == undefined ? params.displayText : productData[0].pconfig[key + '_title'];
        paramValues = params.params.split('|');
        ppValue = productData[0].pconfig[key + '_value'] == undefined ? paramValues[0] : productData[0].pconfig[key + '_value'];

        str += '<tr><td style="text-align:right"><strong>' + ppTitle + '：</strong></td><td>';
        switch (params.displayMode) {
            case '0':
                if (params.paramType == '0') {
                    ppPrice = productData[0].pconfig[key + '_price_0'] == undefined ? '0' : productData[0].pconfig[key + '_price_0'];
                    if (discount > 1) ppPrice = (parseFloat(ppPrice) * discount).toFixed(2);
                    str += '<input style="width:35px;" class="text center" name="' + key + '" value="' + ppValue + '" ' + readOnly + '/> X ' + ppPrice + ' ' + currency + addPriceCycle;
                } else str += '<input style="width:500px;' + (productData[0].pconfig[key + '_showonly'] == '1' ? 'border:0px' : '') + '" class="text" name="' + key + '" value="' + ppValue + '" ' + readOnly + '/>';
                break;
            case '1':
                str += '<textarea style="width:500px;height:65px;' + (productData[0].pconfig[key + '_showonly'] == '1' ? 'border:0px' : '') + '" class="text" name="' + key + '" ' + readOnly + '>' + ppValue.replaceAll('rn', '\r\n') + '</textarea>';
                break;
            case '2':
                if (isNaN(ppValue)) ppValue = '0';
                str += '<select name="' + key + '" ' + readOnly + '>';
                for (i = 0; i < paramValues.length; i++) {
                    if (productData[0].pconfig[key + '_hidden_' + i] == '1') continue;
                    str += '<option value="' + i + '" ' + (ppValue == i.toString() ? 'selected="selected"' : '') + '>' + paramValues[i];
                    ppPrice = productData[0].pconfig[key + '_price_' + i] == undefined ? '0' : productData[0].pconfig[key + '_price_' + i];
                    if (params.paramType == '0' && ppPrice != '0') {
                        if (discount > 1) ppPrice = (parseFloat(ppPrice) * discount).toFixed(2);
                        if (ppPrice.substring(0, 1) != '-') ppPrice = '+' + ppPrice;
                        str += ' (' + ppPrice + addPriceCycle + ')';
                    }
                    str += '</option>'
                }
                str += '</select>';
                break;
            case '3':
            case '4':
                for (i = 0; i < paramValues.length; i++) {
                    if (productData[0].pconfig[key + '_hidden_' + i] == '1') continue;
                    str += '<input type="' + (params.displayMode == '4' ? 'checkbox' : 'radio') + '" ' + ((',' + ppValue + ',').indexOf(',' + i + ',') > -1 ? 'checked="checked"' : '') + ' name="' + key + '" value="' + i + '" id="' + key + '_value_' + i + '" ' + readOnly + '/>' +
                           '<label for="' + key + '_value_' + i + '">' + paramValues[i];
                    ppPrice = productData[0].pconfig[key + '_price_' + i] == undefined ? '0' : productData[0].pconfig[key + '_price_' + i];
                    if (params.paramType == '0' && ppPrice != '0') {
                        if (discount > 1) ppPrice = (parseFloat(ppPrice) * discount).toFixed(2);
                        if (ppPrice.substring(0, 1) != '-') ppPrice = '+' + ppPrice;
                        str += ' (' + ppPrice + addPriceCycle + ')';
                    }
                    str += '</label><br />'
                }
                break;
        }
        str += '</td></tr><tr><td style="height:10px;"></td><td></td></tr>';
    });
    str += '</table><div style="display:none" id="_preview"></div><div style="display:none;line-height:25px" id="preview_win"></div></div>';
    var orderConfig = $('#OrderConfig');
    orderConfig.html(str);
    var buttonPane = $(".ui-dialog-buttonpane");
    if (buttonPane.find("#normalPrice").length < 1) $('<div style="float:left;padding:5px 0px 0px 15px;"><strong>总价格：</strong><strong id="normalPrice" class="pricing"></strong><span id="finalPrice"></span></div>').insertBefore(buttonPane.find(".ui-dialog-buttonset"));

    if (allowTrial) swin.dialog("option", "buttons", { "预览配置": function () { _pm_preview(); }, "马上购买": function () { checkout(0); }, "免费试用": function () { checkout(-1); }, "关 闭": function () { $(this).dialog("close"); } });
    else swin.dialog("option", "buttons", { "预览配置": function () { _pm_preview(); }, "马上购买": function () { checkout(0); }, "关 闭": function () { $(this).dialog("close"); } });
    
    orderConfig.find('input,select').change(function () { _pm_updatePrice(moduleConfig); });
    _pm_updatePrice(moduleConfig);
}

function _pm_preview(action) {
    var preview_win = $("#preview_win");
    preview_win.html($("#_preview").html());
    if (allowTrial) preview_win.dialog({ title: "预览配置", autoOpen: false, resizable: false, width: 800, height: 558, modal: false, buttons: { "马上购买": function () { checkout(0); }, "免费试用": function () { checkout(-1); }, "继续配置": function () { $(this).dialog("close"); } } }).dialog("open");
    else preview_win.dialog({ title: "预览配置", autoOpen: false, resizable: false, width: 800, height: 558, modal: false, buttons: { "马上购买": function () { checkout(0); }, "继续配置": function () { $(this).dialog("close"); } } }).dialog("open");
    
}

function _pm_updatePrice(moduleConfig) {
    var orderForm = $("#orderForm");
    var params;
    var Cycle = orderForm.find("select[name='billingCycle']").val().split('_');
    billingCycle = parseInt(Cycle[0]);
    var discount = parseFloat(productData[0].discount);
    var basePrice = parseFloat(Cycle[1]);
    var tPrice = 0;
    var vstr = '<table style="width:100%">'+
               '<tr style="font-weight:bold;"><td style="width:150px">项目名称</td><td>所选项(数量)</td><td style="width:100px">单 价</td><td style="width:100px">付款周期</td><td style="width:100px">价 格</td></tr>';
    var displayText = '';
    var paramValues;
    var cvalue;
    normalPrice = 0;
    $.each(moduleConfig, function (key, value) {
        if (productData[0].pconfig[key + '_hidden'] == '1') return true;
        params = $.parseJSON(value.replaceAll('&quot;', '"'));
        if (params.paramType != '0') return true;
        paramValues = params.params.split('|');
        displayText = productData[0].pconfig[key + '_title'] == undefined ? params.displayText : productData[0].pconfig[key + '_title'];
        switch (params.displayMode) {
            case '0':
                cvalue = parseInt(orderForm.find("input[name='" + key + "']").val());
                tPrice = cvalue * parseFloat(productData[0].pconfig[key + '_price_0']);
                normalPrice += tPrice;
                if (discount > 1) tPrice = tPrice * discount;
                vstr += '<tr><td>' + displayText + '</td><td>' + cvalue + '</td><td>' + tPrice + '</td><td>x ' + billingCycle + '</td><td>' + (tPrice * billingCycle).toFixed(2) + '</td></tr>';
                break;
            case '2':
                cvalue = parseInt(orderForm.find("select[name='" + key + "']").val());
                tPrice = parseFloat(productData[0].pconfig[key + '_price_' + cvalue]);
                normalPrice += tPrice;
                if (discount > 1) tPrice = tPrice * discount;
                vstr += '<tr><td>' + displayText + '</td><td>' + paramValues[cvalue] + '</td><td>' + tPrice + '</td><td>x ' + billingCycle + '</td><td>' + (tPrice * billingCycle).toFixed(2) + '</td></tr>';
                break;
            case '3':
                cvalue = parseInt(orderForm.find("input[name='" + key + "']:checked").val());
                tPrice = parseFloat(productData[0].pconfig[key + '_price_' + cvalue]);
                normalPrice += tPrice;
                if (discount > 1) tPrice = tPrice * discount;
                vstr += '<tr><td>' + displayText + '</td><td>' + paramValues[cvalue] + '</td><td>' + tPrice + '</td><td>x ' + billingCycle + '</td><td>' + (tPrice * billingCycle).toFixed(2) + '</td></tr>';
                break;
            case '4':
                $(orderForm.find("input[name='" + key + "']:checked")).each(function (i) {
                    cvalue = parseInt($(this).val());
                    tPrice = parseFloat(productData[0].pconfig[key + '_price_' + cvalue]);
                    normalPrice += tPrice;
                    if (discount > 1) tPrice = tPrice * discount;
                    vstr += '<tr><td>' + displayText + '</td><td>' + paramValues[cvalue] + '</td><td>' + tPrice + '</td><td>x ' + billingCycle + '</td><td>' + (tPrice * billingCycle).toFixed(2) + '</td></tr>';
                });
                break;
        }
    });
    vstr += '<tr><td></td><td style="text-align:right;padding-right:8px"><strong>自选项价格</strong>：</td><td>' + (discount > 1 ? (normalPrice * discount).toFixed(2) : normalPrice.toFixed(2)) + '</td><td>x ' + billingCycle + '</td><td><strong>' + (normalPrice * billingCycle * (discount > 1 ? discount : 1)).toFixed(2) + '</strong></td></tr>' +
            '<tr><td></td><td style="text-align:right;padding-right:8px"><strong>标配价格</strong>：</td><td></td><td style="text-align:right;font-weight:bold">+</td><td><strong>' + (discount > 1 ? (basePrice * discount).toFixed(2) : basePrice.toFixed(2)) + '</strong></td></tr>';
    normalPrice = basePrice + normalPrice * billingCycle;
    finalPrice = normalPrice * discount;
    vstr += '<tr><td></td><td style="text-align:right;padding-right:8px"><strong>总计价格</strong>：</td><td></td><td></td><td><strong>' + (discount > 1 ? (normalPrice * discount).toFixed(2) : normalPrice.toFixed(2)) + '</strong> ' + userData[0].currency + '</td></tr>';
    if (normalPrice > finalPrice) {
        $("#normalPrice").html('<strike>' + normalPrice.toFixed(2) + '</strike>');
        $("#finalPrice").html('<strong style="margin-left:18px">帐户优惠价(' + (discount * 100 / 10) + '折)：</strong><strong class="pricing">' + finalPrice.toFixed(2) + '</strong> <strong>' + userData[0].currency + '<strong>');
        vstr += '<tr><td></td><td style="text-align:right;padding-right:8px"><strong>帐户优惠价</strong>：</td><td>' + ((1 - discount) * 100).toFixed(2) + '% Off</td><td>x ' + discount + '</td><td><strong>' + finalPrice.toFixed(2) + '</strong> ' + userData[0].currency + '</td></tr>';
    } else $("#normalPrice").html(finalPrice.toFixed(2) + ' ' + userData[0].currency);
    vstr += '</table>';
    orderForm.find("#_preview").html(vstr);
}

_pm_init();
