﻿/// <reference path="/files/modules/js/jquery-vsdoc.js" />
/// <reference path="/files/modules/js/jquery-ui.min.js" />

var billingMothod = parseInt(serviceData[0].spmothod);
function _pm_init() {
    var moduleConfig = $.parseJSON('$moduleConfig');
    var tempStr = '';
    $(ptData).each(function (i) {
        if (serviceData[0].stype == ptData[i].ptid) {
            tempStr = '管理我的' + ptData[i].ptname;
            return false;
        }
    });
    if (tempStr != '') {
        $("#pageTitle").html(tempStr);
        document.title = tempStr;
    }
    tempStr = '';
    var userRole = utype;
    if (userRole == '1') tempStr = '?c=rmuser&uid=' + userData[0].uid;
    else if (userRole == '10') tempStr = '?c=muser&uid=' + userData[0].uid;
    if (tempStr != '') tempStr = '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;所属用户：<a href="' + tempStr + '" target="_blank">' + userData[0].uname + '</a>';

    var str = '<table width="100%" border="0" cellspacing="0" cellpadding="0" class="table grid"><thead><tr><th style="text-align:right">产品服务基本信息：</th><th>&nbsp;</th></tr></thead><tbody>' +
              '<tr><td class="title">服务编号：</td><td>#<strong>' + serviceData[0].sid + '</strong>' + tempStr + '</td></tr>';
    var params;
    var ppTitle = '', ppValue = '', ppPrice = '0';
    var paramValues, values;
    var addPrice = 0;
    $.each(moduleConfig, function (key, value) {
        if (productData[0].pconfig[key + '_hidden'] == '1') return true;
        params = $.parseJSON(value.replaceAll('&quot;', '"'));
        ppTitle = productData[0].pconfig[key + '_title'] == undefined ? params.displayText : productData[0].pconfig[key + '_title'];
        paramValues = params.params.split('|');
        ppValue = serviceData[0].sconfig[key];
        if (ppValue == undefined || ppValue == '') return true;

        str += '<tr><td class="title">' + ppTitle + '：</td><td>';
        switch (params.displayMode) {
            case '0':
            case '1':
                str += ppValue.replaceAll('\r\n', '<br />');
                if (params.paramType == '0') addPrice += parseInt(ppValue) * parseFloat(productData[0].pconfig[key + '_price_0']);
                break;
            case '2':
            case '3':
                if (isNaN(ppValue)) ppValue = '0';
                str += paramValues[parseInt(ppValue)];
                if (params.paramType == '0') addPrice += parseFloat(productData[0].pconfig[key + '_price_' + ppValue]);
                break;
            case '4':
                values = ppValue.split(',');
                for (i = 0; i < values.length; i++) {
                    if (i > 0) str += ' / ';
                    str += paramValues[parseInt(values[i])];
                    if (params.paramType == '0') addPrice += parseFloat(productData[0].pconfig[key + '_price_' + values[i]]);
                }
                break;
        }
        str += '</td></tr>';
    });
    var statusText = serviceStatus[parseInt(serviceData[0].sstatus) + 2];
    switch (serviceData[0].sstatus) {
        case "3": statusText = '<strong style="color:#CC3300;">' + statusText + '</strong>'; break;
        case "4": statusText = '<strong style="color:#FF0000;">' + statusText + '</strong>'; break;
    }
    var sTrial = serviceData[0].strial == undefined ? 0 : parseFloat(serviceData[0].strial);
    if (sTrial > 0) statusText += '（试用' + sTrial + '小时）';

    switch (billingMothod) {
        case 1: //周期付款
            str += '<tr><td class="title">续费价格：</td><td>' + serviceData[0].sprice + ' / ' + serviceData[0].spcycle + '个月&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="javascript:_pm_renew(' + addPrice + ');">『马上续费』</a></td></tr>' +
                   '<tr><td class="title">到期时间：</td><td>' + getUnixTime(serviceData[0].etime) + '&nbsp;&nbsp;&nbsp;<input id="autorenew" type="checkbox" ' + (serviceData[0].autorenew == '0' ? 'checked="checked"' : '') + '/><label for="autorenew">自动续费</label></td></tr>';
            break;
        case 2: //一次性付款
            str += '<tr><td class="title">续费价格：</td><td>' + serviceData[0].sprice + ' (一次性)</td></tr>';
            break;
        case 3: //免费试用
            str += '<tr><td class="title">到期时间：</td><td>' + getUnixTime(serviceData[0].etime) + ' (免费试用)</td></tr>';
            break;
    }
    str += '<tr><td class="title">服务状态：</td><td>' + statusText + '</td></tr>' +
            '</tbody></table>' +
            '<table width="100%" border="0" cellspacing="0" cellpadding="0" class="table grid"><thead><tr><th>当前服务其它信息：</th><th>&nbsp;</th></tr></thead><tbody>';
    var suffix;
    $.each(serviceData[0].sconfig, function (key, value) {
        if (key.indexOf('as_name_') == 0) {
            suffix = key.substring(8);
            str += '<tr><td class="title">' + value + '：</td><td style="line-height:21px">' + htmlDecode(serviceData[0].sconfig['as_value_' + suffix]) + '</td></tr>';
        }
    });
    str += '</tbody></table>';
    var ViewService = $("#ViewService");
    ViewService.html(str);
    ViewService.find(".title").css("text-align", "right");

    ViewService.find("#autorenew").css("cursor", "pointer").click(function () {
        var autorenew = $(this).prop("checked") ? '0' : '1';
        setAutorenew(serviceData[0].sid, autorenew);
    });
}

var finalPrice = 0;
var normalPrice = 0;
var productID = productData[0].pid;
var billingCycle = 1;
function _pm_renew(addPrice) {
    if (billingMothod != 1) {
        alert("您当前服务无需续费！");
        return false;
    }
    var discount = parseFloat(productData[0].discount);
    var str = '<p style="line-height:28px"><strong>帐户余额</strong>：<strong>' + userData[0].balance + '</strong> ' + userData[0].currency;
    if (discount < 1) str += '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong>帐户优惠</strong>：<strong style="color:#0000FF">' + (discount * 100 / 10) + '</strong>折';
    str += '&nbsp;<br /><strong>请选择续费周期</strong>：<br />';
    var pcycles = productData[0].pprice.cycle.split(',');
    var pcprice = productData[0].pprice.cprice.split(',');
    var pp1 = 0, pp2 = 0;
    var cprice, yprice;
    for (i = 0; i < pcycles.length; i++) {
        if (pcprice[i] != '0') {
            cprice = parseFloat(pcprice[i]) + (addPrice * parseInt(pcycles[i]));
            yprice = cprice;
            if (pcycles[i] == serviceData[0].spcycle) cprice = serviceData[0].sprice;
            else {
                if (discount > 1) {
                    cprice = cprice * discount;
                }
            }
            if (pp1 == 0) pp1 = parseFloat(yprice) / parseInt(pcycles[i]);
            else {
                pp2 = (parseFloat(yprice) / parseInt(pcycles[i]) / pp1 * 10).toFixed(1);
            }
            str += '<input type="radio" name="cycle" value="' + pcycles[i] + '_' + cprice + '_' + yprice + '" id="cycle' + pcycles[i] + '" /><label for="cycle' + pcycles[i] + '">';
            switch (pcycles[i]) {
                case "1": str += '月　付'; break;
                case "3": str += '季　付'; break;
                case "6": str += '半年付'; break;
                case "12": str += '年　付'; break;
                case "24": str += '二年付'; break;
                default: str += pcycles[i] + '个月付'; break;
            }
            str += '：' + cprice + (pp2 != 0 ? ' (' + pp2 + '折)' : '') + '</label><br />';
        }
    }
    str += '&nbsp;<br /><strong>续费价格</strong>：<strong class="finalPrice"></strong> ' + userData[0].currency + '&nbsp;&nbsp;&nbsp;<span class="normalPrice"></span><br />&nbsp;<br />' +
           '<span>优 惠 码：<input class="text" id="couponcode" style="width:100px"/> <input type="button" class="button" value="使用" onclick="applyCode(\'renew\')"/> <input type="button" class="button" value="不使用" onclick="clearCouponCode(1)"/></span><br />' +
           '<span id="ccdes" class="pptext"></span></p>';
    suwin.html(str);
    suwin.dialog({ title: "续费确认", autoOpen: false, resizable: false, width: 500, height: 500, modal: false, buttons: { "确认续费": function () { renew(serviceData[0].sid, billingCycle, $("#couponcode").val()); }, "关 闭": function () { $(this).dialog("close"); } } }).dialog("open");
    suwin.find("input:radio").click(function () {
        clearCouponCode(1);
        var ps = $(this).val().split('_');
        billingCycle = parseInt(ps[0]);
        finalPrice = parseFloat(ps[1]);
        normalPrice = parseFloat(ps[2]);
        if (billingCycle != parseInt(serviceData[0].spcycle) && discount < 1) finalPrice = finalPrice * discount;
        suwin.find(".finalPrice").html(finalPrice.toFixed(2));
    });
    suwin.find("#cycle" + serviceData[0].spcycle).click();
}

_pm_init();
