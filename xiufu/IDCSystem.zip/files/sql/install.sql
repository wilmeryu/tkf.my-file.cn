﻿IF OBJECT_ID('[coupon_group]') IS NOT NULL DROP TABLE [coupon_group]
GO

CREATE TABLE [coupon_group] (
	[gid] [int] IDENTITY(1,1) NOT NULL CONSTRAINT [PK_coupon_group] PRIMARY KEY  CLUSTERED ([gid] ASC)  ON [PRIMARY],
	[gname] [nvarchar](50) NOT NULL DEFAULT (''),
	[gpublic] [int] NOT NULL DEFAULT (0),
) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_coupon_group] ON [coupon_group] ([gpublic] ASC)
GO

IF OBJECT_ID('[log_list]') IS NOT NULL DROP TABLE [log_list]
GO

CREATE TABLE [log_list] (
	[lid] [int] IDENTITY(1,1) NOT NULL CONSTRAINT [PK_log_list] PRIMARY KEY  CLUSTERED ([lid])  ON [PRIMARY],
	[uid] [int] NOT NULL DEFAULT (0),
	[vid] [int] NOT NULL DEFAULT (0),
	[ltype] [int] NOT NULL DEFAULT (0),
	[lprice] [int] NOT NULL DEFAULT (0),
	[ldes] [nvarchar](255) NOT NULL DEFAULT (''),
	[lstatus] [int] NOT NULL DEFAULT (0),
	[ltime] [smalldatetime] NOT NULL DEFAULT (getdate()),
) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_log_list] ON [log_list]([uid] ASC,[vid] ASC,[ltype] ASC,[lstatus] ASC)
GO

IF OBJECT_ID('[mail_list]') IS NOT NULL DROP TABLE [mail_list]
GO

CREATE TABLE [mail_list] (
	[mailid] [int] IDENTITY(1,1) NOT NULL CONSTRAINT [PK_mail_list] PRIMARY KEY  CLUSTERED ([mailid] ASC)  ON [PRIMARY],
	[uid] [int] NOT NULL DEFAULT (0),
	[vid] [int] NOT NULL DEFAULT (0),
	[subject] [nvarchar](100) NOT NULL DEFAULT (''),
	[body] [nvarchar](4000) NOT NULL DEFAULT (''),
	[mtime] [int] NOT NULL DEFAULT (0),
	[mstatus] [int] NOT NULL DEFAULT (0),
	[mtype] [int] NOT NULL DEFAULT (0),
	[to] [varchar](255) NOT NULL DEFAULT (''),
	[mconfig] [nvarchar](255) NOT NULL DEFAULT (''),
) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_mail_list] ON [mail_list] ([uid] ASC,[vid] ASC,[mstatus] ASC);
CREATE NONCLUSTERED INDEX [IX_mail_list_1] ON [mail_list] ([mtime] ASC);
CREATE NONCLUSTERED INDEX [IX_mail_list_type] ON [mail_list] ([mtype] ASC);
CREATE NONCLUSTERED INDEX [IX_mail_list_to] ON [mail_list] ([to] ASC);
GO

IF OBJECT_ID('[news_list]') IS NOT NULL DROP TABLE [news_list]
GO

CREATE TABLE [news_list] (
	[nid] [int] IDENTITY(1,1) NOT NULL CONSTRAINT [PK_news_list] PRIMARY KEY  CLUSTERED ([nid])  ON [PRIMARY],
	[ntitle] [nvarchar](100) NOT NULL DEFAULT (''),
	[ncontent] [nvarchar](4000) NOT NULL DEFAULT (''),
	[ntime] [smalldatetime] NOT NULL DEFAULT (getdate()),
	[ntype] [int] NOT NULL DEFAULT (0),
	[nstatus] [int] NOT NULL DEFAULT (0),
	[nclick] [int] NOT NULL DEFAULT (0),
) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_news_list_type_status] ON [news_list] ([ntype] ASC,[nstatus] ASC);
CREATE NONCLUSTERED INDEX [IX_news_list_title] ON [news_list] ([ntitle] ASC);
CREATE NONCLUSTERED INDEX [IX_news_click] ON [news_list] ([nclick] ASC);
GO

IF OBJECT_ID('[pay_list]') IS NOT NULL DROP TABLE [pay_list]
GO

CREATE TABLE [pay_list] (
	[pid] [int] IDENTITY(1,1) NOT NULL,
	[id] [bigint] NOT NULL DEFAULT (0) CONSTRAINT [PK_pay_list] PRIMARY KEY  CLUSTERED ([pid] ASC,[id] ASC)  ON [PRIMARY],
	[uid] [int] NOT NULL DEFAULT (0),
	[amount] [float] NOT NULL DEFAULT (0),
	[pdes] [nvarchar](255) NOT NULL DEFAULT (''),
	[pstatus] [int] NOT NULL DEFAULT (0),
	[ptime] [datetime] NOT NULL DEFAULT (getdate()),
	[ptype] [int] NOT NULL DEFAULT (0),
	[pconfig] [nvarchar](100) NOT NULL DEFAULT (''),
	[pmid] [int] NOT NULL DEFAULT (0),
	[ctime] [int] NOT NULL DEFAULT (0),
	[pbalance] [float] NOT NULL DEFAULT (-1),
) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_pay_list] ON [pay_list]([uid] ASC,[pstatus] ASC)
CREATE NONCLUSTERED INDEX [IX_pay_list_1] ON [pay_list]([pdes] ASC)
CREATE NONCLUSTERED INDEX [IX_pay_list_ptype] ON [pay_list]([ptype] ASC);
CREATE NONCLUSTERED INDEX [IX_pay_list_pmid] ON [pay_list] ([pmid] ASC);
CREATE NONCLUSTERED INDEX [IX_pay_list_ctime] ON [pay_list] ([ctime] ASC);
GO

IF OBJECT_ID('[referral_pay]') IS NOT NULL DROP TABLE [referral_pay]
GO

CREATE TABLE [referral_pay] (
	[rid] [int] IDENTITY(1,1) NOT NULL CONSTRAINT [PK_referral_pay] PRIMARY KEY  CLUSTERED ([rid] ASC)  ON [PRIMARY],
	[uid] [int] NOT NULL DEFAULT (0),
	[amount] [int] NOT NULL DEFAULT (0),
	[payto] [varchar](255) NOT NULL DEFAULT (''),
	[rstatus] [int] NOT NULL DEFAULT (0),
	[rtime] [smalldatetime] NOT NULL DEFAULT (getdate()),
	[rdes] [nvarchar](255) NOT NULL DEFAULT (''),
) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_referral_pay] ON [referral_pay]([uid] ASC,[rstatus] ASC)
GO

IF OBJECT_ID('[sys_config]') IS NOT NULL DROP TABLE [sys_config]
GO

CREATE TABLE [sys_config] (
	[cid] [int] IDENTITY(1,1) NOT NULL CONSTRAINT [PK_sys_config] PRIMARY KEY  CLUSTERED ([cid] ASC)  ON [PRIMARY],
	[sname] [nvarchar](50) NOT NULL DEFAULT (''),
	[cname] [varchar](30) NOT NULL DEFAULT (''),
	[cvalue] [varchar](1000) NOT NULL DEFAULT (''),
	[cdes] [nvarchar](255) NOT NULL DEFAULT (''),
	[ctype] [int] NOT NULL DEFAULT (0),
	[cconfig] [nvarchar](4000) NOT NULL DEFAULT (''),
	[cstatus] [int] NOT NULL DEFAULT (1),
	[corder] [int] NOT NULL DEFAULT (0),
	[extfield1] [int] NOT NULL DEFAULT (0),
	[extfield2] [int] NOT NULL DEFAULT (0),
) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_sc_name] ON [sys_config]([cname] ASC)
CREATE NONCLUSTERED INDEX [IX_sc_type] ON [sys_config]([ctype] ASC);
CREATE NONCLUSTERED INDEX [IX_sys_config_status] ON [sys_config] ([cstatus] ASC,[extfield1] ASC,[extfield2] ASC);
CREATE NONCLUSTERED INDEX [IX_sys_config_order] ON [sys_config] ([corder] ASC);
GO

IF OBJECT_ID('[ticket_list]') IS NOT NULL DROP TABLE [ticket_list]
GO

CREATE TABLE [ticket_list] (
	[tid] [int] IDENTITY(1,1) NOT NULL CONSTRAINT [PK_ticket_list] PRIMARY KEY  CLUSTERED ([tid] ASC)  ON [PRIMARY],
	[ttid] [int] NOT NULL DEFAULT (0),
	[uid] [int] NOT NULL DEFAULT (0),
	[vid] [int] NOT NULL DEFAULT (0),
	[ttype] [int] NOT NULL DEFAULT (0),
	[ttitle] [nvarchar](50) NOT NULL DEFAULT (''),
	[tcontent] [nvarchar](1000) NOT NULL DEFAULT (''),
	[ttime] [smalldatetime] NOT NULL DEFAULT (getdate()),
	[tstatus] [int] NOT NULL DEFAULT (0),
	[email] [bit] NOT NULL DEFAULT (0),
	[tdepartment] [int] NOT NULL DEFAULT (0),
	[rtime] [int] NOT NULL DEFAULT (0),
	[tnote] [nvarchar](1000) NOT NULL DEFAULT (''),
	[submitter] [nvarchar](255) NOT NULL DEFAULT (''),
	[attcount] [int] NOT NULL DEFAULT (0),
) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_ticket_list] ON [ticket_list]([ttid] ASC,[uid] ASC,[vid] ASC,[ttype] ASC)
CREATE NONCLUSTERED INDEX [IX_ticket_list_1] ON [ticket_list]([tstatus] ASC)
CREATE NONCLUSTERED INDEX [IX_ticket_list_2] ON [ticket_list]([ttime] ASC)
CREATE NONCLUSTERED INDEX [IX_ticket_list_tdepartment] ON [ticket_list] ([tdepartment] ASC);
CREATE NONCLUSTERED INDEX [IX_ticket_list_rtime] ON [ticket_list] ([rtime] ASC);
GO

IF OBJECT_ID('[user_list]') IS NOT NULL DROP TABLE [user_list]
GO

CREATE TABLE [user_list] (
	[uid] [int] IDENTITY(8080,1) NOT NULL CONSTRAINT [PK_user_list] PRIMARY KEY  CLUSTERED ([uid] ASC)  ON [PRIMARY],
	[uname] [varchar](30) NOT NULL DEFAULT (''),
	[name] [nvarchar](50) NOT NULL DEFAULT (''),
	[upass] [varchar](32) NOT NULL DEFAULT (''),
	[umail] [varchar](255) NOT NULL DEFAULT (''),
	[vcount] [int] NOT NULL DEFAULT (0),
	[balance] [float] NOT NULL DEFAULT (0),
	[total] [float] NOT NULL DEFAULT (0),
	[currency] [varchar](10) NOT NULL DEFAULT ('RMB'),
	[utype] [int] NOT NULL DEFAULT (0),
	[tel] [bigint] NOT NULL DEFAULT (0),
	[qq] [bigint] NOT NULL DEFAULT (0),
	[logintime] [smalldatetime] NOT NULL DEFAULT (getdate()),
	[regtime] [smalldatetime] NOT NULL DEFAULT (getdate()),
	[referral] [int] NOT NULL DEFAULT (0),
	[udes] [nvarchar](255) NOT NULL DEFAULT (''),
	[apikey] [varchar](50) NOT NULL DEFAULT (''),
	[adminps] [varchar](32) NOT NULL DEFAULT (''),
	[cvdate] [int] NOT NULL DEFAULT (0),
	[rvcount] [int] NOT NULL DEFAULT (0),
	[dvcount] [int] NOT NULL DEFAULT (0),
	[reseller] [int] NOT NULL DEFAULT (0),
	[uconfig] [nvarchar](255) NOT NULL DEFAULT (''),
	[sutype] [int] NOT NULL DEFAULT (0),
	[ustatus] [int] NOT NULL DEFAULT (0),
	[reg_ip] [varchar](50) NOT NULL DEFAULT (''),
	[login_ip] [varchar](50) NOT NULL DEFAULT (''),
	[extfield1] [nvarchar](255) NOT NULL DEFAULT (''),
	[extfield2] [nvarchar](255) NOT NULL DEFAULT (''),
	[extfield3] [nvarchar](255) NOT NULL DEFAULT (''),
	[extfield4] [nvarchar](255) NOT NULL DEFAULT (''),
	[extfield5] [nvarchar](255) NOT NULL DEFAULT (''),
	[extfield6] [nvarchar](255) NOT NULL DEFAULT (''),
	[extfield7] [nvarchar](255) NOT NULL DEFAULT (''),
	[extfield8] [nvarchar](255) NOT NULL DEFAULT (''),
	[extfield9] [nvarchar](255) NOT NULL DEFAULT (''),
	[extfield10] [nvarchar](255) NOT NULL DEFAULT (''),
) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_user_vchar] ON [user_list]([uname] ASC,[name] ASC,[umail] ASC,[udes] ASC)
CREATE NONCLUSTERED INDEX [IX_user_int1] ON [user_list]([utype] ASC,[tel] ASC,[qq] ASC,[referral] ASC,[reseller] ASC)
CREATE NONCLUSTERED INDEX [IX_user_int2] ON [user_list]([vcount] ASC,[balance] ASC,[total] ASC)
CREATE NONCLUSTERED INDEX [IX_user_sutype] ON [user_list]([sutype] ASC);
CREATE NONCLUSTERED INDEX [IX_user_status] ON [user_list]([ustatus] ASC);
CREATE NONCLUSTERED INDEX [IX_user_ip] ON [user_list] ([reg_ip] ASC,[login_ip] ASC);
CREATE NONCLUSTERED INDEX [IX_user_list_extfield1] ON [user_list] ([extfield1] ASC);
CREATE NONCLUSTERED INDEX [IX_user_list_extfield2] ON [user_list] ([extfield2] ASC);
CREATE NONCLUSTERED INDEX [IX_user_list_extfield3] ON [user_list] ([extfield3] ASC);
CREATE NONCLUSTERED INDEX [IX_user_list_extfield4] ON [user_list] ([extfield4] ASC);
CREATE NONCLUSTERED INDEX [IX_user_list_extfield5] ON [user_list] ([extfield5] ASC);
CREATE NONCLUSTERED INDEX [IX_user_list_extfield6] ON [user_list] ([extfield6] ASC);
CREATE NONCLUSTERED INDEX [IX_user_list_extfield7] ON [user_list] ([extfield7] ASC);
CREATE NONCLUSTERED INDEX [IX_user_list_extfield8] ON [user_list] ([extfield8] ASC);
CREATE NONCLUSTERED INDEX [IX_user_list_extfield9] ON [user_list] ([extfield9] ASC);
CREATE NONCLUSTERED INDEX [IX_user_list_extfield10] ON [user_list] ([extfield10] ASC);
GO

IF OBJECT_ID('[utype_list]') IS NOT NULL DROP TABLE [utype_list]
GO

CREATE TABLE [utype_list] (
	[tid] [int] IDENTITY(1,1) NOT NULL,
	[utype] [int] NOT NULL DEFAULT (0) CONSTRAINT [PK_utype_list] PRIMARY KEY  CLUSTERED ([tid] ASC,[utype] ASC) ON [PRIMARY],
	[tname] [nvarchar](50) NOT NULL DEFAULT (''),
	[tprice] [varchar](8) NOT NULL DEFAULT ('1'),
	[tbalance] [int] NOT NULL DEFAULT (0),
	[uttype] [int] NOT NULL DEFAULT (0),
	[utconfig] [nvarchar](2000) NOT NULL DEFAULT (''),
	[utorder] [int] NOT NULL DEFAULT (0),
) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_ut_type] ON [utype_list]([uttype] ASC);
CREATE NONCLUSTERED INDEX [IX_ul_utorder] ON [utype_list] ([utorder] ASC);
GO

IF OBJECT_ID('[product_group]') IS NOT NULL DROP TABLE [product_group]
GO

CREATE TABLE [product_group] (
	[pgid] [int] IDENTITY(1,1) NOT NULL CONSTRAINT [PK_product_group] PRIMARY KEY  CLUSTERED ([pgid])  ON [PRIMARY],
	[pgname] [nvarchar](50) NOT NULL DEFAULT (''),
	[pgtype] [int] NOT NULL DEFAULT (0),
	[pgdes] [nvarchar](255) NOT NULL DEFAULT (''),
	[pcount] [int] NOT NULL DEFAULT (0),
	[pgorder] [int] NOT NULL DEFAULT (0),
	[pgpublic] [int] NOT NULL DEFAULT (0),
) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_pg_type_public] ON [product_group]([pgtype] ASC,[pgpublic] ASC);
CREATE NONCLUSTERED INDEX [IX_pg_order] ON [product_group]([pgorder] ASC);
GO

IF OBJECT_ID('[product_list]') IS NOT NULL DROP TABLE [product_list]
GO

CREATE TABLE [product_list] (
	[pid] [int] IDENTITY(1,1) NOT NULL CONSTRAINT [PK_product_list] PRIMARY KEY  CLUSTERED ([pid])  ON [PRIMARY],
	[pgid] [int] NOT NULL DEFAULT (0),
	[pname] [nvarchar](50) NOT NULL DEFAULT (''),
	[pdes] [nvarchar](2000) NOT NULL DEFAULT (''),
	[pstock] [int] NOT NULL DEFAULT (0),
	[psales] [int] NOT NULL DEFAULT (0),
	[porder] [int] NOT NULL DEFAULT (0),
	[phidden] [int] NOT NULL DEFAULT (0),
	[pprice] [varchar](500) NOT NULL DEFAULT (''),
	[pconfig] [varchar](8000) NOT NULL DEFAULT (''),
	[pupgrade] [varchar](8000) NOT NULL DEFAULT (''),
	[ptsales] [int] NOT NULL DEFAULT (0),
	[pmsales] [int] NOT NULL DEFAULT (0),
	[pysales] [int] NOT NULL DEFAULT (0),
	[module] [int] NOT NULL DEFAULT (0),
	[psconfig] [varchar](500) NOT NULL DEFAULT (''),
) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_pl_pgid_ph] ON [product_list]([pgid] ASC,[pstock] ASC,[phidden] ASC);
CREATE NONCLUSTERED INDEX [IX_pl_order] ON [product_list]([psales] ASC,[porder] ASC);
CREATE NONCLUSTERED INDEX [IX_pl_name] ON [product_list]([pname] ASC);
CREATE NONCLUSTERED INDEX [IX_pl_sales] ON [product_list] ([ptsales] ASC,[pmsales] ASC,[pysales] ASC);
CREATE NONCLUSTERED INDEX [IX_pl_module] ON [product_list] ([module] ASC);
GO

IF OBJECT_ID('[coupon_code]') IS NOT NULL DROP TABLE [coupon_code]
GO

CREATE TABLE [coupon_code] (
	[cid] [int] IDENTITY(1,1) NOT NULL CONSTRAINT [PK_coupon_code] PRIMARY KEY  CLUSTERED ([cid])  ON [PRIMARY],
	[cgid] [int] NOT NULL DEFAULT (0),
	[ctype] [int] NOT NULL DEFAULT (0),
	[code] [varchar](50) NOT NULL DEFAULT (''),
	[climit] [int] NOT NULL DEFAULT (0),
	[discount] [float] NOT NULL DEFAULT (0),
	[edate] [smalldatetime] NOT NULL DEFAULT (getdate()),
	[cdes] [nvarchar](255) NOT NULL DEFAULT (''),
	[cconfig] [nvarchar](500) NOT NULL DEFAULT (''),
) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_cc_cgid_ctype_climit] ON [coupon_code]([cgid] ASC,[ctype] ASC,[climit] ASC);
CREATE NONCLUSTERED INDEX [IX_cc_code] ON [coupon_code]([code] ASC);
GO

IF OBJECT_ID('[service_list]') IS NOT NULL DROP TABLE [service_list]
GO

CREATE TABLE [service_list] (
	[sid] [int] IDENTITY(1,1) NOT NULL CONSTRAINT [PK_service_list] PRIMARY KEY  CLUSTERED ([sid])  ON [PRIMARY],
	[uid] [int] NOT NULL DEFAULT (0),
	[pid] [int] NOT NULL DEFAULT (0),
	[stype] [int] NOT NULL DEFAULT (0),
	[ssid] [int] NOT NULL DEFAULT (0),
	[sfprice] [float] NOT NULL DEFAULT (0),
	[sprice] [float] NOT NULL DEFAULT (0),
	[spmothod] [int] NOT NULL DEFAULT (0),
	[spcycle] [int] NOT NULL DEFAULT (0),
	[ctime] [int] NOT NULL DEFAULT (0),
	[stime] [int] NOT NULL DEFAULT (0),
	[etime] [int] NOT NULL DEFAULT (0),
	[sstatus] [int] NOT NULL DEFAULT (0),
	[autorenew] [int] NOT NULL DEFAULT (0),
	[sdes] [nvarchar](255) NOT NULL DEFAULT (''),
	[sconfig] [nvarchar](4000) NOT NULL DEFAULT (''),
	[sname] [nvarchar](255) NOT NULL DEFAULT (''),
	[checktime] [int] NOT NULL DEFAULT (0),
	[strial] [int] NOT NULL DEFAULT (0),
	[slabel] [nvarchar](50) NOT NULL DEFAULT (''),
	[ssetting] [nvarchar](1000) NOT NULL DEFAULT (''),
	[sulabel] [nvarchar](255) NOT NULL DEFAULT (''),
) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_sl_int] ON [service_list]([uid] ASC,[pid] ASC,[spmothod] ASC,[stype] ASC,[ssid] ASC,[spcycle] ASC,[sstatus] ASC);
CREATE NONCLUSTERED INDEX [IX_sl_p_t] ON [service_list]([sfprice] ASC,[sprice] ASC,[ctime] ASC,[stime] ASC,[etime] ASC);
CREATE NONCLUSTERED INDEX [IX_sl_sname] ON [service_list] ([sname] ASC);
CREATE NONCLUSTERED INDEX [IX_sl_checktime] ON [service_list] ([checktime] ASC);
CREATE NONCLUSTERED INDEX [IX_sl_trial] ON [service_list] ([strial] ASC);
CREATE NONCLUSTERED INDEX [IX_sl_label] ON [service_list] ([slabel] ASC);
CREATE NONCLUSTERED INDEX [IX_sl_ulabel] ON [service_list] ([sulabel] ASC);
GO

IF OBJECT_ID('[consumer_list]') IS NOT NULL DROP TABLE [consumer_list]
GO

CREATE TABLE [consumer_list] (
	[cid] [int] IDENTITY(1,1) NOT NULL CONSTRAINT [PK_consumer_list] PRIMARY KEY  CLUSTERED ([cid]) ON [PRIMARY],
	[serviceid] [int] NOT NULL DEFAULT (0),
	[amount] [float] NOT NULL DEFAULT (0),
	[stime] [int] NOT NULL DEFAULT (0),
	[etime] [int] NOT NULL DEFAULT (0),
	[cdes] [nvarchar](255) NOT NULL DEFAULT (''),
	[cconfig] [varchar](100) NOT NULL DEFAULT (''),
	[ctime] [int] NOT NULL DEFAULT (0),
	[pid] [int] NOT NULL DEFAULT (0),
	[uid] [int] NOT NULL DEFAULT (0),
	[stype] [int] NOT NULL DEFAULT (0),
) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_cl_id] ON [consumer_list]([serviceid] ASC);
CREATE NONCLUSTERED INDEX [IX_cl_time] ON [consumer_list]([stime] ASC,[etime] ASC);
CREATE NONCLUSTERED INDEX [IX_cl_ctime] ON [consumer_list]([ctime] ASC);
CREATE NONCLUSTERED INDEX [IX_cl_pid] ON [consumer_list]([pid] ASC);
CREATE NONCLUSTERED INDEX [IX_cl_uid_stype] ON [consumer_list]([uid] ASC,[stype] ASC);
GO

IF OBJECT_ID('[user_field]') IS NOT NULL DROP TABLE [user_field]
GO

CREATE TABLE [user_field] (
	[fid] [int] IDENTITY(1,1) NOT NULL CONSTRAINT [PK_user_field] PRIMARY KEY  CLUSTERED ([fid])  ON [PRIMARY],
	[uid] [int] NOT NULL DEFAULT (0),
	[ftype] [int] NOT NULL DEFAULT (0),
	[fsid] [int] NOT NULL DEFAULT (0),
	[fname] [varchar](100) NOT NULL DEFAULT (''),
	[fvalue] [nvarchar](255) NOT NULL DEFAULT (''),
) ON [PRIMARY]

CREATE NONCLUSTERED INDEX [IX_uf_uid_type] ON [user_field]([uid] ASC,[ftype] ASC,[fsid] ASC);
CREATE NONCLUSTERED INDEX [IX_uf_name] ON [user_field]([fname] ASC);
GO

IF OBJECT_ID('[product_type]') IS NOT NULL DROP TABLE [product_type]
GO

CREATE TABLE [product_type] (
	[id] [int] IDENTITY(1,1) NOT NULL,
	[ptid] [int] NOT NULL DEFAULT (0) CONSTRAINT [PK_product_type] PRIMARY KEY  CLUSTERED ([id] ASC,[ptid] ASC) ON [PRIMARY],
	[ptname] [nvarchar](100) NOT NULL DEFAULT (''),
	[ptename] [nvarchar](100) NOT NULL DEFAULT (''),
	[ptorder] [int] NOT NULL DEFAULT (0),
	[pthidden] [int] NOT NULL DEFAULT (0),
	[ptconfig] [nvarchar](4000) NOT NULL DEFAULT (''),
) ON [PRIMARY]

CREATE NONCLUSTERED INDEX [IX_pt_id] ON [product_type] ([ptid] ASC);
CREATE NONCLUSTERED INDEX [IX_pt_name] ON [product_type] ([ptname] ASC,[ptename] ASC);
CREATE NONCLUSTERED INDEX [IX_pt_hidden] ON [product_type] ([pthidden] ASC);
GO

IF OBJECT_ID('[reseller_config]') IS NOT NULL DROP TABLE [reseller_config]
GO

CREATE TABLE [reseller_config] (
	[rcid] [int] IDENTITY(1,1) NOT NULL CONSTRAINT [PK_reseller_config] PRIMARY KEY  CLUSTERED ([rcid])  ON [PRIMARY],
	[uid] [int] NOT NULL DEFAULT (0),
	[rctype] [int] NOT NULL DEFAULT (0),
	[rcname] [varchar](100) NOT NULL DEFAULT (''),
	[rcvalue] [nvarchar](4000) NOT NULL DEFAULT (''),
	[rcstatus] [int] NOT NULL DEFAULT (0),
) ON [PRIMARY]
CREATE NONCLUSTERED INDEX [IX_rc_int] ON [reseller_config] ([uid] ASC,[rctype] ASC,[rcstatus] ASC);
CREATE NONCLUSTERED INDEX [IX_rc_name] ON [reseller_config] ([rcname] ASC);
GO

IF OBJECT_ID('[gift_card]') IS NOT NULL DROP TABLE [gift_card]
GO

CREATE TABLE [gift_card] (
	[gid] [int] IDENTITY(1,1) NOT NULL CONSTRAINT [PK_gift_card] PRIMARY KEY CLUSTERED ([gid]) ON [PRIMARY],
	[gnumber] [int] NOT NULL DEFAULT (0),
	[gcode] [varchar](50) NOT NULL DEFAULT (''),
	[gamount] [float] NOT NULL DEFAULT (0),
	[guid] [int] NOT NULL DEFAULT (0),
	[stime] [int] NOT NULL DEFAULT (0),
	[etime] [int] NOT NULL DEFAULT (0),
	[gstatus] [int] NOT NULL DEFAULT (0),
	[gconfig] [nvarchar](1000) NOT NULL DEFAULT (''),
) ON [PRIMARY]
CREATE NONCLUSTERED INDEX [IX_gift_card_int] ON [gift_card] ([gnumber] ASC,[guid] ASC,[gstatus] ASC);
CREATE NONCLUSTERED INDEX [IX_gift_card_time] ON [gift_card] ([stime] ASC,[etime] ASC);
GO

IF OBJECT_ID('[transaction_list]') IS NOT NULL DROP TABLE [transaction_list]
GO

CREATE TABLE [transaction_list] (
	[tid] [int] IDENTITY(1,1) NOT NULL CONSTRAINT [PK_transaction_list] PRIMARY KEY CLUSTERED ([tid]) ON [PRIMARY],
	[suid] [int] NOT NULL DEFAULT (0),
	[tuid] [int] NOT NULL DEFAULT (0),
	[ttype] [int] NOT NULL DEFAULT (0),
	[id] [int] NOT NULL DEFAULT (0),
	[tamount] [float] NOT NULL DEFAULT (0),
	[stime] [int] NOT NULL DEFAULT (0),
	[etime] [int] NOT NULL DEFAULT (0),
	[tstatus] [int] NOT NULL DEFAULT (0),
	[tconfig] [nvarchar](4000) NOT NULL DEFAULT (''),
) ON [PRIMARY]
CREATE NONCLUSTERED INDEX [IX_transaction_list_int] ON [transaction_list] ([suid] ASC,[tuid] ASC,[ttype] ASC,[id] ASC,[tstatus] ASC);
CREATE NONCLUSTERED INDEX [IX_transaction_list_time] ON [transaction_list] ([stime] ASC,[etime] ASC);
GO

IF OBJECT_ID('[report_list]') IS NOT NULL DROP TABLE [report_list]
GO

CREATE TABLE [report_list] (
	[rid] [int] IDENTITY(1,1) NOT NULL CONSTRAINT [PK_report_list] PRIMARY KEY CLUSTERED ([rid]) ON [PRIMARY],
	[rtype] [int] NOT NULL DEFAULT (0),
	[rsubtype] [int] NOT NULL DEFAULT (0),
	[rtime] [int] NOT NULL DEFAULT (0),
	[extfield1] [float] NOT NULL DEFAULT (0),
	[extfield2] [float] NOT NULL DEFAULT (0),
	[extfield3] [float] NOT NULL DEFAULT (0),
	[extfield4] [float] NOT NULL DEFAULT (0),
	[extfield5] [float] NOT NULL DEFAULT (0),
	[rconfig] [nvarchar](4000) NOT NULL DEFAULT (''),
) ON [PRIMARY]
CREATE NONCLUSTERED INDEX [IX_report_list_type] ON [report_list] ([rtype] ASC,[rsubtype] ASC);
CREATE NONCLUSTERED INDEX [IX_report_list_time] ON [report_list] ([rtime] ASC);
CREATE NONCLUSTERED INDEX [IX_report_list_extfield] ON [report_list] ([extfield1] ASC,[extfield2] ASC,[extfield3] ASC,[extfield4] ASC,[extfield5] ASC);
GO

IF OBJECT_ID('[attachment_list]') IS NOT NULL DROP TABLE [attachment_list]
GO

CREATE TABLE [attachment_list] (
	[aid] [int] IDENTITY(1,1) NOT NULL CONSTRAINT [PK_attachment_list] PRIMARY KEY CLUSTERED ([aid]) ON [PRIMARY],
	[atype] [int] NOT NULL DEFAULT (0),
	[asid] [int] NOT NULL DEFAULT (0),
	[aname] [nvarchar](50) NOT NULL DEFAULT (''),
	[aurl] [varchar](255) NOT NULL DEFAULT (''),
	[atime] [int] NOT NULL DEFAULT (0),
	[extfield1] [int] NOT NULL DEFAULT (0),
	[extfield2] [int] NOT NULL DEFAULT (0),
	[extfield3] [int] NOT NULL DEFAULT (0),
	[aconfig] [nvarchar](1000) NOT NULL DEFAULT (''),
) ON [PRIMARY]
CREATE NONCLUSTERED INDEX [IX_attachment_list_type_sid] ON [attachment_list] ([atype] ASC,[asid] ASC);
CREATE NONCLUSTERED INDEX [IX_attachment_list_time] ON [attachment_list] ([atime] ASC);
CREATE NONCLUSTERED INDEX [IX_attachment_list_extfield] ON [attachment_list] ([extfield1] ASC,[extfield2] ASC,[extfield3] ASC);
GO

IF OBJECT_ID('[is_tracker_list]') IS NOT NULL DROP TABLE [is_tracker_list]
GO

CREATE TABLE [is_tracker_list] (
	[tid] [int] IDENTITY(1,1) NOT NULL CONSTRAINT [PK_is_tracker_list] PRIMARY KEY  CLUSTERED ([tid] ASC)  ON [PRIMARY],
	[uid] [int] NOT NULL DEFAULT (0),
	[sid] [int] NOT NULL DEFAULT (0),
	[tip] [varchar](50) NOT NULL DEFAULT (''),
	[tdes] [nvarchar](255) NOT NULL DEFAULT (''),
	[ttime] [int] NOT NULL DEFAULT (0),
	[tdatetime] [smalldatetime] NOT NULL DEFAULT (getdate()),
) ON [PRIMARY]
CREATE NONCLUSTERED INDEX [IX_is_tracker_list_id] ON [is_tracker_list] ([uid] ASC,[sid] ASC);
CREATE NONCLUSTERED INDEX [IX_is_tracker_list_ip] ON [is_tracker_list] ([tip] ASC);
CREATE NONCLUSTERED INDEX [IX_is_tracker_list_des] ON [is_tracker_list] ([tdes] ASC);
CREATE NONCLUSTERED INDEX [IX_is_tracker_list_time] ON [is_tracker_list] ([ttime] ASC);
GO

insert into [utype_list] (utype,tname,tprice,tbalance,uttype,utconfig) values ('10','管理员','1',0,10,'{"mall":"1","delservice":"0","api":"0"}');
insert into [utype_list] (utype,tname,tprice,tbalance,uttype,utconfig) values ('0','普通用户','1',0,0,'{"delservice":"-1","api":"-1"}');

insert into [product_type] (ptid,ptname,ptename) values (1,'VPS主机','VPS');
insert into [product_type] (ptid,ptname,ptename) values (2,'虚拟主机','Vhost');
insert into [product_type] (ptid,ptname,ptename) values (3,'域名注册','Domain');
insert into [product_type] (ptid,ptname,ptename) values (4,'服务器租用','Server');
insert into [product_type] (ptid,ptname,ptename) values (5,'服务器托管','Colo');
insert into [product_type] (ptid,ptname,ptename) values (6,'其它产品','Other');

/* System */
insert into [sys_config] (cname,cvalue,ctype) values ('idcname','CloudGoing',0);
insert into [sys_config] (cname,cvalue,ctype) values ('homepage','WWW.CloudGoing.Com',0);
insert into [sys_config] (cname,cvalue,ctype) values ('idcmail','service@email.com',0);
insert into [sys_config] (cname,cvalue,ctype) values ('smtp','{"password":"","username":"smtp@gmail.com","port":"25","host":"smtp.gmail.com","enablessl":"1"}',0);
insert into [sys_config] (cname,cconfig,ctype) values ('notification','{"sms_signature":"云系统","sms_service_renew":"0","email_admin_login":"0","sms_service_del":"0","sms_admin_login":"0","email_service_del":"1","email_service_renew":"1"}',0);
insert into [sys_config] (cname,cvalue,ctype) values ('tp_path','{"frontend_cache":"0","frontend":"/files/templates/frontend/default/","frontend_pages":"html/","backend_cache":"0","frontend_theme_id":"0","backend_theme_id":"0","backend":"/files/templates/backend/default/"}',0);
insert into [sys_config] (cname,cvalue,ctype) values ('apikey','',0);
insert into [sys_config] (cname,cvalue,ctype) values ('clientid','',0);
insert into [sys_config] (cname,cvalue,ctype) values ('hostkey','',0);
insert into [sys_config] (cname,cvalue,ctype) values ('homepage_url','{"mode":"0","url":""}',0);
insert into [sys_config] (cname,cvalue,ctype) values ('license','{"acid":"","code":""}',0);
insert into [sys_config] (cname,cvalue,ctype) values ('site_status','{"status":"0","msg":"系统维护中，请稍候重试！"}',0);
insert into [sys_config] (cname,ctype) values ('idcmobile',0);
insert into [sys_config] (cname,cvalue) values ('sms',0);
insert into [sys_config] (cname,ctype,cvalue,cconfig) values ('access_control',0,'{"vcode_color3":"#d22000","vcode_color2":"#0060ca","verification_manual":"0","vcode_color1":"#b3d7ff","vcode_resetps_sms":"1","vcode_resetps_email":"1","vcode_reg_sms":"1","vcode_length":"5","vcode_font":"Verdana","vcode_login_graph":"0","verification_order":"0","vcode_reg_email":"1","vcode_fontsize":"12","verification_login":"0","vcode_color0":"#ffffff","vcode_reg_graph":"1"}','{"ip_blacklist":""}');
insert into [sys_config] (cname,ctype) values ('username_blacklist',0);
insert into [sys_config] (cname,ctype) values ('sys_check_update',0);
insert into [sys_config] (cname,ctype) values ('referral',0);
insert into [sys_config] (cname,ctype) values ('backup_setting',5);
insert into [sys_config] (cname,ctype) values ('support_ticket_setting',5);
insert into [sys_config] (cname,ctype) values ('user_extfield_setting',0);
insert into [sys_config] (cname,ctype,cvalue) values ('ntp_setting',0,'{"server":"pool.ntp.org","time":"'+CONVERT(varchar(100), GETDATE(), 20)+'"}');


/* function setting */
insert into [sys_config] (sname,cname,cvalue,ctype,cconfig) values('支付宝','enabled','{"module":"/modules/payment/AliPay/","encryption_key":""}',1,'{"Email":"支付宝邮件帐号","PartnerID":"合作身份IDPartnerID","Key":"密钥Key"}');
insert into [sys_config] (cname,ctype,cconfig) values ('news_type',5,'{"nt_1":"系统公告"}');
insert into [sys_config] (cname,ctype,cconfig) values ('support_department',5,'{"dpid_0":"0","dpname_0":"售后部门","dpmember_0":"","dpshow_0":"0","dpsend_0":"0"}');
insert into [sys_config] (sname,cname,ctype,cvalue,cconfig,cstatus) values ('默认风格主题','default','10','{"path":"/files/templates/frontend/default/","pages":"html/"}','',1);
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cconfig,cstatus,corder,extfield2) values ('默认后台风格主题','default','{"path":"/files/templates/backend/default/","version":"1.0","mtag":"Default","files":""}','默认后台风格主题',4,'{"page_footer":"&lt;p&gt;全球领先的IDC综合业务管理平台，云计算管理平台创领者&lt;/p&gt;&lt;p&gt;Copyright &amp;copy;&amp;nbsp;CloudGoing 2011-{＄idcsystem_year}.All rights reserved. Powered by &lt;a class=&quot;pagelink&quot; href=&quot;http://www.cloudgoing.com/products/idcsystem&quot; target=&quot;_blank&quot;&gt;IDCSystem Ver {＄idcsystem_version} Platform&lt;/a&gt;&lt;/p&gt;","idcsystem_footer":"&lt;p&gt;Powered By &lt;a href=&quot;http://www.cloudgoing.com/products/idcsystem/&quot; target=&quot;_blank&quot;&gt;IDCSystem&amp;nbsp;&lt;/a&gt;&amp;nbsp;Ver {＄idcsystem_version}　Copyright &amp;copy;&amp;nbsp;&lt;a href=&quot;http://www.cloudgoing.com/&quot; target=&quot;_blank&quot;&gt;CloudGoing Inc.&lt;/a&gt;&amp;nbsp;2011 ~ {＄idcsystem_year} All Rights Reserved.&lt;/p&gt;"}',1,0,0);
update [sys_config] set cvalue=replace(cvalue,'"frontend_theme_id":"0"','"frontend_theme_id":"'+convert(varchar,(select top 1 cid from [sys_config] where ctype=10 order by cid asc),10)+'"') where cname='tp_path' and ctype=0;
update [sys_config] set cvalue=replace(cvalue,'"backend_theme_id":"0"','"backend_theme_id":"'+convert(varchar,(select top 1 cid from [sys_config] where ctype=4 order by cid asc),10)+'"') where cname='tp_path' and ctype=0;

/*Top Menu*/
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('进入后台管理','none','{"url":"javascript:adminLogin(0)；","target":"_self","area":"1"}','',6,2,1,0);
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('返回客户前台','none','{"url":"?","target":"_self","area":"2"}','',6,2,2,0);
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('功能快捷菜单','none','{"url":"javascript:；","target":"_self","area":"0"}','',6,0,3,1);
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('个人帐户资料管理','none','{"url":"?c=userinfo","target":"_self","area":"0"}','功能快捷菜单',6,0,1,0);
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('管理我的产品服务','none','{"url":"?c=myservice","target":"_self","area":"0"}','功能快捷菜单',6,0,2,0);
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('在线充值财务管理','none','{"url":"?c=finance","target":"_self","area":"0"}','功能快捷菜单',6,0,3,0);
update [sys_config] set extfield1=(select cid from [sys_config] where sname='功能快捷菜单' and ctype=6) where cdes='功能快捷菜单' and ctype=6;
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('在线QQ客服','none','{"url":"javascript:；","target":"_self","area":"0"}','',6,0,4,1);
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('客服QQ:12345678','none','{"url":"http:\/\/wpa.qq.com\/msgrd?v=3&uin=12345678&site=qq&menu=yes","target":"_blank","area":"0"}','在线QQ客服',6,0,1,0);
update [sys_config] set extfield1=(select cid from [sys_config] where sname='在线QQ客服' and ctype=6) where cdes='在线QQ客服' and ctype=6;
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('售后服务工单','none','{"url":"?c=tklist","target":"_self","area":"0"}','',6,0,5,1);
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('我的服务工单(Ticket)','none','{"url":"?c=tklist","target":"_self","area":"0"}','售后服务工单',6,0,1,0);
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('提交新的工单(Ticket)','none','{"url":"?c=tklist&submit=yes","target":"_self","area":"0"}','售后服务工单',6,0,2,0);
update [sys_config] set extfield1=(select cid from [sys_config] where sname='售后服务工单' and ctype=6) where cdes='售后服务工单' and ctype=6;
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('代理商专区','none','{"url":"javascript:；","target":"_self","area":"0"}','',6,1,6,1);
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('代理商系统设置','none','{"url":"?c=rconfig","target":"_self","area":"0"}','代理商专区',6,1,1,0);
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('代理子用户管理','none','{"url":"?c=rmuser","target":"_self","area":"0"}','代理商专区',6,1,2,0);
update [sys_config] set extfield1=(select cid from [sys_config] where sname='代理商专区' and ctype=6) where cdes='代理商专区' and ctype=6;
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('用户使用教程','none','{"url":"javascript:；","target":"_self","area":"0"}','',6,0,7,1);
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('IDCSystem使用教程','none','{"url":"http:\/\/wiki.cloudgoing.com\/idcsystem\/index.html","target":"_blank","area":"0"}','用户使用教程',6,0,1,0);
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('IDCSystem技术交流论坛','none','{"url":"http:\/\/www.chinahost.org\/list-81-1.html","target":"_blank","area":"0"}','用户使用教程',6,0,2,0);
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('XenSystem使用教程','none','{"url":"http:\/\/wiki.cloudgoing.com\/xensystem\/index.html","target":"_blank","area":"0"}','用户使用教程',6,0,3,0);
update [sys_config] set extfield1=(select cid from [sys_config] where sname='用户使用教程' and ctype=6) where cdes='用户使用教程' and ctype=6;
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('网站首页','none','{"url":"\/","target":"_blank","area":"0"}','',6,0,8,0);


/*User Left Menu*/
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('用户中心首页','none','{"url":"?","target":"_self","area":"1"}','',7,0,1,0);
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('账户资料管理','none','{"url":"?c=userinfo","target":"_self","area":"0"}','',7,0,2,0);
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('账务管理与充值','none','{"url":"?c=finance","target":"_self","area":"0"}','',7,0,3,0);
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('管理我的产品服务','none','{"active":"1","url":"javascript:；","target":"_self","area":"0"}','',7,0,4,1);
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('管理我的所有服务','serviceList','{"url":"?c=myservice","target":"_self","area":"0"}','管理我的产品服务',7,0,1,0);
update [sys_config] set extfield1=(select cid from [sys_config] where sname='管理我的产品服务' and ctype=7) where cdes='管理我的产品服务' and ctype=7;
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('购买新的产品服务','orderLink','{"url":"javascript:；","target":"_self","area":"0"}','',7,0,5,0);
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('帐户升级享受优惠','none','{"url":"?c=ut","target":"_self","area":"0"}','',7,0,6,0);
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('推介下线链接赚钱','ureferral','{"url":"?c=referral","target":"_self","area":"0"}','',7,3,7,0);
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('安全退出系统','none','{"url":"?c=logout","target":"_self","area":"0"}','',7,0,8,0);


/*Admin Left Menu*/
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('后台管理首页','none','{"url":"?c=admin","target":"_self","area":"2"}','',8,2,1,0);
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('客户服务管理中心','none','{"url":"javascript:；","target":"_self","area":"2"}','',8,2,2,1);
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('用户工单(Ticket)管理','amenu mticket','{"url":"?c=mticket","target":"_self","area":"2"}','客户服务管理中心',8,2,1,0);
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('群发短信邮件通知','amenu mnotice','{"url":"?c=mnotice","target":"_self","area":"2"}','客户服务管理中心',8,2,2,0);
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('客户服务功能设置','amenu msupport','{"url":"?c=msupport","target":"_self","area":"2"}','客户服务管理中心',8,2,3,0);
update [sys_config] set extfield1=(select cid from [sys_config] where sname='客户服务管理中心' and ctype=8) where cdes='客户服务管理中心' and ctype=8;
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('系统文章内容管理','amenu mnews','{"url":"?c=mnews","target":"_self","area":"2"}','',8,2,3,0);
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('产品配置与营销设置','none','{"url":"javascript:；","target":"_self","area":"2"}','',8,2,4,1);
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('产品配置与管理','amenu mproducts','{"url":"?c=mproducts","target":"_self","area":"2"}','产品配置与营销设置',8,2,1,0);
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('优惠码与促销管理','amenu mcoupon','{"url":"?c=mcoupon","target":"_self","area":"2"}','产品配置与营销设置',8,2,2,0);
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('推介下线返现管理','amenu mreferral','{"url":"?c=mreferral","target":"_self","area":"2"}','产品配置与营销设置',8,2,3,0);
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('充值(礼品)卡管理','amenu mgiftcard','{"url":"?c=mgiftcard","target":"_self","area":"2"}','产品配置与营销设置',8,2,4,0);
update [sys_config] set extfield1=(select cid from [sys_config] where sname='产品配置与营销设置' and ctype=8) where cdes='产品配置与营销设置' and ctype=8;
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('用户及其服务管理','none','{"url":"javascript:；","target":"_self","area":"2"}','',8,2,5,1);
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('用户产品服务管理','amenu mservice','{"url":"?c=mservice","target":"_self","area":"2"}','用户及其服务管理',8,2,1,0);
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('用户帐号资料管理','amenu muser','{"url":"?c=muser","target":"_self","area":"2"}','用户及其服务管理',8,2,2,0);
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('用户分组级别管理','amenu mut','{"url":"?c=mut","target":"_self","area":"2"}','用户及其服务管理',8,2,3,0);
update [sys_config] set extfield1=(select cid from [sys_config] where sname='用户及其服务管理' and ctype=8) where cdes='用户及其服务管理' and ctype=8;
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('财务与运营数据管理','none','{"url":"javascript:；","target":"_self","area":"2"}','',8,2,6,1);
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('数据报表分析管理','amenu mreports','{"url":"javascript:；","target":"_self","area":"2"}','财务与运营数据管理',8,2,1,1);
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('用户数据报表分析','none','{"url":"?c=mreports&r=user","target":"_self","area":"2"}','数据报表分析管理',8,2,1,0);
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('财务收入报表分析','none','{"url":"?c=mreports&r=finance","target":"_self","area":"2"}','数据报表分析管理',8,2,2,0);
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('产品服务数据分析','none','{"url":"?c=mreports&r=service","target":"_self","area":"2"}','数据报表分析管理',8,2,3,0);
update [sys_config] set extfield1=(select cid from [sys_config] where sname='数据报表分析管理' and ctype=8) where cdes='数据报表分析管理' and ctype=8;
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('用户账务记录查询','amenu mplog','{"url":"?c=mplog","target":"_self","area":"2"}','财务与运营数据管理',8,2,2,0);
update [sys_config] set extfield1=(select cid from [sys_config] where sname='财务与运营数据管理' and ctype=8) where cdes='财务与运营数据管理' and ctype=8;
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('功能模块与插件管理','none','{"url":"javascript:；","target":"_self","area":"2"}','',8,2,7,1);
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('产品模型设置管理','amenu mpmodule','{"url":"?c=mmodules&mt=product","target":"_self","area":"2"}','功能模块与插件管理',8,2,1,0);
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('支付方式设置管理','amenu mpayment','{"url":"?c=mmodules&mt=payment","target":"_self","area":"2"}','功能模块与插件管理',8,2,2,0);
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('功能应用插件管理','amenu mjsplugin','{"url":"?c=mmodules&mt=plugin","target":"_self","area":"2"}','功能模块与插件管理',8,2,3,0);
update [sys_config] set extfield1=(select cid from [sys_config] where sname='功能模块与插件管理' and ctype=8) where cdes='功能模块与插件管理' and ctype=8;
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('风格模板与界面管理','none','{"url":"javascript:；","target":"_self","area":"2"}','',8,2,8,1);
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('系统导航菜单管理','amenu mmenu','{"url":"?c=mmenu","target":"_self","area":"2"}','风格模板与界面管理',8,2,1,0);
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('后台风格模板管理','amenu mbtheme','{"url":"?c=mbtheme","target":"_self","area":"2"}','风格模板与界面管理',8,2,2,0);
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('销售前台模板管理','amenu mftheme','{"url":"?c=mftheme","target":"_self","area":"2"}','风格模板与界面管理',8,2,3,0);
update [sys_config] set extfield1=(select cid from [sys_config] where sname='风格模板与界面管理' and ctype=8) where cdes='风格模板与界面管理' and ctype=8;
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('系统基本功能管理','none','{"url":"javascript:；","target":"_self","area":"2"}','',8,2,9,1);
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('系统基本参数设置','amenu mconfig','{"url":"?c=mconfig&mt=base","target":"_self","area":"2"}','系统基本功能管理',8,2,1,0);
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('邮件短信功能设置','amenu mconfig','{"url":"?c=mconfig&mt=sender","target":"_self","area":"2"}','系统基本功能管理',8,2,2,0);
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('系统日志分析管理','amenu mlog','{"url":"?c=mlog","target":"_self","area":"2"}','系统基本功能管理',8,2,3,0);
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('系统日常数据清理','amenu mclear','{"url":"?c=mclear","target":"_self","area":"2"}','系统基本功能管理',8,2,4,0);
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('刷新系统数据缓存','none','{"url":"?c=ctc","target":"_self","area":"2"}','系统基本功能管理',8,2,5,0);
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('系统数据备份管理','amenu mbackup','{"url":"?c=mbackup","target":"_self","area":"2"}','系统基本功能管理',8,2,6,0);
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('系统在线更新升级','amenu update','{"url":"?c=update","target":"_self","area":"2"}','系统基本功能管理',8,2,7,0);
update [sys_config] set extfield1=(select cid from [sys_config] where sname='系统基本功能管理' and ctype=8) where cdes='系统基本功能管理' and ctype=8;
insert into [sys_config] (sname,cname,cvalue,cdes,ctype,cstatus,corder,extfield2) values ('安全退出系统','none','{"url":"?c=logout","target":"_self","area":"2"}','',8,2,10,0);

update [sys_config] set cdes='' where cdes<>'' and ctype in (6,7,8);

/* sms&email template*/
insert into [sys_config] (sname,cname,cvalue,ctype,cconfig,cstatus) values ('操作短信验证','sms_verify','{"sendername":"IDCSystem"}',9,'{"smsType":"vCode","signature":"{＄sms_signature}","vCode":"{＄verification_code}"}',1);
insert into [sys_config] (sname,cname,cvalue,ctype,cconfig,cstatus) values ('管理员登陆通知。','sms_admin_login','{"sendername":"IDCSystem"}',9,'{"smsType":"loginNotice","signature":"{＄sms_signature}","username":"{＄user_name}","time":"{＄time}","domain":"{＄domain}","ip_address":"{＄ip_address}"}',1);
insert into [sys_config] (sname,cname,cvalue,ctype,cconfig,cstatus) values ('服务续费短信通知','sms_renew','{"sendername":"IDCSystem"}',9,'{"smsType":"renewalNotice","signature":"{＄sms_signature}","serviceID":"{＄service_id}","time":"{＄due_date}","domain":"{＄idc_homepage}","ptName":"{＄pt_name}"}',1);
insert into [sys_config] (sname,cname,cvalue,ctype,cconfig,cstatus) values ('服务删除短信通知','sms_renew_failed','{"sendername":"IDCSystem"}',9,'{"smsType":"removeNotice","signature":"{＄sms_signature}","serviceID":"{＄service_id}","domain":"{＄idc_homepage}","ptName":"{＄pt_name}"}',1);

insert into [sys_config] (sname,cname,cvalue,ctype,cconfig,cstatus) values ('欢迎使用{＄idc_name}服务！','mail_reg','{"sendername":"IDCSystem","ishtml":"1"}',9,'<p>请牢记您在{＄idc_name}的以下信息：<br/>用户编号：{＄user_id}<br/>用户名称：{＄user_name}<br/>登陆密码：******（安全隐藏）<br/>电子邮箱：{＄user_mail}<br/>------------------------------------------<br/>客服邮箱：{＄idc_mail}<br/>网站地址：http://{＄idc_homepage}</p>',1);
insert into [sys_config] (sname,cname,cvalue,ctype,cconfig,cstatus) values ('操作验证码 - {＄user_mail}','mail_verify','{"sendername":"IDCSystem","ishtml":"1"}',9,'<p>您的邮箱地址：{＄user_mail}，本次操作验证码是：{＄verification_code}</p> <p>------------------------------------------<br/>客服邮箱：{＄idc_mail}<br/>网站地址：http://{＄idc_homepage}</p>',1);
insert into [sys_config] (sname,cname,cvalue,ctype,cconfig,cstatus) values ('您在{＄idc_name}的API密钥！','mail_apikey','{"sendername":"IDCSystem","ishtml":"1"}',9,'<p>您好：<br/>您在{＄idc_name}控制平台的API密钥为：{＄apikey}<br/>(鉴于API密钥的权限重要性，请务必妥善保管好此密钥)<br/> <br/>------------------------------------------<br/>客服邮箱：{＄idc_mail}<br/>网站地址：http://{＄idc_homepage}</p>',1);
insert into [sys_config] (sname,cname,cvalue,ctype,cconfig,cstatus) values ('服务#{＄service_id}续费通知！请尽快续费','mail_renew','{"sendername":"IDCSystem","ishtml":"1"}',9,'<p>您在{＄idc_name}的产品服务#{＄service_id} {＄service_name}将于{＄due_date}到期！<br/>如果您设置的是自动续费，请在此日期前确保您帐户余额大于续费所需金额：{＄service_price}元，以备系统进行自动续费！<br/>如果您是手动续费：请登陆 http://{＄idc_homepage}/ 相关管理页面进行手动续费！<br/> <br/>-----------------------------<br/>服务管理：http://{＄domain}/process.aspx?c=go&url=%3fc%3dmyservice%26id%3d{＄service_id} <br/>客服邮箱：{＄idc_mail} <br/>网站地址：http://{＄idc_homepage}</p>',1);
insert into [sys_config] (sname,cname,cvalue,ctype,cconfig,cstatus) values ('产品服务#{＄service_id}过期删除通知！','mail_renew_failed','{"sendername":"IDCSystem","ishtml":"1"}',9,'<p>您在{＄idc_name}的产品服务#{＄service_id} {＄service_name}已于{＄due_date}到期。<br/>请立即登陆 http://{＄idc_homepage}/ 相关管理页面进行手动续费，所需金额：{＄service_price}元。<br/>逾期未续费系统将作自动删除处理，再次请您尽快进行续费。<br/> <br/>-----------------------------<br/>服务管理：http://{＄domain}/process.aspx?c=go&url=%3fc%3dmyservice%26id%3d{＄service_id} <br/>客服邮箱：{＄idc_mail} <br/>网站地址：http://{＄idc_homepage}</p>',1);
insert into [sys_config] (sname,cname,cvalue,ctype,cconfig,cstatus) values ('{＄ticket_title}','mail_ticket','{"sendername":"IDCSystem","ishtml":"1"}',9,'<p>{＄ticket_content}<br/> <br/>-------------------------------------<br/>工单(Ticket)地址：{＄ticket_url}<br/>请登陆和管理系统处理相关问题或与我们联系获得帮助。<br/> <br/>本邮件为系统自动通知，请勿直接回复！<br/>------------------------------------------<br/>客服邮箱：{＄idc_mail} <br/>网站地址：http://{＄idc_homepage}</p>',1);
insert into [sys_config] (sname,cname,cvalue,ctype,cconfig,cstatus) values ('后台管理登陆提示！','mail_admin_login','{"sendername":"IDCSystem","ishtml":"1"}',9,'<p>{＄user_name} 于{＄date} {＄time}登陆 http://{＄domain} 管理后台，登陆IP：{＄ip_address}。</p>',1);
insert into [sys_config] (sname,cname,cvalue,ctype,cconfig,cstatus) values ('{＄bulk_mail_title}','mail_bulk','{"sendername":"ID System","ishtml":"1"}',9,'<p>{＄bulk_mail_content}<br/> <br/>------------------------------------<br/><strong>{＄idc_name}</strong><br/>http://{＄idc_homepage}/</p>',1);
insert into [sys_config] (sname,cname,cvalue,ctype,cconfig,cstatus) values ('用户订单通知！','mail_order_notice','{"sendername":"IDCSystem","ishtml":"1"}',9,'<p>用户编号：{$user_id}<br />用户名称：{$user_name}<br />产品服务：{$service_name}<br />购买价格：{$service_price}<br />服务编号：{$service_id}<br />购买时间：{$date} {$time}</p>',1);

insert into [sys_config] (cname,cvalue) values ('dversion','201503301200');
GO
