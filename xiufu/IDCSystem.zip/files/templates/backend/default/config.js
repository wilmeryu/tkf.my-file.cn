﻿/// <reference path="/files/js/jquery.min.js" />
var themeConfig = swin.find("#themeConfig");
var upWin;

function loadThemeConfig() {
    var configString = '<div id="params" style="padding-top:20px;">' +
                       insertFormItem('登陆页面设置', '', 'label', '', 0, '') +
                       insertFormItem('LOGO图片页面', 'page_logo.png', '', 'imgUpload', 0, '（推荐图片尺寸：97x70）') +
                       insertFormItem('页脚信息设置', 'page_footer', 'text', 'html', '500', '') +
                       insertFormItem('后台管理页面', '', 'label', '', 0, '') +
                       insertFormItem('LOGO图片页面', 'idcsystem_logo.png', '', 'imgUpload', 0, '（推荐图片尺寸：215x80）') +
                       insertFormItem('页脚信息设置', 'idcsystem_footer', 'text', 'html', '500', '') +
                       '</div>';


    configString += '<div id="upwin" style="display:none;text-align:center"><p><input type="button"  class="button" id="btn_upload" value="重新上传图片"/></p><p style="padding-top:5px"><a href="javascript:;" target="_blank"><img src="" alt="点击查看原始图片大小！" style="max-height:200px;max-width:650px;"/></a></p></div>';
    themeConfig.html(configString);
    upWin = themeConfig.find("#upwin");



    themeConfig.find('#params .button').click(function () {
        var cKey = $(this).attr("name");
        var bAction = cKey.substring(0, cKey.indexOf('_'));
        cKey = cKey.substring(cKey.indexOf('_') + 1);
        switch (bAction) {
            case 'htmledit':
                htmlEdit('input[name=config_' + cKey + ']', 0);
                break;
            case 'upload':
                uploadImgs(cKey);
                break;
        }
    });
}

loadThemeConfig();

function insertFormItem(label, cKey, iType, bType, iWidth, Des) {
    var configDataValue = configData[cKey] == undefined ? '' : configData[cKey];
    var _str = '<strong>' + label + '：</strong>';
    if (iType == 'label') return _str + '<br />'; //如果仅插件标签项

    switch (iType) {
        case "text":
            _str += '<input style="width:' + iWidth + 'px" type="text" class="text" value="' + configDataValue.replaceAll('；', ';') + '" name="config_' + cKey + '" />&nbsp;&nbsp;';
            break;
    }
    switch (bType) {
        case "html":
            _str += '<input type="button" class="button" value="可视化编辑" name="htmledit_' + cKey + '"/>';
            break;
        case "imgUpload":
            _str += '<input type="button" class="button" value="上传图片" name="upload_' + cKey + '"/>';
            break;
    }

    _str += '&nbsp;&nbsp;&nbsp;' + Des + '<br />';
    return _str;
}

var myUploader = initUploader(themeConfig.find("#btn_upload"), 1, false, function () {
    var imgPath = upWin.find("img").attr("src");
    if (imgPath.indexOf('?') > -1) imgPath = imgPath.substring(0, imgPath.indexOf('?'));
    imgPath += '?' + new Date();
    upWin.find("img").parent().attr("href", imgPath);
    upWin.find("img").attr("src", imgPath);
});

function uploadImgs(imgName) {
    var imgPath = swin.find("input[name='configvalue_path']").val() + 'images/' + imgName;
    myUploader.settings.headers.filepath = imgPath;
    imgPath += '?' + new Date();
    upWin.find("img").parent().attr("href", imgPath);
    upWin.find("img").attr("src", imgPath);
    upWin.dialog({ title: "上传图片", autoOpen: false, resizable: false, width: 700, height: 365, modal: true, buttons: { "确 定": function () { $(this).dialog("close"); } } }).dialog("open");
}