﻿/// <reference path="/files/js/jquery.min.js" />
var themeConfig = swin.find("#themeConfig");
var configData = configData;
var upWin;

function loadThemeConfig() {
    var str = '';
    var homeConfigs = $.parseJSON('{' +
    '"dom_home_title":{"l":"　　网站首页标题","t":"input","width":"520px","des":"","max":1,"data":"","df":"网站首页"},' +
    '"dom_cloud_title":{"l":"　云主机页面标题","t":"input","width":"520px","des":"","max":1,"data":"","df":"VPS云主机"},' +
    '"dom_vhost_title":{"l":"　　虚拟主机标题","t":"input","width":"520px","des":"","max":1,"data":"","df":"虚拟主机"},' +
    '"dom_server_title":{"l":"　服务器租用标题","t":"input","width":"520px","des":"","max":1,"data":"","df":"服务器租用"},' +
    '"dom_host_title":{"l":"　服务器托管标题","t":"input","width":"520px","des":"","max":1,"data":"","df":"服务器托管"},' +
    '"dom_domain_title":{"l":"域名注册页面标题","t":"input","width":"520px","des":"","max":1,"data":"","df":"域名注册"},' +
    '"dom_about_title":{"l":"关于我们页面标题","t":"input","width":"520px","des":"","max":1,"data":"","df":"关于我们"},' +

    '"logo":{"l":"LOGO设置：","t":"button","width":"130px","des":"","max":1,"data":"upImg","ImgName":"logo.png"},' +
    '"blogint1":{"l":"菜单名称","t":"input","width":"150px","des":"&nbsp;&nbsp;","max":1,"data":"","df":"用户中心","br":""},' +
    '"bloginu1":{"l":"链接地址","t":"input","width":"300px","des":"","max":1,"data":"","df":"process.aspx?c=go"},' +
    '"blogint2":{"l":"菜单名称","t":"input","width":"150px","des":"&nbsp;&nbsp;","max":1,"data":"","df":"产品服务管理","br":""},' +
    '"bloginu2":{"l":"链接地址","t":"input","width":"300px","des":"","max":1,"data":"","df":"process.aspx?c=go&url=?c=myservice"},' +
    '"blogint3":{"l":"菜单名称","t":"input","width":"150px","des":"&nbsp;&nbsp;","max":1,"data":"","df":"财务管理","br":""},' +
    '"bloginu3":{"l":"链接地址","t":"input","width":"300px","des":"","max":1,"data":"","df":"process.aspx?c=go&url=?c=finance"},' +
    '"blogint4":{"l":"菜单名称","t":"input","width":"150px","des":"&nbsp;&nbsp;","max":1,"data":"","df":"售后服务中心","br":""},' +
    '"bloginu4":{"l":"链接地址","t":"input","width":"300px","des":"","max":1,"data":"","df":"process.aspx?c=go&url=?c=tklist&submit=yes"},' +
    '"blogint5":{"l":"菜单名称","t":"input","width":"150px","des":"&nbsp;&nbsp;","max":1,"data":"","df":"联系我们","br":""},' +
    '"bloginu5":{"l":"链接地址","t":"input","width":"300px","des":"","max":1,"data":"","df":"about.html"},' +

    '"Font_Footer_pg":{"l":"页脚内容调用","t":"button","width":"60px","des":"","max":1,"data":"news","df":"0"},' +

    '"hb1img":{"l":"滚动广告图片[1]","t":"button","width":"130px","des":"","max":1,"data":"upImg","ImgName":"banner01.jpg","br":"s"},' +
    '"hb1url":{"l":"链接地址","t":"input","width":"330px","des":"","max":1,"data":"","br":"t","df":"javascript:;"},' +
    '"hb2img":{"l":"滚动广告图片[2]","t":"button","width":"130px","des":"","max":1,"data":"upImg","ImgName":"banner02.jpg","br":"s"},' +
    '"hb2url":{"l":"链接地址","t":"input","width":"330px","des":"","max":1,"data":"","br":"t","df":"javascript:;"},' +
    '"hb3img":{"l":"滚动广告图片[3]","t":"button","width":"130px","des":"","max":1,"data":"upImg","ImgName":"banner03.jpg","br":"s"},' +
    '"hb3url":{"l":"链接地址","t":"input","width":"330px","des":"","max":1,"data":"","br":"t"},' +
    '"hb4img":{"l":"滚动广告图片[4]","t":"button","width":"130px","des":"","max":1,"data":"upImg","ImgName":"banner04.jpg","br":"s"},' +
    '"hb4url":{"l":"链接地址","t":"input","width":"330px","des":"","max":1,"data":"","br":"t"},' +
    '"hb5img":{"l":"滚动广告图片[5]","t":"button","width":"130px","des":"","max":1,"data":"upImg","ImgName":"banner05.jpg","br":"s"},' +
    '"hb5url":{"l":"链接地址","t":"input","width":"330px","des":"","max":1,"data":"","br":"t"},' +

    '"hpt":{"l":"产品介绍标题","t":"input","width":"200px","des":"","max":1,"data":"","br":"s","df":"我们的产品"},' +
    '"home_Product_url":{"l":"[更多]链接地址","t":"input","width":"200px","des":"","max":1,"data":"","df":"javascript:;" },' +
    '"hpi1":{"l":"封面图片","t":"button","width":"130px","des":"（推荐图片尺寸：280x90）","max":1,"data":"upImg","ImgName":"I280x90_1.png","df":""},' +
    '"hpt1":{"l":"产品类型名称","t":"input","width":"500px","des":"","max":1,"data":""  },' +
    '"hpu1":{"l":"产品购买链接","t":"input","width":"500px","des":"","max":1 ,"data":"" },' +
    '"hpc1":{"l":"产品介绍描述","t":"input","width":"500px","height":"90px","des":"","max":54 ,"data":"" },' +
    '"hpi2":{"l":"封面图片","t":"button","width":"130px","des":"（推荐图片尺寸：280x90）","max":1,"data":"upImg","ImgName":"I280x90_2.png","df":""},' +
    '"hpt2":{"l":"产品类型名称","t":"input","width":"500px","des":"","max":1,"data":""  },' +
    '"hpu2":{"l":"产品购买链接","t":"input","width":"500px","des":"","max":1 ,"data":"" },' +
    '"hpc2":{"l":"产品介绍描述","t":"input","width":"500px","height":"90px","des":"","max":54 ,"data":"" },' +
    '"hpi3":{"l":"封面图片","t":"button","width":"130px","des":"（推荐图片尺寸：280x90）","max":1,"data":"upImg","ImgName":"I280x90_3.png","df":""},' +
    '"hpt3":{"l":"产品类型名称","t":"input","width":"500px","des":"","max":1,"data":""  },' +
    '"hpu3":{"l":"产品购买链接","t":"input","width":"500px","des":"","max":1 ,"data":"" },' +
    '"hpc3":{"l":"产品介绍描述","t":"input","width":"500px","height":"90px","des":"","max":54 ,"data":"" },' +
    '"hpi4":{"l":"封面图片","t":"button","width":"130px","des":"（推荐图片尺寸：280x90）","max":1,"data":"upImg","ImgName":"I280x90_4.png","df":""},' +
    '"hpt4":{"l":"产品类型名称","t":"input","width":"500px","des":"","max":1,"data":""  },' +
    '"hpu4":{"l":"产品购买链接","t":"input","width":"500px","des":"","max":1 ,"data":"" },' +
    '"hpc4":{"l":"产品介绍描述","t":"input","width":"500px","height":"90px","des":"","max":54 ,"data":"" },' +


    '"hsi":{"l":"服务封面图片","t":"button","width":"130px","des":"（推荐图片尺寸：400x318）","max":1,"data":"upImg","ImgName":"I400x318.jpg"},' +
    '"hst":{"l":"服务标题设置","t":"input","width":"200px","des":"","max":1,"data":"","br":"s","df":"我们的服务"},' +
    '"hsu":{"l":"[更多]链接地址","t":"input","width":"200px","des":"","max":1,"data":"","df":"javascript:void(0);"},' +
    '"hsn":{"l":"服务介绍详情","t":"button","width":"60px","des":"（文章内容建议在224个字符以内）","max":1,"data":"news","df":"0"},' +
    '"hsimg1":{"l":"特色图标[1]","t":"button","width":"130px","des":"（推荐图片尺寸：70x70，内容简介推荐在30个中文字符以内）","max":1,"data":"upImg","ImgName":"I70x70_1.png"},' +
    '"hst1":{"l":"特点标题[1]","t":"input","width":"500px","des":"","max":1,"data":"","df":""},' +
    '"hsc1":{"l":"内容简介[1]","t":"input","width":"500px","des":"","max":1 ,"data":"","df":""},' +
    '"hsimg2":{"l":"特色图标[2]","t":"button","width":"130px","des":"（推荐图片尺寸：70x70，内容简介推荐在30个中文字符以内）","max":1,"data":"upImg","ImgName":"I70x70_2.png"},' +
    '"hst2":{"l":"特点标题[2]","t":"input","width":"500px","des":"","max":1,"data":"","df":""},' +
    '"hsc2":{"l":"内容简介[2]","t":"input","width":"500px","des":"","max":1 ,"data":"","df":""},' +
    '"hsimg3":{"l":"特色图标[3]","t":"button","width":"130px","des":"（推荐图片尺寸：70x70，内容简介推荐在30个中文字符以内）","max":1,"data":"upImg","ImgName":"I70x70_3.png"},' +
    '"hst3":{"l":"特点标题[3]","t":"input","width":"500px","des":"","max":1,"data":"","df":""},' +
    '"hsc3":{"l":"内容简介[3]","t":"input","width":"500px","des":"","max":1 ,"data":"","df":""},' +
    '"hsimg4":{"l":"特色图标[4]","t":"button","width":"130px","des":"（推荐图片尺寸：70x70，内容简介推荐在30个中文字符以内）","max":1,"data":"upImg","ImgName":"I70x70_4.png"},' +
    '"hst4":{"l":"特点标题[4]","t":"input","width":"500px","des":"","max":1,"data":"","df":""},' +
    '"hsc4":{"l":"内容简介[4]","t":"input","width":"500px","des":"","max":1 ,"data":"","df":""},' +
    '"hsimg5":{"l":"特色图标[5]","t":"button","width":"130px","des":"（推荐图片尺寸：70x70，内容简介推荐在30个中文字符以内）","max":1,"data":"upImg","ImgName":"I70x70_5.png"},' +
    '"hst5":{"l":"特点标题[5]","t":"input","width":"500px","des":"","max":1,"data":"","df":""},' +
    '"hsc5":{"l":"内容简介[5]","t":"input","width":"500px","des":"","max":1 ,"data":"","df":""},' +


    '"fhnt":{"l":"文章动态主标题","t":"input","width":"200px","des":"","max":1,"data":"","df":"最新动态新闻","br":"s"},' +
    '"fhnurl":{"l":"[更多]链接地址","t":"input","width":"200px","des":"","max":1,"data":"" ,"df":"javascript:;"},' +
     '"fhntl":{"l":"左侧新闻栏标题","t":"input","width":"200px","des":"","max":1,"data":"","df":"行业动态","br":"s"},' +
     '"fhn_pg":{"l":"新闻栏内容调用","t":"button","width":"95px","des":"","max":1,"data":"newstype","df":"0"},' +
     '"fhntr":{"l":"右侧新闻栏标题","t":"input","width":"200px","des":"","max":1,"data":"","df":"热门新闻Hot~"},' +
    '"hnimg1":{"l":"文章封面图片","t":"button","width":"0px","des":"（推荐图片尺寸：180x143）","max":1,"data":"upImg","ImgName":"I180x143_1.jpg"},' +
    '"hnpg1":{"l":"文章调用内容","t":"button","width":"60px","des":"","max":1,"data":"news","df":"0"},' +
    '"hnimg2":{"l":"文章调用内容","t":"button","width":"0px","des":"（推荐图片尺寸：180x143）","max":1,"data":"upImg","ImgName":"I180x143_2.jpg"},' +
    '"hnpg2":{"l":"新闻调用内容","t":"button","width":"60px","des":"","max":1,"data":"news","df":"0"},' +
    '"hnimg3":{"l":"文章封面图片","t":"button","width":"0px","des":"（推荐图片尺寸：180x143）","max":1,"data":"upImg","ImgName":"I180x143_3.jpg"},' +
    '"hnpg3":{"l":"文章调用内容","t":"button","width":"60px","des":"","max":1,"data":"news","df":"0"},' +
    

    '"cpg":{"l":"允许显示的产品分组","t":"button","width":"278px","des":"","max":20,"data":"productgroup","df":"0"},' +
    '"cdpg":{"l":"默认显示的产品分组","t":"button","width":"278px","des":"","max":1,"data":"productgroup","df":"0"},' +
    '"cht":{"l":"右侧云主机介绍标题","t":"input","width":"380px","des":"","max":1,"data":"","df":"云主机产品介绍："},' +
    '"chpg":{"l":"右侧云主机介绍内容","t":"button","width":"195px","des":"","max":1,"data":"news","df":"0"},' +
    '"ccpu":{"l":"允许选择的CPU核心","t":"input","width":"380px","des":"例如(核)：1,2,4,6,8,12,16","max":1,"data":"","df":"1,2,4,6,8,10,12"},' +
    '"cnram":{"l":"允许选择的内存大小","t":"input","width":"380px","des":"例如(MB)：512,1024,2048","max":1,"data":"","df":"512,1024,2048,4096,8192"},' +
    '"cvdisk":{"l":"允许选择的存储大小","t":"input","width":"380px","des":"例如(GB)：10,30,50,100","max":1,"data":"" ,"df":"10,20,30,50,80,100,200"},' +
    '"cloudip":{"l":"允许选择的IP地址数","t":"input","width":"380px","des":"例如(个)：1,2,3,5,10","max":1,"data":"","df":"1,2,3,5,10"},' +
    '"cosl":{"l":"允许选择的Linux系统","t":"button","width":"370px","des":"","max":0,"data":"os","df":"0,CentOS|0,Debian|0,Ubuntu"},' +
    '"cosw":{"l":"允许选择的Windows系统","t":"button","width":"345px","des":"","max":0,"data":"os","df":"0,Windows 2003|0,Windows 2008|0,Windows 2012"},' +

    '"vhpg":{"l":"允许显示的产品分组","t":"button","width":"230px","des":"","max":3,"data":"productgroup","df":"0"},' +
    '"vdpg":{"l":"默认显示的产品分组","t":"button","width":"230px","des":"","max":1,"data":"productgroup","df":"0"},' +
    '"vhost_ico":{"l":"产品列表显示的图标","t":"button","width":"130px","des":"（推荐图片尺寸：180x130）","max":1,"data":"upImg","ImgName":"vhostPro.jpg"},' +
    '"vhdp":{"l":"右侧默认显示的产品","t":"button","width":"230px","des":"","max":1,"data":"product","df":"0"},' +
    '"vhtt":{"l":"右侧产品介绍栏标题","t":"input","width":"230px","des":"","max":1,"data":"","df":"虚拟主机产品介绍","br":"t"},' +
    '"vhtpg":{"l":"右侧介绍栏内容调用","t":"button","width":"230px","des":"","max":1,"data":"news","df":"0"},' +

    '"sfat":{"l":"产品特点介绍的标题","t":"input","width":"150px","des":"","max":1,"data":"","df":"产品.优势.特点","br":"s"},' +
    '"sfa":{"l":"介绍内容调用","t":"button","width":"60px","des":"","max":1,"data":"news","df":"0"},' +
    '"server_list_title":{"l":"产品配置列表的标题","t":"input","width":"150px","des":"","max":1,"data":"","df":"服务器租用产品","br":"s"},' +
    '"server_pgs":{"l":"显示产品分组","t":"button","width":"139px","des":"","max":10,"data":"productgroup","df":"0"},' + 
    '"sfpgt":{"l":"下方新闻内容栏标题","t":"input","width":"399px","des":"","max":1,"data":"","df":"服务器租用相关资讯","br":"t"},' +
    '"sfpg":{"l":"更多链接的文章分组","t":"button","width":"39px","des":"","max":1,"data":"newstype","br":"s","df":"0"},' +
    '"sfnpg":{"l":"链接的文章","t":"button","width":"50px","des":"","max":1,"data":"news","df":"0"},' +
    '"fsin1":{"l":"文章封面图片","t":"button","width":"150px","des":"（推荐图片尺寸：256x200）","max":1,"data":"upImg","ImgName":"S256x200_1.jpg"},' +
    '"fspgn1":{"l":"文章调用内容","t":"button","width":"60px","des":"","max":1,"data":"news","df":"0"},' +
    '"fsin2":{"l":"文章封面图片","t":"button","width":"150px","des":"（推荐图片尺寸：256x200）","max":1,"data":"upImg","ImgName":"S256x200_2.jpg"},' +
    '"fspgn2":{"l":"文章调用内容","t":"button","width":"60px","des":"","max":1,"data":"news","df":"0"},' +
    '"fsin3":{"l":"文章封面图片","t":"button","width":"150px","des":"（推荐图片尺寸：256x200）","max":1,"data":"upImg","ImgName":"S256x200_3.jpg"},' +
    '"fspgn3":{"l":"文章调用内容","t":"button","width":"60px","des":"","max":1,"data":"news","df":"0"},' +

    '"fHostAt":{"l":"产品特点介绍的标题","t":"input","width":"150px","des":"","max":1,"data":"","df":"产品.优势.特点 ","br":"s"},' +
    '"fHostA":{"l":"介绍内容调用","t":"button","width":"60px","des":"","max":1,"data":"news","df":"0"},' +
    '"colo_list_title":{"l":"产品配置列表的标题","t":"input","width":"150px","des":"","max":1,"data":"","df":"服务器托管产品","br":"s"},' +
    '"host_pgs":{"l":"显示产品分组","t":"button","width":"139px","des":"","max":10,"data":"productgroup","df":"0"},' +
    '"Hostnpgt":{"l":"下方新闻内容栏标题","t":"input","width":"399px","des":"","max":1,"data":"","df":"服务器托管相关资讯","br":"t"},' +
    '"fHostpg":{"l":"更多链接的文章分组","t":"button","width":"39px","des":"","max":1,"data":"newstype","br":"s","df":"0"},' +
    '"Hostnpg":{"l":"链接的文章","t":"button","width":"50px","des":"","max":1,"data":"news","df":"0"},' +
    '"Hostnpg1":{"l":"文章封面图片","t":"button","width":"150px","des":"（推荐图片尺寸：256x200）","max":1,"data":"upImg","ImgName":"H256x200_1.jpg"},' +
    '"Hostpg1":{"l":"文章调用内容","t":"button","width":"60px","des":"","max":1,"data":"news","df":"0"},' +
    '"Hostnpg2":{"l":"文章封面图片","t":"button","width":"150px","des":"（推荐图片尺寸：256x200）","max":1,"data":"upImg","ImgName":"H256x200_2.jpg"},' +
    '"Hostpg2":{"l":"文章调用内容","t":"button","width":"60px","des":"","max":1,"data":"news","df":"0"},' +
    '"Hostnpg3":{"l":"文章封面图片","t":"button","width":"150px","des":"（推荐图片尺寸：256x200）","max":1,"data":"upImg","ImgName":"H256x200_3.jpg"},' +
    '"Hostpg3":{"l":"文章调用内容","t":"button","width":"60px","des":"","max":1,"data":"news","df":"0"},' +

    '"domain_pid":{"l":"域名注册调用产品","t":"button","width":"139px","des":"","max":1,"data":"product","df":"0"},' +
    '"fdtt":{"l":"右侧产品说明标题","t":"input","width":"220px","des":"","max":1,"data":"","df":"域名产品介绍："},' +
    '"fdtpg":{"l":"产品说明内容调用","t":"button","width":"60px","des":"","max":1,"data":"news","df":"0"},' +

    '"about_news" :{"l":"左侧导航菜单调用","t":"button","width":"60px","des":"","max":1,"data":"newstype","df":"0"},' +
    '"Font_AboutD_pg":{"l":"默认展示内容调用","t":"button","width":"60px","des":"","max":1,"data":"news","df":"0"},' +

    '"newsron":{"l":"新闻中心列表显示的文章数","t":"input","width":"60px","des":"","max":1,"data":"","df":"10"}' +
    '}');

    var configDataValue = bltopurl = home = homebanner = homeProducts = homeser = homeNews = cloud = vhost = server = host = domain = aboutnews = p1 = p2 = p3 = p4 = s1 = s2 = s3 = s4 = s5 = hn1 = hn2 = hn3 = sn1 = sn2 = sn3 = on1 = on2 = on3 = title = yejiao = gywm = newspg = '';


    $.each(homeConfigs, function (key, value) {
        switch (key) {
            case "hb1img": case "hb2img": case "hb3img": case "hb4img": case "hb5img": case "hb1url":
            case "hb2url": case "hb3url": case "hb4url": case "hb5url": homebanner += createConfigshtml(key, value); break;
            case "hpt": case 'home_Product_url': homeProducts += createConfigshtml(key, value); break;
            case "blogint1": case "blogint2": case "blogint3": case "blogint4": case "blogint5":
            case "bloginu1": case "bloginu2": case "bloginu3": case "bloginu4": case "bloginu5": bltopurl += createConfigshtml(key, value); break;


            case "hpt1": case "hpc1": case "hpi1": case "hpu1": p1 += createConfigshtml(key, value); break;
            case "hpt2": case "hpc2": case "hpi2": case "hpu2": p2 += createConfigshtml(key, value); break;
            case "hpt3": case "hpc3": case "hpi3": case "hpu3": p3 += createConfigshtml(key, value); break;
            case "hpt4": case "hpc4": case "hpi4": case "hpu4": p4 += createConfigshtml(key, value); break;
            case "fhn_pg": case "fhnt": case "fhnurl": case "fhntl": case "fhntr": homeNews += createConfigshtml(key, value); break;
            case 'hnpg1': case "hnimg1": hn1 += createConfigshtml(key, value); break;
            case 'hnpg2': case "hnimg2": hn2 += createConfigshtml(key, value); break;
            case 'hnpg3': case "hnimg3": hn3 += createConfigshtml(key, value); break;
            case "hsi": case "hsn": case "hst": case "hsu": homeser += createConfigshtml(key, value); break;
            case "hsimg1": case "hst1": case "hsc1": s1 += createConfigshtml(key, value); break;
            case "hsimg2": case "hst2": case "hsc2": s2 += createConfigshtml(key, value); break;
            case "hsimg3": case "hst3": case "hsc3": s3 += createConfigshtml(key, value); break;
            case "hsimg4": case "hst4": case "hsc4": s4 += createConfigshtml(key, value); break;
            case "hsimg5": case "hst5": case "hsc5": s5 += createConfigshtml(key, value); break;
            case 'ccpu': case "cnram": case "cvdisk": case "cloudip": case 'cpg': case 'cdpg': case 'cosl': case 'cosw': case "cht": case 'chpg': cloud += createConfigshtml(key, value); break;
            case 'vdpg': case 'vhpg': case 'vhdp': case "vhtt": case "vhtpg": case "vhost_ico": vhost += createConfigshtml(key, value); break;
            case 'server_pgs': case "server_list_title": case "sfat": case "sfa": case "sfpgt": case 'sfpg': case 'sfnpg': server += createConfigshtml(key, value); break;
            case 'fspgn1': case 'fsin1': sn1 += createConfigshtml(key, value); break;
            case 'fspgn2': case 'fsin2': sn2 += createConfigshtml(key, value); break;
            case 'fspgn3': case 'fsin3': sn3 += createConfigshtml(key, value); break;
            case "host_pgs": case "colo_list_title": case "fHostAt": case "Hostnpgt": case "fHostA": case 'fHostpg': case 'Hostnpg': host += createConfigshtml(key, value); break;
            case 'Hostnpg1': case 'Hostpg1': on1 += createConfigshtml(key, value); break;
            case 'Hostnpg2': case 'Hostpg2': on2 += createConfigshtml(key, value); break;
            case 'Hostnpg3': case 'Hostpg3': on3 += createConfigshtml(key, value); break;
            case 'domain_pid': case "fdtt": case 'fdtpg': domain += createConfigshtml(key, value); break;
            case "logo": break;
            case "dom_home_title": case "dom_cloud_title": case "dom_vhost_title": case "dom_server_title":
            case "dom_host_title": case "dom_domain_title": case "dom_about_title": title += createConfigshtml(key, value); break;
            case "Font_AboutD_pg": case "about_news": gywm += createConfigshtml(key, value); break;
            case "newsron": newspg += createConfigshtml(key, value); break;
            case "Font_Footer_pg": yejiao += createConfigshtml(key, value); break;
        }
    });

    homeProducts += '<div id="homeProducts">  ' + (accordionStr('产品类型[1]', p1) + accordionStr('产品类型[2]', p2) + accordionStr('产品类型[3]', p3) + accordionStr('产品类型[4]', p4)) + '</div>';
    homeser += '<div id="homeser">' + (accordionStr('服务特色[1]', s1) + accordionStr('服务特色[2]', s2) + accordionStr('服务特色[3]', s3) + accordionStr('服务特色[4]', s4) + accordionStr('服务特色[5]', s5)) + '</div>';
    homeNews += ' <div id="homeNews">' + (accordionStr('右侧轮播文章[1]', hn1) + accordionStr('右侧轮播文章[2]', hn2) + accordionStr('右侧轮播文章[3]', hn3)) + '</div>';
    server += '<div id="serverNews">' + (accordionStr('下方轮播文章[1]', sn1) + accordionStr('下方轮播文章[2]', sn2) + accordionStr('下方轮播文章[3]', sn3)) + '</div>';
    host += '<div id="hostNews">' + (accordionStr('下方轮播文章[1]', on1) + accordionStr('下方轮播文章[2]', on2) + accordionStr('下方轮播文章[3]', on3)) + '</div>';

    var headerStr = '<strong>LOGO图片设置：</strong><input type="button" class="button" value="上传图片" name="btn_logo">&nbsp;&nbsp;&nbsp;（推荐图片尺寸：280x102）<br/>' +
                    '<div id="topMenu">' + accordionStr('顶部导航菜单设置', bltopurl) + accordionStr('主导航菜单设置', navInfoStr()) + '</div>';

    var htmlstr = '<div id="params">' +
                    accordionStr('网站页面标题设置', title) +
                    accordionStr('网站头部内容设置', headerStr) +
                    accordionStr('网站底部内容设置', yejiao) +
                    accordionStr('首页横幅广告设置', homebanner + '<strong>温馨提示：</strong>推荐图片尺寸：1440x300；链接地址为空则不显示该图片。<br/>') +
                    accordionStr('首页产品介绍设置', homeProducts) +
                    accordionStr('首页服务介绍设置', homeser) +
                    accordionStr('首页新闻动态设置', homeNews) +
                    accordionStr('VPS云主机页面设置', cloud) +
                    accordionStr('虚拟主机页面设置', vhost) +
                    accordionStr('服务器租用页面设置', server) +
                    accordionStr('服务器托管页面设置', host) +
                    accordionStr('域名注册页面设置', domain) +
                    accordionStr('关于我们页面设置', gywm) +
					accordionStr('新闻中心页面设置', newspg) +
                    '</div><div id="upwin" style="display:none;text-align:center"><p><input type="button"  class="button" id="btn_upload" value="重新上传图片"/></p><p style="padding-top:5px"><a href="javascript:;" target="_blank"><img src="" alt="点击查看原始图片大小！" style="max-height:200px;max-width:650px;"/></a></p></div>';
    themeConfig.html(htmlstr);
    upWin = themeConfig.find("#upwin");

    themeConfig.find("#params,#topMenu,#homeProducts,#homeser,#homeNews,#serverNews,#hostNews").accordion({ heightStyle: "content", collapsible: true, active: 999 });

    themeConfig.find('.button').click(function () {
        var cKey = $(this).attr("name");
        if (cKey != undefined) cKey = cKey.substring(4);
        else return true;
        var cClass = $(this).attr("class");
        var cValue = homeConfigs[cKey];
        switch (cValue.data) {
            case 'product':
            case 'productgroup':
                selectProducts(cKey, '选择：' + cValue.l, cValue.data, cValue.max, 0);
                break;
            case 'news':
            case 'newstype':

                if (cClass.indexOf('btn_editnews') > -1) {
                    //编辑/创建文章
                    editNews(themeConfig.find('input[name="cvalue_' + cKey + '"]').val(), 0, cValue.l, '文章内容', cKey);
                } else {
                    //选择文章或分组
                    selectNews(cKey, '选择：' + cValue.l, cValue.data, cValue.max, 0);
                }
                break;
            case 'os':
                _setOS(cKey, 0);
                break;
            case 'upImg':
                uploadImgs(cValue.ImgName, cKey);
                break;
        }
    });

   
    swin.dialog({ buttons: { "保存(Ctrl+Enter)": function () { setData(0); }, "仅保存(不关闭)": function () { setData(1); }, "关 闭": function () { $(this).dialog("close"); } } });
    themeConfig.find('input[name="addnavInfo"]').click(function () { swin.find('#navInfo').append(navInfAdd()); }).addClass('button');
    themeConfig.find('input[name="RestoreNavCode"]').click(function () { RestoreNavCode(); }).addClass('button');
    themeConfig.find("textarea").each(function (index, dom) {
        $(dom).val($(dom).next('input').val());
    })
}
loadThemeConfig();


function createConfigshtml(key, value) {
    var str = '';
    var configDataValue = configData[key] == undefined ? ((value.data.indexOf('news') > -1 || value.data.indexOf('p') > -1) ? '0' : '') : configData[key];

    str += '<strong>' + value.l + '</strong>：<input type="hidden" name="cname_' + key + '" value="' + key + '"/>';
    if (value.t == 'button') {
        var btnname = '';

        switch (value.data) {
            case 'news': btnname = '选择文章'; break;
            case 'newstype': btnname = '选择文章分组'; break;
            case 'os': btnname = '设置操作系统'; break;
            case 'upImg': btnname = "上传图片"; break;
            case "productgroup": btnname = "选择产品分组"; break;
            default: btnname = '选择产品'; break;
        }
        if (value.data == 'upImg') {
            str += '<input type="button" class="button" name="btn_' + key + '" value="' + btnname + '"/>';
        }
        else {
            str += '<input style="' + (value.width != '' ? 'width:' + value.width + ';' : '') + '" type="text" class="text" value="' + configDataValue + '" name="cvalue_' + key + '" />&nbsp;&nbsp;&nbsp;<input type="button" class="button" value="' + btnname + '" name="btn_' + key + '"/>&nbsp;&nbsp;&nbsp;';
            if (value.data == 'news') {
                if (configDataValue != '0' && configDataValue != '') str += '<input class="button btn_editnews" value="快速编辑" type="button" name="btn_' + key + '"/>';
                else str += '<input class="button btn_editnews" value="创建调用文章" type="button" name="btn_' + key + '"/>';
            }
        }
    } else if (value.t == 'select') {
        str += '<select style="' + (value.width != '' ? 'width:' + value.width + ';' : '') + '" data="' + value.data + '" name="cvalue_' + key + '" ><option value="' + configDataValue + '">Loading...</option></select> ';
    } else if (value.t == 'input') {
        var vdata = configData[key] == undefined ? (value.df == undefined ? '' : value.df) : configData[key];
        str += '<input style="' + (value.width != '' ? 'width:' + value.width + ';' : '') + '" type="text" class="text" value="' + vdata + '" name="cvalue_' + key + '" />';
    } else if (value.t == 'textarea') {
        str = value.l + '：<input type="hidden" name="cname_' + key + '" value="' + key + '"/>&nbsp;&nbsp;(字数限制：' + value.max + '个/字)<br/>';
        str += '<textarea style="resize: none;' + (value.width != '' ? 'width:' + value.width + ';' : '') + (value.height != '' ? 'height:' + value.height + ';' : '') + '" type="text" class="text"   name="cvalue_' + key + '" /></textarea> <input  type="hidden" value="' + (configData[key] == undefined ? '' : configData[key]) + '"/> <br/>';
    }
    if (value.des != '') str += ' ' + value.des;
    
    //处理换行符等
    if (value.br == undefined || value.br == 't') { str += '<br />'; } else if (value.br == '2t') { str += '<br />&nbsp;<br />'; } else if (value.br == 's') { str += '&nbsp;&nbsp;&nbsp;'; } else { str += ''; }

    return str;
}

var myUploader = initUploader(themeConfig.find("#btn_upload"), 1, false, function () {
    var imgPath = upWin.find("img").attr("src");
    if (imgPath.indexOf('?') > -1) imgPath = imgPath.substring(0, imgPath.indexOf('?'));
    imgPath += '?' + new Date();
    upWin.find("img").parent().attr("href", imgPath);
    upWin.find("img").attr("src", imgPath);
});
function uploadImgs(imgName, key) {
    var imgPath = swin.find("input[name='configvalue_path']").val() + 'images/' + imgName;
    myUploader.settings.headers.filepath = imgPath;
    imgPath += '?' + new Date();
    upWin.find("img").parent().attr("href", imgPath);
    upWin.find("img").attr("src", imgPath);
    upWin.dialog({ title: "上传图片", autoOpen: false, resizable: false, width: 700, height: 365, modal: true, buttons: { "确 定": function () { $(this).dialog("close"); } } }).dialog("open");
}

function _addOS(oid, oname) {
    suwin.find("#oslist").append('<li>系统模板ID编号：<input type="text" class="text center" name="oid" style="width:50px" value="' + oid + '"/> &nbsp;&nbsp;操作系统名称：<input type="text" class="text" name="oname" value="' + oname + '"/> &nbsp;&nbsp;<input type="button" class="button" value="删除" onclick="_delOS(this)"/></li>');
}

function _delOS(ca) {
    $(ca).parent().remove();
}

function _setOS(key, action) {
    var str = '';
    if (action == 0) {
        var cInput = swin.find("input[name='cvalue_" + key + "']");
        var cOS = cInput.val().split('|');
        str = '<strong>设置允许使用的VPS操作系统列表：</strong> <input type="button" class="button" value="添加" onclick="_addOS(\'0\',\'\')"/><br />' +
              '<span style="color:#ff4700;">相关的编号请登录您的<strong>XenSystem</strong>后台“操作系统模板设置”中获取。</span><ul id="oslist"></ul>';
        suwin.html(str);
        if (cOS[0].indexOf(',') > 0) {
            for (i = 0; i < cOS.length; i++) {
                _addOS(cOS[i].substring(0, cOS[i].indexOf(',')), cOS[i].substring(cOS[i].indexOf(',') + 1));
            }
        }
        suwin.dialog({ title: '设置允许使用的VPS操作系统列表', autoOpen: false, resizable: false, width: 750, height: 550, modal: true, buttons: { "保 存": function () { _setOS(key, 1); }, "取 消": function () { $(this).dialog("close"); } } }).dialog("open");
    } else {
        var lis = suwin.find("li");
        if (lis.length < 1) alert('请添加允许使用的VPS操作系统！');
        else {
            $(lis).each(function () {
                str += '|' + $(this).find("input[name='oid']").val() + ',' + $(this).find("input[name='oname']").val();
            });
            str = str.substring(1);
            swin.find("input[name='cvalue_" + key + "']").val(str);
            suwin.dialog("close");
        }
    }
}



//======================主菜单导航栏==========================
function navInfoStr() {
    var navCode = typeof (configData.navInfo_Code) == 'undefined' ? '' : configData.navInfo_Code;
    var str = '<input type="hidden" name="cname_navInfo_Code" value="navInfo_Code"><input style="width:200px;" type="hidden" class="text" value="' + navCode + '" name="cvalue_navInfo_Code"><input type="button" name="addnavInfo"  value="添加菜单"/><input type="button"  style="margin-left:15px; "  name="RestoreNavCode"  value="恢复初始设置"/></br>' +
              '<ul id="navInfo" style="line-height:35px;">';
    if (navCode == '') {
        navCode = RestoreNavCode('list');
    } else {
        navCode = new Array();
        suwin.html(htmlDecode(configData['navInfo_Code']));
        $.each(suwin.find('a'), function (key, val) {
            navCode[navCode.length] = { 'name': $(val).html(), 'title': $(val).attr('title'), 'val': $(val).attr('href') }
        });
    }
    $.each(navCode, function (key, value) {
        str += navInfAdd(value.name, value.title, value.val);
    });
    str += '</ul>';
    return str;
}

function RestoreNavCode(cmd) {
    if (cmd != 'list') {
        if (!confirm("确认要将导航菜单回复初始设置吗？")) {
            return;
        }
    }
    var navCode = [
                        { 'name': '网站首页', 'val': 'index.html' },
                        { 'name': 'VPS云主机', 'val': 'cloud.html' },
                        { 'name': '虚拟主机',  'val': 'vhost.html' },
                        { 'name': '域名注册', 'val': 'domain.html' },
                        { 'name': '服务器租用',  'val': 'server.html' },
                        { 'name': '服务器托管',  'val': 'colo.html' },
                        { 'name': '关于我们',  'val': 'about.html' },
                        { 'name': '管理中心', 'val': 'process.aspx?c=go' }
    ];
    if (cmd == 'list') { return navCode; }
    swin.find('#navInfo').html('');
    $.each(navCode, function (key, value) {
        swin.find('#navInfo').append(navInfAdd(value.name, value.title, value.val));
    });
}
function navInfAdd(name, title, val) {
    val = typeof (val) == 'undefined' ? '' : val;
    name = typeof (name) == 'undefined' ? '' : name;
    title = typeof (title) == 'undefined' ? '' : title;
    return '<li><strong>菜单名称：</strong><input name="navName" style="width: 130px;" class="text"  value="' + name + '"/> &nbsp;&nbsp;&nbsp;<strong>链接地址：</strong><input name="navUrl" class="text"  value="' + val + '"/>&nbsp;&nbsp;&nbsp;<a href="javascript:;" onclick="delField(this);">[删除]</a> &nbsp;<a href="javascript:;" onclick="fieldUp(this);">[上移]</a> &nbsp;<a href="javascript:;" onclick="fieldDown(this);">[下移]</a>';
}

function savenavInf() {
    var navStr = '<ul class="nav floatRight">';
    themeConfig.find('#navInfo li').each(function (key, dom) {
        var navName = $(dom).find('input[name="navName"]')
        var navUrl = $(dom).find('input[name="navUrl"]')
        if (typeof (navName) != 'undefined' && typeof (navUrl) != 'undefined') {
            if (navName.val().replace(/ /g, '') != '' && navUrl.val().replace(/ /g, '') != '') {
                var url = navUrl.val().replace(/ /g, '');
                navStr += '<li><a href="' + url + '" >' + navName.val() + '</a></li>'
            }
        }
    });
    navStr += '</ul>';

    swin.find('input[name="cvalue_navInfo_Code"]').val(navStr);
}
//

//========================常用方法========================

function accordionStr(title, text) {
    var strhtml = '<h3><span></span><strong>' + (typeof (title) == 'undefined' ? '' : title) + '</strong></h3> <div style="line-height:30px">' + (typeof (text) == 'undefined' ? '' : text) + '</div>';
    return strhtml;
}

//最后调用保存方法
function setData(action) {

    savenavInf();
    //最后调用保存方法
    save(action);
}

function delField(ca) {
    $(ca).parent().remove();
}
function fieldUp(ca) {
    $($(ca).parent().prev()).before($(ca).parent());
}
function fieldDown(ca) {
    $($(ca).parent().next()).after($(ca).parent());
}