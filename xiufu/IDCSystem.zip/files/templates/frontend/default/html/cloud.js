﻿//<!--idcsystem_template type="file" name="config.html"-->{$file_content}<!--/idcsystem_template-->

//<!--no-cache-->
var element = $("#element");
var cPG = rGet(curl, 'pg');
if (cPG == '') cPG = '{$define_cdpg_value}';
if (cPG == '";') cPG = '';
$("#pg_" + cPG).addClass("on");
var cTitle = $("#pg_" + cPG).text();
document.title = cTitle + ' - ' + document.title;
element.find('#vpsTi').html(cTitle);


var pList = element.find("#pList");
var cloudData;
var plist = '';
$.getJSON("process.aspx?c=jsapi&action=product&groupid=" + cPG + "&" + new Date(), function (rdata) {
    if (rdata == null) return false;
    cloudData = rdata;
    plist = '<li class="proTi">配置：</li>';
    $(rdata).each(function (i) {
        plist += '<li id="p_' + i + '"><a href="javascript:customCloud(' + i + ');" title="' + rdata[i].pname + '">' + rdata[i].pname + '</a></li>';
    });
    pList.find("li").remove();
    pList.append(plist);
    customCloud(0);
}, "json");

function changeOS(os) {
    element.find(".osMenu a").removeClass("oson");
    element.find(".osMenu ." + os).addClass("oson");
    element.find(".osConfi div").css("display", "none");
    element.find(".osConfi #" + os + "_os").css("display", "");
    element.find(".osConfi #" + os + "_os input:first").attr("checked", "checked");
}

var cData;

function customCloud(num) {
    cData = cloudData[num];
    showCloudInfo(cData);
    pList.find("li").removeClass("on");
    pList.find("#p_" + num).addClass("on");
    var osMenu = element.find("div[class='osMenu']").children();
    var isolist = new Array();
    isolist[isolist.length] = '{$define_cosw_value}'.split('|');
    isolist[isolist.length] = '{$define_cosl_value}'.split('|');
    for (var i = 0; i < osMenu.length; i++) {
        $(osMenu[i]).click(function () {
            element.find("div[class='osMenu']").children().removeClass('on');
            $(this).addClass('on');

            element.find("div[class='osConfi']").children().remove();
            var os = isolist[$(element.find("div[class='osMenu']").children()).index(this)];

            for (var j = 0; j < os.length; j++) {
                if (os[j].length > 0) {
                    var iso = os[j].split(',');
                    element.find("div[class='osConfi']").append('<p val="' + iso[0] + '"  style="cursor:pointer">' + iso[1] + '</p>');
                }
            }
            element.find("div[class='osConfi']").children().click(function () {
                element.find("div[class='osConfi']").children().removeClass('on');
                $(this).addClass('on');
            });
            element.find("div[class='osConfi']").children().first().click();
        });
    }
    element.find("div[class='osMenu']").children().first().click();



    var ipMin = cData.pconfig.ipc == undefined ? 1 : parseInt(cData.pconfig.ipc);
    var ipMax = cData.pupgrade.ip_max == undefined ? 1 : parseInt(cData.pupgrade.ip_max);
    if (ipMax < ipMin) ipMax = ipMin;
    var snapshotMin = cData.pconfig.snapshot == undefined ? 0 : parseInt(cData.pconfig.snapshot);
    var snapshotMax = cData.pupgrade.snapshot_max == undefined ? 0 : parseInt(cData.pupgrade.snapshot_max);
    if (snapshotMax < snapshotMin) snapshotMax = snapshotMin;
    var fullBackupMin = cData.pconfig.full_backup == undefined ? 0 : parseInt(cData.pconfig.full_backup);
    var fullBackupMax = cData.pupgrade.full_backup_max == undefined ? 0 : parseInt(cData.pupgrade.full_backup_max);
    if (fullBackupMax < fullBackupMin) fullBackupMax = fullBackupMin;

    var timeCycle = cData.psconfig.time_cycle == undefined ? '0' : cData.psconfig.time_cycle;
   
    $('#snapshot').children().remove();
    for (i = snapshotMin; i <= snapshotMax; i++) $('#snapshot').append('<option value="' + i.toString() + '">' + i.toString() + '个快照备份 &nbsp;&nbsp;' + (i > snapshotMin ? ((i - snapshotMin) * cData.pupgrade.snapshot_price) + '元/' + getTimeCycleSuffix(cData.pprice.cycle.split(',')[0], timeCycle, 0) + '' : '') + '</option>');

    $('#full_backup').children().remove();
    for (i = fullBackupMin; i <= fullBackupMax; i++) $('#full_backup').append('<option value="' + i.toString() + '">' + i.toString() + '个完整备份 &nbsp;&nbsp;' + (i > fullBackupMin ? ((i - fullBackupMin) * cData.pupgrade.full_backup_price) + '元/' + getTimeCycleSuffix(cData.pprice.cycle.split(',')[0], timeCycle, 0) + '' : '') + '</option>');



    var mincpu = parseFloat(cData.pconfig.cpu);
    var maxcpu = parseFloat(cData.pupgrade.cpu_max);
    var cpu_step = parseFloat(cData.pupgrade.cpu_step);
    var cpu_price = parseFloat(cData.pupgrade.cpu_price);

    var minram = parseFloat(typeof (cData.pconfig.ram) == 'undefined' ? cData.pconfig.ram_max : cData.pconfig.ram);
    var maxram = parseFloat(cData.pupgrade.ram_max);
    var ram_step = parseFloat(cData.pupgrade.ram_step);
    var ram_price = parseFloat(cData.pupgrade.ram_price);

    var mindisk = parseFloat(cData.pconfig.disk);
    var maxdisk = parseFloat(cData.pupgrade.disk_max);
    var disk_step = parseFloat(cData.pupgrade.disk_step);
    var disk_price = parseFloat(cData.pupgrade.disk_price);


    var minbw = parseFloat(cData.pconfig.bw);
    var maxbw = parseFloat(cData.pupgrade.bw_max);
    var bw_step = parseFloat(cData.pupgrade.bw_step);
    var bw_price = parseFloat(cData.pupgrade.bw_price);
    if (cData.pconfig.bw == '0') {
        minbw = 0;
        maxbw = 0;
    }
    var minport = parseFloat(cData.pconfig.port);
    var maxport = parseFloat(cData.pupgrade.port_max);

    if (cData.pconfig.port == '0' || cData.pconfig.port == cData.pupgrade.port_max) {
        minport = 0;
        maxport = 0;
    }

    var port_step = parseFloat(cData.pupgrade.port_step);
    var port_price = parseFloat(cData.pupgrade.port_price);

    element.find("#cpuText span:eq(1)").text(maxcpu + "核");
    element.find("#ramText span:eq(1)").text(maxram + "MB");
    element.find("#diskText span:eq(1)").text(maxdisk + "GB");
    element.find("#portText span:eq(1)").text((maxport == 0 ? "不限端口" : maxport + "MB"));
    element.find("#bwText span:eq(1)").text((maxbw == 0 ? "不限流量" : maxbw + "GB"));

    cloudSlider(mincpu, maxcpu, cpu_step, cpu_price, minram, maxram, ram_step, ram_price, mindisk, maxdisk, disk_step, disk_price, minbw, maxbw, bw_step, bw_price, minport, maxport, port_step, port_price);
    updatePrice(mincpu, cpu_price, cpu_step, minram, ram_price, ram_step, mindisk, disk_price, disk_step, minbw, bw_price, bw_step, minport, port_price, port_step);
    element.find("select").change(function () {
        updatePrice(mincpu, cpu_price, cpu_step, minram, ram_price, ram_step, mindisk, disk_price, disk_step, minbw, bw_price, bw_step, minport, port_price, port_step);
    });
}

var vport = element.find("#vport");
var vbw = element.find("#vbw");

var sl_port = element.find("#sl_port");
var sl_bw = element.find("#sl_bw");

function cloudSlider(mincpu, maxcpu, cpu_step, cpu_price, minram, maxram, ram_step, ram_price, mindisk, maxdisk, disk_step, disk_price, minbw, maxbw, bw_step, bw_price, minport, maxport, port_step, port_price) {

    element.find("#vcpu").children().remove();
    var ccpu = '{$define_ccpu_value}';
    if (ccpu != '' && ccpu != '";') {
        var strs = new Array();
        var strs = ccpu.split(',');
        if (strs.length > 0) {
            for (var i = 0; i < strs.length; i++) {
                if (strs[i] != '' && strs[i] >= mincpu && strs[i] <= maxcpu) {
                    element.find("#vcpu").append('<span style="cursor:pointer">' + strs[i] + '核</span>')
                }
            }
        } else {
            for (var i = mincpu; i <= maxcpu; i++) {
                element.find("#vcpu").append('<span style="cursor:pointer">' + i + '核</span>')
            }
        }

    } else {
        for (var i = mincpu; i <= maxcpu; i++) {
            element.find("#vcpu").append('<span style="cursor:pointer">' + i + '核</span>')
        }
    }
    element.find("#vcpu").children().click(function () {
        element.find("#vcpu").children().removeClass('on');
        $(this).addClass('on');
        element.find(".cmArea span[name='cpu']").html($(this).html());
        updatePrice(mincpu, cpu_price, cpu_step, minram, ram_price, ram_step, mindisk, disk_price, disk_step, minbw, bw_price, bw_step, minport, port_price, port_step);
    });
    element.find("#vcpu").children().eq(0).click();



    element.find("#vram").children().remove();
    var cnram = '{$define_cnram_value}'

    var strcnram = new Array();
    var strcnram = cnram.split(',');
    if (maxram <= minram) {
        if (minram % 1024 == 0) {
            element.find("#vram").append('<span style="cursor:pointer">' + (minram / 1024) + 'GB</span>');
        } else {
            element.find("#vram").append('<span style="cursor:pointer">' + minram + 'MB</span>');
        }
    }
    else if (cnram != '' && cnram != '";' && strcnram.length > 0) {
        for (var j = 0; j < strcnram.length; j++) {

            if (strcnram[j] != '' && strcnram[j] >= minram && strcnram[j] <= maxram) {
                if ((strcnram[j] % 1024) == 0) {
                    element.find("#vram").append('<span style="cursor:pointer">' + (strcnram[j] / 1024) + 'GB</span>')
                } else {
                    element.find("#vram").append('<span style="cursor:pointer">' + strcnram[j] + 'MB</span>')
                }
            }
        }
    } else {
        for (var i = 1; i <= (maxram / minram); i++) {
            if (((i * minram) % 1024) == 0) {
                element.find("#vram").append('<span style="cursor:pointer">' + ((i * minram) / 1024) + 'GB</span>')
            } else {
                if (i > 2) {
                    if ((i % 2) == 0) {
                        element.find("#vram").append('<span style="cursor:pointer">' + (i * minram) + 'MB</span>')
                    }
                } else {
                    element.find("#vram").append('<span style="cursor:pointer">' + (i * minram) + 'MB</span>')
                }
            }
        }
    }
    element.find("#vram").children().click(function () {

        element.find("#vram").children().removeClass('on');
        $(this).addClass('on');
        element.find(".cmArea span[name='ram']").html($(this).html());
        updatePrice(mincpu, cpu_price, cpu_step, minram, ram_price, ram_step, mindisk, disk_price, disk_step, minbw, bw_price, bw_step, minport, port_price, port_step);

    });
    element.find("#vram").children().eq(0).click();


    element.find("#vdisk").children().remove();


    var cvdisk = '{$define_cvdisk_value}'

    var cvdisklist = new Array();
    var cvdisklist = cvdisk.split(',');


    if (maxdisk <= mindisk) {
        element.find("#vdisk").append('<span style="cursor:pointer">' + mindisk + 'GB</span>');
    }
    else if (cvdisk != '' && cvdisk != '";' && cvdisklist.length > 0) {
        for (var v = 0; v < cvdisklist.length; v++) {

            if (cvdisklist[v] != '' && cvdisklist[v] >= mindisk && cvdisklist[v] <= maxdisk) {
                element.find("#vdisk").append('<span style="cursor:pointer">' + cvdisklist[v] + 'GB</span>')
            }
        }
    } else {

        for (var i = mindisk; i <= maxdisk; i++) {
            if (((i - mindisk) % 10) == 0) {
                element.find("#vdisk").append('<span style="cursor:pointer">' + i + 'GB</span>')
            }
        }
    }
    element.find("#vdisk").children().click(function () {
        element.find("#vdisk").children().removeClass('on');
        $(this).addClass('on');
        element.find(".cmArea span[name='disk']").html($(this).html());
        updatePrice(mincpu, cpu_price, cpu_step, minram, ram_price, ram_step, mindisk, disk_price, disk_step, minbw, bw_price, bw_step, minport, port_price, port_step);
    });
    element.find("#vdisk").children().eq(0).click();


    element.find("#vip").children().remove();

    var cloudvip = '{$define_cloudip_value}'

    var cloudiplist = new Array();
    var cloudiplist = cloudvip.split(',');

    if (cloudvip != '' && cloudvip != '";' && cloudiplist.length > 0) {

        for (var v = 0; v < cloudiplist.length; v++) {

            if (cloudiplist[v] != '' && parseInt(cloudiplist[v]) >= parseInt(cData.pconfig.ipc) && parseInt(cloudiplist[v]) <= parseInt(cData.pupgrade.ip_max)) {
                element.find("#vip").append('<span style="cursor:pointer">' + cloudiplist[v] + '个</span>');
            }
        }
    } else {
        for (var i = cData.pconfig.ipc; i <= cData.pupgrade.ip_max; i++) {
            element.find("#vip").append('<span style="cursor:pointer">' + i + '个</span>');
        }
    }
    element.find("#vip").children().click(function () {
        element.find("#vip").children().removeClass('on');
        $(this).addClass('on');
        element.find(".cmArea span[name='ipc']").html($(this).html() + ' IP地址');
        updatePrice(mincpu, cpu_price, cpu_step, minram, ram_price, ram_step, mindisk, disk_price, disk_step, minbw, bw_price, bw_step, minport, port_price, port_step);

    });
    element.find("#vip").children().eq(0).click();


    var minPortVal = 0;
    if (maxport == 0) {
        minPortVal = -1;
        vport.css("display", "none");
    } else vport.css("display", "");

    sl_port.slider({
        range: "min",
        value: minport,
        min: minPortVal,
        max: maxport,
        step: port_step,
        slide: function (event, ui) {
            vport.val(ui.value);
            updatePrice(mincpu, cpu_price, cpu_step, minram, ram_price, ram_step, mindisk, disk_price, disk_step, minbw, bw_price, bw_step, minport, port_price, port_step);
        },
        stop: function (event, ui) {
            if (parseInt(ui.value) <= minport) {
                sl_port.slider("value", minport);
                vport.val(minport);
                sl_port.attr("title", minport + "MB");
                if (maxport == 0) element.find(".cmArea span[name='port']").html('不限端口');
                else element.find(".cmArea span[name='port']").html(minport + ' MB');
            } else {
                if (maxport == 0) sl_port.attr("title", "不限端口");
                else sl_port.attr("title", ui.value + "MB");

                element.find(".cmArea span[name='port']").html(maxport == 0 ? "不限端口" : ui.value + ' MB');
            }

            updatePrice(mincpu, cpu_price, cpu_step, minram, ram_price, ram_step, mindisk, disk_price, disk_step, minbw, bw_price, bw_step, minport, port_price, port_step);
            sl_port.find('span').attr('style', sl_port.find('a').last().attr('style')).html(maxport == 0 ? "不限端口" : sl_port.attr("title"));
        }
    });
    vport.val(minport);
    sl_port.slider("value", minport);
    if (maxport == 0) sl_port.attr("title", "不限端口");
    else sl_port.attr("title", minport + "MB");
    sl_port.find('span').attr('style', sl_port.find('a').last().attr('style')).html(maxport == 0 ? "不限端口" : sl_port.attr("title"));
    $('#portText>p[class="valueMax"]').html(maxport + 'MB');
    $('#portText>p[class="valueMin"]').html(maxport / 2 + 'MB')



    var minVal = 0;
    if (maxbw == 0) {
        minVal = -1;

    } else vbw.css("display", "");
    sl_bw.slider({
        range: "min",
        value: minbw,
        min: minVal,
        max: maxbw,
        step: bw_step,
        slide: function (event, ui) {
            vbw.val(ui.value);
            updatePrice(mincpu, cpu_price, cpu_step, minram, ram_price, ram_step, mindisk, disk_price, disk_step, minbw, bw_price, bw_step, minport, port_price, port_step);
        },
        stop: function (event, ui) {
            if (parseInt(ui.value) < minbw) {
                sl_bw.slider("value", minbw);
                vbw.val(minbw);
                sl_bw.attr("title", minbw + "GB");
                if (maxbw == 0) element.find(".cmArea span[name='bw']").html('不限流量');
                else element.find(".cmArea span[name='bw']").html(minbw + ' GB');
            } else {
                if (maxbw == 0) sl_bw.attr("title", "不限流量");
                else sl_bw.attr("title", ui.value + "GB");
                element.find(".cmArea span[name='bw']").html(maxbw == 0 ? "不限流量" : ui.value + ' GB');
            }
            updatePrice(mincpu, cpu_price, cpu_step, minram, ram_price, ram_step, mindisk, disk_price, disk_step, minbw, bw_price, bw_step, minport, port_price, port_step);
            sl_bw.find('span').attr('style', sl_bw.find('a').last().attr('style')).html(maxbw == 0 ? "不限流量" : sl_bw.attr("title"));
        }
    });
    vbw.val(minbw);
    sl_bw.slider("value", minbw);
    if (maxbw == 0) sl_bw.attr("title", "不限流量");
    else sl_bw.attr("title", minbw + "GB");

    $('#bwText>p[class="valueMax"]').html(maxbw + 'GB');
    $('#bwText>p[class="valueMin"]').html(maxbw / 2 + 'GB')
    sl_bw.find('span').attr('style', sl_bw.find('a').last().attr('style')).html(maxbw == 0 ? "不限流量" : sl_bw.attr("title"));
}

function updatePrice(mincpu, cpu_price, cpu_step, minram, ram_price, ram_step, mindisk, disk_price, disk_step, minbw, bw_price, bw_step, minport, port_price, port_step) {

    var vramVal; if ($('#vram>span[class="on"]').html() != undefined && $('#vram>span[class="on"]').html().indexOf('MB') > 0) { vramVal = parseInt($('#vram>span[class="on"]').html().replace(/MB/g, '')) } else { vramVal = (parseInt($('#vram>span[class="on"]').html().replace(/GB/g, '')) * 1024) };

    var addPrice = (parseFloat($('#vcpu>span[class="on"]').html().replace(/核/g, '')) - mincpu) * cpu_price / cpu_step;
    addPrice += (parseFloat(vramVal) - minram) / ram_step * ram_price;

    addPrice += (parseFloat($('#vdisk>span[class="on"]').html().replace(/GB/g, '')) - mindisk) * disk_price / disk_step;

    if (minbw > 0) addPrice += (parseFloat(vbw.val()) - minbw) * bw_price / bw_step;
    if (minport > 0) addPrice += (parseFloat(vport.val()) - minport) * port_price / port_step;

    var ipMin = cData.pconfig.ipc == undefined ? 1 : parseInt(cData.pconfig.ipc);
    var snapshotMin = cData.pconfig.snapshot == undefined ? 0 : parseInt(cData.pconfig.snapshot);
    var fullBackupMin = cData.pconfig.full_backup == undefined ? 0 : parseInt(cData.pconfig.full_backup);
    var addIPC = $('#vip>span[class="on"]').html().replace(/个/g, '') == undefined ? ipMin : parseInt($('#vip>span[class="on"]').html().replace(/个/g, ''));
    var addSnapshot = element.find("#snapshot").val() == undefined ? snapshotMin : parseInt(element.find("#snapshot").val());
    var addFullBackup = element.find("#full_backup").val() == undefined ? fullBackupMin : parseInt(element.find("#full_backup").val());
    addIPC = addIPC - ipMin;
    addSnapshot = addSnapshot - snapshotMin;
    addFullBackup = addFullBackup - fullBackupMin;

    if (addIPC > 0) addPrice += addIPC * parseFloat(cData.pupgrade.ip);
    if (addSnapshot > 0) addPrice += addSnapshot * parseFloat(cData.pupgrade.snapshot_price);
    if (addFullBackup > 0) addPrice += addFullBackup * parseFloat(cData.pupgrade.full_backup_price);

    var timeCycle = cData.psconfig.time_cycle == undefined ? '0' : cData.psconfig.time_cycle;
    var priceList = '<span>费用：</span>';
    var pps = cData.pprice.cprice.split(',');
    var pcs = cData.pprice.cycle.split(',');
    var p;
    for (p = 0; p < pps.length; p++) {
        if (pps[p] != '0') {
            priceList += '<label><input name="cycle" type="radio" value="' + pcs[p] + '" /><span>' + (parseFloat(pps[p]) + (addPrice * parseInt(pcs[p]))).toFixed(2) + '</span>元/';
            priceList +=getTimeCycleSuffix(pcs[p], timeCycle, 0);
            priceList += '</label>';
        }
    }

    element.find(".price").html(priceList);
    $(".cmArea li:last span>span").html((parseFloat(pps[0]) + (addPrice * parseInt(pcs[0]))).toFixed(2));
    element.find(".price input:radio:first").attr("checked", "checked");
    element.find(".price label").click(function () {
        element.find(".cmArea li:last").html('<strong>价格：</strong><span>' + $(this).text() + '</span>')
    })

}

function showCloudInfo(info) {
     var thePrice = getPrice(info.pprice, info.psconfig, -1);
    if (thePrice.indexOf('<span>') > -1) thePrice += '起';
    else thePrice = htmlDecode(thePrice);
    
    var timeCycle = info.psconfig.time_cycle == undefined ? '0' : info.psconfig.time_cycle;
    thePrice = thePrice.replace("月", getTimeCycleSuffix(info.pprice.cycle.split(',')[0], timeCycle, 0));

    element.find(".cmArea li").remove();
    var str = '<li><strong>CPU：</strong><span name="cpu">' + info.pconfig['cpu'] + '核 </span></li>' +
              '<li><strong>内存：</strong><span name="ram"> ' + parseFloat(typeof (info.pconfig['ram']) == 'undefined' ? info.pconfig['ram_max'] : info.pconfig['ram']) + 'MB </span></li>' +
              '<li><strong>硬盘：</strong><span name="disk"> ' + info.pconfig['disk'] + 'GB  </span></li>' +
              '<li><strong>端口：</strong><span name="port">' + (info.pconfig['port'] == '0' || cData.pconfig.port == cData.pupgrade.port_max ? '不限端口' : '' + info.pconfig['port'] + ' MB') + '</span></li>' +
              '<li><strong>流量：</strong><span name="bw"> ' + (info.pconfig['bw'] == '0' ? '不限流量' : '' + info.pconfig['bw'] + ' GB ') + '</span></li>' +
              '<li><strong>ＩＰ：</strong><span name="ipc"> ' + info.pconfig['ipc'] + '个IP地址</span></li>' +
			  '<li><strong>价格：</strong><span> ' + thePrice + '</span></li>';
    element.find(".cmArea").append(str);
    element.find(".vpsbuy").html('&nbsp;&nbsp;<input onclick="cloudOrder(0);" type="button" value="立即购买" class="paramBuy" />');
}

function cloudOrder(action) {
    if (action == 0) {
        if (userID == '') userLogin(0, 'cmd:cloudOrder(1);');
        else cloudOrder(1);
    }
    else if (action == 1) {
        var cPrice = element.find(".price input:radio:checked").parent();
        var billingCycle = cPrice.find("input:radio:checked").val();
        var amount = parseFloat(cPrice.find("span").text());
        var ipMin = cData.pconfig.ipc == undefined ? 1 : parseInt(cData.pconfig.ipc);
        var snapshotMin = cData.pconfig.snapshot == undefined ? 0 : parseInt(cData.pconfig.snapshot);
        var fullBackupMin = cData.pconfig.full_backup == undefined ? 0 : parseInt(cData.pconfig.full_backup);
        var ipcount = $('#vip>span[class="on"]').html().replace(/个/g, '') == undefined ? ipMin : parseInt($('#vip>span[class="on"]').html().replace(/个/g, ''));
        var snapshot = element.find("#snapshot").val() == undefined ? snapshotMin : parseInt(element.find("#snapshot").val());
        var full_backup = element.find("#full_backup").val() == undefined ? fullBackupMin : parseInt(element.find("#full_backup").val());

        var vramVal; if ($('#vram>span[class="on"]').html().indexOf('MB') > 0) {
            vramVal = parseInt($('#vram>span[class="on"]').html().replace(/MB/g, ''))
        } else {
            var vramMax = (typeof (cData.pconfig.ram) == 'undefined' ? cData.pconfig.ram_max : cData.pconfig.ram);
            vramVal = ((parseInt($('#vram>span[class="on"]').html().replace(/GB/g, '')) * 1024) / vramMax) * vramMax

        };
        var str = '<form id="OrderConfig"><div style="line-height:30px"><strong>您选择的VPS云主机配置：</strong><br />' +
                  '<strong>CPU核数：</strong>' + parseFloat($('#vcpu>span[class="on"]').html().replace(/核/g, '')) + ' 核<br />' +
                  '<strong>内存大小：</strong>' + $('#vram>span[class="on"]').html() + ' <br />' +
                  '<strong>存储容量：</strong>' + $('#vdisk>span[class="on"]').html().replace(/GB/g, '') + ' GB<br />' +
                  '<strong>端口速度：</strong>' + ((vport.val() == '0') ? '不限流量' : vport.val() + ' MB') + '<br />' +
                  '<strong>流量带宽：</strong>' + (vbw.val() == '0' ? '不限流量' : vbw.val() + ' GB') + '<br />' +
                  '<strong>ＩＰ地址：</strong>' + ipcount + ' 个<br />' +
                  (snapshot > 0 ? '<strong>快照备份：</strong>' + snapshot + ' 个<br />' : '') +
                  (full_backup > 0 ? '<strong>完整备份：</strong>' + full_backup + ' 个<br />' : '') +
                  '<strong>最终价格：</strong><strong style="color:#FF4B00">' + cPrice.text() + '</strong><br />' +
                  '&nbsp;<br />' +
                  '</div><input type="hidden" name="vos" value="' + $('div[class="osConfi"] p[class="on"]').attr('val') + '"/>' +
                  '<input type="hidden" name="vcpu" value="' + parseFloat($('#vcpu>span[class="on"]').html().replace(/核/g, '')) + '"/>' +
                  '<input type="hidden" name="vram" value="' + vramVal + '"/>' +
                  '<input type="hidden" name="vdisk" value="' + ($('#vdisk>span[class="on"]').html().replace(/GB/g, '').replace(/ /g, '')) + '"/>' +
                  '<input type="hidden" name="vbw" value="' + vbw.val() + '"/>' +
                  '<input type="hidden" name="vport" value="' + (vport.val() == "0" ? -1 : vport.val()) + '"/>' +
                  '<input type="hidden" name="ipcount" value="' + ipcount + '"/>' +
                  '<input type="hidden" name="snapshot" value="' + snapshot + '"/>' +
                  '<input type="hidden" name="full_backup" value="' + full_backup + '"/>' +
                  '</form>';

        swin.html(str);
        swin.dialog({ title: "购买确认", autoOpen: false, resizable: false, width: 388, modal: true, buttons: { "确定购买": function () { checkout(cData.pid, billingCycle); }, "关 闭": function () { $(this).dialog("close"); }, "在线充值": function () { payOnline(0, amount); } } }).dialog("open");
    }
}
