"use strict";

item_f.itemServer.addRoute("Fold", status_f.foldItem);
item_f.itemServer.addRoute("Toggle", status_f.toggleItem);
item_f.itemServer.addRoute("Tag", status_f.tagItem);
item_f.itemServer.addRoute("Bind", status_f.bindItem);
item_f.itemServer.addRoute("Examine", status_f.examineItem);
item_f.itemServer.addRoute("ReadEncyclopedia", status_f.readEncyclopedia);