"use strict";

item_f.itemServer.addRoute("TradingConfirm", trade_f.confirmTrading);
item_f.itemServer.addRoute("RagFairBuyOffer", trade_f.confirmRagfairTrading);