"use strict";

item_f.itemServer.addRoute("AddToWishList", wishList_f.addToWishList);
item_f.itemServer.addRoute("RemoveFromWishList", wishList_f.removeFromWishList);