﻿"use strict";

class LocaleServer {
    constructor() {
        this.languages = {};
        this.locales = {};
    }

    initialize() {
        this.languages = json.parse(json.read(db.user.cache.languages));

        for (let lang in db.locales) {
            this.locales[lang] = {
                "menu": json.parse(json.read(db.locales[lang.toLowerCase()].menu)),
                "global": json.parse(json.read(db.user.cache["locale_" + lang.toLowerCase()]))
            };
        }
    }

    getLanguages() {
        return json.stringify(this.languages);
    }
    
    getMenu(lang = "en") {
        return json.stringify(this.locales[lang].menu);
    }
    
    getGlobal(lang = "en") {
        return json.stringify(this.locales[lang].global);
    }
}

module.exports.localeServer = new LocaleServer();