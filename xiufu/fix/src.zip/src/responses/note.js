"use strict";

item_f.itemServer.addRoute("AddNote", note_f.addNote);
item_f.itemServer.addRoute("EditNote", note_f.editNode);
item_f.itemServer.addRoute("DeleteNote", note_f.deleteNote);