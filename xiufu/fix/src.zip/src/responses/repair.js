"use strict";

item_f.itemServer.addRoute("Repair", repair_f.main);
